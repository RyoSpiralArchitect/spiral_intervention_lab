from __future__ import annotations

import json
from collections.abc import Sequence as SequenceABC
from dataclasses import asdict, is_dataclass
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence

from .compiler import StepContext, compile_command
from .edit_budget import (
    LOOP_RESCUE_EDIT_BUDGET_POOL,
    MAIN_EDIT_BUDGET_POOL,
    PRODUCTION_TRIAL_EDIT_BUDGET_POOL,
    PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL,
)
from .policy import PolicyViolation, budget_violation_reason, command_budget_usage
from . import candidate_handoff, operation_cards, prefix_control


class TaskEnv(Protocol):
    def reset(self, seed: int) -> str:
        ...

    def score(self, output: str) -> float:
        ...

    def done(self, output: str) -> bool:
        ...


class ControllerClient(Protocol):
    def invoke(self, packet: dict[str, Any]) -> dict[str, Any]:
        ...


class WorkerRuntime(Protocol):
    def reset(self, prompt: str) -> None:
        ...

    def step(self) -> None:
        ...

    def done(self) -> bool:
        ...

    def build_controller_packet(self) -> dict[str, Any]:
        ...

    def observe_recent_effects(self) -> None:
        ...

    def tick_ttl(self) -> None:
        ...

    def cleanup_expired(self) -> None:
        ...

    def final_text(self) -> str:
        ...


class StructuredLogger(Protocol):
    def log(self, event: dict[str, Any]) -> None:
        ...


@dataclass
class InMemoryStructuredLogger:
    events: list[dict[str, Any]] = field(default_factory=list)

    def log(self, event: dict[str, Any]) -> None:
        self.events.append(_coerce_jsonable(dict(event)))


@dataclass
class JSONLStructuredLogger:
    path: Path

    def log(self, event: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(_coerce_jsonable(event), ensure_ascii=False, sort_keys=True))
            handle.write("\n")


@dataclass
class EpisodeResult:
    prompt: str
    output: str
    score: float
    steps: int


def _coerce_jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return _coerce_jsonable(asdict(value))
    if isinstance(value, Mapping):
        return {str(key): _coerce_jsonable(item) for key, item in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_coerce_jsonable(item) for item in value]
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    try:
        return {str(key): _coerce_jsonable(item) for key, item in vars(value).items()}
    except Exception:
        pass
    return value


def _latest_controller_trace(controller_client: Any) -> Mapping[str, Any] | None:
    getter = getattr(controller_client, "latest_trace", None)
    if not callable(getter):
        return None
    trace = getter()
    if not isinstance(trace, Mapping):
        return None
    return trace


def _log_controller_trace(
    logger: StructuredLogger | None,
    *,
    step: int,
    trace: Mapping[str, Any] | None,
) -> None:
    if logger is None or trace is None:
        return

    telemetry_keys = (
        "provider",
        "model",
        "packet_view",
        "action_view",
        "raw_payload_char_count",
        "provider_payload_char_count",
        "payload_reduction_ratio",
        "system_prompt_char_count",
        "rough_input_token_estimate",
        "effective_max_output_tokens",
        "success",
        "attempt_count",
        "error",
    )
    telemetry = {key: trace.get(key) for key in telemetry_keys if trace.get(key) is not None}
    if telemetry:
        logger.log({"event": "controller_prompt_telemetry", "step": step, **telemetry})
    if isinstance(trace.get("operation_menu"), Mapping):
        logger.log({"event": "controller_operation_menu", "step": step,
                    **dict(trace["operation_menu"])})

    observation = trace.get("observation")
    if isinstance(observation, Mapping):
        logger.log({"event": "controller_observation", "step": step, **dict(observation)})

    for attempt in trace.get("attempts", []) if isinstance(trace.get("attempts"), Sequence) else []:
        if isinstance(attempt, Mapping):
            logger.log({"event": "controller_provider_attempt", "step": step, **dict(attempt)})

    decision = trace.get("decision")
    if isinstance(decision, Mapping):
        logger.log({"event": "controller_decision", "step": step, **dict(decision)})


def _latest_effect_trace(worker_runtime: Any) -> Mapping[str, Any] | None:
    getter = getattr(worker_runtime, "latest_effect_trace", None)
    if not callable(getter):
        return None
    trace = getter()
    if not isinstance(trace, Mapping):
        return None
    return trace


def _log_effect_trace(
    logger: StructuredLogger | None,
    *,
    step: int,
    worker_runtime: Any,
) -> None:
    if logger is None:
        return
    trace = _latest_effect_trace(worker_runtime)
    if trace is None:
        return

    completed = trace.get("completed_effects")
    if isinstance(completed, Sequence):
        for effect in completed:
            if isinstance(effect, Mapping):
                logger.log({"event": "controller_effect", "step": step, **dict(effect)})

    summary = trace.get("summary")
    if isinstance(summary, Mapping):
        logger.log({"event": "controller_effect_summary", "step": step, **dict(summary)})


def _command_field(command: Any, name: str) -> Any:
    if isinstance(command, Mapping):
        return command.get(name)
    return getattr(command, name, None)


def _command_decision(command: Any) -> str:
    return str(_command_field(command, "decision") or "").strip().lower()


def _command_meta(command: Any) -> dict[str, Any] | None:
    meta = _command_field(command, "meta")
    if not isinstance(meta, Mapping):
        return None
    return dict(meta)


def _command_edit_count(command: Any) -> int:
    edits = _command_field(command, "edits")
    if isinstance(edits, SequenceABC) and not isinstance(edits, (str, bytes, bytearray)):
        return len(edits)
    return 0


def _command_surface_family_key(command: Any) -> str | None:
    edits = _command_field(command, "edits")
    if not isinstance(edits, SequenceABC) or isinstance(edits, (str, bytes, bytearray)):
        return None
    for edit in edits:
        if isinstance(edit, Mapping):
            target = edit.get("target")
            op = edit.get("op")
        else:
            target = getattr(edit, "target", None)
            op = getattr(edit, "op", None)
        surface_id = None
        if isinstance(target, Mapping):
            surface_id = target.get("surface_id")
        elif target is not None:
            surface_id = getattr(target, "surface_id", None)
        op_kind = None
        if isinstance(op, Mapping):
            op_kind = op.get("kind")
        elif op is not None:
            op_kind = getattr(op, "kind", None)
        if surface_id:
            if op_kind:
                return f"{str(op_kind)}_{str(surface_id)}"
            return str(surface_id)
    return None


def _guarded_noop_command(
    command: Any,
    *,
    noop_reason: str | None = None,
    apply_block_reason: str | None = None,
    finish_budget_reserved: int | bool | None = None,
    evidence_bullets: Sequence[str] = (),
) -> dict[str, Any]:
    guarded_command = {
        "version": str(_command_field(command, "version") or "0.1"),
        "decision": "noop",
        "edits": [],
        "rollback_ids": [],
    }
    meta = dict(_command_meta(command) or {})
    controller_memory = meta.get("controller_memory")
    normalized_memory = dict(controller_memory) if isinstance(controller_memory, Mapping) else {}
    blocked_apply_kind = meta.pop("apply_kind", None)
    if blocked_apply_kind not in (None, ""):
        meta.setdefault("blocked_apply_kind", blocked_apply_kind)
        normalized_memory.setdefault("blocked_apply_kind", blocked_apply_kind)
    if noop_reason is not None:
        meta.setdefault("noop_reason", noop_reason)
        normalized_memory.setdefault("noop_reason", noop_reason)
    if apply_block_reason is not None:
        meta.setdefault("apply_block_reason", apply_block_reason)
        normalized_memory.setdefault("apply_block_reason", apply_block_reason)
    if finish_budget_reserved is not None:
        meta.setdefault("finish_budget_reserved", finish_budget_reserved)
        normalized_memory.setdefault("finish_budget_reserved", finish_budget_reserved)
    surface_family_key = _command_surface_family_key(command)
    if surface_family_key is not None:
        meta.setdefault("surface_family_key", surface_family_key)
        normalized_memory.setdefault("surface_family_key", surface_family_key)
    bullets: list[str] = []
    raw_existing_bullets = normalized_memory.get("evidence_bullets")
    if isinstance(raw_existing_bullets, SequenceABC) and not isinstance(raw_existing_bullets, (str, bytes, bytearray)):
        for item in raw_existing_bullets:
            text = " ".join(str(item).split()).strip()
            if text and text not in bullets:
                bullets.append(text)
    for item in evidence_bullets:
        text = " ".join(str(item).split()).strip()
        if text and text not in bullets:
            bullets.append(text)
    if bullets:
        normalized_memory["evidence_bullets"] = bullets[:4]
    if normalized_memory:
        meta["controller_memory"] = normalized_memory
    if meta:
        guarded_command["meta"] = meta
    return guarded_command


def _guard_exhausted_apply_command(
    command: Any,
    packet: Mapping[str, Any],
) -> tuple[Any, dict[str, Any] | None]:
    decision = _command_decision(command)
    if decision != "apply":
        return command, None
    budget = packet.get("budget")
    if not isinstance(budget, Mapping):
        return command, None
    edits_left_this_run = budget.get("edits_left_this_run")
    try:
        edits_left_this_run = int(edits_left_this_run)
    except Exception:
        return command, None
    if edits_left_this_run > 0:
        return command, None
    try:
        usage = command_budget_usage(command, packet)
    except Exception:
        usage = {
            MAIN_EDIT_BUDGET_POOL: {"edit_count": 1.0},
            LOOP_RESCUE_EDIT_BUDGET_POOL: {"edit_count": 0.0},
            PRODUCTION_TRIAL_EDIT_BUDGET_POOL: {"edit_count": 0.0},
            PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL: {"edit_count": 0.0},
        }
    loop_rescue_edits_left_this_run = budget.get("loop_rescue_edits_left_this_run")
    try:
        loop_rescue_edits_left_this_run = int(loop_rescue_edits_left_this_run)
    except Exception:
        loop_rescue_edits_left_this_run = 0
    if (
        int(usage.get(MAIN_EDIT_BUDGET_POOL, {}).get("edit_count", 0.0) or 0.0) == 0
        and int(usage.get(LOOP_RESCUE_EDIT_BUDGET_POOL, {}).get("edit_count", 0.0) or 0.0) > 0
        and loop_rescue_edits_left_this_run > 0
    ):
        return command, None
    production_trial_edits_left_this_run = budget.get("production_trial_edits_left_this_run")
    try:
        production_trial_edits_left_this_run = int(production_trial_edits_left_this_run)
    except Exception:
        production_trial_edits_left_this_run = 0
    if (
        int(usage.get(MAIN_EDIT_BUDGET_POOL, {}).get("edit_count", 0.0) or 0.0) == 0
        and int(usage.get(PRODUCTION_TRIAL_EDIT_BUDGET_POOL, {}).get("edit_count", 0.0) or 0.0) > 0
        and production_trial_edits_left_this_run > 0
    ):
        return command, None
    production_trial_followup_edits_left_this_run = budget.get("production_trial_followup_edits_left_this_run")
    try:
        production_trial_followup_edits_left_this_run = int(production_trial_followup_edits_left_this_run)
    except Exception:
        production_trial_followup_edits_left_this_run = 0
    if (
        int(usage.get(MAIN_EDIT_BUDGET_POOL, {}).get("edit_count", 0.0) or 0.0) == 0
        and int(usage.get(PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL, {}).get("edit_count", 0.0) or 0.0) > 0
        and production_trial_followup_edits_left_this_run > 0
    ):
        return command, None
    guarded_command = _guarded_noop_command(
        command,
        noop_reason="budget_exhausted",
        apply_block_reason="edits_left_this_run_exhausted",
        evidence_bullets=(
            "main_edit_budget exhausted",
            f"requested_edit_count={_command_edit_count(command)}",
        ),
    )
    return guarded_command, {
        "reason": "edits_left_this_run_exhausted",
        "original_decision": decision,
        "edits_left_this_run": edits_left_this_run,
        "requested_edit_count": _command_edit_count(command),
    }


def _guard_budget_violating_apply_command(
    command: Any,
    packet: Mapping[str, Any],
    *,
    policy: Any | None = None,
) -> tuple[Any, dict[str, Any] | None]:
    decision = _command_decision(command)
    if decision != "apply":
        return command, None
    try:
        usage = command_budget_usage(command, packet, policy=policy)
        reason = budget_violation_reason(command, packet, policy=policy, usage=usage)
    except Exception:
        return command, None
    if reason is None:
        return command, None
    guarded_command = _guarded_noop_command(
        command,
        noop_reason="guardrail_blocked",
        apply_block_reason=reason,
        evidence_bullets=(
            "runtime_guardrail converted apply to noop",
            str(reason),
        ),
    )
    return guarded_command, {
        "reason": reason,
        "original_decision": decision,
        "requested_edit_count": _command_edit_count(command),
        "requested_main_alpha": float(usage.get(MAIN_EDIT_BUDGET_POOL, {}).get("alpha", 0.0) or 0.0),
        "requested_loop_rescue_alpha": float(
            usage.get(LOOP_RESCUE_EDIT_BUDGET_POOL, {}).get("alpha", 0.0) or 0.0
        ),
        "requested_production_trial_alpha": float(
            usage.get(PRODUCTION_TRIAL_EDIT_BUDGET_POOL, {}).get("alpha", 0.0) or 0.0
        ),
        "requested_production_trial_followup_alpha": float(
            usage.get(PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL, {}).get("alpha", 0.0) or 0.0
        ),
    }


def _extract_controller_memory(command: Any) -> tuple[Mapping[str, Any] | None, str | None]:
    if isinstance(command, Mapping):
        meta = command.get("meta")
        decision = command.get("decision")
    else:
        meta = getattr(command, "meta", None)
        decision = getattr(command, "decision", None)
    if not isinstance(meta, Mapping):
        return None, None if decision is None else str(decision)
    entry = meta.get("controller_memory")
    if isinstance(entry, Mapping):
        normalized = dict(entry)
    else:
        normalized = {}
    if meta.get("hypothesis") is not None and "hypothesis" not in normalized:
        normalized["hypothesis"] = meta.get("hypothesis")
    if meta.get("micro_rationale") is not None and "micro_rationale" not in normalized:
        normalized["micro_rationale"] = meta.get("micro_rationale")
    if meta.get("next_trigger") is not None and "next_trigger" not in normalized:
        normalized["next_trigger"] = meta.get("next_trigger")
    if meta.get("next_action") is not None and "next_action" not in normalized:
        normalized["next_action"] = meta.get("next_action")
    for key in (
        "noop_reason",
        "apply_block_reason",
        "apply_kind",
        "surface_family_key",
        "focus_term",
        "objective_bundle_key",
        "step_actuator_bundle_key",
        "blocked_by",
        "next_evidence_needed",
        "why_not_apply",
        "transfer_confidence",
        "same_family_escalation_risk",
        "finish_budget_reserved",
        "production_apply_allowed",
        "certified_for_apply",
        "evidence_bullets",
    ):
        if meta.get(key) is not None and key not in normalized:
            normalized[key] = meta.get(key)
    shadow_proposals = meta.get("shadow_proposals")
    if shadow_proposals is not None and "shadow_proposals" not in normalized:
        normalized["shadow_proposals"] = shadow_proposals
    if "surface_family_key" not in normalized:
        derived_surface_family_key = _command_surface_family_key(command)
        if derived_surface_family_key is not None:
            normalized["surface_family_key"] = derived_surface_family_key
    if not normalized:
        return None, None if decision is None else str(decision)
    return normalized, None if decision is None else str(decision)


def _extract_observer_check_request(command: Any) -> Mapping[str, Any] | None:
    meta = _command_meta(command)
    if not isinstance(meta, Mapping):
        return None
    if "operation_id" in meta:
        return None
    request = meta.get("observer_check_request")
    if request is True:
        return {"kind": "semantic_progress"}
    if isinstance(request, Mapping):
        return dict(request)
    if str(meta.get("next_action") or "").strip().lower().replace("-", "_") == "request_observer_check":
        return {
            "kind": "semantic_progress",
            "trigger": "controller_next_action",
            "reason": str(meta.get("why_not_apply") or meta.get("micro_rationale") or "controller requested observer check"),
        }
    return None


def _extract_tool_requests(command: Any) -> list[dict[str, Any]]:
    meta = _command_meta(command)
    if not isinstance(meta, Mapping):
        return []
    if "operation_id" in meta:
        return []
    requests = meta.get("tool_requests")
    if isinstance(requests, Mapping):
        return [dict(requests)]
    if not isinstance(requests, SequenceABC) or isinstance(requests, (str, bytes, bytearray)):
        return []
    normalized: list[dict[str, Any]] = []
    for item in requests:
        if isinstance(item, Mapping):
            normalized.append(dict(item))
    return normalized


def _dispatch_controller_observer_and_tools(
    worker_runtime: Any, command: Any, *, logger: StructuredLogger | None,
    step: int, controller_round: int | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    event_round = {} if controller_round is None else {"controller_round": controller_round}
    requests: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    observer_request = _extract_observer_check_request(command)
    if observer_request is not None:
        requests.append({"kind": "observer_check", **dict(observer_request)})
        requester = getattr(worker_runtime, "request_observer_check", None)
        result = None
        if callable(requester):
            try:
                result = requester(observer_request, source="controller")
            except TypeError:
                result = requester(observer_request)
        if isinstance(result, Mapping):
            results.append(dict(result))
        if logger is not None:
            event = {"event": "controller_observer_check_request", "step": step,
                     **event_round, **dict(observer_request), "executed": bool(result)}
            if isinstance(result, Mapping):
                event.update(result_trigger=result.get("trigger"),
                             result_verdict=result.get("verdict"), result_score=result.get("score"))
            logger.log(event)
        _log_pending_observer_check_events(logger, step=step, worker_runtime=worker_runtime)

    tool_requests = _extract_tool_requests(command)
    if tool_requests:
        requests.extend({"kind": "tool_request", **dict(request)} for request in tool_requests)
        requester = getattr(worker_runtime, "request_controller_tools", None)
        tool_results = []
        if callable(requester):
            try:
                tool_results = requester(tool_requests, source="controller") or []
            except TypeError:
                tool_results = requester(tool_requests) or []
        results.extend(dict(result) for result in tool_results if isinstance(result, Mapping))
        if logger is not None:
            for request in tool_requests:
                logger.log({"event": "controller_tool_request", "step": step,
                            **event_round, **dict(request), "executed": bool(tool_results)})
        _log_pending_tool_events(logger, step=step, worker_runtime=worker_runtime)
    return requests, results


def _diagnostic_request_from_next_action(value: Any) -> str | None:
    text = str(value or "").strip().lower().replace("-", "_")
    return {
        "request_operator_diagnostic": "operator_diagnostic_replay",
        "request_attention_head_ablation": "attention_head_ablation_on_frontier",
        "request_attention_readout_carrier_probe": "attention_readout_carrier_probe",
        "request_readout_logit_adjacent_probe": "readout_logit_adjacent_probe",
        "request_sae_feature_scan": "sae_feature_emitter_scan",
        "request_compare_extra_operator_diagnostics": "compare_extra_operator_diagnostics",
        "request_non_kv_operator_search": "compare_extra_operator_diagnostics",
        "request_target_entity_insertion_probe": "target_entity_insertion_probe",
        "request_entity_insertion_operator_candidate_review": "entity_insertion_operator_candidate_review",
        "request_objective_rotation_pipeline": "objective_rotation_pipeline",
        "request_carrier_to_actuator_conversion_sweep": "carrier_to_actuator_conversion_sweep",
        "request_cross_bundle_bridge_search": "cross_bundle_bridge_search",
        "request_activation_patch_candidate_review": "activation_patch_candidate_review",
        "request_activation_patch_runtime_support_probe": "activation_patch_runtime_support_probe",
        "request_activation_patch_promotion_gate_review": "activation_patch_promotion_gate_review",
        "request_activation_patch_production_shadow_replay": "activation_patch_production_shadow_replay",
        "request_activation_patch_production_trial_gate_review": "activation_patch_production_trial_gate_review",
        "request_readout_gap_confirmation_or_variant_sweep": "readout_gap_confirmation_or_variant_sweep",
    }.get(text)


def _strategy_canonical_diagnostic_request(strategy_hints: Mapping[str, Any]) -> dict[str, Any] | None:
    raw = strategy_hints.get("diagnostic_frontier_canonical_request") or strategy_hints.get("canonical_followup_request")
    if isinstance(raw, Mapping):
        request = dict(raw)
    else:
        request = {}
    if not request and str(strategy_hints.get("diagnostic_frontier_request") or ""):
        request = {
            "diagnostic": strategy_hints.get("diagnostic_frontier_request"),
            "bundle_key": strategy_hints.get("diagnostic_frontier_bundle_key"),
            "objective_bundle_key": strategy_hints.get("diagnostic_frontier_bundle_key"),
            "next_evidence_needed": strategy_hints.get("diagnostic_frontier_next_evidence"),
            "operator_recipe_expansion_mode": strategy_hints.get(
                "diagnostic_frontier_operator_recipe_expansion_mode"
            ),
            "reason": strategy_hints.get("diagnostic_frontier_reason_text"),
        }
    diagnostic = str(
        request.get("diagnostic")
        or request.get("diagnostic_request")
        or request.get("request")
        or request.get("kind")
        or ""
    )
    if not diagnostic:
        return None
    request["diagnostic"] = diagnostic
    return {key: value for key, value in request.items() if value not in (None, "", [])}


def _diagnostic_name(value: Any) -> str:
    if isinstance(value, Mapping):
        return str(
            value.get("diagnostic")
            or value.get("diagnostic_request")
            or value.get("request")
            or value.get("kind")
            or value.get("name")
            or ""
        )
    return str(value or "")


def _canonicalize_diagnostic_request_row(
    row: dict[str, Any],
    *,
    meta: Mapping[str, Any],
    strategy_hints: Mapping[str, Any],
    canonical_request: Mapping[str, Any] | None,
) -> None:
    if not isinstance(canonical_request, Mapping):
        return
    diagnostic = str(row.get("diagnostic") or "")
    if not diagnostic or diagnostic != str(canonical_request.get("diagnostic") or ""):
        return
    canonical_next = str(canonical_request.get("next_evidence_needed") or "")
    canonical_mode = str(canonical_request.get("operator_recipe_expansion_mode") or "")
    if not canonical_next and not canonical_mode:
        return
    row_next = str(row.get("next_evidence_needed") or meta.get("next_evidence_needed") or "")
    row_mode = str(row.get("operator_recipe_expansion_mode") or meta.get("operator_recipe_expansion_mode") or "")
    strategy_next = str(strategy_hints.get("diagnostic_frontier_next_evidence") or "")
    strategy_mode = str(strategy_hints.get("diagnostic_frontier_operator_recipe_expansion_mode") or "")
    applies = (
        (canonical_next and canonical_next in {row_next, strategy_next})
        or (canonical_mode and canonical_mode in {row_mode, strategy_mode})
        or (not row_next and not row_mode)
    )
    if not applies:
        return
    for key in ("bundle_key", "objective_bundle_key", "step_actuator_bundle_key"):
        meta_current = meta.get(key)
        current = row.get(key) or meta_current
        canonical_value = canonical_request.get(key)
        if canonical_value not in (None, "", []):
            if meta_current not in (None, "", []) and str(meta_current) != str(canonical_value):
                row.setdefault(f"controller_requested_{key}", meta_current)
            elif current not in (None, "", []) and str(current) != str(canonical_value):
                row.setdefault(f"controller_requested_{key}", current)
            row[key] = canonical_value
    for key in (
        "next_evidence_needed",
        "operator_recipe_expansion_mode",
        "readout_steering_deepening_requested",
        "seed_operator_recipe_id",
        "seed_recipe_family",
        "seed_recipe_name",
        "terms",
        "target_terms",
        "objective_bundle_keys",
        "seed_objective_bundle_keys",
        "objective_rotation_pipeline",
        "carrier_to_actuator_conversion_sweep",
        "operator_family_shift_requested",
        "operator_family_shift_source",
        "operator_family_shift_preview_rows",
        "reason",
        "permission",
    ):
        value = canonical_request.get(key)
        if value not in (None, "", []):
            row[key] = value
    row["canonical_followup_request_applied"] = True


def _blocked_diagnostic_row(
    row: Mapping[str, Any],
    *,
    strategy_hints: Mapping[str, Any],
) -> Mapping[str, Any] | None:
    diagnostic = str(row.get("diagnostic") or "")
    objective = str(row.get("objective_bundle_key") or row.get("bundle_key") or "")
    blocked_rows = strategy_hints.get("blocked_next_diagnostics")
    if not isinstance(blocked_rows, Sequence) or isinstance(blocked_rows, (str, bytes, bytearray)):
        return None
    for blocked in blocked_rows:
        if not isinstance(blocked, Mapping):
            continue
        if str(blocked.get("diagnostic") or "") != diagnostic:
            continue
        blocked_objective = str(blocked.get("objective_bundle_key") or blocked.get("bundle_key") or "")
        if objective and blocked_objective and objective != blocked_objective:
            continue
        return blocked
    return None


def _extract_diagnostic_requests(command: Any, packet: Mapping[str, Any]) -> list[dict[str, Any]]:
    meta = _command_meta(command)
    if not isinstance(meta, Mapping):
        meta = {}
    if "operation_id" in meta:
        try:
            return [operation_cards.resolve(packet, command)]
        except ValueError:
            return []
    strategy_hints = _packet_strategy_hints(packet)
    canonical_request = _strategy_canonical_diagnostic_request(strategy_hints)
    raw_requests: list[Any] = []
    diagnostic_request = meta.get("diagnostic_request")
    if isinstance(diagnostic_request, Mapping) and diagnostic_request.get("diagnostic") == "candidate_action":
        # A selected offer is exclusive; stale next_action/memory prose must not
        # append a second diagnostic or rewrite a read into a measurement.
        return [{"diagnostic": "candidate_action", "action_id": diagnostic_request.get("action_id")}]
    if isinstance(diagnostic_request, Mapping) and diagnostic_request.get("diagnostic") == "matched_response_probe":
        # Preserve the offered objective/seed and keep this bounded physical
        # measurement separate from stale frontier or next_action requests.
        return [dict(diagnostic_request)]
    if isinstance(diagnostic_request, Mapping) and diagnostic_request.get("evidence_id"):
        from .response_promotion import REVIEW_NAMES
        if diagnostic_request.get("diagnostic") in REVIEW_NAMES:
            return [dict(diagnostic_request)]
    if diagnostic_request not in (None, ""):
        if (
            canonical_request is not None
            and not isinstance(diagnostic_request, Mapping)
            and _diagnostic_name(diagnostic_request) == str(canonical_request.get("diagnostic") or "")
        ):
            raw_requests.append(dict(canonical_request))
        else:
            raw_requests.append(diagnostic_request)
    diagnostic_request_defaults = diagnostic_request if isinstance(diagnostic_request, Mapping) else {}
    mapped_next_action = _diagnostic_request_from_next_action(meta.get("next_action"))
    if mapped_next_action is not None:
        if canonical_request is not None and mapped_next_action == str(canonical_request.get("diagnostic") or ""):
            raw_requests.append(dict(canonical_request))
        else:
            raw_requests.append(mapped_next_action)
    controller_memory = meta.get("controller_memory")
    if isinstance(controller_memory, Mapping):
        memory_request = controller_memory.get("diagnostic_request")
        if memory_request not in (None, ""):
            if (
                canonical_request is not None
                and not isinstance(memory_request, Mapping)
                and _diagnostic_name(memory_request) == str(canonical_request.get("diagnostic") or "")
            ):
                raw_requests.append(dict(canonical_request))
            else:
                raw_requests.append(memory_request)
        memory_next_action = _diagnostic_request_from_next_action(controller_memory.get("next_action"))
        if memory_next_action is not None:
            if canonical_request is not None and memory_next_action == str(canonical_request.get("diagnostic") or ""):
                raw_requests.append(dict(canonical_request))
            else:
                raw_requests.append(memory_next_action)

    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in raw_requests:
        if isinstance(raw, Mapping):
            row = dict(raw)
            name = row.get("diagnostic") or row.get("diagnostic_request") or row.get("request") or row.get("kind") or row.get("name")
        else:
            row = {"diagnostic": str(raw)}
            name = raw
        name_text = str(name or "").strip()
        if not name_text:
            continue
        row.setdefault("diagnostic", name_text)
        if name_text == "inspect_evidence":
            # An ID addresses historical evidence, not the current frontier.
            # Do not silently constrain it to today's objective or replay mode.
            signature = _diagnostic_request_signature(row)
            if signature not in seen:
                seen.add(signature)
                normalized.append(row)
            continue
        _canonicalize_diagnostic_request_row(
            row,
            meta=meta,
            strategy_hints=strategy_hints,
            canonical_request=canonical_request,
        )
        frontier_name = str(
            (canonical_request or {}).get("diagnostic")
            or strategy_hints.get("diagnostic_frontier_request")
            or ""
        )
        matches_frontier = not frontier_name or name_text == frontier_name
        row.setdefault(
            "bundle_key",
            meta.get("objective_bundle_key")
            or diagnostic_request_defaults.get("bundle_key")
            or diagnostic_request_defaults.get("objective_bundle_key")
            or (strategy_hints.get("diagnostic_frontier_bundle_key") if matches_frontier else None)
            or strategy_hints.get("gate_report_frontier_bundle_key")
            or strategy_hints.get("selected_bundle_key"),
        )
        row.setdefault(
            "objective_bundle_key",
            meta.get("objective_bundle_key")
            or diagnostic_request_defaults.get("objective_bundle_key")
            or row.get("bundle_key"),
        )
        row.setdefault(
            "step_actuator_bundle_key",
            meta.get("step_actuator_bundle_key")
            or diagnostic_request_defaults.get("step_actuator_bundle_key")
            or row.get("bundle_key"),
        )
        row.setdefault(
            "next_evidence_needed",
            meta.get("next_evidence_needed")
            or (strategy_hints.get("diagnostic_frontier_next_evidence") if matches_frontier else None),
        )
        row.setdefault("reason", meta.get("why_not_apply") or strategy_hints.get("diagnostic_frontier_reason_text"))
        if meta.get("operator_recipe_expansion_mode") not in (None, ""):
            row.setdefault("operator_recipe_expansion_mode", meta.get("operator_recipe_expansion_mode"))
        elif (
            matches_frontier
            and name_text in {
                "compare_extra_operator_diagnostics",
                "readout_gap_confirmation_or_variant_sweep",
                "carrier_to_actuator_conversion_sweep",
                "activation_patch_candidate_review",
                "activation_patch_runtime_support_probe",
                "activation_patch_promotion_gate_review",
                "activation_patch_production_shadow_replay",
                "activation_patch_production_trial_gate_review",
            }
            and strategy_hints.get("diagnostic_frontier_operator_recipe_expansion_mode") not in (None, "")
        ):
            row.setdefault(
                "operator_recipe_expansion_mode",
                strategy_hints.get("diagnostic_frontier_operator_recipe_expansion_mode"),
            )
        if name_text in {
            "readout_gap_confirmation_or_variant_sweep",
            "carrier_to_actuator_conversion_sweep",
        } and row.get("operator_recipe_expansion_mode") in (None, ""):
            row["operator_recipe_expansion_mode"] = name_text
        if name_text == "activation_patch_candidate_review" and row.get("operator_recipe_expansion_mode") in (None, ""):
            row["operator_recipe_expansion_mode"] = name_text
        blocked = _blocked_diagnostic_row(row, strategy_hints=strategy_hints)
        if blocked is not None:
            alternate = str(blocked.get("suggested_alternate_diagnostic") or "")
            if not alternate:
                continue
            row["diagnostic_unavailable_veto"] = True
            row["unavailable_diagnostic"] = row.get("diagnostic")
            row["diagnostic"] = alternate
            row.setdefault("next_evidence_needed", "diagnostic_unavailable_veto")
            row.setdefault("reason", blocked.get("reason") or "diagnostic unavailable for this objective")
            row["substituted_for_unavailable_diagnostic"] = True
        post_bridge_requested = (
            str(row.get("next_evidence_needed") or "") == "post_bridge_exhaustion_recipe_expansion"
            or bool(meta.get("post_bridge_exhaustion_recipe_expansion_requested", False))
            or str(row.get("operator_recipe_expansion_mode") or "") == "post_bridge_exhaustion"
        )
        if post_bridge_requested and str(row.get("diagnostic") or "") == "compare_extra_operator_diagnostics":
            row.setdefault("operator_recipe_expansion_mode", "post_bridge_exhaustion")
        readout_steering_deepening_requested = (
            str(row.get("next_evidence_needed") or "") == "readout_steering_deepening"
            or str(row.get("operator_recipe_expansion_mode") or "") == "readout_steering_deepening"
            or bool(meta.get("readout_steering_deepening_requested", False))
        )
        if (
            readout_steering_deepening_requested
            and str(row.get("diagnostic") or "") == "compare_extra_operator_diagnostics"
        ):
            row.setdefault("operator_recipe_expansion_mode", "readout_steering_deepening")
            row.setdefault("readout_steering_deepening_requested", True)
        carrier_conversion_requested = (
            str(row.get("next_evidence_needed") or "") == "carrier_to_actuator_conversion_sweep"
            or str(row.get("operator_recipe_expansion_mode") or "") == "carrier_to_actuator_conversion_sweep"
            or bool(meta.get("carrier_to_actuator_conversion_sweep", False))
        )
        if carrier_conversion_requested and str(row.get("diagnostic") or "") == "carrier_to_actuator_conversion_sweep":
            row.setdefault("operator_recipe_expansion_mode", "carrier_to_actuator_conversion_sweep")
            row.setdefault("carrier_to_actuator_conversion_sweep", True)
        if bool(meta.get("post_bridge_exhaustion_recipe_expansion_requested", False)) or (
            str(row.get("operator_recipe_expansion_mode") or "") == "post_bridge_exhaustion"
        ):
            row.setdefault("post_bridge_exhaustion_recipe_expansion_requested", True)
        if isinstance(meta.get("cross_bundle_bridge_search_state"), Mapping):
            row.setdefault("cross_bundle_bridge_search_state", dict(meta["cross_bundle_bridge_search_state"]))
        signature = _diagnostic_request_signature(row)
        if signature in seen:
            continue
        seen.add(signature)
        normalized.append(row)
    return normalized


def _diagnostic_request_signature(request: Mapping[str, Any]) -> str:
    candidate = request.get("activation_patch_shadow_actuator") or request.get("alternate_trial_candidate")
    candidate_recipe_id = (
        candidate.get("operator_recipe_id")
        if isinstance(candidate, Mapping)
        else request.get("operator_recipe_id")
    )
    return "|".join(
        str(request.get(key, "") or "")
        for key in (
            "diagnostic",
            "bundle_key",
            "objective_bundle_key",
            "next_evidence_needed",
            "operator_recipe_expansion_mode",
            "execution_id", "evidence_id", "action_id", "dose_grid", "candidate_ids", "limit", "comparison_axis",
        )
    ) + "|" + str(candidate_recipe_id or "")


def _diagnostic_requests_next_evidence(requests: Sequence[Mapping[str, Any]]) -> str | None:
    for request in requests:
        if not isinstance(request, Mapping):
            continue
        value = request.get("next_evidence_needed")
        if value not in (None, ""):
            return str(value)
    return None


def _diagnostic_results_next_evidence(results: Sequence[Any]) -> str | None:
    for result in reversed(list(results)):
        if not isinstance(result, Mapping):
            continue
        value = result.get("next_evidence_needed")
        if value not in (None, ""):
            return str(value)
    return None


def _diagnostic_context_next_evidence(packet: Mapping[str, Any]) -> str | None:
    strategy_hints = _packet_strategy_hints(packet)
    value = strategy_hints.get("diagnostic_frontier_next_evidence")
    if value not in (None, ""):
        return str(value)
    return None


def _command_next_evidence_needed(command: Any) -> str | None:
    meta = _command_meta(command)
    if not isinstance(meta, Mapping):
        return None
    value = meta.get("next_evidence_needed")
    if value not in (None, ""):
        return str(value)
    controller_memory = meta.get("controller_memory")
    if isinstance(controller_memory, Mapping):
        value = controller_memory.get("next_evidence_needed")
        if value not in (None, ""):
            return str(value)
    return None


def _diagnostic_next_evidence_transition(before: str | None, after: str | None) -> bool:
    return bool(before not in (None, "") and after not in (None, "") and str(before) != str(after))


def _filter_repeated_diagnostic_requests(
    requests: Sequence[Mapping[str, Any]],
    seen_signatures: set[str],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    fresh: list[dict[str, Any]] = []
    repeated: list[dict[str, Any]] = []
    for request in requests:
        if not isinstance(request, Mapping):
            continue
        normalized = dict(request)
        signature = _diagnostic_request_signature(normalized)
        if signature in seen_signatures:
            repeated.append(normalized | {"diagnostic_signature": signature})
            continue
        fresh.append(normalized)
    return fresh, repeated


def _packet_strategy_hints(packet: Mapping[str, Any]) -> Mapping[str, Any]:
    strategy_hints = packet.get("strategy_hints")
    if isinstance(strategy_hints, Mapping):
        return strategy_hints
    return {}


def _candidate_bundle_signature(item: Mapping[str, Any]) -> tuple[str, str] | None:
    surface_id = item.get("surface_id")
    if surface_id in (None, "") and isinstance(item.get("target"), Mapping):
        surface_id = item["target"].get("surface_id")
    op = item.get("op")
    op_kind = None
    if isinstance(op, Mapping):
        op_kind = op.get("kind")
    elif op is not None:
        op_kind = getattr(op, "kind", None)
    if surface_id in (None, "") or op_kind in (None, ""):
        return None
    return str(surface_id), str(op_kind)


def _command_edit_signature(edit: Any) -> tuple[str, str] | None:
    if isinstance(edit, Mapping):
        target = edit.get("target")
        op = edit.get("op")
    else:
        target = getattr(edit, "target", None)
        op = getattr(edit, "op", None)
    surface_id = None
    if isinstance(target, Mapping):
        surface_id = target.get("surface_id")
    elif target is not None:
        surface_id = getattr(target, "surface_id", None)
    op_kind = None
    if isinstance(op, Mapping):
        op_kind = op.get("kind")
    elif op is not None:
        op_kind = getattr(op, "kind", None)
    if surface_id in (None, "") or op_kind in (None, ""):
        return None
    return str(surface_id), str(op_kind)


def _packet_bundle_candidates(packet: Mapping[str, Any]) -> dict[tuple[str, str], str]:
    strategy_hints = _packet_strategy_hints(packet)
    by_signature: dict[tuple[str, str], str] = {}
    for key in ("kv_candidate_edits", "kv_retry_candidate_edits", "shot_candidate_edits"):
        items = strategy_hints.get(key)
        if not isinstance(items, SequenceABC) or isinstance(items, (str, bytes, bytearray)):
            continue
        for item in items:
            if not isinstance(item, Mapping):
                continue
            signature = _candidate_bundle_signature(item)
            bundle_key = item.get("bundle_key")
            if signature is None or bundle_key in (None, ""):
                continue
            by_signature.setdefault(signature, str(bundle_key))
    return by_signature


def _extract_controller_selected_bundle_key(packet: Mapping[str, Any], command: Any) -> str | None:
    if _command_decision(command) != "apply":
        return None
    bundle_map = _packet_bundle_candidates(packet)
    edits = _command_field(command, "edits")
    if not isinstance(edits, SequenceABC) or isinstance(edits, (str, bytes, bytearray)):
        return None
    matched_bundle_keys: list[str] = []
    for edit in edits:
        signature = _command_edit_signature(edit)
        if signature is None:
            continue
        bundle_key = bundle_map.get(signature)
        if bundle_key and bundle_key not in matched_bundle_keys:
            matched_bundle_keys.append(bundle_key)
    if len(matched_bundle_keys) == 1:
        return matched_bundle_keys[0]
    return None


def _dedup_text_items(*groups: Any) -> list[str]:
    items: list[str] = []
    for group in groups:
        if group is None:
            continue
        if isinstance(group, SequenceABC) and not isinstance(group, (str, bytes, bytearray)):
            values = group
        else:
            values = [group]
        for value in values:
            if value is None:
                continue
            text = str(value).strip()
            if text and text not in items:
                items.append(text)
    return items


def _optional_meta_text(meta: Mapping[str, Any], key: str) -> str | None:
    value = meta.get(key)
    if value in (None, ""):
        return None
    text = str(value).strip()
    return text or None


def _normalized_shadow_proposals(meta: Mapping[str, Any]) -> list[dict[str, Any]]:
    raw = meta.get("shadow_proposals")
    if not isinstance(raw, SequenceABC) or isinstance(raw, (str, bytes, bytearray)):
        return []
    normalized: list[dict[str, Any]] = []
    for item in raw[:3]:
        if not isinstance(item, Mapping):
            continue
        proposal: dict[str, Any] = {}
        for key in (
            "kind",
            "bundle_key",
            "objective_bundle_key",
            "actuator_bundle_key",
            "term",
            "reason",
            "decision",
            "status",
        ):
            if item.get(key) not in (None, ""):
                proposal[key] = item.get(key)
        if proposal:
            normalized.append(proposal)
    return normalized


def _recent_effect_summary(packet: Mapping[str, Any]) -> Mapping[str, Any]:
    summary = packet.get("recent_effect_summary")
    if isinstance(summary, Mapping):
        return summary
    return {}


def _recent_effect_veto_context(
    packet: Mapping[str, Any],
    *,
    frontier_bundle_key: str | None,
    surface_family_key: str | None,
    operator_recipe_id: str | None,
    objective_bundle_key: str | None,
    step_actuator_bundle_key: str | None,
) -> tuple[list[str], str | None]:
    summary = _recent_effect_summary(packet)
    harmful_families = {
        str(item)
        for item in summary.get("recent_harmful_surface_family_keys", ())
        if str(item)
    }
    collapse_families = {
        str(item)
        for item in summary.get("recent_collapse_sharpener_surface_family_keys", ())
        if str(item)
    }
    harmful_recipe_ids = {
        str(item)
        for item in summary.get("recent_harmful_operator_recipe_ids", ())
        if str(item)
    }
    collapse_recipe_ids = {
        str(item)
        for item in summary.get("recent_collapse_sharpener_operator_recipe_ids", ())
        if str(item)
    }
    harmful_bundle_keys = {
        str(item)
        for item in summary.get("recent_harmful_bundle_keys", ())
        if str(item)
    }
    collapse_bundle_keys = {
        str(item)
        for item in summary.get("recent_collapse_sharpener_bundle_keys", ())
        if str(item)
    }
    candidate_bundle_keys = {
        str(item)
        for item in (frontier_bundle_key, objective_bundle_key, step_actuator_bundle_key)
        if item not in (None, "") and str(item)
    }
    latest_effects = summary.get("latest_effects")
    matched_effects: list[Mapping[str, Any]] = []
    if isinstance(latest_effects, SequenceABC) and not isinstance(latest_effects, (str, bytes, bytearray)):
        for effect in latest_effects:
            if not isinstance(effect, Mapping):
                continue
            effect_family = str(effect.get("surface_family_key", "") or "")
            effect_recipe = str(effect.get("operator_recipe_id", "") or "")
            effect_bundle = str(effect.get("bundle_key", "") or "")
            effect_objective = str(effect.get("objective_bundle_key", "") or "")
            effect_step_actuator = str(effect.get("step_actuator_bundle_key", "") or "")
            if (
                (surface_family_key not in (None, "") and effect_family == str(surface_family_key))
                or (operator_recipe_id not in (None, "") and effect_recipe == str(operator_recipe_id))
                or (effect_bundle and effect_bundle in candidate_bundle_keys)
                or (effect_objective and effect_objective in candidate_bundle_keys)
                or (effect_step_actuator and effect_step_actuator in candidate_bundle_keys)
            ):
                matched_effects.append(effect)
    matched_harmful = bool(
        (surface_family_key not in (None, "") and str(surface_family_key) in harmful_families)
        or (operator_recipe_id not in (None, "") and str(operator_recipe_id) in harmful_recipe_ids)
        or any(bundle_key in harmful_bundle_keys for bundle_key in candidate_bundle_keys)
        or any(str(effect.get("verdict", "") or "") == "harmful" for effect in matched_effects)
    )
    matched_collapse = bool(
        (surface_family_key not in (None, "") and str(surface_family_key) in collapse_families)
        or (operator_recipe_id not in (None, "") and str(operator_recipe_id) in collapse_recipe_ids)
        or any(bundle_key in collapse_bundle_keys for bundle_key in candidate_bundle_keys)
        or any(str(effect.get("actuator_class", "") or "") == "collapse_sharpener" for effect in matched_effects)
    )
    if not matched_harmful and not matched_collapse:
        return [], None

    signals: list[str] = []
    if matched_harmful:
        signals.append("recent_harmful_family")
    if matched_collapse:
        signals.append("collapse_sharpener_veto")
    signals.append("no_certified_actuator_for_frontier")

    reason = None
    for effect in reversed(matched_effects):
        effect_family = str(effect.get("surface_family_key", "") or "")
        actuator_class = str(effect.get("actuator_class", "unknown") or "unknown")
        frontier_label = next((bundle for bundle in candidate_bundle_keys if bundle), "frontier candidate")
        if effect_family:
            reason = f"{frontier_label} was vetoed after observed {actuator_class} on {effect_family}"
        else:
            reason = f"{frontier_label} was vetoed after observed {actuator_class}"
        break
    return _dedup_text_items(signals), reason


def _diagnostic_evidence_context(strategy_hints: Mapping[str, Any]) -> dict[str, Any]:
    ledger_raw = strategy_hints.get("diagnostic_evidence_ledger")
    ledger = [
        dict(item)
        for item in ledger_raw[:12]
        if isinstance(item, Mapping)
    ] if isinstance(ledger_raw, Sequence) and not isinstance(ledger_raw, (str, bytes, bytearray)) else []
    status_raw = strategy_hints.get("bundle_diagnostic_status")
    bundle_status = {
        str(key): dict(value)
        for key, value in status_raw.items()
        if str(key) and isinstance(value, Mapping)
    } if isinstance(status_raw, Mapping) else {}
    frontier_bundle_key = str(
        strategy_hints.get(
            "diagnostic_frontier_bundle_key",
            strategy_hints.get(
                "gate_report_frontier_bundle_key",
                strategy_hints.get("selected_bundle_key", ""),
            ),
        )
        or ""
    )
    frontier_status = dict(bundle_status.get(frontier_bundle_key, {})) if frontier_bundle_key else {}
    raw_frontier_status = strategy_hints.get("diagnostic_frontier_status")
    if not frontier_status and isinstance(raw_frontier_status, Mapping):
        frontier_status = dict(raw_frontier_status)
    try:
        ledger_count = int(strategy_hints.get("diagnostic_evidence_ledger_count", len(ledger)) or len(ledger))
    except Exception:
        ledger_count = len(ledger)
    next_evidence = str(
        strategy_hints.get(
            "diagnostic_frontier_next_evidence",
            frontier_status.get("next_evidence_needed", ""),
        )
        or ""
    )
    request = str(
        strategy_hints.get(
            "diagnostic_frontier_request",
            frontier_status.get("diagnostic_request", ""),
        )
        or ""
    )
    reason_text = str(
        strategy_hints.get(
            "diagnostic_frontier_reason_text",
            frontier_status.get("reason_text", ""),
        )
        or ""
    )
    return {
        "diagnostic_evidence_ledger": ledger,
        "diagnostic_evidence_ledger_count": ledger_count,
        "bundle_diagnostic_status": bundle_status,
        "diagnostic_frontier_bundle_key": frontier_bundle_key or None,
        "diagnostic_frontier_status": frontier_status,
        "diagnostic_frontier_next_evidence": next_evidence or None,
        "diagnostic_frontier_request": request or None,
        "diagnostic_frontier_reason_text": reason_text or None,
    }


def _production_trial_evidence_context(packet: Mapping[str, Any], meta: Mapping[str, Any]) -> dict[str, Any]:
    summary = packet.get("recent_effect_summary")
    if not isinstance(summary, Mapping):
        summary = {}
    raw_ledger = summary.get("production_trial_outcome_ledger")
    ledger = [
        dict(item)
        for item in raw_ledger[-8:]
        if isinstance(item, Mapping)
    ] if isinstance(raw_ledger, Sequence) and not isinstance(raw_ledger, (str, bytes, bytearray)) else []
    raw_counts = summary.get("production_trial_outcome_counts")
    counts: dict[str, int] = {}
    if isinstance(raw_counts, Mapping):
        for key, value in raw_counts.items():
            try:
                counts[str(key)] = int(value)
            except Exception:
                continue
    return {
        "production_trial_outcome_counts": counts,
        "production_trial_outcome_ledger": ledger,
        "recent_production_trial_veto_surface_family_keys": list(
            summary.get("recent_production_trial_veto_surface_family_keys", ())
        )
        if isinstance(summary.get("recent_production_trial_veto_surface_family_keys"), Sequence)
        and not isinstance(summary.get("recent_production_trial_veto_surface_family_keys"), (str, bytes, bytearray))
        else [],
        "recent_production_trial_veto_operator_recipe_ids": list(
            summary.get("recent_production_trial_veto_operator_recipe_ids", ())
        )
        if isinstance(summary.get("recent_production_trial_veto_operator_recipe_ids"), Sequence)
        and not isinstance(summary.get("recent_production_trial_veto_operator_recipe_ids"), (str, bytes, bytearray))
        else [],
        "controller_production_trial_outcome": dict(meta["production_trial_outcome"])
        if isinstance(meta.get("production_trial_outcome"), Mapping)
        else None,
        "controller_production_trial_followup": dict(meta["production_trial_followup"])
        if isinstance(meta.get("production_trial_followup"), Mapping)
        else None,
    }


def _visible_no_safe_actuator_guidance(
    *,
    strategy_hints: Mapping[str, Any],
    controller_rejected_signals: Sequence[str],
    controller_objective_bundle_key: str | None,
    controller_step_actuator_bundle_key: str | None,
    controller_shadow_proposals: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    frontier_bundle_key = str(
        strategy_hints.get(
            "gate_report_frontier_bundle_key",
            strategy_hints.get("selected_bundle_key", ""),
        )
        or ""
    )
    unavailable_reason = str(strategy_hints.get("bridge_plan_unavailable_reason", "") or "")
    no_safe_reasons = {
        "all_dead_actuator",
        "all_collapse_sharpener",
        "no_safe_actuator",
        "no_objective_lift_to_frontier",
        "bridge_plan_not_certified",
    }
    rejected_set = {str(item) for item in controller_rejected_signals if str(item)}
    visible_no_safe = bool(
        frontier_bundle_key
        and (
            "no_certified_actuator_for_frontier" in rejected_set
            or "collapse_sharpener_veto" in rejected_set
            or unavailable_reason in no_safe_reasons
        )
    )
    if not visible_no_safe:
        return {}

    objective_key = controller_objective_bundle_key or frontier_bundle_key
    actuator_key = controller_step_actuator_bundle_key or frontier_bundle_key
    suggested_shadow = [
        {
            "kind": "frontier_shadow",
            "bundle_key": frontier_bundle_key,
            "objective_bundle_key": objective_key,
            "actuator_bundle_key": actuator_key,
            "reason": "frontier_visible_but_no_certified_actuator",
            "decision": "shadow",
        }
    ]
    if controller_shadow_proposals:
        suggested_shadow = []

    diagnostic_options = [
        "attention_head_ablation_on_frontier",
        "readout_logit_adjacent_probe",
        "sae_feature_emitter_scan",
    ]
    extra_count = strategy_hints.get("bridge_eval_extra_operator_diagnostic_count")
    try:
        extra_count_int = int(extra_count)
    except Exception:
        extra_count_int = 0
    if extra_count_int > 0:
        diagnostic_options.append("compare_extra_operator_diagnostics")
        diagnostic_options.append("cross_bundle_bridge_search")
    diagnostic_context = _diagnostic_evidence_context(strategy_hints)
    frontier_next_evidence = diagnostic_context.get("diagnostic_frontier_next_evidence")
    frontier_request = diagnostic_context.get("diagnostic_frontier_request")
    frontier_reason = diagnostic_context.get("diagnostic_frontier_reason_text")
    next_evidence_options = [
        "certified_self_or_bridge_actuator",
        "non_dead_attention_ablation_signal",
        "readout_feature_emitter_support",
    ]
    if frontier_next_evidence not in (None, ""):
        next_evidence_options = [
            str(frontier_next_evidence),
            *[item for item in next_evidence_options if item != str(frontier_next_evidence)],
        ]
    if frontier_request not in (None, "", "none") and str(frontier_request) not in diagnostic_options:
        diagnostic_options.insert(0, str(frontier_request))

    return {
        "controller_loop_pressure_mode": "investigate_visible_no_safe_actuator",
        "visible_frontier_status": "visible_but_no_safe_actuator",
        "controller_next_evidence_options": next_evidence_options,
        "controller_diagnostic_request_options": diagnostic_options,
        "controller_recommended_next_evidence": frontier_next_evidence,
        "controller_recommended_diagnostic_request": frontier_request,
        "controller_diagnostic_reason_text": frontier_reason,
        "controller_suggested_shadow_proposals": suggested_shadow,
        "controller_next_action_options": [
            "request_operator_diagnostic",
            "request_attention_head_ablation",
            "request_sae_feature_scan",
            "request_compare_extra_operator_diagnostics",
            "request_non_kv_operator_search",
            "request_cross_bundle_bridge_search",
            "request_activation_patch_candidate_review",
            "request_activation_patch_runtime_support_probe",
            "request_activation_patch_promotion_gate_review",
            "request_activation_patch_production_shadow_replay",
            "request_activation_patch_production_trial_gate_review",
            "noop_until_certified",
        ],
    }


def _build_controller_selection_report(packet: Mapping[str, Any], command: Any) -> dict[str, Any]:
    strategy_hints = _packet_strategy_hints(packet)
    meta = _command_meta(command) or {}
    helper_frontier_bundle_key = strategy_hints.get(
        "gate_report_frontier_bundle_key",
        strategy_hints.get("selected_bundle_key"),
    )
    sidecar_suggested_bundle_key = strategy_hints.get(
        "readout_analyzer_suggested_bundle_key",
        strategy_hints.get("readout_sidecar_suggested_bundle_key"),
    )
    analyzer_hints = strategy_hints.get("readout_analyzer_hints")
    if not isinstance(analyzer_hints, Mapping):
        analyzer_hints = strategy_hints.get("readout_sidecar_hints")
    if not isinstance(analyzer_hints, Mapping):
        analyzer_hints = {}
    analyzer_name = analyzer_hints.get("analyzer_name")
    analyzer_feature_backend = analyzer_hints.get("feature_backend")
    analyzer_sae_status = analyzer_hints.get("sae_status")
    analyzer_sae_feature_hints = analyzer_hints.get("sae_feature_hints")
    analyzer_sae_feature_hint_count = (
        len(analyzer_sae_feature_hints)
        if isinstance(analyzer_sae_feature_hints, Sequence) and not isinstance(analyzer_sae_feature_hints, (str, bytes, bytearray))
        else 0
    )
    analyzer_sae_subspace_groups = analyzer_hints.get("sae_feature_subspace_groups")
    analyzer_sae_subspace_group_count = (
        len(analyzer_sae_subspace_groups)
        if isinstance(analyzer_sae_subspace_groups, Sequence)
        and not isinstance(analyzer_sae_subspace_groups, (str, bytes, bytearray))
        else 0
    )
    activation_patch_subspace_evidence_count = strategy_hints.get("activation_patch_subspace_evidence_count")
    activation_patch_proxy_unreliable_count = strategy_hints.get(
        "activation_patch_proxy_reliability_unreliable_count"
    )
    activation_patch_unreliable_keys = strategy_hints.get("activation_patch_candidate_hint_only_unreliable_keys")
    activation_patch_frontier_preemption = strategy_hints.get("activation_patch_frontier_preemption")
    activation_patch_frontier_preemption_reason = strategy_hints.get(
        "activation_patch_frontier_preemption_reason"
    )
    activation_patch_frontier_preemption_objective = strategy_hints.get(
        "activation_patch_frontier_preemption_objective_bundle_key"
    )
    bridge_plan_objective_bundle_key = (
        meta.get("bridge_plan_objective_bundle_key")
        or strategy_hints.get("bridge_plan_objective_bundle_key")
    )
    bridge_plan_actuator_bundle_key = (
        meta.get("bridge_plan_actuator_bundle_key")
        or strategy_hints.get("bridge_plan_actuator_bundle_key")
    )
    bridge_plan_reason = meta.get("bridge_plan_reason") or strategy_hints.get("bridge_plan_reason")
    bridge_plan_unavailable_reason = (
        meta.get("bridge_plan_unavailable_reason")
        or strategy_hints.get("bridge_plan_unavailable_reason")
    )
    bridge_plan_unavailable_objective_bundle_key = (
        meta.get("bridge_plan_unavailable_objective_bundle_key")
        or strategy_hints.get("bridge_plan_unavailable_objective_bundle_key")
    )
    bridge_plan_unavailable_objective_reasons = (
        meta.get("bridge_plan_unavailable_objective_reasons")
        if isinstance(meta.get("bridge_plan_unavailable_objective_reasons"), Mapping)
        else strategy_hints.get("bridge_plan_unavailable_objective_reasons")
    )
    bridge_eval_context_drift = strategy_hints.get("bridge_eval_context_drift")
    controller_selected_bundle_key = _extract_controller_selected_bundle_key(packet, command)
    controller_objective_bundle_key = _optional_meta_text(meta, "objective_bundle_key")
    if controller_objective_bundle_key is None and controller_selected_bundle_key not in (None, ""):
        controller_objective_bundle_key = str(controller_selected_bundle_key)
    controller_step_actuator_bundle_key = _optional_meta_text(meta, "step_actuator_bundle_key")
    if controller_step_actuator_bundle_key is None and controller_selected_bundle_key not in (None, ""):
        controller_step_actuator_bundle_key = str(controller_selected_bundle_key)
    controller_shadow_proposals = _normalized_shadow_proposals(meta)
    controller_why_not_apply = _optional_meta_text(meta, "why_not_apply")
    raw_controller_apply_kind = _optional_meta_text(meta, "apply_kind")
    controller_apply_kind = raw_controller_apply_kind if _command_decision(command) == "apply" else None
    controller_production_trial_budget_class = _optional_meta_text(meta, "production_trial_budget_class")
    controller_production_trial_followup_allowed = meta.get("production_trial_followup_allowed")
    production_apply_allowed = meta.get("production_apply_allowed")
    certified_for_apply = meta.get("certified_for_apply")
    operator_recipe_id = _optional_meta_text(meta, "operator_recipe_id")
    controller_selection_source = "controller_apply"
    if _command_decision(command) == "apply" and controller_apply_kind == "diagnostic_probe":
        controller_selection_source = "forced_diagnostic_apply"
    elif _command_decision(command) == "apply" and controller_apply_kind == "production_trial":
        controller_selection_source = "production_trial_apply"
    elif controller_selected_bundle_key is None:
        controller_selection_source = "controller_noop" if _command_decision(command) == "noop" else "controller_unresolved"
    elif controller_selected_bundle_key == helper_frontier_bundle_key:
        controller_selection_source = str(
            strategy_hints.get("gate_report_selection_source", strategy_hints.get("selection_source", "controller_apply"))
            or "controller_apply"
        )
    rejected_signal_groups: list[Any] = [meta.get("noop_reason"), meta.get("apply_block_reason")]
    if controller_selected_bundle_key is None or (
        helper_frontier_bundle_key not in (None, "")
        and controller_selected_bundle_key not in (None, "")
        and str(controller_selected_bundle_key) != str(helper_frontier_bundle_key)
    ):
        rejected_signal_groups.extend(
            [
                strategy_hints.get("gate_report_rejected_signals"),
                strategy_hints.get("gate_report_reasons"),
                strategy_hints.get("bundle_rerank_gate_reasons"),
                strategy_hints.get("rerank_vetoes"),
            ]
        )
    recent_effect_signals: list[str] = []
    recent_effect_reason: str | None = None
    if controller_selected_bundle_key is None or _command_decision(command) == "noop":
        recent_effect_signals, recent_effect_reason = _recent_effect_veto_context(
            packet,
            frontier_bundle_key=None if helper_frontier_bundle_key in (None, "") else str(helper_frontier_bundle_key),
            surface_family_key=_optional_meta_text(meta, "surface_family_key") or _command_surface_family_key(command),
            operator_recipe_id=operator_recipe_id,
            objective_bundle_key=controller_objective_bundle_key,
            step_actuator_bundle_key=controller_step_actuator_bundle_key,
        )
        rejected_signal_groups.append(recent_effect_signals)
    controller_rejected_signals = _dedup_text_items(*rejected_signal_groups)
    if controller_why_not_apply is None and recent_effect_reason is not None and _command_decision(command) == "noop":
        controller_why_not_apply = recent_effect_reason
    no_safe_guidance = _visible_no_safe_actuator_guidance(
        strategy_hints=strategy_hints,
        controller_rejected_signals=controller_rejected_signals,
        controller_objective_bundle_key=controller_objective_bundle_key,
        controller_step_actuator_bundle_key=controller_step_actuator_bundle_key,
        controller_shadow_proposals=controller_shadow_proposals,
    )
    diagnostic_context = _diagnostic_evidence_context(strategy_hints)
    production_trial_context = _production_trial_evidence_context(packet, meta)
    if (
        controller_why_not_apply is None
        and no_safe_guidance
        and _command_decision(command) == "noop"
    ):
        controller_why_not_apply = "frontier visible but no certified self or bridge actuator is available"
    bridge_plan_visible = (
        bridge_plan_objective_bundle_key not in (None, "")
        and bridge_plan_actuator_bundle_key not in (None, "")
    )
    controller_plan_mode = (
        "dual_layer"
        if controller_objective_bundle_key not in (None, "")
        and controller_step_actuator_bundle_key not in (None, "")
        and str(controller_objective_bundle_key) != str(controller_step_actuator_bundle_key)
        else "single_layer"
    )
    controller_bridge_dual_layer_missing = bool(
        bridge_plan_visible
        and controller_plan_mode != "dual_layer"
    )
    controller_bridge_dual_layer_reason = (
        "bridge_available_but_single_layer"
        if controller_bridge_dual_layer_missing
        else None
    )
    handoff = strategy_hints.get("candidate_handoff")
    handoff = handoff if isinstance(handoff, Mapping) else {}
    handoff_state = str(handoff.get("state") or "")
    handoff_choice = None
    handoff_defer_reason = None
    handoff_defer_reason_source = None
    if handoff_state == "measurable":
        offered = [item for item in handoff.get("measurement_offers", ()) if isinstance(item, Mapping)]
        requests = _extract_diagnostic_requests(command, packet)
        measured = any(str(item.get("diagnostic") or "") == "matched_response_probe"
                       and candidate_handoff.matches_offered_request(item, offer)
                       for item in requests for offer in offered)
        different_measurement = any(str(item.get("diagnostic") or "") == "matched_response_probe"
                                    and str(item.get("objective_bundle_key") or "") ==
                                    str(offer.get("objective_bundle_key") or "")
                                    for item in requests for offer in offered)
        handoff_choice = ("measurement_requested" if measured else
                          "different_measurement_requested" if different_measurement else
                          "deferred_for_other_diagnostic" if requests else "no_measurement_requested")
        if not measured:
            explicit_reason = _optional_meta_text(meta, "handoff_defer_reason")
            general_reason = _optional_meta_text(meta, "micro_rationale")
            handoff_defer_reason = explicit_reason or general_reason or "not_stated_by_controller"
            handoff_defer_reason_source = ("explicit_handoff_reason" if explicit_reason else
                                          "general_micro_rationale" if general_reason else "missing")
    return {
        "candidate_handoff_state": handoff_state or None,
        "candidate_handoff_choice": handoff_choice,
        "candidate_handoff_defer_reason": handoff_defer_reason,
        "candidate_handoff_defer_reason_source": handoff_defer_reason_source,
        "candidate_handoff_soft_opportunity_cost": handoff.get("soft_opportunity_cost"),
        "candidate_handoff_measured_card_count": handoff.get("measured_card_count"),
        "sidecar_suggested_bundle_key": None if sidecar_suggested_bundle_key in (None, "") else str(sidecar_suggested_bundle_key),
        "readout_analyzer_name": None if analyzer_name in (None, "") else str(analyzer_name),
        "readout_analyzer_feature_backend": None
        if analyzer_feature_backend in (None, "")
        else str(analyzer_feature_backend),
        "readout_analyzer_sae_status": None
        if analyzer_sae_status in (None, "")
        else str(analyzer_sae_status),
        "readout_analyzer_sae_feature_hint_count": int(analyzer_sae_feature_hint_count),
        "readout_analyzer_sae_subspace_group_count": int(analyzer_sae_subspace_group_count),
        "activation_patch_subspace_evidence_count": (
            None
            if activation_patch_subspace_evidence_count is None
            else int(activation_patch_subspace_evidence_count or 0)
        ),
        "activation_patch_frontier_preemption": (
            None if activation_patch_frontier_preemption is None else bool(activation_patch_frontier_preemption)
        ),
        "activation_patch_frontier_preemption_reason": (
            None
            if activation_patch_frontier_preemption_reason in (None, "")
            else str(activation_patch_frontier_preemption_reason)
        ),
        "activation_patch_frontier_preemption_objective_bundle_key": (
            None
            if activation_patch_frontier_preemption_objective in (None, "")
            else str(activation_patch_frontier_preemption_objective)
        ),
        "activation_patch_proxy_reliability_unreliable_count": (
            None
            if activation_patch_proxy_unreliable_count is None
            else int(activation_patch_proxy_unreliable_count or 0)
        ),
        "activation_patch_candidate_hint_only_unreliable_keys": (
            [str(item) for item in activation_patch_unreliable_keys[:6] if str(item)]
            if isinstance(activation_patch_unreliable_keys, Sequence)
            and not isinstance(activation_patch_unreliable_keys, (str, bytes, bytearray))
            else []
        ),
        "gate_report_frontier_bundle_key": None if helper_frontier_bundle_key in (None, "") else str(helper_frontier_bundle_key),
        "bridge_plan_objective_bundle_key": (
            None if bridge_plan_objective_bundle_key in (None, "") else str(bridge_plan_objective_bundle_key)
        ),
        "bridge_plan_actuator_bundle_key": (
            None if bridge_plan_actuator_bundle_key in (None, "") else str(bridge_plan_actuator_bundle_key)
        ),
        "bridge_plan_reason": None if bridge_plan_reason in (None, "") else str(bridge_plan_reason),
        "bridge_plan_unavailable_reason": (
            None if bridge_plan_unavailable_reason in (None, "") else str(bridge_plan_unavailable_reason)
        ),
        "bridge_plan_unavailable_objective_bundle_key": (
            None
            if bridge_plan_unavailable_objective_bundle_key in (None, "")
            else str(bridge_plan_unavailable_objective_bundle_key)
        ),
        "bridge_plan_unavailable_objective_reasons": (
            {
                str(key): str(value)
                for key, value in bridge_plan_unavailable_objective_reasons.items()
                if str(key) and str(value)
            }
            if isinstance(bridge_plan_unavailable_objective_reasons, Mapping)
            else {}
        ),
        "bridge_eval_context_drift": None if bridge_eval_context_drift is None else bool(bridge_eval_context_drift),
        "bridge_plan_used": bool(
            bridge_plan_actuator_bundle_key not in (None, "")
            and controller_selected_bundle_key not in (None, "")
            and str(bridge_plan_actuator_bundle_key) == str(controller_selected_bundle_key)
        ),
        "controller_objective_bundle_key": controller_objective_bundle_key,
        "controller_step_actuator_bundle_key": controller_step_actuator_bundle_key,
        "controller_plan_mode": controller_plan_mode,
        "controller_bridge_plan_visible": bool(bridge_plan_visible),
        "controller_bridge_plan_unavailable_reason": (
            None
            if bridge_plan_visible or bridge_plan_unavailable_reason in (None, "")
            else str(bridge_plan_unavailable_reason)
        ),
        "controller_bridge_dual_layer_missing": controller_bridge_dual_layer_missing,
        "controller_bridge_dual_layer_reason": controller_bridge_dual_layer_reason,
        "controller_shadow_proposals": controller_shadow_proposals,
        "controller_shadow_proposal_count": len(controller_shadow_proposals),
        "controller_apply_kind": controller_apply_kind,
        "controller_production_trial_budget_class": controller_production_trial_budget_class,
        "controller_production_trial_followup_allowed": None
        if controller_production_trial_followup_allowed is None
        else bool(controller_production_trial_followup_allowed),
        "production_apply_allowed": None if production_apply_allowed is None else bool(production_apply_allowed),
        "certified_for_apply": None if certified_for_apply is None else bool(certified_for_apply),
        "controller_why_not_apply": controller_why_not_apply,
        "controller_selected_bundle_key": controller_selected_bundle_key,
        "candidate_diagnostic_choices": strategy_hints.get("candidate_diagnostic_choices"),
        "generation_control": strategy_hints.get("generation_control"),
        "controller_generation_action": meta.get(
            "generation_action", "unspecified"
            if (strategy_hints.get("generation_control") or {}).get("clock_mode") == "explicit" else "advance"),
        **operation_cards.selection_report(packet, command),
        "candidate_trial_handoffs": strategy_hints.get("candidate_trial_handoffs"),
        "candidate_trial_offer": strategy_hints.get("candidate_trial_offer"),
        "controller_rejected_signals": controller_rejected_signals,
        "controller_selection_source": controller_selection_source,
        **diagnostic_context,
        **production_trial_context,
        **no_safe_guidance,
    }


def _log_pending_observer_check_events(
    logger: StructuredLogger | None,
    *,
    step: int,
    worker_runtime: Any,
) -> None:
    if logger is None:
        return
    reader = getattr(worker_runtime, "pop_observer_check_events", None)
    if not callable(reader):
        return
    for event in reader():
        logger.log({"event": "observer_check", "step": step, **dict(event)})


def _log_pending_tool_events(
    logger: StructuredLogger | None,
    *,
    step: int,
    worker_runtime: Any,
) -> None:
    if logger is None:
        return
    reader = getattr(worker_runtime, "pop_tool_events", None)
    if not callable(reader):
        return
    for event in reader():
        logger.log({"event": "controller_tool_result", "step": step, **dict(event)})


def _log_pending_diagnostic_events(
    logger: StructuredLogger | None,
    *,
    step: int,
    worker_runtime: Any,
) -> None:
    if logger is None:
        return
    reader = getattr(worker_runtime, "pop_diagnostic_events", None)
    if not callable(reader):
        return
    for event in reader():
        logger.log({"event": "controller_diagnostic_result", "step": step, **dict(event)})


def _record_controller_memory(
    worker_runtime: Any,
    command: Any,
    *,
    step: int,
    logger: StructuredLogger | None = None,
) -> None:
    recorder = getattr(worker_runtime, "record_controller_memory", None)
    if not callable(recorder):
        return
    entry, decision = _extract_controller_memory(command)
    if entry is None:
        return
    try:
        recorded = recorder(entry, decision=decision)
    except TypeError:
        recorded = recorder(entry)
    if logger is not None and isinstance(recorded, Mapping):
        logger.log({"event": "controller_memory", "step": step, **dict(recorded)})


def run_episode(
    task_env: TaskEnv,
    worker_runtime: WorkerRuntime,
    controller_client: ControllerClient,
    ctx: StepContext,
    *,
    logger: StructuredLogger | None = None,
    policy: Any | None = None,
    max_controller_diagnostic_rethink_rounds: int = 0,
    max_candidate_handoff_rounds: int = 0,
    generation_clock_mode: str = "legacy",
) -> EpisodeResult:
    if generation_clock_mode not in {"legacy", "explicit"}:
        raise ValueError("generation_clock_mode must be legacy or explicit")
    explicit_clock = generation_clock_mode == "explicit"
    prepare = getattr(worker_runtime, "prepare_initial_observation", None)
    if explicit_clock and not callable(prepare):
        raise ValueError("explicit_clock_requires_initial_observation_support")
    prompt = task_env.reset(seed=ctx.runtime_state.seed)
    worker_runtime.reset(prompt)
    if logger is not None:
        logger.log({"event": "episode_start", "seed": ctx.runtime_state.seed, "prompt": prompt,
                    "generation_clock_mode": generation_clock_mode})

    if explicit_clock:
        initial_prefix = worker_runtime.final_text()
        receipt = prepare()
        if worker_runtime.final_text() != initial_prefix:
            raise PolicyViolation("initial_observation_changed_generated_prefix")
        if logger is not None:
            logger.log({"event": "initial_observation_prepared", **receipt})

    step_count = 0
    pending_trial_expiry = []
    max_handoff_rounds = min(2, max(0, int(max_candidate_handoff_rounds)))
    def commit_generation() -> None:
        nonlocal pending_trial_expiry
        worker_runtime.step()
        # TTL counts generated tokens, not controller/diagnostic rounds. Observe
        # the generated effect before expiring hooks and building the next packet.
        worker_runtime.observe_recent_effects()
        _log_effect_trace(logger, step=step_count, worker_runtime=worker_runtime)
        if pending_trial_expiry:
            for compiled in pending_trial_expiry:
                compiled.rollback(ctx)
                ctx.active_edits.pop(compiled.edit_id, None)
                if logger is not None:
                    logger.log({"event": "production_trial_expired", "step": step_count,
                                "edit_id": compiled.edit_id, "generated_tokens_under_trial": 1})
            pending_trial_expiry = []
        worker_runtime.tick_ttl()
        worker_runtime.cleanup_expired()
        for edit_id, compiled in list(ctx.active_edits.items()):
            compiled.ttl_steps -= 1
            if compiled.ttl_steps <= 0:
                compiled.rollback(ctx)
                ctx.active_edits.pop(edit_id, None)
                if logger is not None:
                    logger.log({"event": "runtime_edit_expired", "step": step_count,
                                "edit_id": edit_id, "reason": "generated_token_ttl_elapsed"})
        _log_pending_observer_check_events(logger, step=step_count, worker_runtime=worker_runtime)
        if explicit_clock and logger is not None:
            logger.log({"event": "generation_token_committed", "step": step_count,
                        "generated_token_count": step_count + 1, "ttl_ticks": 1})

    while not worker_runtime.done():
        if not explicit_clock:
            commit_generation()
        prefix_snapshot = worker_runtime.final_text()
        packet = prefix_control.annotate(worker_runtime.build_controller_packet(),
            rounds_left=max_handoff_rounds, terminal=worker_runtime.done(),
            clock_mode=generation_clock_mode, token_count=step_count)
        clock_report = None
        def guard_clock(command: Any, controller_round: int) -> Any:
            nonlocal clock_report
            if not explicit_clock:
                return command
            clock_report = prefix_control.clock_decision(command,
                rounds_left=max_handoff_rounds - controller_round)
            if logger is not None:
                logger.log({"event": "controller_clock_decision", "step": step_count,
                            "generated_token_count": step_count, "controller_round": controller_round,
                            **clock_report})
            if not clock_report["command_valid"]:
                return _guarded_noop_command(command, noop_reason=clock_report["blocked_reason"])
            return command
        try:
            command = controller_client.invoke(packet)
        except Exception as exc:
            _log_controller_trace(logger, step=step_count, trace=_latest_controller_trace(controller_client))
            if logger is not None:
                logger.log({"event": "controller_error", "step": step_count, "phase": "invoke", "error": str(exc)})
            raise

        command, guard_event = _guard_exhausted_apply_command(command, packet)
        command, budget_guard_event = _guard_budget_violating_apply_command(command, packet, policy=policy)
        command = guard_clock(command, 0)
        _log_controller_trace(logger, step=step_count, trace=_latest_controller_trace(controller_client))

        if logger is not None:
            selection_report = _build_controller_selection_report(packet, command)
            if guard_event is not None:
                logger.log({"event": "controller_guardrail", "step": step_count, **guard_event})
            if budget_guard_event is not None:
                logger.log({"event": "controller_guardrail", "step": step_count, **budget_guard_event})
            logger.log({"event": "controller_command", "step": step_count, "command": command, **selection_report})
            logger.log({"event": "controller_selection", "step": step_count, **selection_report})
        _record_controller_memory(worker_runtime, command, step=step_count, logger=logger)
        auxiliary_requests, auxiliary_results = ([], [])
        if not explicit_clock or clock_report["diagnostics_allowed"]:
            auxiliary_requests, auxiliary_results = _dispatch_controller_observer_and_tools(
                worker_runtime, command, logger=logger, step=step_count)

        diagnostic_requests = (_extract_diagnostic_requests(command, packet)
            if not explicit_clock or clock_report["diagnostics_allowed"] else [])
        diagnostic_results: list[Any] = []
        seen_diagnostic_signatures: set[str] = set()
        diagnostic_next_evidence_before = (
            _diagnostic_requests_next_evidence(diagnostic_requests)
            or _diagnostic_context_next_evidence(packet)
        )
        if diagnostic_requests:
            seen_diagnostic_signatures.update(_diagnostic_request_signature(request) for request in diagnostic_requests)
            requester = getattr(worker_runtime, "request_controller_diagnostics", None)
            if callable(requester):
                try:
                    diagnostic_results = requester(diagnostic_requests, source="controller", packet=packet) or []
                except TypeError:
                    try:
                        diagnostic_results = requester(diagnostic_requests, source="controller") or []
                    except TypeError:
                        diagnostic_results = requester(diagnostic_requests) or []
            if logger is not None:
                for request in diagnostic_requests:
                    request_event = {"event": "controller_diagnostic_request", "step": step_count, **dict(request)}
                    request_event["executed"] = bool(diagnostic_results)
                    logger.log(request_event)
            _log_pending_diagnostic_events(logger, step=step_count, worker_runtime=worker_runtime)

        rethink_round = 0
        candidate_handoff_round = 0
        legacy_rethink_round = 0
        followup_reader = getattr(worker_runtime, "candidate_trial_followup_available", None)
        def handoff_available() -> bool:
            return bool(callable(followup_reader) and followup_reader(diagnostic_results))
        def explicit_hold_available() -> bool:
            if explicit_clock:
                results = [*diagnostic_results, *auxiliary_results]
                if worker_runtime.final_text() != prefix_snapshot:
                    raise PolicyViolation("inspection_changed_generated_prefix")
                if any(isinstance(r, Mapping) and (r.get("state_restored") is False
                       or (isinstance(r.get("evidence"), Mapping)
                           and r["evidence"].get("state_restored") is False)) for r in results):
                    raise PolicyViolation("diagnostic_state_restoration_failed")
                if clock_report["continue_research"] and logger is not None:
                    logger.log({"event": "prefix_inspection_complete", "step": step_count,
                                "controller_round": rethink_round,
                                "generated_token_count": step_count,
                                "generated_tokens_during_inspection": 0,
                                "result_count": len(results),
                                "same_prefix_rounds_left": clock_report["same_prefix_rounds_left"]})
                return bool(clock_report["continue_research"])
            report = prefix_control.evaluate(command,
                [*diagnostic_requests, *auxiliary_requests],
                [*diagnostic_results, *auxiliary_results],
                rounds_left=max_handoff_rounds - candidate_handoff_round, terminal=worker_runtime.done())
            if report is not None and logger is not None:
                logger.log({"event": "controller_prefix_hold", "step": step_count,
                            "controller_round": rethink_round, **report})
            return bool(report and report["accepted"])
        hold_available = explicit_hold_available()
        max_rethink_rounds = max(0, int(max_controller_diagnostic_rethink_rounds))
        readout_escape_rethink_enabled = str(packet.get("control_phase_hint", "") or "") == "readout_escape"
        diagnostic_next_evidence_after = _diagnostic_results_next_evidence(diagnostic_results)
        diagnostic_transition_open = _diagnostic_next_evidence_transition(
            diagnostic_next_evidence_before,
            diagnostic_next_evidence_after,
        )
        if logger is not None and diagnostic_requests:
            logger.log(
                {
                    "event": "controller_loop_patience",
                    "step": step_count,
                    "controller_round": 0,
                    "control_phase_hint": packet.get("control_phase_hint"),
                    "readout_escape_rethink_enabled": bool(readout_escape_rethink_enabled),
                    "loop_patience_budget_left": int(max_rethink_rounds),
                    "next_evidence_before": diagnostic_next_evidence_before,
                    "next_evidence_after": diagnostic_next_evidence_after,
                    "next_evidence_transition": bool(diagnostic_transition_open),
                    "repeated_diagnostic_veto": False,
                    "candidate_handoff_budget_left": max_handoff_rounds,
                    "candidate_handoff_available": handoff_available(),
                }
            )
        while (
            not worker_runtime.done()
            and (explicit_clock or diagnostic_requests or auxiliary_requests)
            and (explicit_clock or diagnostic_results or auxiliary_results)
            and _command_decision(command) == "noop"
            and ((not explicit_clock and legacy_rethink_round < max_rethink_rounds and readout_escape_rethink_enabled and diagnostic_transition_open)
                 or (not explicit_clock and candidate_handoff_round < max_handoff_rounds and handoff_available())
                 or hold_available)
        ):
            rethink_round += 1
            candidate_round = not hold_available and candidate_handoff_round < max_handoff_rounds and handoff_available()
            round_kind = "prefix_inspection" if explicit_clock else "controller_prefix_hold" if hold_available else "candidate_trial_handoff" if candidate_round else "diagnostic_rethink"
            candidate_handoff_round += int(candidate_round or hold_available)
            legacy_rethink_round += int(not (candidate_round or hold_available))
            packet = prefix_control.annotate(worker_runtime.build_controller_packet(),
                rounds_left=max_handoff_rounds - candidate_handoff_round, terminal=worker_runtime.done(),
                clock_mode=generation_clock_mode, token_count=step_count,
                controller_round=rethink_round, last_clock_report=clock_report)
            try:
                command = controller_client.invoke(packet)
            except Exception as exc:
                _log_controller_trace(logger, step=step_count, trace=_latest_controller_trace(controller_client))
                if logger is not None:
                    logger.log(
                        {
                            "event": "controller_error",
                            "step": step_count,
                            "controller_round": rethink_round,
                            "phase": "diagnostic_rethink_invoke",
                            "error": str(exc),
                        }
                    )
                raise

            command, guard_event = _guard_exhausted_apply_command(command, packet)
            command, budget_guard_event = _guard_budget_violating_apply_command(command, packet, policy=policy)
            command = guard_clock(command, rethink_round)
            _log_controller_trace(logger, step=step_count, trace=_latest_controller_trace(controller_client))

            if logger is not None:
                selection_report = _build_controller_selection_report(packet, command)
                if guard_event is not None:
                    logger.log(
                        {
                            "event": "controller_guardrail",
                            "step": step_count,
                            "controller_round": rethink_round,
                            **guard_event,
                        }
                    )
                if budget_guard_event is not None:
                    logger.log(
                        {
                            "event": "controller_guardrail",
                            "step": step_count,
                            "controller_round": rethink_round,
                            **budget_guard_event,
                        }
                    )
                logger.log(
                    {
                        "event": "controller_command",
                        "step": step_count,
                        "controller_round": rethink_round,
                        "controller_round_kind": round_kind,
                        "command": command,
                        **selection_report,
                    }
                )
                logger.log(
                    {
                        "event": "controller_selection",
                        "step": step_count,
                        "controller_round": rethink_round,
                        "controller_round_kind": round_kind,
                        **selection_report,
                    }
                )
            _record_controller_memory(worker_runtime, command, step=step_count, logger=logger)

            auxiliary_requests, auxiliary_results = ([], [])
            if not explicit_clock or clock_report["diagnostics_allowed"]:
                auxiliary_requests, auxiliary_results = _dispatch_controller_observer_and_tools(
                    worker_runtime, command, logger=logger, step=step_count,
                    controller_round=rethink_round)

            diagnostic_requests = (_extract_diagnostic_requests(command, packet)
                if not explicit_clock or clock_report["diagnostics_allowed"] else [])
            diagnostic_requests, repeated_diagnostic_requests = _filter_repeated_diagnostic_requests(
                diagnostic_requests,
                seen_diagnostic_signatures,
            )
            if logger is not None and repeated_diagnostic_requests:
                for request in repeated_diagnostic_requests:
                    logger.log(
                        {
                            "event": "controller_diagnostic_veto",
                            "step": step_count,
                            "controller_round": rethink_round,
                            "reason": "repeated_diagnostic_veto",
                            "repeated_diagnostic_veto": True,
                            "loop_patience_budget_left": max(0, max_rethink_rounds - legacy_rethink_round),
                            **dict(request),
                        }
                    )
            diagnostic_next_evidence_before = (
                _diagnostic_requests_next_evidence(diagnostic_requests)
                or _command_next_evidence_needed(command)
                or _diagnostic_context_next_evidence(packet)
                or diagnostic_next_evidence_after
            )
            diagnostic_results = []
            if diagnostic_requests:
                seen_diagnostic_signatures.update(
                    _diagnostic_request_signature(request) for request in diagnostic_requests
                )
                requester = getattr(worker_runtime, "request_controller_diagnostics", None)
                if callable(requester):
                    try:
                        diagnostic_results = requester(diagnostic_requests, source="controller", packet=packet) or []
                    except TypeError:
                        try:
                            diagnostic_results = requester(diagnostic_requests, source="controller") or []
                        except TypeError:
                            diagnostic_results = requester(diagnostic_requests) or []
                if logger is not None:
                    for request in diagnostic_requests:
                        request_event = {
                            "event": "controller_diagnostic_request",
                            "step": step_count,
                            "controller_round": rethink_round,
                            **dict(request),
                        }
                        request_event["executed"] = bool(diagnostic_results)
                        logger.log(request_event)
                _log_pending_diagnostic_events(logger, step=step_count, worker_runtime=worker_runtime)
            diagnostic_next_evidence_after = _diagnostic_results_next_evidence(diagnostic_results)
            hold_available = explicit_hold_available()
            diagnostic_transition_open = _diagnostic_next_evidence_transition(
                diagnostic_next_evidence_before,
                diagnostic_next_evidence_after,
            )
            if logger is not None:
                logger.log(
                    {
                        "event": "controller_loop_patience",
                        "step": step_count,
                        "controller_round": rethink_round,
                        "control_phase_hint": packet.get("control_phase_hint"),
                        "readout_escape_rethink_enabled": bool(readout_escape_rethink_enabled),
                        "loop_patience_budget_left": max(0, max_rethink_rounds - legacy_rethink_round),
                        "next_evidence_before": diagnostic_next_evidence_before,
                        "next_evidence_after": diagnostic_next_evidence_after,
                        "next_evidence_transition": bool(diagnostic_transition_open),
                        "repeated_diagnostic_veto": bool(repeated_diagnostic_requests),
                        "candidate_handoff_budget_left": max(0, max_handoff_rounds - candidate_handoff_round),
                        "candidate_handoff_available": handoff_available(),
                    }
                )

        trial_validator = getattr(worker_runtime, "validate_controller_trial", None)
        if _command_decision(command) == "apply":
            rejection_reason = "trial_authorization_rejected"
            try:
                if worker_runtime.done():
                    rejection_reason = "no_next_token_for_edit"
                    raise PolicyViolation(rejection_reason)
                if callable(trial_validator):
                    command = trial_validator(command, packet)
            except PolicyViolation as exc:
                command = _guarded_noop_command(command,
                    noop_reason=rejection_reason, apply_block_reason=str(exc))
                command["meta"].update(blocked_by=str(exc), why_not_apply=str(exc))
                _record_controller_memory(worker_runtime, command, step=step_count, logger=logger)
                if logger is not None:
                    logger.log({"event": "controller_guardrail", "step": step_count,
                                "controller_round": rethink_round, "reason": rejection_reason, "detail": str(exc)})
                    logger.log({"event": "controller_command", "step": step_count,
                                "controller_round_kind": "trial_guardrail", "command": command,
                                **_build_controller_selection_report(packet, command)})
                    logger.log({"event": "controller_selection", "step": step_count,
                                "controller_round_kind": "trial_guardrail",
                                **_build_controller_selection_report(packet, command)})
        try:
            compiled_edits = compile_command(command, packet, ctx, policy=policy)
        except Exception as exc:
            if logger is not None:
                logger.log({"event": "controller_error", "step": step_count, "phase": "compile", "error": str(exc)})
            raise

        for compiled in compiled_edits:
            compiled.apply(ctx)
            if compiled.kind == "rollback":
                ctx.active_edits.pop(compiled.edit_id, None)
            else:
                ctx.active_edits[compiled.edit_id] = compiled
            if logger is not None:
                logger.log(
                    {
                        "event": "compiled_edit",
                        "step": step_count,
                        "edit_id": compiled.edit_id,
                        "kind": compiled.kind,
                        "ttl_steps": compiled.ttl_steps,
                    }
                )

        if compiled_edits:
            consume_trial = getattr(worker_runtime, "consume_controller_trial", None)
            if callable(consume_trial):
                consume_trial(command)
        if not explicit_clock or compiled_edits:
            worker_runtime.observe_recent_effects()
            _log_effect_trace(logger, step=step_count, worker_runtime=worker_runtime)
        production_trial_apply_executed = (
            _command_decision(command) == "apply"
            and _optional_meta_text(_command_meta(command) or {}, "apply_kind") == "production_trial"
            and bool(compiled_edits)
        )
        if production_trial_apply_executed:
            pending_trial_expiry = list(compiled_edits)
            if logger is not None:
                logger.log(
                    {
                        "event": "production_trial_ttl_deferred",
                        "step": step_count,
                        "reason": "trial edit must survive one generated token before ttl tick",
                    }
                )
        if explicit_clock:
            if logger is not None:
                logger.log({"event": "generation_commit", "step": step_count,
                            "generated_token_count_before": step_count,
                            "commit_source": clock_report["commit_source"],
                            "controller_rounds": rethink_round + 1,
                            "final_edit_decision": _command_decision(command),
                            "compiled_edit_count": len(compiled_edits)})
            commit_generation()
        step_count += 1

    output = worker_runtime.final_text()
    score = task_env.score(output)
    if logger is not None:
        logger.log(
            {
                "event": "episode_end",
                "steps": step_count,
                "output": output,
                "score": score,
                "task_done": task_env.done(output),
            }
        )
    return EpisodeResult(prompt=prompt, output=output, score=score, steps=step_count)
