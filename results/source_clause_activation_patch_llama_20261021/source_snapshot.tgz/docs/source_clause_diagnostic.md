# Source-bound clause readout diagnostic

Date: 2026-10-20. Follows the merged #32-34 ceiling, dose-response and
[clause-structure survey](clause_structure_survey.md).

## Evidence carried forward

The stored survey has nine cases, six failed natural continuations and three
cases with a successful forced-connective branch. At the L1 review prefix
`Nora will take the sample to Ivo`, the stored `,` rank is 2 and its top-1
logit gap is 1.125. Seven of 90 source-patch curves win the structural token,
but only with released caps and large changes at L25-L27. These are historical
quarantined measurements, not new live results, controller choices or normal-cap
intervention success.

This suggests observing structural alternatives alongside missing-name
reachability. It does not justify promoting a known successful separator into
the controller's policy, raising caps, or treating a lexical score as role
preservation.

## New contract

`--clause-structure-diagnostics` is opt-in on the main example CLI (paired,
C1-only and seed-sweep paths). It offers `source_clause_structure_probe` in the
existing diagnostic menu. Default runs are unchanged.

The runtime extracts up to 12 distinct **actual source-body token IDs** whose
complete decoded pieces match a fixed connective/punctuation vocabulary.
Repeated occurrences share one row with source positions. Header and answer
prefix tokens, names, subpieces of longer words and unseen connectives are not
inferred or added. Natural connectives such as `before` and terminal punctuation
are retained; this is not a list of past rescue tokens. Source order is preserved.
For example, `;` is not offered merely because a past forced-token survey found
it useful if it does not occur in the current source.

The offer is available at any nonempty, nonterminal prefix with source
structural tokens, no active edits and remaining diagnostic budget. No role-frame annotation,
expected missing clause, successful position or future continuation determines
its availability. The controller chooses whether and where to request it.
One optional offer is appended without replacing the existing frontier or
displacing the original menu entries.

Execution uses one restored, unedited next-token replay. Active patches are
excluded in v1 so their effects or hook telemetry cannot be mistaken for a
no-edit observation. Each row reports its
exact vocabulary rank, probability, logit, gap to the current greedy token,
top-20 membership and source positions. This is the readout **after existing
decode constraints and decoder control**, not an unprocessed model logit.
Tied best rank is not called a greedy win; the argmax token is recorded
separately. Masked tokens have null rank/logit/gap rather than infinite JSON.

The request binds the prompt, exact current tokens, active edits, model config,
decode settings and source token catalog. A stale or missing ID is rejected
without work or charge. Each context is attempted once per episode, surviving
diagnostic history eviction; forward errors remain failed attempts rather than
positive evidence. A changed prefix permits another observation. Successful or
failed physical attempts cost one existing diagnostic slot, invalid/duplicate
requests cost zero, and generation/TTL do not advance. Exhausted budgets do not
offer executable cards.

Operation-card and legacy requests preserve this exact context instead of
inheriting another frontier's objective or expansion mode. Compact packets and
results retain binding, costs, masked rows, state restoration and the permission
boundary:

```text
current-prefix readout != operator effect
source structure visibility != clause rescue
diagnostic observation != apply permission
```

No operator candidate, frozen response card, trial offer or certification is
created by this diagnostic. It does not call the offline role checker or change
the legacy evaluator. Caps, alpha budgets, trial gates and controller prompts
are unchanged.

## Narrow verification

The replay harness below checks checkpoint hashes and the recorded prompt, then
decodes normally to the requested prefixes. Each full decoded prefix must equal
the recorded observation; clipped tails or drift fail closed. It resolves the
offered operation ID through the normal runtime dispatcher, asserts restored
state and writes a fresh receipt without overwriting an existing output.

```sh
SRC=results/entity_probe_refresh_llama_20261014_retry1
python3 -m SpiralInterventionLab.examples.replay_source_clause_diagnostic \
  --source-jsonl "$SRC/live/c1.jsonl" \
  --source-manifest "$SRC/manifest.json" \
  --worker-model-path "$LLAMA_MODEL_PATH" \
  --positions 7,8,9 \
  --output results/<new_dir>/source_clause_readout.json
```

There are no provider calls, forced tokens, raised caps or edited continuations.
This harness requests observations itself; it **does not measure Luna's choice**
and does not reconstruct the historical diagnostic ledger. The chosen positions
are an explicit retrospective fixture, not a discovered optimum.

Fresh Llama loading was deferred on 2026-10-20: available disk space was about
5.2 GiB, below the space available at an earlier swap-related reboot. Other
local experiments and saved outputs were not modified. Tests use synthetic
readouts and cover ID binding, source filtering, duplicate/error accounting,
state restoration, compact delivery and card dispatch; they are not new model
efficacy evidence.

Validation on 2026-10-20:
`python3 -m pytest SpiralInterventionLab/tests -q --tb=short` completed with
617 passed, 9 subtests passed and 14 dependency deprecation warnings.
`git diff --check` passed. No new Llama/GPT-2 checkpoint was loaded and no
provider/interview call was made in this verification.

## Matched-prefix observation on 2026-10-21

The provider-free Llama replay completed after disk space was freed. The local
checkpoint files matched the source manifest's SHA-256 values, and all three
decoded prefixes matched the recorded episode exactly. The run used the full
28-layer Llama-3.2-3B-Instruct checkpoint, float16, MPS, seed 0 and the L1 rewrite
fixture. No cap, model precision or decode policy was changed to obtain a match.

Receipts:

- [Readout measurements](../results/source_clause_diagnostic_llama_20261021/source_clause_readout.json)
- [Historical readout comparison](../results/source_clause_diagnostic_llama_20261021/readout_audit.json)
- [Source and receipt hashes](../results/source_clause_diagnostic_llama_20261021/sha256.txt)

| Generated tokens | Prefix ending | Greedy next piece | Comma rank | Comma gap to top-1 | ` while` rank | ` while` gap |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| 7 | `to I` | `vo` | 62 | 17.492188 | 3025 | 24.296875 |
| 8 | `to Ivo` | ` before` | 2 | 1.125000 | 7 | 4.218750 |
| 9 | `to Ivo before` | ` sending` | 75 | 8.265625 | 787 | 11.511719 |

At prefix 8, the comma and ` while` ranks and gaps exactly reproduce the stored
survey's pre-intervention measurements. Those are the two overlapping
source-bound pieces at the surveyed position; this is not a claim that every
historical result was reproduced. The current source also contributes
` before` and `.\n`. It does not contribute the survey's unseen `;` or ` and`.

All three observations preserved tokens, cache, runtime step and active-edit
state. Each used one diagnostic slot: 12 -> 11 -> 10 -> 9. There were three
unedited physical replays, zero edited replays and zero provider calls.
`production_apply_allowed`, `certified_for_apply` and `policy_candidate_ready`
remained false. The harness selected the cards; Luna did not select them.

The narrow observation is a sharply position-dependent structural alternative
in this single trajectory: comma is much nearer the greedy readout after the
complete recipient name than immediately before or after that point. It does
not establish a safe operator, a causal rescue, a general clause-boundary rule
or task-score improvement. Prefix 7 is still inside the tokenized name `Ivo`.
The replay stops at prefix 9 rather than evaluating a new completed answer.

Resource note: available disk space started near 19 GiB, briefly fell to about
8 GiB during loading, and was about 11 GiB after process exit. No other local
experiment was stopped and no saved output was removed. MPS emitted its backend
correctness warning; the checkpoint/prefix/readout matches above are narrow
checks, not a validation of all MPS computations.

Post-run checks: `test_clause_structure.py` and `test_operation_cards.py`
completed with 36 passed and 14 dependency deprecation warnings.
`git diff --check` passed. Package versions and the dirty-source commit/branch
are recorded in
[environment.json](../results/source_clause_diagnostic_llama_20261021/environment.json).

## Next experiment

The three-prefix observation is now complete. The frozen choice protocol below
tests interface use before any new operator experiment.

Only after that interface test should an independently measured, normal-cap
structure-target operator be offered. Source attention/KV routes and
norm-relative cap policy remain separate research/design decisions. Visibility
alone is not a reason to authorize a punctuation-writing intervention.

## Frozen Luna choice protocol

The comparison is bounded to the retrospectively selected prefix 8. Selection
of this prefix uses the earlier observation; it is not a blind search for a
boundary. The worker reconstructs the prefix once without the historical
diagnostic ledger and exports three inputs:

- `off`: existing packet and offers, with only the source-clause offer and its
  explanatory hint removed.
- `offered`: the same packet with the additional optional observation.
- `observed`: the same generation position after the harness measured that
  observation, including the result and one spent diagnostic slot.

The old requests, order, costs and availability must match in `off` and
`offered`. Operation IDs bind whole packets, so IDs necessarily change across
conditions; the test compares their resolved request semantics, not ID bytes.
No forced-rescue continuation, offline role verdict, winning dose or preferred
separator is included. Pre-observation inputs must not contain measured
structure-readout rows.

`gpt-5.6-luna` uses the unchanged operation-card prompt and compact projection.
Each call is independent, with no conversational carry-over. The fixed order
is `off, offered, offered, off, observed, observed`: two observations per
condition, not enough to estimate a general selection effect. The result-shown
condition is **harness-supplied evidence**, not a claim that Luna first chose
the probe and then received its result in an interactive rollout.

The comparator loads no local model and dispatches none of Luna's selected
commands. It retains raw first replies, parse failures, input hashes and usage.
There is one attempt per call, no SDK retry, a 180-second request timeout and
at most six requests. API failures stop the batch and preserve the partial
receipt. A dry run validates and saves inputs without provider calls.

```sh
python3 -m SpiralInterventionLab.examples.replay_source_clause_diagnostic \
  --source-jsonl "$SRC/live/c1.jsonl" \
  --source-manifest "$SRC/manifest.json" \
  --worker-model-path "$LLAMA_MODEL_PATH" \
  --positions 8 --export-controller-packets \
  --output results/<new_dir>/frozen_prefix8.json

python3 -m SpiralInterventionLab.examples.compare_source_clause_choices \
  --source-receipt results/<new_dir>/frozen_prefix8.json \
  --controller-model gpt-5.6-luna --dry-run \
  --output results/<new_dir>/choice_preflight.json

python3 -m SpiralInterventionLab.examples.compare_source_clause_choices \
  --source-receipt results/<new_dir>/frozen_prefix8.json \
  --controller-model gpt-5.6-luna \
  --output results/<new_dir>/luna_choices.json
```

## Luna observations on 2026-10-21

The fresh prefix-8 export again reproduced comma rank 2 / gap 1.125 and
` while` rank 7 / gap 4.21875. The dry run passed before the six provider calls.
All six first replies parsed without a repair attempt and all frozen packets
were unchanged after invocation.

| Condition | Calls | Source-clause selections | Other diagnostic selections | Apply commands |
| --- | ---: | ---: | ---: | ---: |
| off | 2 | 0 | 0 | 0 |
| offered | 2 | 1 | 0 | 0 |
| observed | 2 | 0 | 0 | 0 |

The selected source-clause operation resolved to the exact offered context ID
and requested `hold_prefix`. The other offered-condition reply declined
diagnostics, citing improving progress and lack of a certified intervention.
The result-shown replies did not re-request the consumed probe. Neither reply's
short rationale establishes that the structural measurements changed its
decision; both cited progress and unavailable certified actions.

One `off` reply requested `hold_prefix` without an accompanying evidence request.
It is valid ControllerCommand JSON, but the existing `prefix_control.evaluate`
function rejects that hold with `no_fresh_requested_result`. This was checked
statically against the recorded command, not dispatched or silently repaired.
Parser success is therefore not a claim that all six clock decisions could
execute as written.

Important limitations:

- The fresh reconstructed context offered **zero** old diagnostic cards.
  `offered` added one; this tests uptake of an optional tool, not prioritization
  among competing diagnostic cards.
- This harness retains the earlier replay's **legacy** clock annotation.
  It does not test the explicit inspect/commit-clock interface.
- The task feedback at this prefix was `progressing`, partial score 0.694444,
  with four of nine required terms present. The measurements do not prove
  that choosing advance was irrational, or that the controller anticipated the
  later clause omission.
- Two calls per condition at one retrospectively selected position are not an
  estimate of reliability. The mixed offered-condition decisions are retained.
- The six choices dispatched no diagnostics, applied no edit and generated no
  worker continuation. The separate packet-export replay made one unedited
  observation. There is no new task-score or operator-effect result.

The evidence narrows the interface question: the source-bound tool can be
selected by exact ID, but optional availability does not guarantee uptake.
Result visibility alone supplies neither an executable structural operator nor
permission. Do not tune the prompt to make the recorded comma win. An explicit
clock / genuinely competing-menu comparison would be a separate interface
experiment; a normal-cap structure-target operator replay would be a separate
actuation experiment.

Receipts:

- [Frozen inputs and readout](../results/source_clause_luna_choices_20261021/frozen_prefix8.json)
- [Preflight](../results/source_clause_luna_choices_20261021/choice_preflight.json)
- [First replies and usage](../results/source_clause_luna_choices_20261021/luna_choices.json)
- [Choice audit](../results/source_clause_luna_choices_20261021/choice_audit.json)
- [Static hold-contract audit](../results/source_clause_luna_choices_20261021/hold_contract_audit.json)

Provider usage across the six calls: 72,692 input tokens, including 36,337
cached input tokens, and 961 output tokens; 73,653 total. No extra interview,
repair or retry call was made.

Post-comparison validation: the full suite completed with 623 passed,
9 subtests passed and 14 dependency deprecation warnings. New tests cover
off/on invariance, exact request preservation, corrupt or leaking snapshots,
six-call bounds, retained invalid first replies and stopping on provider error.

## Normal-cap operator connection

`source_clause_activation_patch_probe` is a separate, opt-in instrument behind
`--clause-structure-operator-diagnostics`, which also requires
`--clause-structure-diagnostics`. Observational runs are unchanged by default.

The controller receives one optional operation card per measured SOURCE token.
The card resolves to a context-bound operator ID, not a free-form patch. It does
not displace the existing frontier, nominate the comma, or prefer candidates by
historical rescue results. A successful source-clause observation at the exact
current prefix is required. Stale requests, missing cache, lost observations,
active patches and exhausted budgets do not create an executable offer.

Materialization binds the actual source token ID and its **first SOURCE
occurrence** directly. It does not retokenize punctuation through the entity
resolver or fall back to the constraint header. For each target, the recipe uses
the last *already offered* layer of `resid_pre` and `mlp_out`, where present.
This is not necessarily the model's final layer. No new surface is opened.
The fixed recipe is `activation_patch/blend`, alpha at most 0.04, step size at
most 0.08, each further bounded by the existing surface caps, and TTL 1.
There is no policy override or cap release.

One request costs at most one diagnostic slot and **four physical one-token
replays for one site, six for two sites**: two no-edit controls, then two repeats
per edited site. Every simulation must restore the prefix, logits, cache and
hooks before the next call. Preflight failures are free and consumed at that
context; failed physical attempts are retained and charged once. Hook execution
must be observed, not inferred from registration. Caps are checked unchanged.

The report retains exact source tensor identities, edit payloads, fingerprints,
hook telemetry, paired deltas and repeat variation. It measures all observed
source structure tokens to distinguish intended-token response from cross-token
lift. Effect labels require agreement in both repeats above observed repeat
variation; the mass-lift reporting threshold is 1e-4, or a top-20 entry.
Gap/rank-only movement remains distinct. This threshold labels diagnostic
evidence; it does not certify an actuator. Ownership is limited to the observed
structure-token set, not semantic roles or causal path fidelity.

One-token repetition/entropy/margin changes are reported, but clause correctness
and semantic safety remain **unassessed**. Even a target-aligned positive result
does not mint a frozen apply card, trial offer or production permission. A
positive punctuation logit is not a rescued rewrite.

For a bounded local pass, request every offered token in SOURCE order at one
recorded prefix, with no provider calls:

```sh
python3 -m SpiralInterventionLab.examples.replay_source_clause_diagnostic \
  --source-jsonl "$SRC/live/c1.jsonl" \
  --source-manifest "$SRC/manifest.json" \
  --worker-model-path "$LLAMA_MODEL_PATH" \
  --positions 8 --measure-source-operators \
  --output results/<new_dir>/normal_cap_structure_patch.json
```

This is harness-selected measurement, not evidence of controller uptake.
It is deliberately separate from the frozen Luna visibility comparison.
