import json
import subprocess
import sys
import tempfile
import unittest
from importlib.util import find_spec
from pathlib import Path
from unittest.mock import patch

import torch

from SpiralInterventionLab.controllers.base import ControllerProvider, ControllerProviderRequest, ControllerProviderResponse
from SpiralInterventionLab.examples import (
    create_task_env,
    create_readout_analyzer,
    create_readout_sidecar_analyzer,
    build_default_activation_surface_catalog,
    build_allowed_token_ids_for_constraint,
    build_hooked_transformer_worker_runtime,
    load_worker_model,
    run_readout_escape_replay_harness,
    run_shot_mode_probe_harness,
    run_digit_transform_c1_only_experiment,
    run_digit_transform_experiment,
    run_digit_transform_sweep,
)
from SpiralInterventionLab.examples.digit_transform_e2e import (
    _FrontierReplayControllerClient,
    _build_parser,
    build_post_run_debrief_packet,
    _configure_torch_default_device_for_worker,
    _controller_step_views,
    _diagnostic_evidence_ledger,
    _effective_diagnostic_frontier_summary,
    _focused_bridge_eval_recipe_specs,
    _infer_tlens_model_ref,
    _resolve_worker_device,
    write_post_run_debrief_artifacts,
)
from SpiralInterventionLab.examples.summarize_activation_patch_jsonl import summarize_activation_patch_jsonl
from SpiralInterventionLab.examples.compare_activation_patch_jsonl import compare_activation_patch_runs
from SpiralInterventionLab.runtime.codecs import CharacterCodec, ModelTokenizerCodec
from SpiralInterventionLab.runtime import candidate_handoff
from SpiralInterventionLab.runtime.diagnostic_orchestration import (
    completed_expansion_keys,
    confirmed_gap_only_objective_rows,
    expansion_already_replayed,
    operator_family_shift_canonical_request,
    readout_gap_confirmation_seen_for_objective,
)
from SpiralInterventionLab.runtime.loop import (
    _build_controller_selection_report,
    _extract_diagnostic_requests,
    _extract_observer_check_request,
)
from SpiralInterventionLab.runtime.sidecar import (
    ReadoutSidecarCapture,
    ReadoutSidecarSiteCapture,
    normalize_readout_sidecar_hints,
)
from SpiralInterventionLab.runtime.worker import HookedTransformerWorkerRuntime
from SpiralInterventionLab.tasks import (
    SpiralConstrainedRewriteEnv,
    SpiralDigitCopyEnv,
    SpiralDigitTransformEnv,
    SpiralEasyConstrainedRewriteEnv,
    SpiralEntailmentReasoningEnv,
    SpiralSentenceOrderingEnv,
    SpiralStructuredSummaryEnv,
)

HAS_TRANSFORMER_LENS = bool(find_spec("transformer_lens"))
if HAS_TRANSFORMER_LENS:
    from transformer_lens import HookedTransformer, HookedTransformerConfig


class _NoopProvider(ControllerProvider):
    @property
    def provider_name(self) -> str:
        return "fake"

    @property
    def model_name(self) -> str:
        return "fake-controller"

    def complete(self, request: ControllerProviderRequest) -> ControllerProviderResponse:
        text = '{"version":"0.1","decision":"noop"}' if request.expect_json else ""
        return ControllerProviderResponse(
            text=text,
            provider=self.provider_name,
            model=self.model_name,
            raw={"seen_payload": request.payload_text()},
        )


class _DebriefProvider(ControllerProvider):
    def __init__(self):
        self.last_request: ControllerProviderRequest | None = None

    @property
    def provider_name(self) -> str:
        return "fake"

    @property
    def model_name(self) -> str:
        return "fake-debrief"

    def complete(self, request: ControllerProviderRequest) -> ControllerProviderResponse:
        self.last_request = request
        return ControllerProviderResponse(
            text=(
                "## What happened?\n"
                "- The controller completed a quarantined debrief.\n"
                "## What made the run difficult?\n"
                "- Evidence stayed diagnostic-only.\n"
                "## Most likely failure factors\n"
                "- No certified actuator.\n"
                "## Evidence supporting this reading\n"
                "- controller_command events were present.\n"
                "## What I would try next\n"
                "- Request more diagnostics.\n"
                "## What would have made this easier?\n"
                "- A compact diagnostic affordance ledger would help.\n"
                "## What should not be concluded\n"
                "- This is not a score.\n"
                "## Controller-perspective note\n"
                "- I would describe the run as diagnostic-only."
            ),
            provider=self.provider_name,
            model=self.model_name,
            usage={"output_tokens": 64},
        )


class _FakeTokenizer:
    def decode(self, token_ids, clean_up_tokenization_spaces=False):
        mapping = {0: " ", 1: "1", 2: " 2", 3: "a"}
        return "".join(mapping[int(token_id)] for token_id in token_ids)


class _FakeCodecModel:
    def __init__(self):
        self.tokenizer = _FakeTokenizer()

    def to_tokens(self, text: str, prepend_bos: bool = False):
        return __import__("torch").tensor([[1 if char == "1" else 0 for char in text]], dtype=__import__("torch").long)

    def to_string(self, tensor):
        return ["should-not-leak-list-format"]


class _FakeHFConfig:
    def __init__(self, **kwargs):
        self.model_type = kwargs.get("model_type", "llama")
        self.hidden_size = kwargs.get("hidden_size", 3072)
        self.num_hidden_layers = kwargs.get("num_hidden_layers", 28)
        self.vocab_size = kwargs.get("vocab_size", 128256)


class _StubSemanticCritic:
    mode = "minilm"
    model_name = "stub-minilm"

    def score(self, *, reference_text: str, candidate_text: str) -> float:
        return 0.75


class TestPostRunDebrief(unittest.TestCase):
    def test_build_post_run_debrief_packet_quarantines_freeform_memo_context(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            log_path = Path(temp_dir) / "c1.jsonl"
            log_path.write_text(
                "\n".join(
                    [
                        json.dumps({"event": "controller_command", "step": 0, "decision": "noop"}),
                        json.dumps({"event": "episode_end", "steps": 1, "output": "the the", "score": 0.45}),
                    ]
                )
                + "\n",
                encoding="utf-8",
            )
            packet = build_post_run_debrief_packet(
                result_payload={
                    "suite_mode": "c1_only",
                    "task_id": "constrained_rewrite_easy",
                    "seed": 7,
                    "c1": {"output": "the the", "score": 0.45, "steps": 1},
                },
                log_dir=temp_dir,
            )

        self.assertTrue(packet["qualitative_only"])
        self.assertTrue(packet["not_for_scoring"])
        self.assertTrue(packet["not_for_future_context"])
        self.assertTrue(packet["do_not_autofeed_into_next_run"])
        self.assertIn("What would have made this easier?", packet["required_output_sections"])
        self.assertEqual(packet["output_diet_contract"]["max_bullets_per_section"], 3)
        self.assertIn("missing_signal", packet["output_diet_contract"]["what_would_have_helped_schema"])
        self.assertEqual(packet["run_result_digest"]["task_id"], "constrained_rewrite_easy")
        self.assertEqual(packet["log_digest"]["event_counts"]["controller_command"], 1)
        self.assertEqual(packet["log_digest"]["event_counts"]["episode_end"], 1)

    def test_write_post_run_debrief_artifacts_uses_plain_text_request(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            log_path = Path(temp_dir) / "c1.jsonl"
            log_path.write_text(
                json.dumps({"event": "controller_command", "step": 0, "decision": "noop"}) + "\n",
                encoding="utf-8",
            )
            provider = _DebriefProvider()

            artifact = write_post_run_debrief_artifacts(
                provider=provider,
                result_payload={
                    "suite_mode": "c1_only",
                    "task_id": "constrained_rewrite_easy",
                    "c1": {"output": "the the", "score": 0.45, "steps": 1},
                },
                log_dir=temp_dir,
                max_output_tokens=333,
            )

            markdown_path = Path(artifact["markdown_path"])
            json_path = Path(artifact["json_path"])
            saved = json.loads(json_path.read_text(encoding="utf-8"))

        self.assertIsNotNone(provider.last_request)
        self.assertFalse(provider.last_request.expect_json)
        self.assertEqual(provider.last_request.max_output_tokens, 333)
        self.assertEqual(provider.last_request.metadata["qualitative_only"], "true")
        self.assertEqual(provider.last_request.metadata["not_for_scoring"], "true")
        self.assertIn("not hidden chain-of-thought", provider.last_request.system_prompt)
        self.assertIn("Controller-perspective note", provider.last_request.system_prompt)
        self.assertIn("What would have made this easier?", provider.last_request.system_prompt)
        self.assertIn("must not authorize interventions", provider.last_request.system_prompt)
        self.assertIn("Do not claim private feelings", provider.last_request.system_prompt)
        self.assertTrue(markdown_path.name.endswith("post_run_debrief.md"))
        self.assertEqual(json_path.name, "post_run_debrief.json")
        self.assertTrue(saved["qualitative_only"])
        self.assertTrue(saved["not_for_scoring"])
        self.assertTrue(saved["not_for_future_context"])
        self.assertIn("## What happened?", saved["debrief_text"])
        self.assertIn("## What would have made this easier?", saved["debrief_text"])
        self.assertIn("## Controller-perspective note", saved["debrief_text"])

    def test_parser_accepts_post_run_debrief_flags(self):
        parser = _build_parser()

        args = parser.parse_args(
            [
                "--provider",
                "openai",
                "--controller-model",
                "gpt-5.5",
                "--log-dir",
                "results/demo",
                "--post-run-debrief",
                "controller",
                "--post-run-debrief-model",
                "gpt-5.5",
                "--post-run-debrief-max-output-tokens",
                "999",
            ]
        )

        self.assertEqual(args.post_run_debrief, "controller")
        self.assertEqual(args.post_run_debrief_model, "gpt-5.5")
        self.assertEqual(args.post_run_debrief_max_output_tokens, 999)
        self.assertEqual(args.controller_prompt_profile, "compact")
        self.assertEqual(args.controller_packet_view, "compact")

    def test_parser_accepts_controller_diet_flags(self):
        parser = _build_parser()

        args = parser.parse_args(
            [
                "--provider",
                "openai",
                "--controller-model",
                "gpt-5.5",
                "--controller-prompt-profile",
                "full",
                "--controller-packet-view",
                "full",
                "--controller-prompt-asset",
                "controller_v01.txt",
                "--max-diagnostic-calls-per-run",
                "12",
                "--diagnostic-result-window",
                "12",
            ]
        )

        self.assertEqual(args.controller_prompt_profile, "full")
        self.assertEqual(args.controller_packet_view, "full")
        self.assertEqual(args.controller_prompt_asset, "controller_v01.txt")
        self.assertEqual(args.max_diagnostic_calls_per_run, 12)
        self.assertEqual(args.diagnostic_result_window, 12)


class TestObserverAndEntityProbeContracts(unittest.TestCase):
    def test_diagnostic_orchestration_helpers_keep_evidence_apply_closed(self):
        diagnostic_results = [
            {
                "diagnostic": "readout_gap_confirmation_or_variant_sweep",
                "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                "objective_bundle_key": "entity_insert:budget:source_body:weak_reachable",
                "recorded_step": 4,
                "readout_deepening_review_summary": {
                    "objective_bundle_key": "entity_insert:budget:source_body:weak_reachable",
                    "best_candidate_role": "gap_closer_candidate",
                    "production_trial_eligible": False,
                    "gap_delta": -0.002,
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                },
            }
        ]

        self.assertTrue(
            readout_gap_confirmation_seen_for_objective(
                diagnostic_results,
                "entity_insert:budget:source_body:weak_reachable",
            )
        )
        rows = confirmed_gap_only_objective_rows(
            diagnostic_results,
            term_resolver=lambda objective_key: objective_key.split(":")[1],
        )
        self.assertEqual(rows[0]["objective_status"], "confirmed_gap_only_no_target_lift")
        self.assertFalse(rows[0]["rotation_eligible"])

        request = operator_family_shift_canonical_request(
            objective_bundle_key=rows[0]["objective_bundle_key"],
            objective_term=rows[0]["term"],
            seed_recipe_id="readout_deepen_target_pure_a060_gap",
            seed_recipe_family="readout_steering|carrier_to_actuator_conversion",
        )

        self.assertEqual(request["operator_recipe_expansion_mode"], "non_kv_operator_search")
        self.assertFalse(request["production_apply_allowed"])
        self.assertFalse(request["policy_candidate_ready"])
        self.assertGreater(len(request["operator_family_shift_preview_rows"]), 0)

    def test_observer_check_next_action_maps_to_default_semantic_request(self):
        request = _extract_observer_check_request(
            {
                "version": "0.1",
                "decision": "noop",
                "meta": {
                    "next_action": "request_observer_check",
                    "micro_rationale": "Check semantic grounding before another edit.",
                },
            }
        )

        self.assertIsNotNone(request)
        self.assertEqual(request["kind"], "semantic_progress")
        self.assertEqual(request["trigger"], "controller_next_action")
        self.assertIn("semantic grounding", request["reason"])

    def test_target_entity_probe_next_action_maps_to_diagnostic_request(self):
        requests = _extract_diagnostic_requests(
            {
                "version": "0.1",
                "decision": "noop",
                "meta": {
                    "next_action": "request_target_entity_insertion_probe",
                    "objective_bundle_key": "kv_pair:budget:source_body:72:73",
                    "why_not_apply": "inspect target terms before another entity edit",
                },
            },
            {
                "strategy_hints": {
                    "diagnostic_frontier_bundle_key": "kv_pair:budget:source_body:72:73",
                    "diagnostic_frontier_next_evidence": "early_target_entity_insertion_probe",
                    "diagnostic_frontier_reason_text": "missing payload terms remain early",
                }
            },
        )

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "target_entity_insertion_probe")
        self.assertEqual(requests[0]["objective_bundle_key"], "kv_pair:budget:source_body:72:73")
        self.assertEqual(requests[0]["next_evidence_needed"], "early_target_entity_insertion_probe")
        self.assertIn("target terms", requests[0]["reason"])

    def test_entity_candidate_review_next_action_maps_to_diagnostic_request(self):
        requests = _extract_diagnostic_requests(
            {
                "version": "0.1",
                "decision": "noop",
                "meta": {
                    "next_action": "request_entity_insertion_operator_candidate_review",
                    "next_evidence_needed": "entity_insertion_operator_candidate_review",
                    "why_not_apply": "turn term probe rows into shadow blueprints",
                },
            },
            {"strategy_hints": {}},
        )

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "entity_insertion_operator_candidate_review")
        self.assertEqual(requests[0]["next_evidence_needed"], "entity_insertion_operator_candidate_review")

    def test_entity_insertion_candidate_review_emits_shadow_blueprints_only(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._latest_diagnostic_results = []
        runtime._last_task_feedback = {
            "required_term_recall": 0.25,
            "required_term_span_progress": 0.25,
            "entity_recall_terms": ["Mira", "send", "Omar"],
            "missing_required_terms": ["Mira", "send", "Omar"],
        }
        runtime._diagnostic_results = [
            {
                "diagnostic": "target_entity_insertion_probe",
                "status": "ok",
                "next_evidence_needed": "entity_insertion_operator_candidate_review",
                "top20_reachable_count": 1,
                "near_reachable_count": 2,
                "source_body_span_count": 4,
                "term_readout_rows": [
                    {
                        "term": "budget",
                        "first_piece": " budget",
                        "first_token_id": 4466,
                        "rank": 1,
                        "prob": 0.145,
                        "top20_hit": True,
                        "readout_status": "top20_reachable",
                        "source_provenance": "source_body",
                        "span_progress": 0.25,
                    },
                    {
                        "term": "Mira",
                        "first_piece": " Mir",
                        "first_token_id": 7381,
                        "rank": 72,
                        "prob": 0.0018,
                        "top20_hit": False,
                        "readout_status": "near_reachable",
                        "source_provenance": "source_body",
                        "span_progress": 0.0,
                    },
                    {
                        "term": "send",
                        "first_piece": " send",
                        "first_token_id": 3758,
                        "rank": 211,
                        "prob": 0.0006,
                        "top20_hit": False,
                        "readout_status": "weak_reachable",
                        "source_provenance": "source_body",
                        "span_progress": 0.0,
                    },
                    {
                        "term": "Omar",
                        "first_piece": " Omar",
                        "first_token_id": 24980,
                        "rank": 337,
                        "prob": 0.00036,
                        "top20_hit": False,
                        "readout_status": "weak_reachable",
                        "source_provenance": "source_body",
                        "span_progress": 0.0,
                    },
                ],
            }
        ]

        result = runtime._execute_controller_diagnostic_request(
            {"diagnostic": "entity_insertion_operator_candidate_review"},
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["status"], "candidate_blueprints_ready")
        self.assertEqual(result["diagnostic_role"], "entity_insertion_operator_candidate_review")
        self.assertFalse(result["production_apply_allowed"])
        self.assertFalse(result["certified_for_apply"])
        self.assertEqual(result["next_evidence_needed"], "operator_diagnostic_replay_for_entity_candidates")
        self.assertEqual(result["candidate_terms"], ["Mira", "send", "Omar"])
        self.assertEqual(result["candidate_blueprint_count"], 3)
        self.assertEqual(result["candidate_blueprints"][0]["candidate_status"], "shadow_blueprint_only")
        self.assertEqual(result["candidate_blueprints"][0]["recommended_next_diagnostic"], "operator_diagnostic_replay")
        self.assertIn("source_body_kv_v_exact_span", result["candidate_blueprints"][0]["recommended_operator_families"])

    def test_operator_replay_materializes_entity_blueprints_as_diagnostic_only_evidence(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 2
        runtime._latest_diagnostic_results = []
        runtime._last_task_feedback = {
            "required_term_recall": 0.25,
            "required_term_span_progress": 0.25,
            "entity_recall_terms": ["Mira", "send"],
            "missing_required_terms": ["Mira", "send"],
        }
        runtime._diagnostic_results = [
            {
                "diagnostic": "entity_insertion_operator_candidate_review",
                "status": "candidate_blueprints_ready",
                "candidate_blueprints": [
                    {
                        "kind": "entity_insertion_candidate_blueprint",
                        "objective_term": "Mira",
                        "first_piece": " Mira",
                        "first_token_id": 43000,
                        "readout_status": "near_reachable",
                        "rank": 72,
                        "source_provenance": "source_body",
                        "candidate_key": "entity_insert:mira:source_body:near_reachable",
                        "recommended_operator_families": ["target_readout_direction_patch"],
                    }
                ],
            }
        ]

        def fake_readout_candidate(**kwargs):
            return {
                "surface_id": "s_resid_pre_l5_last",
                "kind": "resid_add",
                "role": "readout_steering:entity_target_readout",
                "focus_feature": kwargs["intended_term"],
                "focus_term": kwargs["intended_term"],
                "bundle_key": kwargs["bundle_key"],
                "bundle_family": "readout_steering",
                "phase_objective": "readout_escape",
                "provenance_class": "readout_direction",
                "span_kind": "readout_direction",
                "recipe_localization": kwargs["steering_kind"],
                "recipe_pooling": "readout_unembed",
                "contrast_mode": kwargs["contrast_mode"],
                "recipe_contrast_scale": kwargs["negative_scale"],
                "recipe_alpha": kwargs["alpha"],
                "target": {"surface_id": "s_resid_pre_l5_last"},
                "source": {"dtype": "vector", "expr": {"fn": "readout_direction", "target_token_ids": [43000]}},
                "op": {"kind": "resid_add", "alpha": kwargs["alpha"]},
                "budget": {"ttl_steps": 1, "norm_clip": 1.0, "step_size": kwargs["alpha"], "revertible": True},
                "operator_recipe_id": "readout_escape|readout_steering|readout_direction|entity_target_readout|readout_unembed|target_readout_minus_attractor@0.050|a0.0400",
                "operator_family_key": "readout_escape|readout_steering|readout_direction|readout_direction",
            }

        def fake_replay(candidate_edits, **kwargs):
            return {
                "status": "ok",
                "label": kwargs.get("label"),
                "actual_delta_class": "readout_gap_movement",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "target_piece": " Mira",
                "target_piece_logit_delta": 0.04,
                "target_piece_prob_delta": 0.00001,
                "target_rank_after": 64,
                "target_top20_threshold_gap_baseline": 1.5,
                "target_top20_threshold_gap": 1.2,
                "target_top20_threshold_gap_after": 1.2,
                "target_top20_threshold_gap_delta": -0.3,
                "focus_rank_delta": 8,
                "repeat_flag_delta": 0,
                "entropy_delta": 0.0,
                "top1_margin_delta": 0.0,
                "term_readout_deltas": {
                    "Mira": {
                        "lift_score": 0.08,
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                        "focus_rank_delta": 8,
                    }
                },
                "candidate_fingerprint": {"bundle_key": candidate_edits[0]["bundle_key"]},
                "eval_context_fingerprint": {"decode_step": 0},
            }

        runtime._readout_steering_candidate = fake_readout_candidate

        def fake_replay_with_dead_non_kv(candidate_edits, **kwargs):
            label = str(kwargs.get("label") or "")
            if "mini_non_kv_anti_attractor_suppress" in label:
                return {
                    "status": "ok",
                    "label": label,
                    "actual_delta_class": "dead_actuator",
                    "target_mass_delta": -0.000001,
                    "target_top20_hit_delta": 0,
                    "target_piece": " Mira",
                    "target_piece_logit_delta": 0.0003,
                    "target_piece_prob_delta": 0.0,
                    "target_rank_after": 64,
                    "target_top20_threshold_gap_baseline": 1.5,
                    "target_top20_threshold_gap": 1.4997,
                    "target_top20_threshold_gap_after": 1.4997,
                    "target_top20_threshold_gap_delta": -0.0003,
                    "focus_rank_delta": 0,
                    "repeat_flag_delta": 0,
                    "entropy_delta": 0.0,
                    "top1_margin_delta": 0.0,
                    "term_readout_deltas": {
                        "Mira": {
                            "lift_score": 0.0,
                            "target_mass_delta": -0.000001,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 0,
                        }
                    },
                    "candidate_fingerprint": {"bundle_key": candidate_edits[0]["bundle_key"]},
                    "eval_context_fingerprint": {"decode_step": 0},
                }
            if "anti_attractor_calibrate_l075_a030" in label:
                return {
                    "status": "ok",
                    "label": label,
                    "actual_delta_class": "collapse_suppressor",
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                    "target_piece": " Mira",
                    "target_piece_logit_delta": 0.0001,
                    "target_piece_prob_delta": 0.0,
                    "target_rank_after": 64,
                    "target_top20_threshold_gap_baseline": 1.5,
                    "target_top20_threshold_gap": 1.499,
                    "target_top20_threshold_gap_after": 1.499,
                    "target_top20_threshold_gap_delta": -0.001,
                    "attractor_family_mass_delta": -0.00002,
                    "attractor_top20_hit_delta": -1,
                    "focus_rank_delta": 0,
                    "repeat_flag_delta": 0,
                    "entropy_delta": 0.0,
                    "top1_margin_delta": 0.0,
                    "term_readout_deltas": {
                        "Mira": {
                            "lift_score": 0.0,
                            "target_mass_delta": 0.0,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 0,
                        }
                    },
                    "candidate_fingerprint": {"bundle_key": candidate_edits[0]["bundle_key"]},
                    "eval_context_fingerprint": {"decode_step": 0},
                }
            return fake_replay(candidate_edits, **kwargs)

        runtime.replay_candidate_edits_actual_delta = fake_replay_with_dead_non_kv

        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "operator_diagnostic_replay",
                "next_evidence_needed": "operator_diagnostic_replay_for_entity_candidates",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["entity_operator_materialization_status"], "materialized")
        self.assertEqual(result["entity_operator_materialization_count"], 1)
        self.assertEqual(result["next_evidence_needed"], "readout_steering_deepening")
        self.assertFalse(result["production_apply_allowed"])
        self.assertFalse(result["certified_for_apply"])
        plan = result["entity_operator_deepening_plan"]
        self.assertEqual(plan["kind"], "positive_operator_deepening_plan")
        self.assertEqual(plan["source"], "entity_insertion_materialized_candidate")
        self.assertEqual(plan["permission"], "diagnostic_only")
        self.assertEqual(plan["suggested_next_evidence"], "readout_steering_deepening")
        self.assertEqual(plan["suggested_operator_recipe_expansion_mode"], "readout_steering_deepening")
        self.assertEqual(plan["deepening_axis"], "target_top20_gap_closing")
        self.assertEqual(plan["reason_code"], "entity_materialized_rank_carrier_gap_deepening")
        self.assertFalse(plan["production_apply_allowed"])
        self.assertFalse(plan["policy_candidate_ready"])
        self.assertEqual(result["positive_operator_deepening_plan"]["reason_code"], plan["reason_code"])
        self.assertEqual(
            result["diagnostic_summary"]["entity_operator_deepening_next_evidence"],
            "readout_steering_deepening",
        )
        self.assertEqual(result["diagnostic_summary"]["evidence_kind_counts"]["operator_replay"], 1)
        canonical = result["canonical_followup_request"]
        self.assertEqual(canonical["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(canonical["objective_bundle_key"], "entity_insert:mira:source_body:near_reachable")
        self.assertEqual(canonical["operator_recipe_expansion_mode"], "readout_steering_deepening")
        self.assertTrue(canonical["readout_steering_deepening_requested"])
        row = result["evidence_rows"][0]
        self.assertEqual(row["diagnostic_family"], "entity_insertion_materialized_candidate")
        self.assertEqual(row["status"], "supportive")
        self.assertEqual(row["actual_delta_class"], "readout_gap_movement")
        self.assertEqual(row["ownership_role"], "self")
        self.assertEqual(row["effect_role"], "readout_gap_movement")
        self.assertIn("top20_gap_closer_candidate", row["positive_traits"])

        runtime._diagnostic_results = [result]
        deepening = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": "entity_insert:mira:source_body:near_reachable",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "operator_recipe_expansion_mode": "readout_steering_deepening",
                "next_evidence_needed": "readout_steering_deepening",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(deepening)
        assert deepening is not None
        self.assertEqual(deepening["operator_recipe_expansion_summary"]["status"], "rank_carrier_family_found")
        self.assertEqual(
            deepening["operator_recipe_expansion_summary"]["best_readout_steering_rank_carrier_recipe_family"],
            "readout_steering|target_readout_deepening",
        )
        self.assertGreater(deepening["readout_steering_deepening_followup_count"], 0)
        self.assertEqual(deepening["readout_steering_deepening_followup_status"], "matrix_replayed")
        self.assertEqual(deepening["next_evidence_needed"], "readout_steering_deepening_review_complete")
        review = deepening["readout_deepening_review_summary"]
        self.assertEqual(review["readout_deepening_review_status"], "complete")
        self.assertEqual(review["best_candidate_role"], "gap_closer_candidate")
        self.assertFalse(review["production_trial_eligible"])
        self.assertEqual(review["why_not_trial"], "gap moved, but target_mass/top20 lift is still uncertified")
        self.assertEqual(review["recommended_next_action"], "request_readout_gap_confirmation_or_variant_sweep")
        self.assertEqual(review["recommended_next_evidence"], "readout_gap_confirmation_or_variant_sweep")
        self.assertEqual(
            review["recommended_operator_recipe_expansion_mode"],
            "readout_gap_confirmation_or_variant_sweep",
        )
        self.assertEqual(
            deepening["diagnostic_summary"]["readout_steering_deepening_followup_status"],
            "matrix_replayed",
        )
        self.assertEqual(
            deepening["diagnostic_summary"]["readout_deepening_review_summary"]["best_candidate_role"],
            "gap_closer_candidate",
        )
        self.assertTrue(
            any(
                row.get("readout_deepening_followup")
                for row in deepening["operator_recipe_expansion_matrix"]
            )
        )
        self.assertEqual(deepening["operator_recipe_expansion_matrix"][0]["failure_mode"], "self_rank_carrier")

        runtime._diagnostic_results = [result, deepening]
        repeated = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": "entity_insert:mira:source_body:near_reachable",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "operator_recipe_expansion_mode": "readout_steering_deepening",
                "next_evidence_needed": "readout_steering_deepening",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(repeated)
        assert repeated is not None
        self.assertEqual(repeated["status"], "already_replayed")
        self.assertEqual(repeated["diagnostic_call_cost"], 0)
        self.assertEqual(repeated["new_measurement_count"], 0)
        self.assertEqual(repeated["readout_steering_deepening_followup_count"], 0)
        self.assertEqual(repeated["readout_steering_deepening_followup_status"], "already_replayed")
        self.assertEqual(repeated["next_evidence_needed"], "choose_unreplayed_diagnostic")
        self.assertEqual(repeated["operator_recipe_expansion_summary"]["matrix_row_count"], 3)
        self.assertEqual(
            repeated["readout_deepening_review_summary"]["recommended_next_action"],
            "request_readout_gap_confirmation_or_variant_sweep",
        )

        confirmation = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "readout_gap_confirmation_or_variant_sweep",
                "bundle_key": "entity_insert:mira:source_body:near_reachable",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                "next_evidence_needed": "readout_gap_confirmation_or_variant_sweep",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(confirmation)
        assert confirmation is not None
        self.assertGreater(confirmation["readout_steering_deepening_followup_count"], 0)
        self.assertEqual(confirmation["readout_steering_deepening_followup_status"], "matrix_replayed")
        self.assertGreater(confirmation["readout_gap_confirmation_variant_count"], 0)
        self.assertEqual(confirmation["next_evidence_needed"], "readout_gap_confirmation_review_complete")
        self.assertEqual(confirmation["readout_deepening_review_summary"]["best_candidate_role"], "gap_closer_candidate")
        self.assertTrue(
            any(
                row.get("readout_gap_confirmation_variant")
                for row in confirmation["operator_recipe_expansion_matrix"]
            )
        )

        runtime._diagnostic_results = [result, deepening, confirmation]
        conversion = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "carrier_to_actuator_conversion_sweep",
                "bundle_key": "entity_insert:mira:source_body:near_reachable",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "objective_bundle_keys": ["entity_insert:mira:source_body:near_reachable"],
                "operator_recipe_expansion_mode": "carrier_to_actuator_conversion_sweep",
                "next_evidence_needed": "carrier_to_actuator_conversion_sweep",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(conversion)
        assert conversion is not None
        self.assertEqual(conversion["diagnostic"], "carrier_to_actuator_conversion_sweep")
        self.assertEqual(conversion["diagnostic_role"], "carrier_to_actuator_conversion_sweep")
        self.assertGreater(conversion["carrier_to_actuator_conversion_variant_count"], 0)
        self.assertEqual(
            conversion["next_evidence_needed"],
            "suppress_then_target_after_calibration_review_complete",
        )
        self.assertEqual(
            conversion["readout_deepening_review_summary"]["best_candidate_role"],
            "carrier_only_no_target_actuator",
        )
        self.assertFalse(conversion["readout_deepening_review_summary"]["production_trial_eligible"])
        self.assertEqual(
            conversion["operator_family_shift_status"],
            "needed_after_gap_carrier_conversion_failed",
        )
        self.assertGreater(len(conversion["operator_family_shift_preview_rows"]), 0)
        self.assertEqual(
            conversion["readout_deepening_review_summary"]["operator_family_shift_status"],
            "needed_after_gap_carrier_conversion_failed",
        )
        self.assertEqual(
            conversion["readout_deepening_review_summary"]["operator_family_shift_canonical_request"]["diagnostic"],
            "compare_extra_operator_diagnostics",
        )
        self.assertEqual(
            conversion["readout_deepening_review_summary"]["operator_family_shift_canonical_request"][
                "operator_recipe_expansion_mode"
            ],
            "non_kv_operator_search",
        )
        self.assertTrue(conversion["mini_non_kv_first_pass_executed"])
        self.assertEqual(conversion["mini_non_kv_first_pass_rows"], 2)
        self.assertEqual(conversion["mini_non_kv_first_pass_source"], "carrier_to_actuator_conversion_failed")
        self.assertEqual(conversion["best_non_kv_candidate_role"], "gap_closer_candidate")
        self.assertFalse(conversion["mini_non_kv_first_pass_summary"]["production_apply_allowed"])
        self.assertGreater(len(conversion["mini_non_kv_first_pass_evidence_rows"]), 0)
        anti_rows = [
            row
            for row in conversion["mini_non_kv_first_pass_evidence_rows"]
            if row.get("operator_family") == "anti_attractor_suppression_patch"
        ]
        self.assertEqual(anti_rows[0]["actual_delta_class"], "dead_actuator")
        self.assertEqual(anti_rows[0]["non_kv_candidate_role"], "dead")
        self.assertTrue(
            all(
                row.get("candidate_fingerprint")
                for row in conversion["mini_non_kv_first_pass_evidence_rows"]
            )
        )
        self.assertTrue(
            conversion["readout_deepening_review_summary"]["mini_non_kv_first_pass_executed"]
        )
        self.assertTrue(conversion["non_kv_variant_or_two_stage_requested"])
        self.assertEqual(conversion["non_kv_variant_or_two_stage_review_status"], "matrix_replayed")
        self.assertGreater(
            conversion["non_kv_variant_or_two_stage_summary"]["non_kv_variant_or_two_stage_rows"],
            0,
        )
        self.assertGreater(len(conversion["non_kv_variant_or_two_stage_rows"]), 0)
        self.assertTrue(
            any(
                row.get("two_stage_patch")
                for row in conversion["non_kv_variant_or_two_stage_rows"]
            )
        )
        self.assertTrue(
            any(
                row.get("carrier_to_actuator_conversion_variant")
                for row in conversion["operator_recipe_expansion_matrix"]
            )
        )
        self.assertTrue(conversion["inline_anti_attractor_suppression_calibration_executed"])
        self.assertEqual(
            conversion["anti_attractor_suppression_calibration_review_status"],
            "inline_suppress_then_target_replayed",
        )
        self.assertGreater(conversion["anti_attractor_suppression_calibration_row_count"], 0)
        self.assertGreater(
            len(conversion["inline_anti_attractor_suppression_calibration_rows"]),
            0,
        )
        self.assertEqual(
            conversion["inline_anti_attractor_suppression_calibration_summary"][
                "best_inline_anti_attractor_suppression_role"
            ],
            "collapse_suppressor_candidate",
        )
        self.assertTrue(
            conversion["readout_deepening_review_summary"][
                "inline_anti_attractor_suppression_calibration_executed"
            ]
        )
        self.assertTrue(conversion["inline_suppress_then_target_after_calibration_executed"])
        self.assertGreater(
            len(conversion["inline_suppress_then_target_after_calibration_rows"]),
            1,
        )
        self.assertGreater(
            len(
                {
                    row.get("recipe_name")
                    for row in conversion["inline_suppress_then_target_after_calibration_rows"]
                    if row.get("recipe_name")
                }
            ),
            1,
        )
        self.assertEqual(
            conversion["inline_suppress_then_target_after_calibration_summary"][
                "best_inline_suppress_then_target_role"
            ],
            "gap_closer_candidate",
        )
        self.assertTrue(
            conversion["readout_deepening_review_summary"][
                "inline_suppress_then_target_after_calibration_executed"
            ]
        )

        runtime._diagnostic_results = [result, deepening, confirmation, conversion]
        repeated_conversion = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "carrier_to_actuator_conversion_sweep",
                "bundle_key": "entity_insert:mira:source_body:near_reachable",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "operator_recipe_expansion_mode": "carrier_to_actuator_conversion_sweep",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )
        self.assertIsNotNone(repeated_conversion)
        assert repeated_conversion is not None
        self.assertEqual(repeated_conversion["status"], "already_replayed")
        self.assertEqual(repeated_conversion["diagnostic_call_cost"], 0)
        self.assertEqual(repeated_conversion["carrier_to_actuator_conversion_variant_count"], 0)
        runtime._diagnostic_results = [result, deepening, confirmation]

        non_kv_preview = runtime._execute_controller_diagnostic_request(
            conversion["readout_deepening_review_summary"]["operator_family_shift_canonical_request"],
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(non_kv_preview)
        assert non_kv_preview is not None
        self.assertEqual(non_kv_preview["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(non_kv_preview["next_evidence_needed"], "non_kv_operator_search_preview_complete")
        self.assertTrue(non_kv_preview["non_kv_operator_search_requested"])
        self.assertEqual(non_kv_preview["operator_family_shift_status"], "preview_ready")
        self.assertGreater(len(non_kv_preview["operator_family_shift_preview_rows"]), 0)
        self.assertFalse(non_kv_preview["production_apply_allowed"])

        runtime._diagnostic_results = [result, deepening, confirmation]
        variant = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": "entity_insert:mira:source_body:near_reachable",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "operator_recipe_expansion_mode": "non_kv_variant_or_two_stage_design",
                "next_evidence_needed": "non_kv_variant_or_two_stage_design",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(variant)
        assert variant is not None
        self.assertEqual(variant["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertTrue(variant["non_kv_variant_or_two_stage_requested"])
        self.assertEqual(variant["next_evidence_needed"], "non_kv_variant_or_two_stage_review_complete")
        self.assertEqual(variant["non_kv_variant_or_two_stage_review_status"], "matrix_replayed")
        self.assertGreater(variant["non_kv_variant_or_two_stage_summary"]["non_kv_variant_or_two_stage_rows"], 0)
        self.assertFalse(variant["non_kv_variant_or_two_stage_summary"]["production_apply_allowed"])
        self.assertGreater(len(variant["non_kv_variant_or_two_stage_rows"]), 0)
        self.assertTrue(
            any(
                row.get("two_stage_patch")
                for row in variant["non_kv_variant_or_two_stage_rows"]
            )
        )
        self.assertTrue(
            all(
                row.get("candidate_fingerprint")
                for row in variant["non_kv_variant_or_two_stage_rows"]
            )
        )

        runtime._diagnostic_results = [result, deepening, confirmation, variant]
        calibration = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": "entity_insert:mira:source_body:near_reachable",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "operator_recipe_expansion_mode": "anti_attractor_suppression_calibration_sweep",
                "next_evidence_needed": "anti_attractor_suppression_calibration_sweep",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(calibration)
        assert calibration is not None
        self.assertEqual(
            calibration["next_evidence_needed"],
            "anti_attractor_suppression_calibration_review_complete",
        )
        self.assertTrue(calibration["anti_attractor_suppression_calibration_requested"])
        self.assertEqual(
            calibration["anti_attractor_suppression_calibration_review_status"],
            "matrix_replayed",
        )
        self.assertGreater(calibration["anti_attractor_suppression_calibration_row_count"], 0)
        self.assertEqual(
            calibration["readout_deepening_review_summary"]["best_candidate_role"],
            "collapse_suppressor_candidate",
        )
        self.assertTrue(
            any(
                row.get("anti_attractor_suppression_calibration")
                for row in calibration["operator_recipe_expansion_matrix"]
            )
        )

    def test_operator_replay_prefers_un_deepened_rotated_objective_for_readout_followup(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 7
        runtime._latest_diagnostic_results = []
        runtime._last_task_feedback = {
            "required_term_recall": 0.25,
            "required_term_span_progress": 0.25,
            "entity_recall_terms": ["Mira", "budget"],
            "missing_required_terms": ["Mira", "budget"],
        }
        runtime._diagnostic_results = [
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "operator_recipe_expansion_mode": "readout_steering_deepening",
                "evidence_rows": [
                    {
                        "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                        "operator_axis": "readout_steering_deepening",
                    }
                ],
            },
            {
                "diagnostic": "entity_insertion_operator_candidate_review",
                "status": "candidate_blueprints_ready",
                "next_evidence_needed": "operator_diagnostic_replay_for_entity_candidates",
                "candidate_blueprints": [
                    {
                        "kind": "entity_insertion_candidate_blueprint",
                        "objective_term": "Mira",
                        "first_piece": " Mira",
                        "first_token_id": 43000,
                        "readout_status": "near_reachable",
                        "source_provenance": "source_body",
                        "candidate_key": "entity_insert:mira:source_body:near_reachable",
                        "recommended_operator_families": ["target_readout_direction_patch"],
                    },
                    {
                        "kind": "entity_insertion_candidate_blueprint",
                        "objective_term": "budget",
                        "first_piece": " budget",
                        "first_token_id": 4466,
                        "readout_status": "weak_reachable",
                        "source_provenance": "source_body",
                        "candidate_key": "entity_insert:budget:source_body:weak_reachable",
                        "recommended_operator_families": ["target_readout_direction_patch"],
                    },
                ],
            },
        ]

        def fake_readout_candidate(**kwargs):
            return {
                "surface_id": "s_resid_pre_l5_last",
                "kind": "resid_add",
                "role": "readout_steering:entity_target_readout",
                "focus_feature": kwargs["intended_term"],
                "focus_term": kwargs["intended_term"],
                "bundle_key": kwargs["bundle_key"],
                "bundle_family": "readout_steering",
                "phase_objective": "readout_escape",
                "target": {"surface_id": "s_resid_pre_l5_last"},
                "source": {"dtype": "vector", "expr": {"fn": "readout_direction", "target_token_ids": [1]}},
                "op": {"kind": "resid_add", "alpha": kwargs["alpha"]},
                "budget": {"ttl_steps": 1, "norm_clip": 1.0, "step_size": kwargs["alpha"], "revertible": True},
                "operator_recipe_id": f"entity_target_readout:{kwargs['intended_term']}:{kwargs['alpha']}",
                "operator_family_key": "readout_escape|readout_steering|readout_direction",
            }

        def fake_replay(candidate_edits, **kwargs):
            bundle_key = str(candidate_edits[0]["bundle_key"])
            is_mira = "mira" in bundle_key
            return {
                "status": "ok",
                "label": kwargs.get("label"),
                "actual_delta_class": "readout_gap_movement",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "target_piece": " Mira" if is_mira else " budget",
                "target_piece_logit_delta": 0.04 if is_mira else 0.03,
                "target_top20_threshold_gap_delta": -0.3 if is_mira else -0.2,
                "focus_rank_delta": 4 if is_mira else 2,
                "repeat_flag_delta": 0,
                "entropy_delta": 0.0,
                "top1_margin_delta": 0.0,
                "candidate_fingerprint": {"bundle_key": bundle_key},
                "eval_context_fingerprint": {"decode_step": 0},
            }

        runtime._readout_steering_candidate = fake_readout_candidate
        runtime.replay_candidate_edits_actual_delta = fake_replay

        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "operator_diagnostic_replay",
                "bundle_key": "entity_rotation:Mira_budget",
                "objective_bundle_key": "entity_rotation:Mira_budget",
                "next_evidence_needed": "operator_diagnostic_replay_for_rotated_entity_candidates",
                "materialize_entity_insertion_candidates": True,
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["entity_operator_materialization_status"], "materialized")
        plan = result["entity_operator_deepening_plan"]
        self.assertEqual(plan["objective_bundle_key"], "entity_insert:budget:source_body:weak_reachable")
        self.assertEqual(plan["intended_term"], "budget")
        self.assertEqual(plan["un_deepened_objective_candidate_count"], 1)
        self.assertEqual(plan["deferred_seen_objective_count"], 1)
        canonical = result["canonical_followup_request"]
        self.assertEqual(canonical["objective_bundle_key"], "entity_insert:budget:source_body:weak_reachable")
        self.assertEqual(canonical["operator_recipe_expansion_mode"], "readout_steering_deepening")

    def test_extract_diagnostic_requests_uses_strategy_hint_readout_steering_deepening_mode(self):
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "next_action": "request_compare_extra_operator_diagnostics",
                "why_not_apply": "entity rank carrier needs local readout deepening",
            },
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": "entity_insert:mira:source_body:near_reachable",
                "diagnostic_frontier_next_evidence": "readout_steering_deepening",
                "diagnostic_frontier_operator_recipe_expansion_mode": "readout_steering_deepening",
            }
        }

        requests = _extract_diagnostic_requests(command, packet)

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(requests[0]["next_evidence_needed"], "readout_steering_deepening")
        self.assertEqual(requests[0]["operator_recipe_expansion_mode"], "readout_steering_deepening")
        self.assertTrue(requests[0]["readout_steering_deepening_requested"])

    def test_extract_diagnostic_requests_uses_canonical_readout_deepening_followup_identity(self):
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "next_action": "request_compare_extra_operator_diagnostics",
                "objective_bundle_key": "kv_pair:Mira:source_body:67:69",
                "why_not_apply": "entity rank carrier needs local readout deepening",
            },
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_next_evidence": "readout_steering_deepening",
                "diagnostic_frontier_operator_recipe_expansion_mode": "readout_steering_deepening",
                "diagnostic_frontier_canonical_request": {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "bundle_key": "entity_insert:mira:source_body:near_reachable",
                    "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                    "step_actuator_bundle_key": "entity_insert:mira:source_body:near_reachable",
                    "next_evidence_needed": "readout_steering_deepening",
                    "operator_recipe_expansion_mode": "readout_steering_deepening",
                    "readout_steering_deepening_requested": True,
                    "seed_operator_recipe_id": "entity_target_readout_patch_l005_a040:entity_insert:mira",
                },
            }
        }

        requests = _extract_diagnostic_requests(command, packet)

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(requests[0]["objective_bundle_key"], "entity_insert:mira:source_body:near_reachable")
        self.assertEqual(requests[0]["bundle_key"], "entity_insert:mira:source_body:near_reachable")
        self.assertEqual(requests[0]["controller_requested_objective_bundle_key"], "kv_pair:Mira:source_body:67:69")
        self.assertEqual(requests[0]["operator_recipe_expansion_mode"], "readout_steering_deepening")
        self.assertEqual(
            requests[0]["seed_operator_recipe_id"],
            "entity_target_readout_patch_l005_a040:entity_insert:mira",
        )
        self.assertTrue(requests[0]["canonical_followup_request_applied"])

    def test_extract_diagnostic_requests_routes_readout_gap_confirmation_next_action(self):
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "next_action": "request_readout_gap_confirmation_or_variant_sweep",
                "why_not_apply": "gap closer needs confirmation before trial",
            },
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_next_evidence": "readout_gap_confirmation_or_variant_sweep",
                "diagnostic_frontier_operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                "diagnostic_frontier_canonical_request": {
                    "diagnostic": "readout_gap_confirmation_or_variant_sweep",
                    "bundle_key": "entity_insert:mira:source_body:near_reachable",
                    "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                    "step_actuator_bundle_key": "entity_insert:mira:source_body:near_reachable",
                    "next_evidence_needed": "readout_gap_confirmation_or_variant_sweep",
                    "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                    "seed_operator_recipe_id": "readout_gap_probe_l005_a040:entity_insert:mira",
                },
            }
        }

        requests = _extract_diagnostic_requests(command, packet)

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "readout_gap_confirmation_or_variant_sweep")
        self.assertEqual(requests[0]["objective_bundle_key"], "entity_insert:mira:source_body:near_reachable")
        self.assertEqual(requests[0]["operator_recipe_expansion_mode"], "readout_gap_confirmation_or_variant_sweep")
        self.assertEqual(
            requests[0]["seed_operator_recipe_id"],
            "readout_gap_probe_l005_a040:entity_insert:mira",
        )
        self.assertTrue(requests[0]["canonical_followup_request_applied"])

    def test_extract_diagnostic_requests_preserves_objective_rotation_terms(self):
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "next_action": "request_objective_rotation_pipeline",
                "why_not_apply": "rotate away from exhausted gap closer",
            },
        }
        packet = {
            "strategy_hints": {
                "objective_rotation_needed": True,
                "diagnostic_frontier_canonical_request": {
                    "diagnostic": "objective_rotation_pipeline",
                    "terms": ["Mira", "Omar", "budget"],
                    "target_terms": ["Mira", "Omar", "budget"],
                    "next_evidence_needed": "objective_rotation_pipeline",
                    "objective_rotation_pipeline": True,
                    "reason": "gap confirmation stayed diagnostic-only for send",
                    "permission": "diagnostic_only",
                },
            }
        }

        requests = _extract_diagnostic_requests(command, packet)

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "objective_rotation_pipeline")
        self.assertEqual(requests[0]["terms"], ["Mira", "Omar", "budget"])
        self.assertEqual(requests[0]["target_terms"], ["Mira", "Omar", "budget"])
        self.assertEqual(requests[0]["next_evidence_needed"], "objective_rotation_pipeline")
        self.assertTrue(requests[0]["objective_rotation_pipeline"])
        self.assertTrue(requests[0]["canonical_followup_request_applied"])

    def test_extract_diagnostic_requests_preserves_carrier_conversion_objectives(self):
        objectives = [
            "entity_insert:send:source_body:weak_reachable",
            "entity_insert:budget:source_body:weak_reachable",
        ]
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "next_action": "request_carrier_to_actuator_conversion_sweep",
                "why_not_apply": "multiple objectives are confirmed gap-only",
            },
        }
        packet = {
            "strategy_hints": {
                "carrier_to_actuator_conversion_sweep_recommended": True,
                "diagnostic_frontier_canonical_request": {
                    "diagnostic": "carrier_to_actuator_conversion_sweep",
                    "objective_bundle_keys": objectives,
                    "seed_objective_bundle_keys": objectives,
                    "terms": ["send", "budget"],
                    "target_terms": ["send", "budget"],
                    "next_evidence_needed": "carrier_to_actuator_conversion_sweep",
                    "operator_recipe_expansion_mode": "carrier_to_actuator_conversion_sweep",
                    "carrier_to_actuator_conversion_sweep": True,
                    "permission": "diagnostic_only",
                },
            }
        }

        requests = _extract_diagnostic_requests(command, packet)

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "carrier_to_actuator_conversion_sweep")
        self.assertEqual(requests[0]["objective_bundle_keys"], objectives)
        self.assertEqual(requests[0]["seed_objective_bundle_keys"], objectives)
        self.assertEqual(requests[0]["operator_recipe_expansion_mode"], "carrier_to_actuator_conversion_sweep")
        self.assertTrue(requests[0]["carrier_to_actuator_conversion_sweep"])
        self.assertTrue(requests[0]["canonical_followup_request_applied"])

    def test_diagnostic_identity_does_not_inherit_another_frontiers_mode(self):
        objective = "entity_insert:send:source_body:near_reachable"
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "diagnostic_request": {
                    "diagnostic": "carrier_to_actuator_conversion_sweep",
                    "objective_bundle_key": objective,
                    "next_evidence_needed": "carrier_to_actuator_conversion_sweep",
                },
            },
        }
        packet = {"strategy_hints": {
            "diagnostic_frontier_canonical_request": {
                "diagnostic": "compare_extra_operator_diagnostics",
                "objective_bundle_key": objective,
                "operator_recipe_expansion_mode": "two_stage_suppress_then_target_review",
                "next_evidence_needed": "two_stage_suppress_then_target_review",
            },
            "diagnostic_frontier_operator_recipe_expansion_mode": "two_stage_suppress_then_target_review",
        }}

        requests = _extract_diagnostic_requests(command, packet)

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "carrier_to_actuator_conversion_sweep")
        self.assertEqual(requests[0]["operator_recipe_expansion_mode"], "carrier_to_actuator_conversion_sweep")
        self.assertNotEqual(requests[0]["operator_recipe_expansion_mode"], "two_stage_suppress_then_target_review")

        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 3
        invalid = runtime._execute_controller_diagnostic_request(
            {**requests[0], "operator_recipe_expansion_mode": "two_stage_suppress_then_target_review"},
            source="unit_test",
            packet=packet,
        )
        self.assertIsNotNone(invalid)
        assert invalid is not None
        self.assertEqual(invalid["status"], "invalid_request")
        self.assertEqual(invalid["blocked_reason"], "diagnostic_mode_mismatch")
        self.assertEqual(invalid["diagnostic_call_cost"], 0)
        self.assertFalse(invalid["production_apply_allowed"])
        invalid_next = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "carrier_to_actuator_conversion_sweep",
                "objective_bundle_key": objective,
                "next_evidence_needed": "two_stage_suppress_then_target_review",
            },
            source="unit_test",
            packet=packet,
        )
        self.assertEqual(invalid_next["blocked_reason"], "diagnostic_mode_mismatch")
        self.assertEqual(invalid_next["diagnostic_call_cost"], 0)

    def test_dedicated_diagnostic_request_and_next_action_are_one_measurement(self):
        objective = "entity_insert:send:source_body:near_reachable"
        requests = _extract_diagnostic_requests(
            {
                "version": "0.1",
                "decision": "noop",
                "meta": {
                    "diagnostic_request": {
                        "diagnostic": "readout_gap_confirmation_or_variant_sweep",
                        "objective_bundle_key": objective,
                        "bundle_key": objective,
                        "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                    },
                    "next_action": "request_readout_gap_confirmation_or_variant_sweep",
                    "next_evidence_needed": "readout_gap_confirmation_or_variant_sweep",
                    "objective_bundle_key": objective,
                },
            },
            {"strategy_hints": {}},
        )
        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["operator_recipe_expansion_mode"], "readout_gap_confirmation_or_variant_sweep")

    def test_rotation_does_not_inherit_unrelated_frontier_mode(self):
        objective = "entity_insert:rotation:take_sample_ivo"
        packet = {"strategy_hints": {
            "diagnostic_frontier_canonical_request": {
                "diagnostic": "objective_rotation_pipeline",
                "objective_bundle_key": objective,
            },
            "diagnostic_frontier_operator_recipe_expansion_mode": "readout_steering_deepening",
        }}
        command = {"version": "0.1", "decision": "noop", "meta": {
            "diagnostic_request": {"diagnostic": "objective_rotation_pipeline", "objective_bundle_key": objective},
            "next_action": "request_objective_rotation_pipeline",
        }}
        requests = _extract_diagnostic_requests(command, packet)
        self.assertEqual(len(requests), 1)
        self.assertNotIn("operator_recipe_expansion_mode", requests[0])

        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 3
        invalid = runtime._execute_controller_diagnostic_request(
            {**requests[0], "operator_recipe_expansion_mode": "readout_steering_deepening"},
            source="unit_test",
            packet=packet,
        )
        self.assertEqual(invalid["blocked_reason"], "diagnostic_mode_mismatch")
        self.assertEqual(invalid["diagnostic_call_cost"], 0)

    def test_empty_matched_response_probe_is_not_a_successful_charged_diagnostic(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 3
        runtime.max_diagnostic_calls_per_run = 12
        runtime.diagnostic_result_window = 12
        runtime._diagnostic_calls_used = 0
        runtime._diagnostic_results = []
        runtime._pending_diagnostic_events = []
        runtime._evidence_inspection_count = 0
        runtime._last_packet = {"strategy_hints": {}}
        with patch("SpiralInterventionLab.runtime.worker.matched_response_probe", return_value={
            "status": "no_candidate_seed",
            "unavailable_reason": "no_candidate_seed",
            "new_measurement_count": 0,
            "physical_replay_count": 0,
            "rows": [],
        }):
            rows = runtime.request_controller_diagnostics(
                {"diagnostic": "matched_response_probe", "objective_bundle_key": "entity_insert:send:source_body:near_reachable"},
                packet={"strategy_hints": {}},
            )
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["status"], "no_candidate_seed")
        self.assertEqual(rows[0]["blocked_reason"], "no_candidate_seed")
        self.assertFalse(rows[0]["diagnostic_budget_charged"])
        self.assertEqual(rows[0]["budget_after"]["diagnostic_calls_left"], 12)

    def test_matched_probe_executor_uses_retained_seed_after_result_eviction(self):
        objective = "entity_insert:mira:source_body:weak_reachable"
        row = {"operator_recipe_id": "readout_escape|activation_patch|resid_pre|L11|mira",
               "operator_axis": "activation_patch_blueprint_materialization",
               "objective_bundle_key": objective, "intended_term": "Mira",
               "actual_delta_class": "rank_carrier", "activation_patch_site": "resid_pre",
               "activation_patch_layer": 11, "activation_patch_alpha": 0.04,
               "activation_patch_source_localization": "source_term_token"}
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 3
        runtime._diagnostic_results = []
        candidate_handoff.reset(runtime)
        candidate_handoff.capture_seed_rows(runtime, {"evidence_rows": [row]})
        with patch("SpiralInterventionLab.runtime.worker.matched_response_probe", return_value={
            "status": "unavailable", "rows": [], "new_measurement_count": 0,
            "physical_replay_count": 0,
        }) as probe:
            runtime._execute_controller_diagnostic_request(
                {"diagnostic": "matched_response_probe", "objective_bundle_key": objective,
                 "focus_term": "Mira", "comparison_axis": "source_localization",
                 "candidate_ids": [row["operator_recipe_id"]], "dose_grid": [0.04]},
                source="unit_test", packet={"strategy_hints": {}})
        self.assertEqual(probe.call_args.args[1][0]["operator_recipe_id"], row["operator_recipe_id"])

    def test_already_replayed_diagnostic_does_not_consume_budget(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 3
        runtime.max_diagnostic_calls_per_run = 12
        runtime.diagnostic_result_window = 12
        runtime._diagnostic_calls_used = 9
        runtime._diagnostic_results = []
        runtime._pending_diagnostic_events = []
        runtime._evidence_inspection_count = 0
        runtime._last_packet = {"strategy_hints": {}}
        runtime._execute_controller_diagnostic_request = lambda *args, **kwargs: {
            "diagnostic": "carrier_to_actuator_conversion_sweep",
            "status": "already_replayed",
            "new_measurement_count": 0,
            "physical_replay_count": 0,
            "diagnostic_call_cost": 0,
            "production_apply_allowed": False,
        }

        rows = runtime.request_controller_diagnostics(
            {"diagnostic": "carrier_to_actuator_conversion_sweep",
             "objective_bundle_key": "entity_insert:send:source_body:near_reachable",
             "operator_recipe_expansion_mode": "carrier_to_actuator_conversion_sweep"},
            packet={"strategy_hints": {}},
        )

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["budget_before"]["diagnostic_calls_left"], 3)
        self.assertEqual(rows[0]["budget_after"]["diagnostic_calls_left"], 3)
        self.assertFalse(rows[0]["diagnostic_budget_charged"])
        self.assertEqual(runtime._diagnostic_calls_used, 9)

    def test_completed_expansion_survives_bounded_result_window(self):
        objective = "entity_insert:send:source_body:near_reachable"
        request = {"diagnostic": "carrier_to_actuator_conversion_sweep",
                   "objective_bundle_key": objective,
                   "operator_recipe_expansion_mode": "carrier_to_actuator_conversion_sweep"}
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 3
        runtime.max_diagnostic_calls_per_run = 12
        runtime.diagnostic_result_window = 1
        runtime._diagnostic_calls_used = 0
        runtime._diagnostic_results = []
        runtime._pending_diagnostic_events = []
        runtime._evidence_inspection_count = 0
        runtime._last_packet = {"strategy_hints": {}}
        def execute_diagnostic(selected, **kwargs):
            if selected["diagnostic"] != "carrier_to_actuator_conversion_sweep":
                return {"diagnostic": selected["diagnostic"], "status": "ok"}
            return {**request, "carrier_to_actuator_conversion_variant_count": 4,
                    "operator_recipe_expansion_matrix": [{
                        "objective_bundle_key": objective,
                        "operator_axis": "carrier_to_actuator_conversion_sweep",
                    }]}
        runtime._execute_controller_diagnostic_request = execute_diagnostic
        runtime.request_controller_diagnostics(request, packet={"strategy_hints": {}})
        assert expansion_already_replayed(request, runtime._completed_expansion_keys, ())
        assert not expansion_already_replayed(
            {**request, "objective_bundle_key": "entity_insert:mira:source_body:near_reachable"},
            runtime._completed_expansion_keys, ())
        runtime.request_controller_diagnostics(
            {"diagnostic": "target_entity_insertion_probe"}, packet={"strategy_hints": {}})
        self.assertEqual(len(runtime._diagnostic_results), 1)
        self.assertEqual(runtime._diagnostic_results[0]["diagnostic"], "target_entity_insertion_probe")
        runtime._execute_controller_diagnostic_request = (
            HookedTransformerWorkerRuntime._execute_controller_diagnostic_request.__get__(runtime))
        repeated = runtime._execute_controller_diagnostic_request(
            request, source="unit_test", packet={"strategy_hints": {}})
        self.assertEqual(repeated["status"], "already_replayed")
        self.assertEqual(repeated["diagnostic_call_cost"], 0)
        self.assertEqual(repeated["physical_replay_count"], 0)
        self.assertFalse(repeated["production_apply_allowed"])
        self.assertEqual(completed_expansion_keys(repeated), set())

    def test_extract_diagnostic_requests_substitutes_blocked_attention_probe(self):
        objective = "entity_insert:send:source_body:weak_reachable"
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "next_action": "request_attention_readout_carrier_probe",
                "objective_bundle_key": objective,
                "why_not_apply": "attention carrier probe has no cached rows",
            },
        }
        packet = {
            "strategy_hints": {
                "blocked_next_diagnostics": [
                    {
                        "diagnostic": "attention_readout_carrier_probe",
                        "objective_bundle_key": objective,
                        "reason": "requires_cached_attention_rows",
                        "suggested_alternate_diagnostic": "attention_head_ablation_on_frontier",
                    }
                ],
            }
        }

        requests = _extract_diagnostic_requests(command, packet)

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "attention_head_ablation_on_frontier")
        self.assertEqual(requests[0]["unavailable_diagnostic"], "attention_readout_carrier_probe")
        self.assertTrue(requests[0]["diagnostic_unavailable_veto"])
        self.assertTrue(requests[0]["substituted_for_unavailable_diagnostic"])

    def test_extract_diagnostic_requests_drops_blocked_attention_probe_without_alternate(self):
        objective = "entity_insert:send:source_body:weak_reachable"
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "next_action": "request_attention_readout_carrier_probe",
                "objective_bundle_key": objective,
            },
        }
        packet = {
            "strategy_hints": {
                "blocked_next_diagnostics": [
                    {
                        "diagnostic": "attention_readout_carrier_probe",
                        "objective_bundle_key": objective,
                        "reason": "requires_cached_attention_rows",
                    }
                ],
            }
        }

        self.assertEqual(_extract_diagnostic_requests(command, packet), [])

    def test_diagnostic_batch_passes_entity_probe_to_review_and_blueprints_to_replay(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._evidence_inspection_count = 0
        runtime.max_diagnostic_calls_per_run = 8
        runtime._diagnostic_results = []
        runtime._latest_diagnostic_results = []
        runtime.diagnostic_result_window = 8
        runtime._pending_diagnostic_events = []
        runtime._last_packet = None
        seen_requests: list[dict[str, object]] = []

        def fake_execute(request, *, source, packet):
            seen_requests.append(dict(request))
            diagnostic = request.get("diagnostic")
            if diagnostic == "target_entity_insertion_probe":
                return {
                    "diagnostic": "target_entity_insertion_probe",
                    "status": "ok",
                    "term_readout_rows": [
                        {
                            "term": "Mira",
                            "rank": 72,
                            "readout_status": "near_reachable",
                            "source_provenance": "source_body",
                        }
                    ],
                    "next_evidence_needed": "entity_insertion_operator_candidate_review",
                }
            if diagnostic == "entity_insertion_operator_candidate_review":
                self.assertIn("target_entity_insertion_probe", request)
                return {
                    "diagnostic": "entity_insertion_operator_candidate_review",
                    "status": "candidate_blueprints_ready",
                    "candidate_blueprints": [
                        {
                            "kind": "entity_insertion_candidate_blueprint",
                            "objective_term": "Mira",
                            "candidate_key": "entity_insert:mira",
                        }
                    ],
                    "candidate_blueprint_count": 1,
                    "next_evidence_needed": "operator_diagnostic_replay_for_entity_candidates",
                }
            if diagnostic == "operator_diagnostic_replay":
                self.assertEqual(
                    request.get("candidate_blueprints"),
                    [
                        {
                            "kind": "entity_insertion_candidate_blueprint",
                            "objective_term": "Mira",
                            "candidate_key": "entity_insert:mira",
                        }
                    ],
                )
                return {
                    "diagnostic": "operator_diagnostic_replay",
                    "status": "ok",
                    "entity_operator_materialization_status": "materialized",
                    "entity_operator_materialization_count": 1,
                }
            return None

        runtime._execute_controller_diagnostic_request = fake_execute

        results = runtime.request_controller_diagnostics(
            [
                {"diagnostic": "target_entity_insertion_probe"},
                {"diagnostic": "entity_insertion_operator_candidate_review"},
                {
                    "diagnostic": "operator_diagnostic_replay",
                    "next_evidence_needed": "operator_diagnostic_replay_for_entity_candidates",
                },
            ],
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertEqual([item["diagnostic"] for item in results], [
            "target_entity_insertion_probe",
            "entity_insertion_operator_candidate_review",
            "operator_diagnostic_replay",
        ])
        self.assertEqual(seen_requests[1]["target_entity_insertion_probe"]["status"], "ok")
        self.assertEqual(seen_requests[2]["candidate_blueprints"][0]["objective_term"], "Mira")

    def test_objective_rotation_pipeline_bundles_probe_review_and_replay_without_apply_permission(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 6
        original_execute = runtime._execute_controller_diagnostic_request
        seen_operator_requests: list[dict[str, object]] = []

        def fake_probe(request, *, source, strategy_hints):
            return {
                "diagnostic": "target_entity_insertion_probe",
                "status": "ok",
                "recorded_step": 6,
                "focus_terms": list(request["terms"]),
                "term_readout_rows": [
                    {
                        "term": "Mira",
                        "rank": 72,
                        "readout_status": "near_reachable",
                        "source_provenance": "source_body",
                    }
                ],
                "top20_reachable_count": 0,
                "near_reachable_count": 1,
                "source_body_span_count": 1,
                "next_evidence_needed": "entity_insertion_operator_candidate_review",
            }

        def fake_review(request, *, source, strategy_hints):
            self.assertEqual(request["target_entity_insertion_probe"]["status"], "ok")
            return {
                "diagnostic": "entity_insertion_operator_candidate_review",
                "status": "candidate_blueprints_ready",
                "recorded_step": 6,
                "focus_terms": ["Mira"],
                "candidate_terms": ["Mira"],
                "candidate_blueprint_count": 1,
                "candidate_blueprints": [
                    {
                        "kind": "entity_insertion_candidate_blueprint",
                        "objective_term": "Mira",
                        "candidate_key": "entity_insert:mira:source_body:near_reachable",
                    }
                ],
                "next_evidence_needed": "operator_diagnostic_replay_for_entity_candidates",
            }

        def intercept_execute(request, *, source, packet):
            if request.get("diagnostic") == "operator_diagnostic_replay":
                seen_operator_requests.append(dict(request))
                return {
                    "diagnostic": "operator_diagnostic_replay",
                    "status": "ok",
                    "recorded_step": 6,
                    "entity_operator_materialization_requested": True,
                    "entity_operator_materialization_status": "materialized",
                    "entity_operator_materialization_count": 1,
                    "entity_operator_materialization_rows": [
                        {
                            "evidence_kind": "operator_replay",
                            "diagnostic_family": "entity_insertion_materialized_candidate",
                            "bundle_key": "entity_insert:mira:source_body:near_reachable",
                            "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                            "status": "supportive",
                        }
                    ],
                    "next_evidence_needed": "readout_steering_deepening",
                    "entity_operator_deepening_plan": {
                        "kind": "positive_operator_deepening_plan",
                        "suggested_next_evidence": "readout_steering_deepening",
                    },
                    "positive_operator_deepening_plan": {
                        "kind": "positive_operator_deepening_plan",
                        "suggested_next_evidence": "readout_steering_deepening",
                    },
                    "canonical_followup_request": {
                        "diagnostic": "compare_extra_operator_diagnostics",
                        "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                        "operator_recipe_expansion_mode": "readout_steering_deepening",
                    },
                    "production_apply_allowed": False,
                    "certified_for_apply": False,
                }
            return original_execute(request, source=source, packet=packet)

        runtime._target_entity_insertion_probe_diagnostic = fake_probe
        runtime._entity_insertion_operator_candidate_review_diagnostic = fake_review
        runtime._execute_controller_diagnostic_request = intercept_execute

        result = original_execute(
            {
                "diagnostic": "objective_rotation_pipeline",
                "terms": ["Mira", "budget"],
                "target_terms": ["Mira", "budget"],
                "next_evidence_needed": "objective_rotation_pipeline",
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["diagnostic"], "objective_rotation_pipeline")
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["pipeline_stage_count"], 3)
        self.assertEqual(
            result["pipeline_stages"],
            [
                "target_entity_insertion_probe",
                "entity_insertion_operator_candidate_review",
                "operator_diagnostic_replay",
            ],
        )
        self.assertEqual(result["target_entity_insertion_probe"]["status"], "ok")
        self.assertEqual(
            result["entity_insertion_operator_candidate_review"]["status"],
            "candidate_blueprints_ready",
        )
        self.assertEqual(result["operator_diagnostic_replay"]["diagnostic"], "operator_diagnostic_replay")
        self.assertEqual(result["entity_operator_materialization_status"], "materialized")
        self.assertEqual(result["next_evidence_needed"], "readout_steering_deepening")
        self.assertEqual(result["canonical_followup_request"]["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertFalse(result["production_apply_allowed"])
        self.assertFalse(result["certified_for_apply"])
        self.assertFalse(result["operator_certified"])
        self.assertTrue(seen_operator_requests)
        self.assertEqual(
            seen_operator_requests[0]["next_evidence_needed"],
            "operator_diagnostic_replay_for_rotated_entity_candidates",
        )
        self.assertTrue(seen_operator_requests[0]["objective_rotation_pipeline"])

    def test_readout_gap_confirmation_seen_is_objective_aware(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._diagnostic_results = [
            {
                "diagnostic": "readout_gap_confirmation_or_variant_sweep",
                "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                "objective_bundle_key": "entity_insert:send:source_body:weak_reachable",
                "readout_deepening_review_summary": {
                    "objective_bundle_key": "entity_insert:send:source_body:weak_reachable",
                },
            }
        ]

        self.assertTrue(
            runtime._readout_gap_confirmation_seen_for_objective(
                "entity_insert:send:source_body:weak_reachable"
            )
        )
        self.assertFalse(
            runtime._readout_gap_confirmation_seen_for_objective(
                "entity_insert:budget:source_body:weak_reachable"
            )
        )

        runtime._diagnostic_results.append(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                "operator_recipe_expansion_summary": {
                    "objective_bundle_key": "entity_insert:budget:source_body:weak_reachable",
                },
                "operator_recipe_expansion_matrix": [
                    {
                        "objective_bundle_key": "entity_insert:budget:source_body:weak_reachable",
                    }
                ],
            }
        )
        self.assertTrue(
            runtime._readout_gap_confirmation_seen_for_objective(
                "entity_insert:budget:source_body:weak_reachable"
            )
        )

    def test_confirmed_gap_only_objective_rows_require_no_target_lift(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._diagnostic_results = [
            {
                "diagnostic": "readout_gap_confirmation_or_variant_sweep",
                "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                "objective_bundle_key": "entity_insert:send:source_body:weak_reachable",
                "recorded_step": 4,
                "readout_deepening_review_summary": {
                    "objective_bundle_key": "entity_insert:send:source_body:weak_reachable",
                    "best_candidate_role": "gap_closer_candidate",
                    "production_trial_eligible": False,
                    "gap_delta": -0.002,
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                },
            },
            {
                "diagnostic": "readout_gap_confirmation_or_variant_sweep",
                "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                "objective_bundle_key": "entity_insert:budget:source_body:weak_reachable",
                "recorded_step": 5,
                "readout_deepening_review_summary": {
                    "objective_bundle_key": "entity_insert:budget:source_body:weak_reachable",
                    "best_candidate_role": "target_actuator_candidate",
                    "production_trial_eligible": True,
                    "gap_delta": -0.004,
                    "target_mass_delta": 0.00005,
                    "target_top20_hit_delta": 0,
                },
            },
        ]

        rows = runtime._confirmed_gap_only_objective_rows()

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["objective_bundle_key"], "entity_insert:send:source_body:weak_reachable")
        self.assertEqual(rows[0]["term"], "send")
        self.assertEqual(rows[0]["objective_status"], "confirmed_gap_only_no_target_lift")
        self.assertFalse(rows[0]["rotation_eligible"])

    def test_strategy_hints_reserve_conversion_after_one_confirmed_gap_only_objective(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime.decoder_control_mode = ""
        runtime._kv_canary_eval_active = False
        runtime._steps = 6
        runtime.max_diagnostic_calls_per_run = 8
        runtime._operator_certification_table = {}
        runtime._operator_bridge_plan_table = {}
        runtime._diagnostic_results = [
            {
                "diagnostic": "readout_gap_confirmation_or_variant_sweep",
                "operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                "objective_bundle_key": "entity_insert:budget:source_body:weak_reachable",
                "recorded_step": 4,
                "readout_deepening_review_summary": {
                    "objective_bundle_key": "entity_insert:budget:source_body:weak_reachable",
                    "best_candidate_role": "gap_closer_candidate",
                    "production_trial_eligible": False,
                    "gap_delta": -0.002,
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                },
            },
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "operator_recipe_expansion_mode": "readout_steering_deepening",
                "objective_bundle_key": "entity_insert:mira:source_body:weak_reachable",
                "recorded_step": 6,
                "readout_deepening_review_summary": {
                    "objective_bundle_key": "entity_insert:mira:source_body:weak_reachable",
                    "best_candidate_role": "gap_closer_candidate",
                    "production_trial_eligible": False,
                    "recommended_next_action": "request_readout_gap_confirmation_or_variant_sweep",
                    "gap_delta": -0.001,
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                    "best_recipe_id": "readout_deepen_target_pure_a060_gap",
                    "best_recipe_family": "readout_steering|target_readout_deepening",
                    "best_recipe_name": "target_readout_deepening",
                    "why_not_trial": "gap moved, but target_mass/top20 lift is still uncertified",
                },
            },
        ]
        runtime._latest_tokenize_terms_result = lambda: {}
        runtime._feedback_terms = lambda keys: ["Mira", "budget"]
        runtime._preprobe_readout_escape_state = lambda canary: (False, {})
        runtime._intersect_terms = lambda raw_terms, allowed_terms: []
        runtime._shot_mode_ready = lambda: False
        runtime._recent_loop_break_attempt_count = lambda: 0
        runtime._recent_stabilizing_only_count = lambda: 0
        runtime._l4_term_nudge_cooldown_active = lambda: False
        runtime._shot_candidate_edits = lambda **kwargs: []
        runtime._kv_candidate_edits = lambda **kwargs: (
            [],
            {
                "called": True,
                "source": "unit_test",
                "stage": "empty",
                "input_hit_count": 0,
                "output_count": 0,
                "prune_reasons": [],
                "target_terms": [],
            },
        )
        runtime._annotate_effect_families = lambda edits: (edits, [])
        runtime._attach_operator_certifications = lambda edits: edits
        runtime._kv_retry_candidate_edits = lambda **kwargs: []
        runtime._shot_probe_needed = lambda **kwargs: False
        runtime._semantic_focus_summary = lambda **kwargs: {}
        runtime._readout_escape_needed = lambda **kwargs: (False, "", {})
        runtime._loop_severity_hint = lambda: "none"
        runtime._ordered_missing_terms_for_phase = lambda **kwargs: []

        hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={},
        )

        self.assertEqual(hints["confirmed_gap_only_count"], 1)
        self.assertTrue(hints["carrier_to_actuator_conversion_sweep_recommended"])
        self.assertTrue(hints["diagnostic_budget_reserved_for_conversion"])
        self.assertTrue(hints["readout_gap_confirmation_skipped_for_conversion"])
        self.assertEqual(
            hints["carrier_to_actuator_conversion_reason"],
            "one_confirmed_gap_only_plus_current_gap_closer_candidate",
        )
        self.assertEqual(hints["diagnostic_frontier_request"], "carrier_to_actuator_conversion_sweep")
        request = hints["diagnostic_frontier_canonical_request"]
        self.assertEqual(request["diagnostic"], "carrier_to_actuator_conversion_sweep")
        self.assertEqual(request["operator_recipe_expansion_mode"], "carrier_to_actuator_conversion_sweep")
        self.assertEqual(
            request["objective_bundle_keys"],
            [
                "entity_insert:mira:source_body:weak_reachable",
                "entity_insert:budget:source_body:weak_reachable",
            ],
        )
        self.assertEqual(request["target_terms"], ["mira", "budget"])

        runtime._diagnostic_results.append({
            "diagnostic": "carrier_to_actuator_conversion_sweep",
            "operator_recipe_expansion_mode": "carrier_to_actuator_conversion_sweep",
            "objective_bundle_key": "entity_insert:mira:source_body:weak_reachable",
            "carrier_to_actuator_conversion_variant_count": 4,
            "recorded_step": 6,
        })
        consumed_hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={},
        )
        self.assertNotEqual(
            consumed_hints.get("diagnostic_frontier_request"),
            "carrier_to_actuator_conversion_sweep",
        )
        self.assertNotIn(
            "carrier_to_actuator_conversion_sweep",
            [row["diagnostic"] for row in consumed_hints.get("available_next_diagnostics", [])],
        )
        runtime._completed_expansion_keys = completed_expansion_keys(runtime._diagnostic_results[-1])
        runtime._diagnostic_results.pop()
        evicted_hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={},
        )
        self.assertNotIn(
            "carrier_to_actuator_conversion_sweep",
            [row["diagnostic"] for row in evicted_hints.get("available_next_diagnostics", [])],
        )

    def test_strategy_hints_request_non_kv_shift_after_carrier_conversion_fails(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime.decoder_control_mode = ""
        runtime._kv_canary_eval_active = False
        runtime._steps = 8
        runtime.max_diagnostic_calls_per_run = 9
        runtime._operator_certification_table = {}
        runtime._operator_bridge_plan_table = {}
        objective_key = "entity_insert:mira:source_body:near_reachable"
        preview_rows = HookedTransformerWorkerRuntime._operator_family_shift_preview_rows(
            objective_bundle_key=objective_key,
            objective_term="mira",
            seed_recipe_id="readout_deepen_target_pure_a060_gap",
            seed_recipe_family="readout_steering|carrier_to_actuator_conversion",
        )
        canonical_request = HookedTransformerWorkerRuntime._operator_family_shift_canonical_request(
            objective_bundle_key=objective_key,
            objective_term="mira",
            seed_recipe_id="readout_deepen_target_pure_a060_gap",
            seed_recipe_family="readout_steering|carrier_to_actuator_conversion",
        )
        runtime._diagnostic_results = [
            {
                "diagnostic": "carrier_to_actuator_conversion_sweep",
                "operator_recipe_expansion_mode": "carrier_to_actuator_conversion_sweep",
                "objective_bundle_key": objective_key,
                "recorded_step": 7,
                "readout_deepening_review_summary": {
                    "objective_bundle_key": objective_key,
                    "best_candidate_role": "carrier_only_no_target_actuator",
                    "production_trial_eligible": False,
                    "recommended_next_action": "request_non_kv_operator_search",
                    "recommended_next_evidence": "operator_family_shift_after_gap_carrier_conversion_failed",
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                    "operator_family_shift_status": "needed_after_gap_carrier_conversion_failed",
                    "operator_family_shift_reason": (
                        "conversion variants were carrier-only with no target mass/top20 lift"
                    ),
                    "operator_family_shift_preview_rows": preview_rows,
                    "operator_family_shift_canonical_request": canonical_request,
                },
            }
        ]
        runtime._latest_tokenize_terms_result = lambda: {}
        runtime._feedback_terms = lambda keys: ["Mira", "budget"]
        runtime._preprobe_readout_escape_state = lambda canary: (False, {})
        runtime._intersect_terms = lambda raw_terms, allowed_terms: []
        runtime._shot_mode_ready = lambda: False
        runtime._recent_loop_break_attempt_count = lambda: 0
        runtime._recent_stabilizing_only_count = lambda: 0
        runtime._l4_term_nudge_cooldown_active = lambda: False
        runtime._shot_candidate_edits = lambda **kwargs: []
        runtime._kv_candidate_edits = lambda **kwargs: (
            [],
            {
                "called": True,
                "source": "unit_test",
                "stage": "empty",
                "input_hit_count": 0,
                "output_count": 0,
                "prune_reasons": [],
                "target_terms": [],
            },
        )
        runtime._annotate_effect_families = lambda edits: (edits, [])
        runtime._attach_operator_certifications = lambda edits: edits
        runtime._kv_retry_candidate_edits = lambda **kwargs: []
        runtime._shot_probe_needed = lambda **kwargs: False
        runtime._semantic_focus_summary = lambda **kwargs: {}
        runtime._readout_escape_needed = lambda **kwargs: (False, "", {})
        runtime._loop_severity_hint = lambda: "none"
        runtime._ordered_missing_terms_for_phase = lambda **kwargs: []

        hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={},
        )

        self.assertTrue(hints["operator_family_shift_recommended"])
        self.assertEqual(
            hints["operator_family_shift_status"],
            "needed_after_gap_carrier_conversion_failed",
        )
        self.assertEqual(hints["diagnostic_frontier_request"], "compare_extra_operator_diagnostics")
        self.assertEqual(hints["diagnostic_frontier_next_evidence"], "non_kv_operator_search")
        self.assertEqual(
            hints["diagnostic_frontier_operator_recipe_expansion_mode"],
            "non_kv_operator_search",
        )
        self.assertEqual(
            hints["operator_family_shift_canonical_request"]["operator_recipe_expansion_mode"],
            "non_kv_operator_search",
        )
        self.assertGreater(len(hints["operator_family_shift_preview_rows"]), 0)

        mini_summary = {
            "mini_non_kv_first_pass_executed": True,
            "mini_non_kv_first_pass_rows": 2,
            "mini_non_kv_first_pass_source": "carrier_to_actuator_conversion_failed",
            "best_non_kv_actual_delta_class": "rank_carrier",
            "best_non_kv_candidate_role": "gap_closer_candidate",
            "best_non_kv_operator_family": "resid_readout_direction_patch",
            "best_non_kv_recipe_name": "mini_non_kv_resid_readout_direction_a060",
            "best_non_kv_target_mass_delta": 0.000002,
            "best_non_kv_target_top20_hit_delta": 0,
            "best_non_kv_target_top20_threshold_gap_delta": -0.002235,
            "production_apply_allowed": False,
        }
        runtime._diagnostic_results[0].update(
            {
                "carrier_to_actuator_conversion_variant_count": 4,
                "mini_non_kv_first_pass_executed": True,
                "mini_non_kv_first_pass_rows": 2,
                "mini_non_kv_first_pass_summary": dict(mini_summary),
                "best_non_kv_candidate_role": "gap_closer_candidate",
            }
        )
        runtime._diagnostic_results[0]["readout_deepening_review_summary"].update(mini_summary)

        mini_hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={},
        )

        self.assertEqual(mini_hints["mini_non_kv_first_pass_review_status"], "complete")
        self.assertTrue(mini_hints["mini_non_kv_first_pass_executed"])
        self.assertEqual(mini_hints["mini_non_kv_first_pass_rows"], 2)
        self.assertEqual(mini_hints["best_non_kv_candidate_role"], "gap_closer_candidate")
        self.assertEqual(
            mini_hints["best_non_kv_operator_family"],
            "resid_readout_direction_patch",
        )
        self.assertEqual(
            mini_hints["non_kv_operator_search_outcome"],
            "non_kv_gap_carrier_no_target_actuator",
        )
        self.assertEqual(
            mini_hints["operator_family_shift_status"],
            "mini_first_pass_review_complete",
        )
        self.assertFalse(mini_hints["operator_family_shift_recommended"])
        self.assertTrue(mini_hints["non_kv_operator_search_review_complete"])
        self.assertEqual(mini_hints["next_evidence_needed"], "non_kv_variant_or_two_stage_design")
        self.assertEqual(mini_hints["diagnostic_frontier_request"], "compare_extra_operator_diagnostics")
        self.assertEqual(mini_hints["diagnostic_frontier_next_evidence"], "non_kv_variant_or_two_stage_design")
        self.assertEqual(
            mini_hints["diagnostic_frontier_operator_recipe_expansion_mode"],
            "non_kv_variant_or_two_stage_design",
        )
        self.assertEqual(
            mini_hints["diagnostic_frontier_canonical_request"]["operator_recipe_expansion_mode"],
            "non_kv_variant_or_two_stage_design",
        )
        self.assertNotIn(
            "carrier_to_actuator_conversion_sweep",
            [row["diagnostic"] for row in mini_hints.get("available_next_diagnostics", [])],
        )

        runtime._diagnostic_results[0]["non_kv_variant_or_two_stage_rows"] = [{
            "objective_bundle_key": objective_key,
            "operator_axis": "two_stage_suppress_then_target_review",
        }]
        already_measured_hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={},
        )
        self.assertNotIn(
            "two_stage_suppress_then_target_review",
            [row.get("request", {}).get("operator_recipe_expansion_mode")
             for row in already_measured_hints.get("available_next_diagnostics", [])],
        )
        self.assertTrue(any(
            row.get("status") == "already_replayed"
            for row in already_measured_hints.get("blocked_next_diagnostics", [])
        ))
        runtime._diagnostic_results[0].pop("non_kv_variant_or_two_stage_rows")

        runtime._diagnostic_results[0].update(
            {
                "inline_suppress_then_target_after_calibration_executed": True,
                "inline_suppress_then_target_after_calibration_summary": {
                    "inline_suppress_then_target_after_calibration_executed": True,
                    "inline_suppress_then_target_after_calibration_rows": 3,
                    "best_inline_suppress_then_target_role": "collapse_suppressor",
                    "best_inline_suppress_then_target_recipe_name": (
                        "calibrated_non_kv_two_stage_suppress_l100_then_target_l025_a070"
                    ),
                    "best_inline_suppress_then_target_target_mass_delta": 0.0,
                    "best_inline_suppress_then_target_target_top20_hit_delta": 0,
                    "best_inline_suppress_then_target_gap_delta": -0.002897,
                    "best_inline_suppress_then_target_attractor_mass_delta": -0.000012,
                },
                "inline_suppress_then_target_after_calibration_rows": [
                    {
                        "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                        "recipe_name": "calibrated_non_kv_two_stage_suppress_l100_then_target_l025_a050",
                        "non_kv_variant_role": "collapse_suppressor",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                    },
                    {
                        "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                        "recipe_name": "calibrated_non_kv_two_stage_suppress_l100_then_target_pure_a060",
                        "non_kv_variant_role": "collapse_suppressor",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                    },
                    {
                        "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                        "recipe_name": "calibrated_non_kv_two_stage_suppress_l100_then_target_l025_a070",
                        "non_kv_variant_role": "collapse_suppressor",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                    },
                ],
            }
        )

        saturated_hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={},
        )

        self.assertTrue(saturated_hints["suppress_then_target_after_calibration_review_complete"])
        self.assertTrue(saturated_hints["suppress_then_target_after_calibration_saturation_detected"])
        self.assertEqual(
            saturated_hints["suppress_then_target_after_calibration_outcome"],
            "saturated_collapse_suppressor_no_target_lift",
        )
        self.assertEqual(
            saturated_hints["next_evidence_needed"],
            "activation_patch_candidate_review",
        )
        self.assertTrue(saturated_hints["new_runtime_operator_needed_after_suppressor_saturation"])
        self.assertTrue(saturated_hints["activation_patch_candidate_review_recommended"])
        self.assertEqual(
            saturated_hints["diagnostic_frontier_request"],
            "activation_patch_candidate_review",
        )
        self.assertEqual(
            saturated_hints["diagnostic_frontier_next_evidence"],
            "activation_patch_candidate_review",
        )
        self.assertEqual(
            saturated_hints["operator_family_shift_status"],
            "suppress_then_target_saturated_no_target_lift",
        )
        self.assertNotEqual(
            saturated_hints.get("diagnostic_frontier_operator_recipe_expansion_mode"),
            "two_stage_suppress_then_target_review",
        )
        blocked = saturated_hints.get("blocked_next_diagnostics", [])
        self.assertTrue(
            any(
                row.get("status") == "diagnostic_saturated"
                and row.get("reason") == "suppress_then_target_after_calibration_saturated_no_target_lift"
                for row in blocked
                if isinstance(row, dict)
            )
        )

    def test_strategy_hints_routes_response_curve_dead_end_to_non_kv_search(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime.decoder_control_mode = ""
        runtime._kv_canary_eval_active = False
        runtime._steps = 10
        runtime.max_diagnostic_calls_per_run = 12
        runtime._operator_certification_table = {}
        runtime._operator_bridge_plan_table = {}
        objective_key = "entity_insert:mira:source_body:near_reachable"
        runtime._diagnostic_results = [
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "operator_recipe_expansion_mode": "two_stage_suppress_then_target_review",
                "objective_bundle_key": objective_key,
                "recorded_step": 8,
                "inline_suppress_then_target_after_calibration_executed": True,
                "inline_suppress_then_target_after_calibration_summary": {
                    "inline_suppress_then_target_after_calibration_executed": True,
                    "inline_suppress_then_target_after_calibration_rows": 2,
                    "best_inline_suppress_then_target_role": "collapse_suppressor",
                    "best_inline_suppress_then_target_target_mass_delta": 0.0,
                    "best_inline_suppress_then_target_target_top20_hit_delta": 0,
                },
                "inline_suppress_then_target_after_calibration_rows": [
                    {
                        "objective_bundle_key": objective_key,
                        "non_kv_variant_role": "collapse_suppressor",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                    },
                    {
                        "objective_bundle_key": objective_key,
                        "non_kv_variant_role": "collapse_suppressor",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                    },
                ],
            },
            {
                "diagnostic": "activation_patch_candidate_review",
                "operator_recipe_expansion_mode": "activation_patch_cap_release_response_curve",
                "next_evidence_needed": "activation_patch_cap_release_response_curve_review_complete",
                "objective_bundle_key": objective_key,
                "bundle_key": objective_key,
                "recorded_step": 9,
                "activation_patch_cap_release_response_curve_executed": True,
                "activation_patch_cap_release_response_curve_summary": {
                    "activation_patch_cap_release_response_curve_executed": True,
                    "activation_patch_cap_release_response_curve_rows": 3,
                    "response_curve_has_target_lift": False,
                    "response_curve_has_collapse": False,
                    "best_activation_patch_response_curve_role": "dead_actuator",
                    "best_activation_patch_response_curve_recipe_name": (
                        "activation_patch_mlp_out_l11_source_term_token_a030_step200"
                    ),
                    "best_activation_patch_response_curve_target_mass_delta": 0.0,
                    "best_activation_patch_response_curve_target_top20_hit_delta": 0,
                },
                "activation_patch_cap_release_response_curve_rows": [
                    {
                        "objective_bundle_key": objective_key,
                        "recipe_name": "activation_patch_mlp_out_l11_source_term_token_a030_step200",
                        "actuator_class": "dead_actuator",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                        "activation_patch_step_size": 0.2,
                    }
                ],
            },
        ]
        runtime._latest_tokenize_terms_result = lambda: {}
        runtime._feedback_terms = lambda keys: ["Mira", "budget"]
        runtime._preprobe_readout_escape_state = lambda canary: (False, {})
        runtime._intersect_terms = lambda raw_terms, allowed_terms: []
        runtime._shot_mode_ready = lambda: False
        runtime._recent_loop_break_attempt_count = lambda: 0
        runtime._recent_stabilizing_only_count = lambda: 0
        runtime._l4_term_nudge_cooldown_active = lambda: False
        runtime._shot_candidate_edits = lambda **kwargs: []
        runtime._kv_candidate_edits = lambda **kwargs: (
            [],
            {
                "called": True,
                "source": "unit_test",
                "stage": "empty",
                "input_hit_count": 0,
                "output_count": 0,
                "prune_reasons": [],
                "target_terms": [],
            },
        )
        runtime._annotate_effect_families = lambda edits: (edits, [])
        runtime._attach_operator_certifications = lambda edits: edits
        runtime._kv_retry_candidate_edits = lambda **kwargs: []
        runtime._shot_probe_needed = lambda **kwargs: False
        runtime._semantic_focus_summary = lambda **kwargs: {}
        runtime._readout_escape_needed = lambda **kwargs: (False, "", {})
        runtime._loop_severity_hint = lambda: "none"
        runtime._ordered_missing_terms_for_phase = lambda **kwargs: []

        hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={},
        )

        self.assertTrue(hints["activation_patch_cap_release_response_curve_review_complete"])
        self.assertTrue(hints["activation_patch_candidate_review_stale_after_response_curve"])
        self.assertEqual(hints["next_evidence_needed"], "non_kv_operator_search")
        self.assertEqual(hints["diagnostic_frontier_request"], "compare_extra_operator_diagnostics")
        self.assertEqual(hints["diagnostic_frontier_next_evidence"], "non_kv_operator_search")
        self.assertEqual(
            hints["diagnostic_frontier_operator_recipe_expansion_mode"],
            "non_kv_operator_search",
        )
        self.assertEqual(
            hints["operator_family_shift_status"],
            "needed_after_activation_patch_response_curve_no_target_lift",
        )
        blocked = hints.get("blocked_next_diagnostics", [])
        self.assertTrue(
            any(
                row.get("status") == "stale_after_response_curve"
                and row.get("reason") == "activation_patch_response_curve_completed_no_target_lift"
                for row in blocked
                if isinstance(row, dict)
            )
        )
        self.assertFalse(
            any(
                isinstance(item, dict)
                and item.get("diagnostic") == "activation_patch_candidate_review"
                for item in hints.get("available_next_diagnostics", [])
            )
        )

    def test_strategy_hints_preempts_activation_patch_review_when_subspace_evidence_available(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime.decoder_control_mode = ""
        runtime._kv_canary_eval_active = False
        runtime._steps = 9
        runtime.max_diagnostic_calls_per_run = 12
        runtime._operator_certification_table = {}
        runtime._operator_bridge_plan_table = {}
        objective_key = "entity_insert:mira:source_body:near_reachable"
        runtime._diagnostic_results = [
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "operator_recipe_expansion_mode": "two_stage_suppress_then_target_review",
                "objective_bundle_key": objective_key,
                "recorded_step": 8,
                "inline_suppress_then_target_after_calibration_executed": True,
                "inline_suppress_then_target_after_calibration_summary": {
                    "inline_suppress_then_target_after_calibration_executed": True,
                    "inline_suppress_then_target_after_calibration_rows": 2,
                    "best_inline_suppress_then_target_role": "collapse_suppressor",
                    "best_inline_suppress_then_target_target_mass_delta": 0.0,
                    "best_inline_suppress_then_target_target_top20_hit_delta": 0,
                },
                "inline_suppress_then_target_after_calibration_rows": [
                    {
                        "objective_bundle_key": objective_key,
                        "non_kv_variant_role": "collapse_suppressor",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                    },
                    {
                        "objective_bundle_key": objective_key,
                        "non_kv_variant_role": "gap_closer_candidate",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                    },
                ],
            },
        ]
        runtime._latest_tokenize_terms_result = lambda: {}
        runtime._feedback_terms = lambda keys: ["Mira", "budget"]
        runtime._preprobe_readout_escape_state = lambda canary: (False, {})
        runtime._intersect_terms = lambda raw_terms, allowed_terms: []
        runtime._shot_mode_ready = lambda: False
        runtime._recent_loop_break_attempt_count = lambda: 0
        runtime._recent_stabilizing_only_count = lambda: 0
        runtime._l4_term_nudge_cooldown_active = lambda: False
        runtime._shot_candidate_edits = lambda **kwargs: []
        runtime._kv_candidate_edits = lambda **kwargs: (
            [],
            {
                "called": True,
                "source": "unit_test",
                "stage": "empty",
                "input_hit_count": 0,
                "output_count": 0,
                "prune_reasons": [],
                "target_terms": [],
            },
        )
        runtime._annotate_effect_families = lambda edits: (edits, [])
        runtime._attach_operator_certifications = lambda edits: edits
        runtime._kv_retry_candidate_edits = lambda **kwargs: []
        runtime._shot_probe_needed = lambda **kwargs: False
        runtime._semantic_focus_summary = lambda **kwargs: {}
        runtime._readout_escape_needed = lambda **kwargs: (False, "", {})
        runtime._loop_severity_hint = lambda: "none"
        runtime._ordered_missing_terms_for_phase = lambda **kwargs: []

        hints = runtime._strategy_hints(
            control_phase_hint="readout_escape",
            answer_readout_canary={},
            readout_sidecar_hints={
                "sae_feature_subspace_groups": [
                    {
                        "bundle_key": objective_key,
                        "subspace_family": "source_body_entity_subspace",
                        "support": 1.2,
                        "operator_family_priors": [
                            "activation_patch_source_to_boundary",
                            "resid_or_readout_boundary",
                        ],
                    }
                ],
            },
        )

        self.assertTrue(hints["activation_patch_frontier_preemption"])
        self.assertTrue(hints["diagnostic_budget_reserved_for_activation_patch_review"])
        self.assertEqual(hints["diagnostic_frontier_request"], "activation_patch_candidate_review")
        request = hints["diagnostic_frontier_canonical_request"]
        self.assertTrue(request["frontier_preemption"])
        self.assertFalse(request["production_apply_allowed"])
        activation_requests = [
            item
            for item in hints.get("available_next_diagnostics", [])
            if isinstance(item, dict)
            and isinstance(item.get("request"), dict)
            and item["request"].get("diagnostic") == "activation_patch_candidate_review"
        ]
        self.assertTrue(activation_requests)
        self.assertEqual(activation_requests[0]["priority"], 1)

    def test_activation_patch_materializer_uses_compact_subspace_seed_rows(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        objective_key = "entity_insert:mira:source_body:72:73"

        class _Token:
            mode = "last"

        class _Target:
            kind = "activation"
            layer = 11
            site = "resid_post"
            token = _Token()

        class _Surface:
            surface_id = "s_resid_post_l11_last"
            target = _Target()
            allow_ops = ("activation_patch",)

        runtime.surface_catalog = [_Surface()]
        runtime._diagnostic_results = []
        runtime._latest_entity_insertion_candidate_blueprints = lambda request: [
            {
                "candidate_key": objective_key,
                "objective_term": "Mira",
                "source_provenance": "source_body",
                "source_span": {
                    "start": 72,
                    "end": 73,
                    "provenance_class": "source_body",
                    "text": "Mira",
                },
            }
        ]
        runtime._activation_patch_trial_edit_from_candidate = lambda candidate, *, trial_contract: None

        rows = runtime._activation_patch_rows_from_entity_blueprints(
            {"objective_bundle_key": objective_key},
            packet_context={
                "strategy_hints": {
                    "activation_patch_subspace_evidence_objectives": [
                        {
                            "bundle_key": "kv_pair:Mira:source_body:72:73",
                            "subspace_family": "source_body_entity_subspace",
                            "support": 1.2,
                            "operator_family_priors": ["activation_patch_source_to_boundary"],
                        }
                    ]
                }
            },
            max_candidates=1,
        )

        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["activation_patch_subspace_consistent_seed"])
        self.assertEqual(rows[0]["activation_patch_subspace_family"], "source_body_entity_subspace")
        self.assertEqual(rows[0]["activation_patch_subspace_support"], 1.2)

    def test_activation_patch_proxy_reliability_ledger_downgrades_dead_proxy_family(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        objective_key = "entity_insert:mira:source_body:near_reachable"
        base_row = {
            "diagnostic_family": "activation_patch",
            "objective_bundle_key": objective_key,
            "intended_term": "Mira",
            "activation_patch_site": "mlp_out",
            "activation_patch_layer": 11,
            "activation_patch_source_localization": "source_term_token",
            "activation_patch_first_order_response_proxy": 0.2,
            "activation_patch_response_effect_role": "no_response",
            "attribution_reliability_status": "dead_response_after_positive_proxy",
            "actual_delta_class": "dead_actuator",
            "target_mass_delta": 0.0,
            "target_top20_hit_delta": 0,
            "production_apply_allowed": False,
        }
        runtime._diagnostic_results = [
            {
                "diagnostic": "activation_patch_candidate_review",
                "activation_patch_cap_release_response_curve_rows": [
                    dict(base_row, recipe_name="a"),
                    dict(base_row, recipe_name="b", activation_patch_step_size=0.2),
                ],
            }
        ]

        ledger = runtime._activation_patch_proxy_reliability_ledger()

        self.assertEqual(ledger[0]["calibration_status"], "candidate_hint_only_unreliable")
        self.assertEqual(ledger[0]["dead_response_after_positive_proxy_count"], 2)
        unreliable_keys = {
            row["activation_patch_proxy_reliability_key"]
            for row in ledger
            if row["calibration_status"] == "candidate_hint_only_unreliable"
        }
        future_row = HookedTransformerWorkerRuntime._apply_activation_patch_proxy_calibration(
            dict(base_row, recipe_name="future"),
            unreliable_keys=unreliable_keys,
        )
        self.assertEqual(
            future_row["activation_patch_proxy_calibration_status"],
            "candidate_hint_only_unreliable",
        )
        self.assertEqual(future_row["activation_patch_proxy_selector_permission"], "candidate_hint_only")
        self.assertFalse(future_row["production_apply_allowed"])

    def test_activation_patch_proxy_reliability_scope_includes_binding_and_seed(self):
        base_row = {
            "objective_bundle_key": "entity_insert:mira:source_body:72:73",
            "intended_term": "Mira",
            "activation_patch_site": "mlp_out",
            "activation_patch_layer": 11,
            "activation_patch_source_localization": "source_term_token",
            "target_piece_binding_id": "mira-leading-space",
            "activation_patch_seed_source": "direct_candidate",
            "production_apply_allowed": False,
        }
        direct_key = HookedTransformerWorkerRuntime._activation_patch_proxy_reliability_key_for_row(
            base_row
        )
        alternate_binding_key = (
            HookedTransformerWorkerRuntime._activation_patch_proxy_reliability_key_for_row(
                dict(base_row, target_piece_binding_id="mira-initial-subpiece")
            )
        )
        observed_seed_key = (
            HookedTransformerWorkerRuntime._activation_patch_proxy_reliability_key_for_row(
                dict(base_row, activation_patch_seed_source="observed_gap_carrier")
            )
        )

        self.assertNotEqual(direct_key, alternate_binding_key)
        self.assertNotEqual(direct_key, observed_seed_key)
        unreliable_keys = {direct_key}
        direct_row = HookedTransformerWorkerRuntime._apply_activation_patch_proxy_calibration(
            base_row,
            unreliable_keys=unreliable_keys,
        )
        alternate_binding_row = (
            HookedTransformerWorkerRuntime._apply_activation_patch_proxy_calibration(
                dict(base_row, target_piece_binding_id="mira-initial-subpiece"),
                unreliable_keys=unreliable_keys,
            )
        )
        observed_seed_row = HookedTransformerWorkerRuntime._apply_activation_patch_proxy_calibration(
            dict(base_row, activation_patch_seed_source="observed_gap_carrier"),
            unreliable_keys=unreliable_keys,
        )

        self.assertEqual(
            direct_row["activation_patch_proxy_calibration_status"],
            "candidate_hint_only_unreliable",
        )
        self.assertEqual(
            alternate_binding_row["activation_patch_proxy_calibration_status"],
            "candidate_hint_only_observe",
        )
        self.assertEqual(
            observed_seed_row["activation_patch_proxy_calibration_status"],
            "candidate_hint_only_observe",
        )

    def test_controller_selection_report_surfaces_activation_patch_preemption_and_reliability(self):
        objective_key = "entity_insert:mira:source_body:72:73"
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective_key,
                "activation_patch_subspace_evidence_count": 2,
                "activation_patch_frontier_preemption": True,
                "activation_patch_frontier_preemption_reason": (
                    "SAE/subspace evidence is available and activation_patch review has not yet been measured"
                ),
                "activation_patch_frontier_preemption_objective_bundle_key": objective_key,
                "activation_patch_proxy_reliability_unreliable_count": 1,
                "activation_patch_candidate_hint_only_unreliable_keys": ["mira|mlp_out|L11|source_term_token"],
            }
        }

        report = _build_controller_selection_report(packet, {"decision": "noop", "meta": {}})

        self.assertEqual(report["activation_patch_subspace_evidence_count"], 2)
        self.assertTrue(report["activation_patch_frontier_preemption"])
        self.assertEqual(report["activation_patch_frontier_preemption_objective_bundle_key"], objective_key)
        self.assertEqual(report["activation_patch_proxy_reliability_unreliable_count"], 1)
        self.assertEqual(
            report["activation_patch_candidate_hint_only_unreliable_keys"],
            ["mira|mlp_out|L11|source_term_token"],
        )

    def test_constrained_rewrite_observer_check_has_lexical_fallback_without_critic(self):
        env = SpiralEasyConstrainedRewriteEnv()
        env.reset(7)
        kwargs = env.worker_runtime_kwargs()

        observer = kwargs.get("observer_check_fn")
        self.assertTrue(callable(observer))
        feedback = env.task_feedback("The budget draft is not a draft.")
        payload = observer(
            "The budget draft is not a draft.",
            task_feedback=feedback,
            trigger="unit_test",
        )

        self.assertIsNotNone(payload)
        self.assertEqual(payload["mode"], "lexical_coverage_fallback")
        self.assertFalse(payload["semantic_backend_available"])
        self.assertEqual(payload["model_name"], "none")
        self.assertEqual(payload["raw_score"], payload["coverage_signal"])
        self.assertEqual(payload["score"], payload["coverage_signal"])


@unittest.skipUnless(HAS_TRANSFORMER_LENS, "transformer_lens is not installed")
class TestExamples(unittest.TestCase):
    def test_model_tokenizer_codec_decodes_without_list_wrapper(self):
        codec = ModelTokenizerCodec(model=_FakeCodecModel())

        self.assertEqual(codec.decode([1, 2]), "1 2")

    def _make_model_and_codec(self):
        alphabet = "".join(chr(i) for i in range(32, 127)) + "\n"
        cfg = HookedTransformerConfig(
            n_layers=2,
            d_model=32,
            n_heads=4,
            d_head=8,
            d_mlp=64,
            n_ctx=256,
            d_vocab=len(alphabet),
            act_fn="relu",
            device="cpu",
            seed=0,
        )
        model = HookedTransformer(cfg)
        model.eval()
        return model, CharacterCodec(alphabet)

    def test_default_surface_catalog_targets_middle_layer(self):
        model, _codec = self._make_model_and_codec()

        catalog = build_default_activation_surface_catalog(model, worker_id="os_0")

        self.assertEqual(len(catalog), 2)
        self.assertEqual(catalog[0]["target"]["kind"], "activation")
        self.assertEqual(catalog[0]["target"]["site"], "resid_pre")
        self.assertEqual(catalog[0]["target"]["layer"], 1)
        self.assertIn("step_size", catalog[0]["caps"])
        self.assertEqual(catalog[1]["surface_id"], "s_resid_pre_l1_prev")
        self.assertEqual(catalog[1]["target"]["token"], {"mode": "index", "value": -2})

    def test_expanded_activation_surface_catalog_exposes_late_multisite_surfaces(self):
        model, _codec = self._make_model_and_codec()

        catalog = build_default_activation_surface_catalog(
            model,
            worker_id="os_0",
            profile="activation_patch_expanded",
        )

        last_surfaces = [surface for surface in catalog if surface["target"]["token"] == {"mode": "last"}]
        self.assertEqual({surface["target"]["site"] for surface in last_surfaces}, {"resid_pre", "resid_post", "mlp_out"})
        self.assertTrue(
            all("activation_patch" in surface["allow_ops"] for surface in last_surfaces)
        )
        self.assertEqual(catalog[-1]["target"]["token"], {"mode": "index", "value": -2})

    def test_activation_patch_jsonl_summary_groups_candidate_rows(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = Path(tmpdir) / "c1.jsonl"
            event = {
                "event": "controller_diagnostic_result",
                "activation_patch_candidate_pool": [
                    {
                        "diagnostic_family": "activation_patch",
                        "activation_patch_op_kind": "activation_patch",
                        "activation_patch_site": "resid_post",
                        "activation_patch_layer": 11,
                        "activation_patch_source_localization": "source_term_token",
                        "activation_patch_alpha": 0.03,
                        "activation_patch_step_size": 0.03,
                        "activation_patch_hook_call_count": 1,
                        "activation_patch_source_target_cosine": 0.42,
                        "activation_patch_blend_delta_norm": 0.0015,
                        "activation_patch_step_size_clip_saturated": False,
                        "actual_delta_class": "dead_actuator",
                        "actuator_class": "dead_actuator",
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                        "target_piece": " Mira",
                        "target_piece_token_id": 43000,
                        "target_piece_binding_report": {
                            "objective_term": "Mira",
                            "candidate_target_pieces": ["M", " Mira"],
                            "candidate_target_token_ids": [44, 43000],
                            "chosen_target_piece": " Mira",
                            "chosen_target_token_id": 43000,
                            "binding_reason": "rank_delta_then_edited_rank",
                            "binding_source": "first_token_target_readout_metrics",
                            "binding_stability_status": "divergent",
                        },
                        "target_top20_threshold_gap_delta": float("nan"),
                        "recipe_name": "activation_patch_resid_post_l11_source_term_token_a030",
                    },
                    {
                        "diagnostic_family": "activation_patch",
                        "activation_patch_op_kind": "activation_patch",
                        "activation_patch_site": "mlp_out",
                        "activation_patch_layer": 11,
                        "activation_patch_source_localization": "source_centered_pm1",
                        "activation_patch_alpha": 0.04,
                        "activation_patch_step_size": 0.08,
                        "actual_delta_class": "readout_gap_movement",
                        "actuator_class": "self_actuator",
                        "target_mass_delta": 0.00001,
                        "target_top20_hit_delta": 0,
                        "target_top20_threshold_gap_delta": -0.002,
                        "recipe_name": "activation_patch_mlp_out_l11_source_centered_pm1_a040",
                    },
                ],
            }
            log_path.write_text(json.dumps(event, allow_nan=True) + "\n", encoding="utf-8")

            summary = summarize_activation_patch_jsonl([log_path])

        self.assertEqual(summary["activation_patch_row_count"], 2)
        self.assertEqual(summary["by_actual_delta_class"]["dead_actuator"], 1)
        self.assertEqual(summary["by_actual_delta_class"]["readout_gap_movement"], 1)
        self.assertEqual(summary["by_site"]["mlp_out"], 1)
        self.assertEqual(summary["by_target_piece_binding_status"]["divergent"], 1)
        self.assertEqual(summary["target_piece_binding_reports"][0]["target_piece_token_id"], 43000)
        self.assertEqual(
            summary["target_piece_binding_reports"][0]["binding_report"]["chosen_target_piece"],
            " Mira",
        )
        self.assertIsNone(summary["best_rows"]["gap_delta"][-1]["gap_delta"])
        self.assertEqual(summary["best_rows"]["gap_delta"][0]["gap_delta"], -0.002)
        resid_post_row = next(row for row in summary["matrix"] if row["site"] == "resid_post")
        self.assertEqual(resid_post_row["hooked_rows"], 1)
        self.assertAlmostEqual(resid_post_row["max_blend_delta_norm"], 0.0015)
        mlp_row = next(row for row in summary["matrix"] if row["site"] == "mlp_out")
        self.assertEqual(mlp_row["max_step_size"], 0.08)

    def test_activation_patch_jsonl_summary_preserves_binding_seed_matrix(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = Path(tmpdir) / "c1.jsonl"
            matrix_id = "tpbsm:test"
            rows = []
            for seed_source in ("direct_candidate", "observed_gap_carrier"):
                for binding_variant, token_id, piece in (
                    ("canonical", 43000, " Mira"),
                    ("alternate", 44, "M"),
                ):
                    rows.append(
                        {
                            "diagnostic_family": "activation_patch",
                            "evidence_kind": "target_piece_binding_replay",
                            "operator_axis": "target_piece_binding_seed_matrix",
                            "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                            "intended_term": "Mira",
                            "activation_patch_site": "mlp_out",
                            "activation_patch_layer": 11,
                            "activation_patch_source_localization": "source_term_token",
                            "activation_patch_seed_source": seed_source,
                            "seed_recipe_name": f"{seed_source}_seed",
                            "target_piece_binding_seed_matrix_id": matrix_id,
                            "target_piece_binding_variant": binding_variant,
                            "target_piece_binding_id": f"tpb:{token_id}",
                            "target_piece_binding_requested_honored": True,
                            "target_piece": piece,
                            "target_piece_token_id": token_id,
                            "target_piece_logit_delta": 0.2 if binding_variant == "alternate" else 0.1,
                            "target_piece_prob_delta": 0.000002,
                            "target_rank_delta": 2,
                            "target_mass_delta": 0.000001,
                            "target_top20_hit_delta": 0,
                            "target_top20_threshold_gap_delta": -0.001,
                            "post_edit_best_piece": piece,
                            "post_edit_matches_binding": True,
                            "actual_delta_class": "rank_carrier",
                            "recipe_name": f"{seed_source}_seed",
                        }
                    )
            event = {
                "event": "controller_diagnostic_result",
                "target_piece_binding_seed_matrix_rows": rows,
                "target_piece_binding_seed_matrix_summary": {
                    "operator_axis": "target_piece_binding_seed_matrix",
                    "target_piece_binding_seed_matrix_id": matrix_id,
                    "status": "factorized_2x2_complete",
                    "row_count": 4,
                },
            }
            log_path.write_text(json.dumps(event) + "\n", encoding="utf-8")

            summary = summarize_activation_patch_jsonl([log_path])

        self.assertEqual(summary["target_piece_binding_seed_matrix_row_count"], 4)
        self.assertEqual(summary["by_target_piece_binding_variant"], {"alternate": 2, "canonical": 2})
        matrix = summary["target_piece_binding_seed_matrices"][0]
        self.assertEqual(matrix["target_piece_binding_seed_matrix_id"], matrix_id)
        self.assertTrue(matrix["factorial_complete"])
        self.assertEqual(matrix["requested_binding_honored_count"], 4)
        self.assertEqual(matrix["post_edit_binding_divergence_count"], 0)
        self.assertEqual(len(matrix["cells"]), 4)

    def test_activation_patch_jsonl_summary_separates_matrix_ids_for_same_objective(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = Path(tmpdir) / "c1.jsonl"
            objective_key = "entity_insert:mira:source_body:near_reachable"
            rows = [
                {
                    "diagnostic_family": "activation_patch",
                    "evidence_kind": "target_piece_binding_replay",
                    "operator_axis": "target_piece_binding_seed_matrix",
                    "objective_bundle_key": objective_key,
                    "activation_patch_site": "mlp_out",
                    "activation_patch_layer": 11,
                    "activation_patch_source_localization": "source_term_token",
                    "activation_patch_seed_source": "direct_candidate",
                    "target_piece_binding_seed_matrix_id": matrix_id,
                    "target_piece_binding_variant": "canonical",
                    "target_piece_binding_id": f"tpb:{matrix_id}",
                    "target_piece": " Mira",
                    "target_piece_token_id": 43000,
                    "target_mass_delta": 0.000001,
                    "target_top20_hit_delta": 0,
                    "target_top20_threshold_gap_delta": -0.001,
                    "actual_delta_class": "rank_carrier",
                    "recipe_name": "direct_seed",
                }
                for matrix_id in ("tpbsm:first", "tpbsm:second")
            ]
            log_path.write_text(
                json.dumps(
                    {
                        "event": "controller_diagnostic_result",
                        "target_piece_binding_seed_matrix_rows": rows,
                    }
                )
                + "\n",
                encoding="utf-8",
            )

            summary = summarize_activation_patch_jsonl([log_path])

        self.assertEqual(summary["target_piece_binding_seed_matrix_row_count"], 2)
        self.assertEqual(
            {
                matrix["target_piece_binding_seed_matrix_id"]
                for matrix in summary["target_piece_binding_seed_matrices"]
            },
            {"tpbsm:first", "tpbsm:second"},
        )

    def test_activation_patch_jsonl_compare_pairs_shared_recipe_keys(self):
        def write_run(path: Path, *, model: str, actual_delta_class: str, target_mass: float, subspace: bool):
            events = [
                {
                    "event": "controller_provider_attempt",
                    "step": 0,
                    "provider": "fake",
                    "model": model,
                    "parse_ok": True,
                },
                {
                    "event": "controller_diagnostic_request",
                    "step": 1,
                    "diagnostic": "activation_patch_candidate_review",
                    "next_evidence_needed": "activation_patch_candidate_review",
                },
                {
                    "event": "controller_diagnostic_result",
                    "activation_patch_candidate_pool": [
                        {
                            "diagnostic_family": "activation_patch",
                            "activation_patch_op_kind": "activation_patch",
                            "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                            "actuator_bundle_key": "entity_insert:mira:source_body:near_reachable",
                            "intended_term": "Mira",
                            "target_piece": " Mira",
                            "activation_patch_site": "mlp_out",
                            "activation_patch_layer": 11,
                            "activation_patch_source_localization": "source_term_token",
                            "operator_axis": "activation_patch_cap_release_response_curve",
                            "activation_patch_alpha": 0.03,
                            "activation_patch_step_size": 0.03,
                            "activation_patch_seed_source": "observed_gap_carrier",
                            "activation_patch_seed_recipe_name": "seed_mlp",
                            "attribution_reliability_status": "dead_response_after_positive_proxy",
                            "activation_patch_subspace_consistent_seed": subspace,
                            "activation_patch_subspace_family": "source_body_entity_subspace"
                            if subspace
                            else None,
                            "activation_patch_response_effect_role": "gap_carrier"
                            if actual_delta_class == "rank_carrier"
                            else "no_response",
                            "actual_delta_class": actual_delta_class,
                            "target_mass_delta": target_mass,
                            "target_top20_hit_delta": 0,
                            "target_top20_threshold_gap_delta": -0.002
                            if actual_delta_class == "rank_carrier"
                            else None,
                            "recipe_name": "activation_patch_mlp_out_l11_source_term_token_a030",
                        }
                    ],
                },
            ]
            path.write_text("\n".join(json.dumps(event) for event in events) + "\n", encoding="utf-8")

        with tempfile.TemporaryDirectory() as tmpdir:
            left = Path(tmpdir) / "left.jsonl"
            right = Path(tmpdir) / "right.jsonl"
            write_run(left, model="gpt-5.5", actual_delta_class="rank_carrier", target_mass=0.000001, subspace=False)
            write_run(right, model="claude-opus-4-8", actual_delta_class="dead_actuator", target_mass=0.0, subspace=True)

            comparison = compare_activation_patch_runs(
                [left],
                [right],
                left_label="gpt55",
                right_label="opus48",
            )

        self.assertEqual(comparison["left"]["provider_parse_ok_count"], 1)
        self.assertEqual(comparison["right"]["provider_models"]["claude-opus-4-8"], 1)
        self.assertEqual(comparison["shared_recipe_key_count"], 1)
        paired = comparison["paired_recipe_comparison"][0]
        self.assertEqual(paired["key"]["objective_bundle_key"], "entity_insert:mira:source_body:near_reachable")
        self.assertEqual(paired["key"]["intended_term"], "Mira")
        self.assertEqual(paired["key"]["target_piece"], " Mira")
        self.assertEqual(paired["key"]["seed_source"], "observed_gap_carrier")
        self.assertEqual(paired["key"]["seed_recipe_name"], "seed_mlp")
        self.assertEqual(paired["key"]["proxy_reliability_status"], "dead_response_after_positive_proxy")
        self.assertEqual(paired["gpt55"]["by_actual_delta_class"]["rank_carrier"], 1)
        self.assertEqual(paired["opus48"]["by_actual_delta_class"]["dead_actuator"], 1)
        self.assertEqual(paired["delta"]["subspace_consistent_rows"], 1)

    def test_activation_patch_jsonl_compare_reports_target_piece_divergence(self):
        def write_run(path: Path, *, target_piece: str, actual_delta_class: str):
            event = {
                "event": "controller_diagnostic_result",
                "activation_patch_candidate_pool": [
                    {
                        "diagnostic_family": "activation_patch",
                        "activation_patch_op_kind": "activation_patch",
                        "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                        "actuator_bundle_key": "entity_insert:mira:source_body:near_reachable",
                        "intended_term": "Mira",
                        "target_piece": target_piece,
                        "target_piece_token_id": 43000 if target_piece == " budget" else 44,
                        "activation_patch_site": "mlp_out",
                        "activation_patch_layer": 11,
                        "activation_patch_source_localization": "source_term_token",
                        "operator_axis": "activation_patch_candidate_review",
                        "activation_patch_alpha": 0.03,
                        "activation_patch_step_size": 0.03,
                        "activation_patch_response_effect_role": "gap_carrier",
                        "actual_delta_class": actual_delta_class,
                        "target_mass_delta": 0.0,
                        "target_top20_hit_delta": 0,
                        "target_top20_threshold_gap_delta": -0.001,
                        "recipe_name": "activation_patch_mlp_out_l11_source_term_token_a030",
                    }
                ],
            }
            path.write_text(json.dumps(event) + "\n", encoding="utf-8")

        with tempfile.TemporaryDirectory() as tmpdir:
            left = Path(tmpdir) / "left.jsonl"
            right = Path(tmpdir) / "right.jsonl"
            write_run(left, target_piece=" budget", actual_delta_class="rank_carrier")
            write_run(right, target_piece="M", actual_delta_class="dead_actuator")

            comparison = compare_activation_patch_runs(
                [left],
                [right],
                left_label="gpt55",
                right_label="opus48",
            )

        self.assertEqual(comparison["strict_shared_recipe_key_count"], 0)
        self.assertEqual(comparison["relaxed_shared_recipe_key_count"], 1)
        relaxed = comparison["relaxed_paired_recipe_comparison"][0]
        self.assertEqual(relaxed["key"]["site"], "mlp_out")
        self.assertEqual(relaxed["gpt55"]["by_actual_delta_class"]["rank_carrier"], 1)
        self.assertEqual(relaxed["opus48"]["by_actual_delta_class"]["dead_actuator"], 1)
        divergence = comparison["target_piece_divergence_report"][0]
        self.assertEqual(divergence["gpt55"]["target_piece_counts"], {" budget": 1})
        self.assertEqual(divergence["opus48"]["target_piece_counts"], {"M": 1})
        self.assertEqual(divergence["gpt55"]["target_piece_token_id_counts"], {"43000": 1})
        self.assertEqual(divergence["opus48"]["target_piece_token_id_counts"], {"44": 1})
        self.assertEqual(divergence["gpt55"]["seed_source_counts"], {"direct_candidate": 1})
        self.assertFalse(divergence["divergence"]["target_piece_sets_match"])
        self.assertFalse(divergence["divergence"]["target_piece_token_id_sets_match"])

    def test_activation_patch_jsonl_compare_supports_direct_script_help(self):
        repo_root = Path(__file__).resolve().parents[2]
        script = repo_root / "SpiralInterventionLab" / "examples" / "compare_activation_patch_jsonl.py"
        completed = subprocess.run(
            [sys.executable, str(script), "--help"],
            cwd=repo_root,
            check=False,
            capture_output=True,
            text=True,
        )

        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("Compare activation_patch diagnostic rows", completed.stdout)

    def test_build_hooked_transformer_worker_runtime_smoke(self):
        model, codec = self._make_model_and_codec()
        env = SpiralDigitTransformEnv(min_digits=4, max_digits=4)
        runtime = build_hooked_transformer_worker_runtime(model, env, seed=5, codec=codec)

        prompt = env.reset(5)
        runtime.reset(prompt)
        runtime.step()
        packet = runtime.build_controller_packet()

        self.assertEqual(packet["task_view"]["task_id"], env.task_id)
        self.assertTrue(packet["surface_catalog"])
        self.assertEqual(packet["surface_catalog"][0]["target"]["site"], "resid_pre")
        self.assertIn("step_size", packet["surface_catalog"][0]["caps"])
        self.assertTrue(runtime.allowed_token_ids)

    def test_build_hooked_transformer_worker_runtime_with_structured_reflection(self):
        model, codec = self._make_model_and_codec()
        env = SpiralDigitTransformEnv(min_digits=4, max_digits=4)
        runtime = build_hooked_transformer_worker_runtime(
            model,
            env,
            seed=5,
            codec=codec,
            controller_reflection_mode="structured",
            controller_memory_window=2,
        )

        runtime.record_controller_memory(
            {
                "hypothesis": "small_rescue",
                "observed_outcome": "harmful",
                "next_change": "prefer noop",
                "confidence": 0.4,
            },
            decision="apply",
        )
        prompt = env.reset(5)
        runtime.reset(prompt)
        runtime.record_controller_memory(
            {
                "hypothesis": "small_rescue",
                "observed_outcome": "harmful",
                "next_change": "prefer noop",
                "confidence": 0.4,
            },
            decision="apply",
        )
        runtime.step()
        packet = runtime.build_controller_packet()

        self.assertIn("controller_memory", packet)
        self.assertEqual(packet["controller_memory"][0]["hypothesis"], "small_rescue")
        self.assertEqual(packet["controller_memory"][0]["decision"], "apply")

    def test_build_hooked_transformer_worker_runtime_with_loop_aware_decoder_control(self):
        model, codec = self._make_model_and_codec()
        env = SpiralDigitTransformEnv(min_digits=4, max_digits=4)
        runtime = build_hooked_transformer_worker_runtime(
            model,
            env,
            seed=5,
            codec=codec,
            worker_decoder_control_mode="loop_aware",
            worker_loop_rescue_edits_per_run=2,
            worker_loop_rescue_total_alpha=0.12,
        )

        prompt = env.reset(5)
        runtime.reset(prompt)
        runtime.step()
        packet = runtime.build_controller_packet()

        self.assertEqual(runtime.decoder_control_mode, "loop_aware")
        self.assertEqual(packet["telemetry"]["decoder_control_mode"], "loop_aware")
        self.assertIn("decoder_rescue_active", packet["telemetry"])
        self.assertEqual(packet["budget"]["loop_rescue_edits_left_this_run"], 2)

    def test_build_hooked_transformer_worker_runtime_with_loop_aware_constraint_decoder_control(self):
        model, codec = self._make_model_and_codec()
        env = SpiralConstrainedRewriteEnv()
        runtime = build_hooked_transformer_worker_runtime(
            model,
            env,
            seed=7,
            codec=codec,
            worker_decoder_control_mode="loop_aware_constraint",
            worker_loop_rescue_edits_per_run=2,
            worker_loop_rescue_total_alpha=0.12,
        )

        prompt = env.reset(7)
        runtime.reset(prompt)
        packet = runtime.build_controller_packet()

        self.assertEqual(runtime.decoder_control_mode, "loop_aware_constraint")
        self.assertEqual(packet["telemetry"]["decoder_control_mode"], "loop_aware_constraint")
        self.assertEqual(packet["telemetry"]["decoder_control_track"], "auxiliary")
        self.assertIn("decoder_constraint_target_count", packet["telemetry"])

    def test_build_hooked_transformer_worker_runtime_with_loop_aware_entity_recall_decoder_control(self):
        model, codec = self._make_model_and_codec()
        env = SpiralConstrainedRewriteEnv()
        runtime = build_hooked_transformer_worker_runtime(
            model,
            env,
            seed=7,
            codec=codec,
            worker_decoder_control_mode="loop_aware_entity_recall",
            worker_loop_rescue_edits_per_run=2,
            worker_loop_rescue_total_alpha=0.12,
        )

        prompt = env.reset(7)
        runtime.reset(prompt)
        packet = runtime.build_controller_packet()

        self.assertEqual(runtime.decoder_control_mode, "loop_aware_entity_recall")
        self.assertEqual(packet["telemetry"]["decoder_control_mode"], "loop_aware_entity_recall")
        self.assertEqual(packet["telemetry"]["decoder_control_track"], "auxiliary")
        self.assertIn("decoder_entity_target_count", packet["telemetry"])
        self.assertIn("decoder_entity_prefix_depth", packet["telemetry"])

    def test_build_hooked_transformer_worker_runtime_with_logit_bias_entity_soft_decoder_control(self):
        model, codec = self._make_model_and_codec()
        env = SpiralConstrainedRewriteEnv()
        runtime = build_hooked_transformer_worker_runtime(
            model,
            env,
            seed=7,
            codec=codec,
            worker_decoder_control_mode="logit_bias_entity_soft",
            worker_loop_rescue_edits_per_run=2,
            worker_loop_rescue_total_alpha=0.12,
        )

        prompt = env.reset(7)
        runtime.reset(prompt)
        packet = runtime.build_controller_packet()

        self.assertEqual(runtime.decoder_control_mode, "logit_bias_entity_soft")
        self.assertEqual(packet["telemetry"]["decoder_control_mode"], "logit_bias_entity_soft")
        self.assertEqual(packet["telemetry"]["decoder_control_track"], "auxiliary")

    def test_build_hooked_transformer_worker_runtime_wires_readout_sidecar_analyzer(self):
        model, codec = self._make_model_and_codec()
        env = SpiralConstrainedRewriteEnv()

        def fake_sidecar(_capture):
            return {"analyzer_name": "fake_sidecar"}

        runtime = build_hooked_transformer_worker_runtime(
            model,
            env,
            seed=7,
            codec=codec,
            readout_sidecar_analyzer=fake_sidecar,
        )

        self.assertIs(runtime.readout_sidecar_analyzer, fake_sidecar)

    def test_build_hooked_transformer_worker_runtime_wires_readout_analyzer_rerank_mode(self):
        model, codec = self._make_model_and_codec()
        env = SpiralConstrainedRewriteEnv()

        runtime = build_hooked_transformer_worker_runtime(
            model,
            env,
            seed=7,
            codec=codec,
            readout_analyzer_rerank_mode="shadow",
        )

        self.assertEqual(runtime.readout_analyzer_rerank_mode, "shadow")

    def test_create_readout_sidecar_analyzer_supports_heuristic_mode(self):
        analyzer = create_readout_sidecar_analyzer("heuristic")

        self.assertTrue(callable(analyzer))

    def test_create_readout_analyzer_supports_heuristic_mode(self):
        analyzer = create_readout_analyzer("heuristic")

        self.assertTrue(callable(analyzer))

    def test_create_readout_analyzer_supports_sae_scaffold_mode(self):
        analyzer = create_readout_analyzer("sae_scaffold")

        self.assertTrue(callable(analyzer))
        capture = ReadoutSidecarCapture(
            run_id="run",
            episode_id="episode",
            worker_id="os_0",
            step=0,
            control_phase_hint="readout_escape",
            answer_readout_canary={
                "reachable_focus_term": "budget",
                "reachable_focus_rank": 900,
                "target_mass": 0.0,
                "attractor_family_mass": 0.2,
            },
            answer_sites=(
                ReadoutSidecarSiteCapture(
                    role="answer_readout",
                    layer=0,
                    token_selector={"mode": "last"},
                    vector=torch.tensor([1.0, 0.0]),
                ),
            ),
            source_sites=(
                ReadoutSidecarSiteCapture(
                    role="source_span",
                    layer=0,
                    token_selector={"mode": "span", "start": 3, "end": 4},
                    vector=torch.tensor([1.0, 0.0]),
                    span=(3, 4),
                    term="budget",
                    provenance_class="source_body",
                ),
            ),
        )
        hints = normalize_readout_sidecar_hints(analyzer(capture))

        self.assertEqual(hints["feature_backend"], "sae_sidecar")
        self.assertEqual(hints["sae_status"], "scaffold_subspace_feature_emitter_no_saelens_runtime")
        self.assertGreaterEqual(len(hints["sae_feature_hints"]), 1)
        self.assertEqual(hints["sae_feature_hints"][0]["operator_family_prior"], "resid_or_readout_boundary")
        self.assertIn(
            "activation_patch_source_to_boundary",
            hints["sae_feature_hints"][0]["operator_family_priors"],
        )
        self.assertEqual(hints["subspace_feature_backend"], "sasa_inspired_scaffold")
        self.assertGreaterEqual(len(hints["sae_feature_subspace_groups"]), 1)
        self.assertEqual(
            hints["sae_feature_subspace_groups"][0]["subspace_family"],
            "source_body_entity_subspace",
        )
        self.assertIn(
            "activation_patch_source_to_boundary",
            hints["sae_feature_subspace_groups"][0]["operator_family_priors"],
        )

    def test_activation_patch_response_guidance_adds_proxy_reliability_evidence(self):
        row = {
            "diagnostic_family": "activation_patch",
            "activation_patch_site": "mlp_out",
            "activation_patch_layer": 11,
            "activation_patch_source_localization": "source_term_token",
            "activation_patch_source_target_cosine": 0.1,
            "activation_patch_source_target_delta_norm": 0.8,
            "activation_patch_blend_delta_norm": 0.12,
            "activation_patch_step_size": 0.2,
            "target_top20_threshold_gap_delta": -0.001,
            "target_piece_logit_delta": 0.0005,
            "target_mass_delta": 0.0,
            "target_top20_hit_delta": 0,
            "focus_rank_delta": 3,
            "production_apply_allowed": False,
            "policy_candidate_ready": False,
        }

        annotated = HookedTransformerWorkerRuntime._annotate_activation_patch_response_guidance(row)

        self.assertTrue(annotated["response_guided_activation_patch_candidate_review"])
        self.assertEqual(annotated["activation_patch_response_guidance_version"], "proxy_v1")
        self.assertEqual(annotated["activation_patch_response_effect_role"], "gap_carrier")
        self.assertLess(annotated["activation_patch_predicted_gap_delta_proxy"], 0.0)
        self.assertIn(
            annotated["attribution_reliability_status"],
            {
                "dead_response_after_positive_proxy",
                "low_proxy_reliability",
                "medium_proxy_reliability",
                "high_proxy_reliability",
            },
        )
        self.assertEqual(
            annotated["activation_patch_response_fingerprint"]["source_localization"],
            "source_term_token",
        )
        self.assertFalse(annotated["production_apply_allowed"])
        self.assertFalse(annotated["policy_candidate_ready"])

    def test_create_readout_sidecar_analyzer_supports_off_mode(self):
        self.assertIsNone(create_readout_sidecar_analyzer("off"))

    def test_create_readout_analyzer_supports_off_mode(self):
        self.assertIsNone(create_readout_analyzer("off"))

    def test_parser_accepts_readout_analyzer_rerank_mode(self):
        parser = _build_parser()

        args = parser.parse_args(
            [
                "--provider",
                "openai",
                "--controller-model",
                "gpt-5.2",
                "--readout-analyzer-rerank-mode",
                "shadow",
            ]
        )

        self.assertEqual(args.readout_analyzer_rerank_mode, "shadow")

    def test_build_hooked_transformer_worker_runtime_wires_semantic_observer(self):
        model, codec = self._make_model_and_codec()
        env = SpiralConstrainedRewriteEnv(semantic_critic=_StubSemanticCritic())
        runtime = build_hooked_transformer_worker_runtime(
            model,
            env,
            seed=7,
            codec=codec,
        )

        prompt = env.reset(7)
        runtime.reset(prompt)

        self.assertIsNotNone(runtime.observer_check_fn)

    def test_build_allowed_token_ids_for_digit_constraint(self):
        codec = CharacterCodec(" 12a")
        model = type("FakeModel", (), {"cfg": type("Cfg", (), {"d_vocab": 4})()})()

        allowed = build_allowed_token_ids_for_constraint(model, codec=codec, decode_constraint="digits_only")

        self.assertEqual(allowed, (1, 2))

    def test_infer_tlens_model_ref_maps_local_llama32_3b_path(self):
        fake_model = type("FakeHFModel", (), {"config": _FakeHFConfig()})()

        inferred = _infer_tlens_model_ref("/definitely/not/local", fake_model)
        self.assertEqual(inferred, "/definitely/not/local")

        with tempfile.TemporaryDirectory() as tmpdir:
            inferred = _infer_tlens_model_ref(tmpdir, fake_model)

        self.assertEqual(inferred, "meta-llama/Llama-3.2-3B")

    def test_create_task_env_supports_copy_and_transform(self):
        self.assertIsInstance(create_task_env("digit_transform"), SpiralDigitTransformEnv)
        self.assertIsInstance(create_task_env("digit_copy"), SpiralDigitCopyEnv)
        self.assertIsInstance(create_task_env("sentence_ordering"), SpiralSentenceOrderingEnv)
        self.assertIsInstance(create_task_env("entailment_reasoning"), SpiralEntailmentReasoningEnv)
        self.assertIsInstance(create_task_env("constrained_rewrite"), SpiralConstrainedRewriteEnv)
        self.assertIsInstance(create_task_env("constrained_rewrite_easy"), SpiralEasyConstrainedRewriteEnv)
        self.assertIsInstance(create_task_env("easy_rewrite"), SpiralEasyConstrainedRewriteEnv)
        self.assertIsInstance(create_task_env("structured_summary"), SpiralStructuredSummaryEnv)

    def test_run_digit_transform_experiment_smoke(self):
        model, codec = self._make_model_and_codec()
        env = SpiralDigitTransformEnv(min_digits=4, max_digits=4)

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "SpiralInterventionLab.examples.digit_transform_e2e.create_controller_provider",
                return_value=_NoopProvider(),
            ):
                result = run_digit_transform_experiment(
                    provider_name="openai",
                    controller_model_name="fake-controller",
                    worker_model_name="tiny-random",
                    seed=7,
                    worker_model=model,
                    task_env=env,
                    codec=codec,
                    log_dir=tmpdir,
                )

            payload = result.to_dict()
            self.assertEqual(payload["controller_provider"], "openai")
            self.assertEqual(payload["task_id"], env.task_id)
            self.assertEqual(payload["controller_reflection_mode"], "off")
            self.assertEqual(payload["semantic_critic_mode"], "off")
            self.assertIsNone(payload["semantic_critic_model_name"])
            self.assertEqual(payload["worker_decoder_control_mode"], "off")

    def test_run_shot_mode_probe_harness_smoke(self):
        class _StubHarnessRuntime:
            def __init__(self):
                self._steps = 0
                self._tool_call_count = 0
                self._surface_catalog_raw = [{"surface_id": "s_resid_pre_l0_last"}]
                self._last_task_feedback = {
                    "required_term_recall": 0.0,
                    "required_term_span_progress": 0.0,
                    "partial_score": 0.45,
                }

            def reset(self, prompt: str) -> None:
                self.prompt = prompt

            def build_controller_packet(self) -> dict[str, object]:
                if self._steps == 0:
                    return {
                        "step": 0,
                        "control_phase_hint": "entity_insertion",
                        "strategy_hints": {
                            "shot_mode_ready": False,
                            "shot_probe_needed": False,
                            "kv_probe_needed": False,
                            "shot_candidate_edits": [],
                            "kv_candidate_edits": [],
                        },
                        "task_feedback": dict(self._last_task_feedback),
                    }
                if self._tool_call_count >= 1:
                    return {
                        "step": 1,
                        "control_phase_hint": "shot_mode",
                        "strategy_hints": {
                            "shot_mode_ready": True,
                            "shot_probe_needed": True,
                            "kv_probe_needed": True,
                            "preferred_kv_surface_id": "s_k_cache_l3_h0_last_promoted",
                            "shot_candidate_edits": [],
                            "kv_candidate_edits": [
                                {
                                    "surface_id": "s_k_cache_l3_h0_last_promoted",
                                    "kind": "kv_mix",
                                    "site": "k_cache",
                                    "recent_probe": {"label": "weak_positive", "score": 1.2},
                                    "source": {
                                        "dtype": "cache_pair",
                                        "k": {
                                            "ref": {
                                                "scope": "runtime",
                                                "worker": "os_0",
                                                "tensor": "k_cache",
                                                "layer": 3,
                                                "head": 0,
                                                "token": {"mode": "index", "value": 4},
                                            }
                                        },
                                    },
                                    "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
                                    "budget": {"ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.03, "revertible": True},
                                    "canary_checked": True,
                                    "canary_pass": True,
                                }
                            ],
                        },
                        "task_feedback": dict(self._last_task_feedback),
                    }
                return {
                    "step": 1,
                    "control_phase_hint": "shot_mode",
                    "strategy_hints": {
                        "shot_mode_ready": True,
                        "shot_probe_needed": True,
                        "kv_probe_needed": True,
                        "preferred_kv_surface_id": "s_k_cache_l3_h0_last_promoted",
                        "shot_candidate_edits": [],
                        "kv_candidate_edits": [
                            {
                                "surface_id": "s_k_cache_l3_h0_last_promoted",
                                "kind": "kv_mix",
                                "site": "k_cache",
                                "source": {
                                    "dtype": "cache_pair",
                                    "k": {
                                        "ref": {
                                            "scope": "runtime",
                                            "worker": "os_0",
                                            "tensor": "k_cache",
                                            "layer": 3,
                                            "head": 0,
                                            "token": {"mode": "index", "value": 4},
                                        }
                                    },
                                },
                                "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
                                "budget": {"ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.03, "revertible": True},
                                "canary_checked": True,
                                "canary_pass": True,
                            },
                            {
                                "surface_id": "s_v_cache_l3_h1_last_promoted",
                                "kind": "kv_mix",
                                "site": "v_cache",
                                "source": {
                                    "dtype": "cache_pair",
                                    "v": {
                                        "ref": {
                                            "scope": "runtime",
                                            "worker": "os_0",
                                            "tensor": "v_cache",
                                            "layer": 3,
                                            "head": 1,
                                            "token": {"mode": "index", "value": 5},
                                        }
                                    },
                                },
                                "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
                                "budget": {"ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.04, "revertible": True},
                                "canary_checked": True,
                                "canary_pass": False,
                            }
                        ],
                    },
                    "task_feedback": dict(self._last_task_feedback),
                }

            def step(self) -> None:
                self._steps += 1

            def done(self) -> bool:
                return False

            def final_text(self) -> str:
                return "EW"

            def request_controller_tools(self, requests, *, source: str = "controller"):
                self._tool_call_count += 1
                return [
                    {
                        "tool": "dry_run_decode",
                        "requested_by": source,
                        "status": "ok",
                        "candidate_edit": dict(requests[0]["candidate_edit"]),
                        "required_term_recall_delta": 0.0,
                        "required_term_span_progress_delta": 0.25,
                        "semantic_progress_delta": 0.02,
                    }
                ]

        env = SpiralConstrainedRewriteEnv()
        stub_runtime = _StubHarnessRuntime()
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "SpiralInterventionLab.examples.digit_transform_e2e.build_hooked_transformer_worker_runtime",
                return_value=stub_runtime,
            ):
                result = run_shot_mode_probe_harness(
                    worker_model_name="tiny-random",
                    seed=7,
                    worker_model=object(),
                    task_env=env,
                    log_dir=tmpdir,
                    worker_decoder_control_mode="logit_bias_entity_soft",
                    max_steps=4,
                    max_probe_candidates=2,
                )

            payload = result.to_dict()
            self.assertTrue(payload["shot_mode_reached"])
            self.assertEqual(payload["shot_mode_step"], 1)
            self.assertEqual(payload["probe_round_count"], 2)
            self.assertEqual(payload["observation_summary"]["preferred_kv_surface_id"], "s_k_cache_l3_h0_last_promoted")
            self.assertEqual(payload["probe_results"][0]["candidate_edit"]["site"], "k_cache")
            self.assertEqual(payload["probe_results"][0]["required_term_span_progress_delta"], 0.25)
            self.assertEqual(payload["probe_results"][0]["probe_stage"], 1)
            self.assertEqual(payload["probe_results"][1]["probe_stage"], 2)
            self.assertTrue((Path(tmpdir) / "shot_harness_summary.json").exists())

    def test_run_digit_transform_c1_only_experiment_smoke(self):
        model, codec = self._make_model_and_codec()
        env = SpiralDigitCopyEnv(min_digits=4, max_digits=4)

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "SpiralInterventionLab.examples.digit_transform_e2e.create_controller_provider",
                return_value=_NoopProvider(),
            ):
                result = run_digit_transform_c1_only_experiment(
                    provider_name="openai",
                    controller_model_name="fake-controller",
                    worker_model_name="tiny-random",
                    seed=7,
                    worker_model=model,
                    task_env=env,
                    codec=codec,
                    log_dir=tmpdir,
                    controller_reflection_mode="structured",
                    semantic_critic_mode="off",
                    worker_decoder_control_mode="loop_aware",
                    worker_loop_rescue_edits_per_run=2,
                    worker_loop_rescue_total_alpha=0.12,
                )

            payload = result.to_dict()
            self.assertEqual(payload["suite_mode"], "c1_only")
            self.assertEqual(payload["task_id"], env.task_id)
            self.assertEqual(payload["controller_reflection_mode"], "structured")
            self.assertEqual(payload["semantic_critic_mode"], "off")
            self.assertEqual(payload["worker_decoder_control_mode"], "loop_aware")
            self.assertEqual(payload["worker_loop_rescue_edits_per_run"], 2)
            self.assertAlmostEqual(payload["worker_loop_rescue_total_alpha"], 0.12)
            self.assertIsNone(payload["b0"])
            self.assertIsNone(payload["b1"])
            self.assertIn("c1", payload)
            self.assertFalse(Path(tmpdir, "b0.jsonl").exists())
            self.assertFalse(Path(tmpdir, "b1.jsonl").exists())
            self.assertTrue(Path(tmpdir, "c1.jsonl").exists())
            self.assertTrue(Path(tmpdir, "experiment_summary.json").exists())

    def test_run_readout_escape_replay_harness_logs_controller_selection(self):
        model, codec = self._make_model_and_codec()
        class _ShortReplayEnv:
            task_id = "readout_escape_replay"

            def reset(self, seed: int) -> str:
                return "SOURCE: send budget\nANSWER:"

            def score(self, output: str) -> float:
                return 0.0

            def done(self, output: str) -> bool:
                return len(output) >= 2

            def worker_runtime_kwargs(self) -> dict[str, int]:
                return {"max_generated_tokens": 2}

        env = _ShortReplayEnv()

        with tempfile.TemporaryDirectory() as tmpdir:
            result = run_readout_escape_replay_harness(
                worker_model_name="tiny-random",
                seed=7,
                worker_model=model,
                task_env=env,
                codec=codec,
                log_dir=tmpdir,
            )

            payload = result.to_dict()
            self.assertEqual(payload["suite_mode"], "readout_escape_replay_harness")
            self.assertTrue(payload["readout_escape_seen"])
            self.assertGreaterEqual(payload["controller_selection_event_count"], 1)
            self.assertGreaterEqual(payload["nonnull_gate_frontier_count"], 1)
            self.assertGreaterEqual(payload["nonnull_controller_selected_count"], 1)
            self.assertEqual(payload["gate_report_frontier_bundle_key"], payload["forced_challenger_bundle_key"])
            self.assertEqual(payload["controller_selected_bundle_key"], payload["forced_challenger_bundle_key"])
            self.assertEqual(payload["controller_selection_source"], "forced_diagnostic_apply")
            self.assertEqual(payload["controller_objective_bundle_key"], payload["forced_challenger_bundle_key"])
            self.assertEqual(payload["controller_step_actuator_bundle_key"], payload["forced_challenger_bundle_key"])
            self.assertEqual(payload["controller_plan_mode"], "single_layer")
            self.assertGreaterEqual(payload["controller_shadow_proposal_count"], 1)
            self.assertIn("controller_step_views", payload)
            self.assertTrue(payload["controller_step_views"])
            first_step_view = payload["controller_step_views"][0]
            self.assertIn("provider_attempts", first_step_view)
            self.assertIn("controller_command", first_step_view)
            self.assertIn("controller_selection", first_step_view)
            self.assertGreaterEqual(first_step_view["provider_attempt_count"], 1)
            first_attempt = first_step_view["provider_attempts"][0]
            self.assertIsNotNone(first_attempt["raw_json_object"])
            self.assertIsNotNone(first_attempt["normalized_payload"])
            self.assertEqual(first_attempt["normalization_delta"]["normalization_kind"], "replay_passthrough")
            self.assertTrue(Path(tmpdir, "readout_escape_replay.jsonl").exists())
            self.assertTrue(Path(tmpdir, "readout_escape_replay_summary.json").exists())

    def test_controller_step_views_hoist_positive_operator_deepening_plan(self):
        plan = {
            "kind": "positive_operator_deepening_plan",
            "recipe_family": "readout_steering",
            "next_action": "deepen_local_gap_closer",
            "deepening_axis": "target_top20_gap_closing",
            "reason_code": "positive_memory_local_gap_closer",
            "curiosity_signal": "positive_operator_memory_deepen_local_gap_closer",
        }
        views = _controller_step_views(
            [
                {
                    "event": "controller_observation",
                    "step": 2,
                    "latest_diagnostic_results": [
                        {
                            "diagnostic": "compare_extra_operator_diagnostics",
                            "operator_recipe_expansion_summary": {
                                "positive_operator_deepening_plan": plan,
                            },
                        }
                    ],
                }
            ]
        )

        self.assertEqual(len(views), 1)
        self.assertEqual(views[0]["positive_operator_deepening_plan"]["reason_code"], "positive_memory_local_gap_closer")
        self.assertEqual(
            views[0]["controller_observation"]["positive_operator_deepening_plan"]["deepening_axis"],
            "target_top20_gap_closing",
        )
        self.assertEqual(
            views[0]["controller_observation"]["controller_curiosity_signal"],
            "positive_operator_memory_deepen_local_gap_closer",
        )

    def test_diagnostic_evidence_ledger_keeps_readout_gap_closer_rows_visible(self):
        extras = [
            {
                "objective_bundle_key": "kv_pair:budget:source_body:72:73",
                "diagnostic_family": "readout_steering",
                "actuator_class": "self_actuator",
                "recipe_name": f"plain_readout_{idx:02d}",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 1,
            }
            for idx in range(60)
        ]
        extras.extend(
            [
                {
                    "objective_bundle_key": "kv_pair:budget:source_body:72:73",
                    "diagnostic_family": "readout_steering",
                    "actuator_class": "self_actuator",
                    "recipe_name": "target_readout_patch_pure_a060_gap",
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                    "target_top20_threshold_gap": 6.1,
                    "focus_rank_delta": 1,
                    "readout_gap_closer_recipe": True,
                    "readout_gap_closer_axis": "target_top20_gap",
                },
                {
                    "objective_bundle_key": "kv_pair:budget:source_body:72:73",
                    "diagnostic_family": "readout_steering",
                    "actuator_class": "self_actuator",
                    "recipe_name": "target_readout_patch_l005_a060_gap",
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                    "target_top20_threshold_gap": 6.0,
                    "focus_rank_delta": 1,
                    "readout_gap_closer_recipe": True,
                    "readout_gap_closer_axis": "target_top20_gap",
                },
            ]
        )

        ledger = _diagnostic_evidence_ledger(
            {"extra_operator_diagnostics": extras},
            {"gate_report_frontier_bundle_key": "kv_pair:budget:source_body:72:73"},
        )["diagnostic_evidence_ledger"]

        visible_names = [item.get("recipe_name") for item in ledger[:4]]
        self.assertIn("target_readout_patch_pure_a060_gap", visible_names)
        self.assertIn("target_readout_patch_l005_a060_gap", visible_names)

    def test_run_readout_escape_replay_harness_directscan_logs_controller_selection(self):
        model, codec = self._make_model_and_codec()

        class _ShortReplayEnv:
            task_id = "readout_escape_replay"

            def reset(self, seed: int) -> str:
                return "Keep these terms: send, budget\nSOURCE: send budget now\nANSWER:"

            def score(self, output: str) -> float:
                return 0.0

            def done(self, output: str) -> bool:
                return len(output) >= 2

            def worker_runtime_kwargs(self) -> dict[str, int]:
                return {"max_generated_tokens": 2}

        with tempfile.TemporaryDirectory() as tmpdir:
            result = run_readout_escape_replay_harness(
                worker_model_name="tiny-random",
                seed=7,
                packet_mode="directscan",
                worker_model=model,
                task_env=_ShortReplayEnv(),
                codec=codec,
                log_dir=tmpdir,
                readout_sidecar_analyzer=create_readout_sidecar_analyzer("heuristic"),
                readout_analyzer_rerank_mode="apply",
            )

            payload = result.to_dict()
            self.assertEqual(payload["suite_mode"], "readout_escape_replay_harness")
            self.assertEqual(payload["packet_mode"], "directscan")
            self.assertTrue(payload["readout_escape_seen"])
            self.assertIn("baseline_span_mean", payload["bridge_eval_recipe_names"])
            self.assertIn("term_centered_pm1_minus_stealer_l025", payload["bridge_eval_recipe_names"])
            self.assertIn("bridge_eval_matrix", payload)
            if payload["bridge_eval_matrix"]:
                first_row = payload["bridge_eval_matrix"][0]
                self.assertIn("candidate_fingerprint", first_row)
                self.assertIn("eval_context_fingerprint", first_row)
                self.assertEqual(payload["bridge_eval_locked_step"], 0)
                self.assertFalse(payload["bridge_eval_context_drift"])
                self.assertEqual(first_row["eval_context_fingerprint"].get("decode_step"), 0)
                self.assertEqual(first_row["eval_context_fingerprint"].get("answer_prefix"), "")
            self.assertIn("bridge_plan_unavailable_reason", payload)
            self.assertIn("bridge_plan_unavailable_objective_reasons", payload)
            self.assertIn("bridge_eval_context_drift", payload)
            self.assertIn("bridge_eval_locked_step", payload)
            self.assertIn("bridge_eval_operator_recipe_mode_diagnostics", payload)
            self.assertTrue(payload["bridge_eval_operator_recipe_mode_diagnostics"])
            first_mode_row = payload["bridge_eval_operator_recipe_mode_diagnostics"][0]
            self.assertIn("diagnosis", first_mode_row)
            self.assertIn("pair_interaction_delta", first_mode_row)
            self.assertIn("modes", first_mode_row)
            self.assertIn("bridge_eval_attention_scale_response_diagnostics", payload)
            self.assertIn("bridge_eval_extra_operator_diagnostics", payload)
            self.assertIn("bridge_eval_poststep_comparison", payload)
            self.assertIn("bridge_eval_candidate_swap_comparison", payload)
            self.assertIn("diagnostic_evidence_ledger", payload)
            self.assertIn("bundle_diagnostic_status", payload)
            self.assertGreaterEqual(payload["diagnostic_evidence_ledger_count"], 0)
            for status in payload["bundle_diagnostic_status"].values():
                self.assertFalse(status.get("operator_certified", False))
                self.assertFalse(status.get("production_operator_certified", False))
                self.assertIn("diagnostic_operator_supported", status)
                self.assertIn("policy_candidate_ready", status)
            if payload["diagnostic_frontier_bundle_key"]:
                self.assertIn(payload["diagnostic_frontier_bundle_key"], payload["bundle_diagnostic_status"])
                self.assertTrue(payload["diagnostic_frontier_next_evidence"])
                self.assertTrue(payload["diagnostic_frontier_request"])
                self.assertIn(
                    payload["diagnostic_frontier_request"],
                    {
                        "operator_diagnostic_replay",
                        "attention_readout_carrier_probe",
                        "attention_head_ablation_on_frontier",
                        "readout_logit_adjacent_probe",
                        "sae_feature_emitter_scan",
                        "compare_extra_operator_diagnostics",
                        "cross_bundle_bridge_search",
                        "activation_patch_candidate_review",
                        "activation_patch_runtime_support_probe",
                        "activation_patch_promotion_gate_review",
                        "activation_patch_production_shadow_replay",
                        "activation_patch_production_trial_gate_review",
                        "none",
                    },
                )
            if payload["bridge_eval_extra_operator_diagnostics"]:
                extra_row = payload["bridge_eval_extra_operator_diagnostics"][0]
                self.assertTrue(extra_row["diagnostic_only"])
                self.assertIn(
                    extra_row["diagnostic_family"],
                    {
                        "resid_source_span",
                        "readout_local_boundary",
                        "attention_head_ablation",
                        "attention_head_scale",
                        "attention_guided_operator",
                        "activation_patch",
                        "logit_adjacent",
                    },
                )
                attention_guided_rows = [
                    row
                    for row in payload["bridge_eval_extra_operator_diagnostics"]
                    if row.get("diagnostic_family") == "attention_guided_operator"
                ]
                for row in attention_guided_rows:
                    self.assertIn("attention_carrier_scale", row)
                    self.assertIn("candidate_fingerprint", row)
                    self.assertIn("eval_context_fingerprint", row)
                activation_patch_rows = [
                    row
                    for row in payload["bridge_eval_extra_operator_diagnostics"]
                    if row.get("diagnostic_family") == "activation_patch"
                ]
                for row in activation_patch_rows:
                    self.assertIn("activation_patch_site", row)
                    self.assertIn("activation_hook_call_count", row)
                    self.assertIn("actual_delta_class", row)
                    self.assertIn("self_delta", row)
                    self.assertIn("cross_delta", row)
                    self.assertIn("alignment_margin", row)
                    self.assertIn("realized_lift_bundle_key", row)
                    self.assertIn("candidate_fingerprint", row)
                    self.assertIn("eval_context_fingerprint", row)
            if payload["bridge_eval_attention_scale_response_diagnostics"]:
                response_row = payload["bridge_eval_attention_scale_response_diagnostics"][0]
                self.assertIn("response_profile", response_row)
                self.assertIn("scale_points", response_row)
                self.assertIn("shadow_actuator", response_row)
                if response_row["shadow_actuator"] is not None:
                    self.assertEqual(response_row["shadow_actuator"]["kind"], "attention_shadow_actuator")
                    self.assertFalse(response_row["shadow_actuator"]["production_apply_allowed"])
                    self.assertIn("counterfactual_delta", response_row["shadow_actuator"])
                    self.assertIn("attention_shadow_actuator_class", response_row["shadow_actuator"])
                    self.assertIn("promotable_to_certification_replay", response_row["shadow_actuator"])
                    self.assertIn("promotion_reason", response_row["shadow_actuator"])
                    self.assertIn("attention_shadow_actuator_class", response_row)
                    self.assertIn("attention_shadow_promotable_to_certification_replay", response_row)
                zero_points = [
                    item
                    for item in response_row["scale_points"]
                    if abs(float(item.get("scale", 1.0) or 0.0)) <= 1e-9
                ]
                if zero_points and float(zero_points[0].get("head_norm_before", 0.0) or 0.0) > 0.0:
                    partial_points = [
                        item
                        for item in response_row["scale_points"]
                        if float(item.get("scale", 0.0) or 0.0) > 0.0
                        and int(item.get("hook_call_count", 0) or 0) > 0
                    ]
                    for item in partial_points:
                        self.assertGreater(float(item.get("head_norm_before", 0.0) or 0.0), 0.0)
            self.assertIsInstance(payload["bridge_eval_locked_step"], (int, type(None)))
            if payload["bridge_plan_recommendation_count"] == 0:
                self.assertTrue(payload["bridge_plan_unavailable_reason"])
            self.assertGreaterEqual(payload["controller_selection_event_count"], 1)
            self.assertIn("controller_step_views", payload)
            self.assertTrue(payload["controller_step_views"])
            if payload["bridge_visible_step_views"]:
                first_bridge_view = payload["bridge_visible_step_views"][0]
                self.assertTrue(first_bridge_view["bridge_visible"])
                self.assertIn("bridge_dual_layer_missing", first_bridge_view)
            if payload["nonnull_gate_frontier_count"] > 0:
                self.assertGreaterEqual(payload["nonnull_controller_selected_count"], 1)
                self.assertEqual(payload["controller_selected_bundle_key"], payload["gate_report_frontier_bundle_key"])

    def test_run_readout_escape_replay_harness_directscan_executes_diagnostic_request_mode(self):
        model, codec = self._make_model_and_codec()

        class _ShortReplayEnv:
            task_id = "readout_escape_replay"

            def reset(self, seed: int) -> str:
                return "Keep these terms: send, budget\nSOURCE: send budget now\nANSWER:"

            def score(self, output: str) -> float:
                return 0.0

            def done(self, output: str) -> bool:
                return len(output) >= 3

            def worker_runtime_kwargs(self) -> dict[str, int]:
                return {"max_generated_tokens": 3}

        with tempfile.TemporaryDirectory() as tmpdir:
            result = run_readout_escape_replay_harness(
                worker_model_name="tiny-random",
                seed=7,
                packet_mode="directscan",
                controller_replay_mode="diagnostic_request",
                worker_model=model,
                task_env=_ShortReplayEnv(),
                codec=codec,
                log_dir=tmpdir,
                readout_sidecar_analyzer=create_readout_sidecar_analyzer("heuristic"),
                readout_analyzer_rerank_mode="apply",
            )

            payload = result.to_dict()
            self.assertEqual(payload["replay_mode"], "directscan_diagnostic_request")
            self.assertGreaterEqual(payload["diagnostic_request_event_count"], 1)
            self.assertGreaterEqual(payload["diagnostic_result_event_count"], 1)
            self.assertTrue(payload["controller_diagnostic_request_names"])
            self.assertTrue(payload["latest_diagnostic_results"])
            latest = payload["latest_diagnostic_results"][-1]
            self.assertFalse(latest["production_apply_allowed"])
            self.assertFalse(latest.get("operator_certified", False))
            self.assertFalse(latest.get("production_operator_certified", False))
            self.assertIn("diagnostic_operator_supported", latest)
            self.assertIn("policy_candidate_ready", latest)
            if latest["diagnostic"] == "operator_diagnostic_replay":
                self.assertTrue(
                    any(
                        row.get("evidence_kind")
                        in {
                            "operator_mode_decomposition",
                            "attention_guided_operator_certification",
                            "activation_patch_certification",
                        }
                        for row in latest.get("evidence_rows", [])
                    )
                )
            self.assertIn(
                latest["diagnostic"],
                {
                    "operator_diagnostic_replay",
                    "attention_readout_carrier_probe",
                    "attention_head_ablation_on_frontier",
                    "readout_logit_adjacent_probe",
                    "sae_feature_emitter_scan",
                    "compare_extra_operator_diagnostics",
                    "cross_bundle_bridge_search",
                    "activation_patch_candidate_review",
                    "activation_patch_runtime_support_probe",
                    "activation_patch_promotion_gate_review",
                    "activation_patch_production_shadow_replay",
                    "activation_patch_production_trial_gate_review",
                },
            )
            if latest["diagnostic"] == "activation_patch_candidate_review":
                self.assertEqual(latest.get("diagnostic_role"), "activation_patch_candidate_review")
                self.assertFalse(latest["production_apply_allowed"])
                if latest.get("activation_patch_candidate_review") is not None:
                    self.assertIn("blueprint", latest["activation_patch_candidate_review"])
                    self.assertFalse(latest["activation_patch_candidate_review"]["blueprint"]["production_apply_allowed"])
                    self.assertIn("compile_preview_created", latest["activation_patch_candidate_review"])
                    self.assertIn("compile_preview_blocked_reason", latest["activation_patch_candidate_review"])
                    if latest["activation_patch_candidate_review"].get("compile_preview") is not None:
                        self.assertTrue(latest["activation_patch_candidate_review"]["compile_preview_created"])
                        self.assertFalse(latest["activation_patch_candidate_review"]["compile_preview"]["production_apply_allowed"])
                        self.assertEqual(
                            latest["activation_patch_candidate_review"]["compile_preview"]["compile_state"],
                            "preview_only",
                        )
                    else:
                        self.assertFalse(latest["activation_patch_candidate_review"]["compile_preview_created"])
                        self.assertIsNotNone(latest["activation_patch_candidate_review"]["compile_preview_blocked_reason"])
                self.assertIn("activation_patch_compile_preview_created", latest)
            if latest.get("activation_patch_compile_preview_created"):
                self.assertIn(
                    latest["next_evidence_needed"],
                    {
                        "production_activation_patch_operator_support",
                        "same_context_physical_confirmation",
                        "activation_patch_promotion_gate_review",
                        "activation_patch_production_shadow_replay",
                        "activation_patch_production_trial_gate_review",
                        "alternate_activation_patch_or_bridge_evidence",
                        "production_policy_review",
                        "production_trial_gate_review",
                        "bounded_production_trial",
                        "production_trial_gate_followup",
                        "post_bridge_exhaustion_recipe_expansion",
                        "readout_steering_deepening",
                    },
                )
                self.assertFalse(latest["production_apply_allowed"])
            if latest["diagnostic"] == "activation_patch_runtime_support_probe":
                self.assertEqual(latest.get("diagnostic_role"), "activation_patch_runtime_support_probe")
                self.assertFalse(latest["production_apply_allowed"])
                self.assertIn("activation_patch_runtime_support_probe", latest)
                self.assertIn("activation_patch_diagnostic_executable_created", latest)
                if latest.get("activation_patch_executable_shadow") is not None:
                    self.assertEqual(
                        latest["activation_patch_executable_shadow"]["compile_state"],
                        "executable_shadow",
                    )
                    self.assertFalse(latest["activation_patch_executable_shadow"]["production_apply_allowed"])
                    self.assertFalse(latest["activation_patch_executable_shadow"]["certified_for_apply"])
            if latest["diagnostic"] == "activation_patch_promotion_gate_review":
                self.assertEqual(latest.get("diagnostic_role"), "activation_patch_promotion_gate_review")
                self.assertFalse(latest["production_apply_allowed"])
                self.assertIn("activation_patch_promotion_gate_review", latest)
                self.assertIn("activation_patch_promotion_gate_passed", latest)
                self.assertIn("activation_patch_production_denial_dossier", latest)
                dossier = latest.get("activation_patch_production_denial_dossier")
                self.assertIsInstance(dossier, dict)
                self.assertFalse(dossier["production_apply_allowed"])
                self.assertFalse(dossier["production_operator_certified"])
                self.assertIn("active_reasons", dossier)
                self.assertIn("axes", dossier)
                self.assertEqual(
                    set(dossier["axes"]),
                    {
                        "ownership_not_live_certified",
                        "safety_not_certified",
                        "context_equivalence_missing",
                        "rollback_contract_missing",
                        "effect_size_too_small",
                    },
                )
                self.assertIn("production_denial_reasons", latest)
                if latest.get("activation_patch_production_apply_candidate") is not None:
                    self.assertTrue(latest["policy_candidate_ready"])
                    self.assertTrue(latest["diagnostic_operator_supported"])
                    self.assertEqual(
                        latest["activation_patch_production_apply_candidate"]["compile_state"],
                        "production_apply_candidate",
                    )
                    self.assertFalse(latest["activation_patch_production_apply_candidate"]["production_apply_allowed"])
                    self.assertFalse(latest["activation_patch_production_apply_candidate"]["certified_for_apply"])
            if latest["diagnostic"] == "activation_patch_production_shadow_replay":
                self.assertEqual(latest.get("diagnostic_role"), "activation_patch_production_shadow_replay")
                self.assertFalse(latest["production_apply_allowed"])
                self.assertFalse(latest.get("production_operator_certified", False))
                self.assertIn("activation_patch_production_shadow_replay", latest)
                self.assertIn("activation_patch_production_shadow_dossier", latest)
                shadow_dossier = latest.get("activation_patch_production_shadow_dossier")
                self.assertIsInstance(shadow_dossier, dict)
                self.assertFalse(shadow_dossier["production_apply_allowed"])
                self.assertFalse(shadow_dossier["production_operator_certified"])
                self.assertIn("active_reasons_after_shadow", shadow_dossier)
                self.assertIn("axes", shadow_dossier)
                self.assertEqual(
                    set(shadow_dossier["axes"]),
                    {
                        "ownership_not_live_certified",
                        "safety_not_certified",
                        "context_equivalence_missing",
                        "rollback_contract_missing",
                        "effect_size_too_small",
                    },
                )
                self.assertIn("production_denial_reasons_after_shadow", latest)
            if latest["diagnostic"] == "activation_patch_production_trial_gate_review":
                self.assertEqual(latest.get("diagnostic_role"), "activation_patch_production_trial_gate_review")
                self.assertFalse(latest["production_apply_allowed"])
                self.assertFalse(latest.get("production_operator_certified", False))
                self.assertFalse(latest.get("operator_certified", False))
                self.assertIn("activation_patch_production_trial_gate_review", latest)
                self.assertIn("activation_patch_production_trial_dossier", latest)
                self.assertIn("production_trial_allowed", latest)
                self.assertIn("production_trial_blocked_reasons", latest)
                trial_dossier = latest.get("activation_patch_production_trial_dossier")
                self.assertIsInstance(trial_dossier, dict)
                self.assertFalse(trial_dossier["production_apply_allowed"])
                self.assertFalse(trial_dossier["production_operator_certified"])
                self.assertIn("trial_blocked_reasons", trial_dossier)
                self.assertIn("contract", trial_dossier)
                trial_contract = latest.get("activation_patch_production_trial_contract")
                if trial_contract is not None:
                    self.assertEqual(trial_contract["ttl_steps"], 1)
                    self.assertLessEqual(float(trial_contract["norm_clip"]), 1.0)
                    self.assertLessEqual(float(trial_contract["max_alpha"]), 0.15)
                    self.assertTrue(trial_contract["revertible"])
                    self.assertTrue(trial_contract["separate_trial_budget"])
                    self.assertFalse(trial_contract["production_apply_allowed"])
                    self.assertFalse(trial_contract["certified_for_apply"])
                if latest.get("production_trial_allowed"):
                    self.assertIn("activation_patch_production_trial_candidate", latest)
                    trial_candidate = latest.get("activation_patch_production_trial_candidate")
                    self.assertIsInstance(trial_candidate, dict)
                    self.assertEqual(trial_candidate["compile_state"], "production_trial_candidate")
                    self.assertEqual(trial_candidate["apply_kind"], "production_trial")
                    self.assertFalse(trial_candidate["production_apply_allowed"])
                    self.assertFalse(trial_candidate["certified_for_apply"])
                    self.assertIn("trial_edit", trial_candidate)
                    self.assertEqual(trial_candidate["trial_edit"]["meta"]["apply_kind"], "production_trial")
                    self.assertFalse(trial_candidate["trial_edit"]["meta"]["production_apply_allowed"])
                    self.assertFalse(trial_candidate["trial_edit"]["meta"]["certified_for_apply"])
            if latest["diagnostic"] == "attention_readout_carrier_probe":
                self.assertEqual(latest.get("diagnostic_role"), "rank_readout_carrier")
                self.assertFalse(latest["production_apply_allowed"])
                if latest.get("attention_shadow_actuator") is not None:
                    self.assertFalse(latest["attention_shadow_actuator"]["production_apply_allowed"])
                    self.assertIn("counterfactual_delta", latest["attention_shadow_actuator"])
                    self.assertIn("attention_shadow_actuator_class", latest["attention_shadow_actuator"])
                    self.assertIn("promotable_to_certification_replay", latest["attention_shadow_actuator"])
                    self.assertIn("attention_shadow_actuator_class", latest)
                    self.assertIn("attention_shadow_promotable_to_certification_replay", latest)
            if latest.get("activation_patch_shadow_actuator") is not None:
                self.assertFalse(latest["activation_patch_shadow_actuator"]["production_apply_allowed"])
                self.assertIn("counterfactual_delta", latest["activation_patch_shadow_actuator"])
                self.assertIn("activation_patch_actuator_class", latest["activation_patch_shadow_actuator"])
                self.assertIn("activation_patch_actuator_class", latest)
                self.assertIn("activation_patch_promotable_to_candidate", latest)
            self.assertTrue(
                any(
                    view["diagnostic_request_count"] >= 1 and view["diagnostic_result_count"] >= 1
                    for view in payload["controller_step_views"]
                )
            )
            self.assertTrue(
                any(
                    view.get("loop_patience_count", 0) >= 1
                    for view in payload["controller_step_views"]
                )
            )
            self.assertTrue(
                any(
                    "loop_patience_budget_left" in row
                    and "next_evidence_transition" in row
                    for view in payload["controller_step_views"]
                    for row in view.get("loop_patience", [])
                )
            )
            if latest.get("activation_patch_compile_preview_created"):
                self.assertTrue(
                    any(
                        row.get("next_evidence_transition") is True
                        and row.get("next_evidence_after")
                        in {
                            "production_activation_patch_operator_support",
                            "activation_patch_runtime_operator_certification",
                            "activation_patch_promotion_gate_review",
                            "production_shadow_replay",
                            "production_policy_review",
                            "production_trial_gate_review",
                            "bounded_production_trial",
                            "production_trial_gate_followup",
                        }
                        for view in payload["controller_step_views"]
                        for row in view.get("loop_patience", [])
                    )
                )
            self.assertTrue(
                any(
                    isinstance(view.get("controller_observation"), dict)
                    and view["controller_observation"].get("latest_diagnostic_result_count", 0) >= 1
                    for view in payload["controller_step_views"]
                )
            )
            self.assertTrue(Path(tmpdir, "readout_escape_replay.jsonl").exists())
            self.assertTrue(Path(tmpdir, "readout_escape_replay_summary.json").exists())
            with Path(tmpdir, "readout_escape_replay.jsonl").open() as handle:
                rows = [json.loads(line) for line in handle if line.strip()]
            trial_apply_rows = [
                row
                for row in rows
                if row.get("event") == "controller_selection"
                and row.get("controller_selection_source") == "production_trial_apply"
            ]
            if latest["diagnostic"] == "activation_patch_production_trial_gate_review" and latest.get(
                "production_trial_allowed"
            ):
                self.assertTrue(trial_apply_rows)
                trial_apply_row = trial_apply_rows[0]
                self.assertEqual(trial_apply_row["controller_apply_kind"], "production_trial")
                self.assertFalse(trial_apply_row["production_apply_allowed"])
                self.assertFalse(trial_apply_row["certified_for_apply"])
                self.assertTrue(
                    any(row.get("event") == "production_trial_ttl_deferred" for row in rows)
                )
                trial_effect_rows = [
                    row
                    for row in rows
                    if row.get("event") == "controller_effect"
                    and row.get("apply_kind") == "production_trial"
                ]
                for row in trial_effect_rows:
                    self.assertFalse(row["production_apply_allowed"])
                    self.assertFalse(row["certified_for_apply"])

    def test_frontier_replay_consumes_production_trial_followup_before_runtime_probe(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        recipe = "readout_escape|activation_patch|resid_post|L6|source_span_to_last|blend|a0.150"
        compile_preview = {
            "bundle_key": objective,
            "objective_bundle_key": objective,
            "actuator_bundle_key": objective,
            "recipe_name": "activation_patch_source_span_to_last",
            "operator_recipe_id": recipe,
            "compile_state": "preview_only",
            "production_apply_allowed": False,
            "certified_for_apply": False,
        }
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": recipe,
            "surface_family_key": "activation_patch_trial:s_resid_pre_l6_last",
            "trial_effect_class": "regressing",
            "verdict": "harmful",
            "actuator_class": "unknown",
        }
        base_packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
        }

        pre_followup_packet = {
            **base_packet,
            "latest_diagnostic_results": [
                {
                    "diagnostic": "activation_patch_production_trial_gate_review",
                    "objective_bundle_key": objective,
                    "activation_patch_compile_preview": compile_preview,
                    "production_apply_allowed": False,
                }
            ],
        }
        pre_command = controller._diagnostic_request_command(
            packet=pre_followup_packet,
            strategy_hints=pre_followup_packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )
        self.assertEqual(pre_command["decision"], "noop")
        self.assertEqual(pre_command["meta"]["next_action"], "request_compare_extra_operator_diagnostics")
        self.assertEqual(pre_command["meta"]["diagnostic_request"]["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(
            pre_command["meta"]["next_evidence_needed"],
            "alternate_operator_recipe_after_trial",
        )

        post_followup_packet = {
            **base_packet,
            "latest_diagnostic_results": [
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "activation_patch_compile_preview": compile_preview,
                    "evidence_rows": [
                        {
                            "evidence_kind": "activation_patch_certification",
                            "status": "blocked",
                            "operator_recipe_id": recipe,
                        }
                    ],
                    "production_apply_allowed": False,
                    "diagnostic_operator_supported": False,
                    "policy_candidate_ready": False,
                }
            ],
        }
        post_command = controller._diagnostic_request_command(
            packet=post_followup_packet,
            strategy_hints=post_followup_packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )
        meta = post_command["meta"]
        self.assertEqual(post_command["decision"], "noop")
        self.assertEqual(meta["next_action"], "noop")
        self.assertEqual(meta["next_evidence_needed"], "alternate_trial_candidate_generator")
        self.assertNotIn("diagnostic_request", meta)
        self.assertTrue(meta["production_trial_followup_consumed"])
        self.assertTrue(meta["activation_patch_pipeline_suppressed_by_production_trial_outcome"])
        self.assertEqual(
            meta["blocked_by"],
            "production_trial_alternate_evidence_pending_candidate_generator",
        )
        self.assertIn("production_trial_alternate_evidence", meta)

    def test_frontier_replay_neutral_trial_requests_confirmation_neighborhood(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        recipe = "readout_escape|activation_patch|resid_pre|L6|source_centered_pm1_to_last|blend|a0.050"
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": recipe,
            "surface_family_key": "activation_patch_trial:s_resid_pre_l6_last",
            "trial_effect_class": "neutral",
            "verdict": "neutral",
            "actuator_class": "unknown",
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
            "latest_diagnostic_results": [
                {
                    "diagnostic": "activation_patch_production_trial_gate_review",
                    "objective_bundle_key": objective,
                    "production_apply_allowed": False,
                }
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )

        meta = command["meta"]
        request = meta["diagnostic_request"]
        self.assertEqual(command["decision"], "noop")
        self.assertEqual(meta["next_action"], "request_compare_extra_operator_diagnostics")
        self.assertEqual(meta["next_evidence_needed"], "neutral_followup_confirmation_replay")
        self.assertEqual(meta["blocked_by"], "production_trial_neutral_followup_confirmation")
        self.assertEqual(meta["neutral_followup_neighborhood"], "contrastive_source_local")
        self.assertTrue(meta["production_trial_neutral_followup_confirmation_requested"])
        self.assertEqual(request["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(request["trial_followup_mode"], "confirmation_neighborhood")
        self.assertEqual(request["neutral_followup_neighborhood"], "contrastive_source_local")
        self.assertEqual(
            meta["controller_memory"]["neutral_followup_neighborhood"],
            "contrastive_source_local",
        )

    def test_frontier_replay_generates_alternate_trial_candidate_from_compare_evidence(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        stealer = "kv_pair:send:source_body:70:71"
        failed_recipe = "readout_escape|activation_patch|resid_post|L6|source_span_to_last|blend|a0.150"
        site_shift_recipe = "readout_escape|activation_patch|resid_pre|L6|source_span_to_last|blend|a0.050"
        source_local_recipe = "readout_escape|activation_patch|resid_pre|L6|source_centered_pm1_to_last|blend|a0.050"
        alternate_recipe = (
            "readout_escape|activation_patch|resid_pre|L6|"
            "source_term_token_minus_stealer_l025_to_last|blend|a0.050"
        )
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": failed_recipe,
            "surface_family_key": "activation_patch_trial:s_resid_post_l6_last",
            "trial_effect_class": "regressing",
            "verdict": "harmful",
            "actuator_class": "unknown",
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
            "latest_diagnostic_results": [
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "evidence_rows": [
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "resid_pre_source_term_token_minus_stealer_l025_to_last_blend_a050",
                            "operator_recipe_id": alternate_recipe,
                            "activation_patch_site": "resid_pre",
                            "activation_patch_layer": 6,
                            "activation_patch_alpha": 0.05,
                            "activation_patch_source_localization": "source_term_token_minus_stealer_l025",
                            "activation_patch_patch_mode": "blend",
                            "activation_patch_base_localization": "source_term_token",
                            "activation_patch_contrast_mode": "minus_stealer",
                            "activation_patch_contrast_scale": 0.25,
                            "activation_patch_stealer_bundle_key": stealer,
                            "activation_patch_stealer_term": "send",
                            "target_mass_delta": 0.0003,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 10,
                            "self_delta": 0.8,
                            "cross_delta": 0.1,
                            "alignment_margin": 0.7,
                            "realized_lift_bundle_key": objective,
                            "realized_lift_term": "budget",
                        },
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "resid_pre_source_centered_pm1_to_last_blend_a050",
                            "operator_recipe_id": source_local_recipe,
                            "activation_patch_site": "resid_pre",
                            "activation_patch_layer": 6,
                            "activation_patch_alpha": 0.05,
                            "activation_patch_source_localization": "source_centered_pm1",
                            "activation_patch_patch_mode": "blend",
                            "target_mass_delta": 0.0002,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 8,
                            "self_delta": 0.6,
                            "cross_delta": 0.2,
                            "alignment_margin": 0.4,
                            "realized_lift_bundle_key": objective,
                            "realized_lift_term": "budget",
                        },
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "resid_pre_source_span_to_last_blend_a050",
                            "operator_recipe_id": site_shift_recipe,
                            "activation_patch_site": "resid_pre",
                            "activation_patch_layer": 6,
                            "activation_patch_alpha": 0.05,
                            "activation_patch_source_localization": "source_span_mean",
                            "activation_patch_patch_mode": "blend",
                            "target_mass_delta": 0.003,
                            "focus_rank_delta": 45,
                            "self_delta": 1.4,
                            "alignment_margin": 1.0,
                            "realized_lift_bundle_key": objective,
                            "realized_lift_term": "budget",
                        },
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "resid_post_source_span_to_last_blend_a050",
                            "operator_recipe_id": failed_recipe.replace("a0.150", "a0.050"),
                            "activation_patch_site": "resid_post",
                            "activation_patch_layer": 6,
                            "activation_patch_alpha": 0.05,
                            "activation_patch_source_localization": "source_span_mean",
                            "activation_patch_patch_mode": "blend",
                            "target_mass_delta": 0.002,
                            "focus_rank_delta": 40,
                            "self_delta": 1.2,
                            "alignment_margin": 0.9,
                            "realized_lift_bundle_key": objective,
                            "realized_lift_term": "budget",
                        },
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "resid_post_source_span_to_last_blend_a150",
                            "operator_recipe_id": failed_recipe,
                            "activation_patch_site": "resid_post",
                            "activation_patch_layer": 6,
                            "activation_patch_alpha": 0.15,
                            "target_mass_delta": 0.001,
                            "focus_rank_delta": 20,
                            "self_delta": 1.0,
                            "alignment_margin": 0.8,
                        },
                    ],
                    "production_apply_allowed": False,
                    "diagnostic_operator_supported": True,
                    "policy_candidate_ready": False,
                }
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )
        meta = command["meta"]
        request = meta["diagnostic_request"]
        alternate = request["activation_patch_shadow_actuator"]
        self.assertEqual(command["decision"], "noop")
        self.assertEqual(meta["next_action"], "request_activation_patch_candidate_review")
        self.assertEqual(meta["next_evidence_needed"], "alternate_activation_patch_candidate_review")
        self.assertEqual(request["diagnostic"], "activation_patch_candidate_review")
        self.assertEqual(alternate["operator_recipe_id"], alternate_recipe)
        self.assertNotEqual(alternate["operator_recipe_id"], failed_recipe)
        self.assertEqual(meta["blocked_by"], "production_trial_alternate_candidate_shadow_review")
        self.assertEqual(meta["production_trial_alternate_candidate"]["operator_recipe_id"], alternate_recipe)
        self.assertFalse(meta["production_trial_alternate_candidate"]["same_failed_recipe_family"])
        self.assertFalse(meta["production_trial_alternate_candidate"]["same_failed_recipe_structural_family"])
        self.assertEqual(
            alternate["activation_patch_source_localization"],
            "source_term_token_minus_stealer_l025",
        )
        self.assertEqual(alternate["activation_patch_stealer_bundle_key"], stealer)
        self.assertEqual(alternate["activation_patch_stealer_term"], "send")

        alternate_review_packet = {
            **packet,
            "latest_diagnostic_results": [
                packet["latest_diagnostic_results"][0],
                {
                    "diagnostic": "activation_patch_candidate_review",
                    "objective_bundle_key": objective,
                    "activation_patch_compile_preview": {
                        "kind": "activation_patch_compile_preview",
                        "objective_bundle_key": objective,
                        "actuator_bundle_key": objective,
                        "objective_term": "budget",
                        "recipe_name": "resid_pre_source_term_token_minus_stealer_l025_to_last_blend_a050",
                        "operator_recipe_id": alternate_recipe,
                        "site": "resid_pre",
                        "layer": 6,
                        "alpha": 0.05,
                        "source_localization": "source_term_token_minus_stealer_l025",
                        "base_localization": "source_term_token",
                        "contrast_mode": "minus_stealer",
                        "contrast_scale": 0.25,
                        "stealer_bundle_key": stealer,
                        "stealer_term": "send",
                        "source": "source_body_span",
                        "target": "answer_boundary_last",
                        "patch_mode": "blend",
                        "compile_state": "preview_only",
                        "actual_delta_class": "target_lift",
                        "production_apply_allowed": False,
                        "certified_for_apply": False,
                    },
                    "production_apply_allowed": False,
                },
            ],
        }
        runtime_command = controller._diagnostic_request_command(
            packet=alternate_review_packet,
            strategy_hints=alternate_review_packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )
        runtime_meta = runtime_command["meta"]
        runtime_request = runtime_meta["diagnostic_request"]
        self.assertEqual(runtime_meta["next_action"], "request_activation_patch_runtime_support_probe")
        self.assertEqual(runtime_request["diagnostic"], "activation_patch_runtime_support_probe")
        self.assertEqual(
            runtime_request["activation_patch_shadow_actuator"]["operator_recipe_id"],
            alternate_recipe,
        )
        self.assertEqual(
            runtime_request["activation_patch_shadow_actuator"]["activation_patch_stealer_bundle_key"],
            stealer,
        )

        latest_promotion = controller._activation_patch_promotion_gate_from_results(
            [
                {
                    "diagnostic": "activation_patch_promotion_gate_review",
                    "activation_patch_promotion_gate_review": {
                        "production_apply_candidate": {
                            "operator_recipe_id": failed_recipe,
                        }
                    },
                },
                {
                    "diagnostic": "activation_patch_promotion_gate_review",
                    "activation_patch_promotion_gate_review": {
                        "production_apply_candidate": {
                            "operator_recipe_id": alternate_recipe,
                        }
                    },
                },
            ]
        )
        self.assertEqual(
            latest_promotion["production_apply_candidate"]["operator_recipe_id"],
            alternate_recipe,
        )

        alternate_runtime_packet = {
            **packet,
            "latest_diagnostic_results": [
                alternate_review_packet["latest_diagnostic_results"][1],
                {
                    "diagnostic": "activation_patch_runtime_support_probe",
                    "objective_bundle_key": objective,
                    "activation_patch_runtime_support_probe": {
                        "runtime_supported_shadow_candidate": True,
                        "executable_shadow": {
                            "operator_recipe_id": alternate_recipe,
                            "objective_bundle_key": objective,
                            "actuator_bundle_key": objective,
                            "objective_term": "budget",
                            "recipe_name": "resid_pre_source_term_token_minus_stealer_l025_to_last_blend_a050",
                            "site": "resid_pre",
                            "layer": 6,
                            "alpha": 0.05,
                            "source_localization": "source_term_token_minus_stealer_l025",
                            "base_localization": "source_term_token",
                            "contrast_mode": "minus_stealer",
                            "contrast_scale": 0.25,
                            "stealer_bundle_key": stealer,
                            "stealer_term": "send",
                            "compile_state": "executable_shadow",
                            "production_apply_allowed": False,
                            "certified_for_apply": False,
                        },
                    },
                    "production_apply_allowed": False,
                },
            ],
        }
        promotion_command = controller._diagnostic_request_command(
            packet=alternate_runtime_packet,
            strategy_hints=alternate_runtime_packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )
        promotion_request = promotion_command["meta"]["diagnostic_request"]
        self.assertEqual(promotion_request["diagnostic"], "activation_patch_promotion_gate_review")
        self.assertEqual(
            promotion_request["activation_patch_shadow_actuator"]["operator_recipe_id"],
            alternate_recipe,
        )

    def test_frontier_replay_surfaces_bridge_alternate_after_failed_trial(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        stealer = "kv_pair:send:source_body:70:71"
        failed_recipe = (
            "readout_escape|activation_patch|resid_pre|L2|"
            "source_term_token_minus_stealer_l050_to_last|blend|a0.050"
        )
        bridge_recipe = (
            "readout_escape|activation_patch|resid_pre|L2|"
            "source_term_token_minus_stealer_l025_to_last|blend|a0.050"
        )
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": failed_recipe,
            "surface_family_key": "activation_patch_trial:s_resid_pre_l2_last",
            "trial_effect_class": "regressing",
            "verdict": "harmful",
            "actuator_class": "dead_actuator",
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
            "latest_diagnostic_results": [
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "activation_patch_candidate_pool": [
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "actuator_bundle_key": stealer,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "bridge_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "resid_pre_source_term_token_minus_stealer_l025_to_last_blend_a050",
                            "operator_recipe_id": bridge_recipe,
                            "activation_patch_site": "resid_pre",
                            "activation_patch_layer": 2,
                            "activation_patch_alpha": 0.05,
                            "activation_patch_source_localization": "source_term_token_minus_stealer_l025",
                            "activation_patch_patch_mode": "blend",
                            "activation_patch_base_localization": "source_term_token",
                            "activation_patch_contrast_mode": "minus_stealer",
                            "activation_patch_contrast_scale": 0.25,
                            "activation_patch_stealer_bundle_key": stealer,
                            "activation_patch_stealer_term": "send",
                            "target_mass_delta": 0.0002,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 3,
                            "self_delta": 2.73,
                            "cross_delta": 2.74,
                            "alignment_margin": -0.01,
                            "objective_term": "budget",
                            "realized_lift_bundle_key": objective,
                            "realized_lift_term": "budget",
                        }
                    ],
                    "production_apply_allowed": False,
                    "diagnostic_operator_supported": True,
                    "policy_candidate_ready": False,
                }
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )

        meta = command["meta"]
        request = meta["diagnostic_request"]
        alternate = request["alternate_trial_candidate"]
        self.assertEqual(request["diagnostic"], "activation_patch_candidate_review")
        self.assertEqual(request["step_actuator_bundle_key"], stealer)
        self.assertEqual(meta["step_actuator_bundle_key"], stealer)
        self.assertEqual(meta["next_evidence_needed"], "bridge_plan_dual_layer_shadow_review")
        self.assertEqual(meta["blocked_by"], "production_trial_alternate_candidate_shadow_review")
        self.assertTrue(meta["bridge_plan_available"])
        self.assertEqual(meta["bridge_plan_objective_bundle_key"], objective)
        self.assertEqual(meta["bridge_plan_actuator_bundle_key"], stealer)
        self.assertEqual(alternate["activation_patch_actuator_class"], "bridge_actuator")
        self.assertEqual(alternate["objective_bundle_key"], objective)
        self.assertEqual(alternate["actuator_bundle_key"], stealer)
        self.assertFalse(alternate["promotable_to_candidate_compiler"])
        self.assertTrue(alternate["requires_bridge_plan"])
        self.assertEqual(alternate["alternate_candidate_mode"], "bridge_actuator_shadow_review")
        self.assertFalse(alternate["production_apply_allowed"])

    def test_frontier_replay_rejects_wrong_direction_bridge_alternate_after_failed_trial(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        stealer = "kv_pair:send:source_body:70:71"
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": "failed_recipe",
            "trial_effect_class": "regressing",
            "verdict": "harmful",
            "actuator_class": "dead_actuator",
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
            "latest_diagnostic_results": [
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "activation_patch_candidate_pool": [
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "bridge_actuator",
                            "actual_delta_class": "target_lift",
                            "operator_recipe_id": "budget_recipe_that_lifts_send",
                            "realized_lift_bundle_key": stealer,
                            "realized_lift_term": "send",
                            "self_delta": 0.01,
                            "cross_delta": 0.04,
                            "alignment_margin": -0.03,
                        }
                    ],
                    "production_apply_allowed": False,
                    "diagnostic_operator_supported": True,
                    "policy_candidate_ready": False,
                }
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )

        meta = command["meta"]
        self.assertEqual(command["decision"], "noop")
        request = meta["diagnostic_request"]
        self.assertEqual(meta["next_action"], "request_cross_bundle_bridge_search")
        self.assertEqual(meta["next_evidence_needed"], "direction_correct_bridge_plan_search")
        self.assertEqual(request["diagnostic"], "cross_bundle_bridge_search")
        self.assertEqual(request["production_trial_alternate_evidence"]["alternate_candidate_absent_reason"], "wrong_direction_bridge_only")
        self.assertNotIn("production_trial_alternate_candidate", meta)
        self.assertNotIn("bridge_plan_available", meta)

    def test_frontier_replay_consumes_cross_bundle_bridge_search_shadow(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        actuator = "kv_pair:send:source_body:70:71"
        bridge_recipe = (
            "readout_escape|activation_patch|resid_pre|L2|"
            "send_term_token_to_last|blend|a0.050"
        )
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": "failed_recipe",
            "trial_effect_class": "regressing",
            "verdict": "harmful",
            "actuator_class": "dead_actuator",
        }
        shadow = {
            "kind": "activation_patch_shadow_actuator",
            "decision": "shadow",
            "objective_bundle_key": objective,
            "actuator_bundle_key": actuator,
            "objective_term": "budget",
            "recipe_name": "resid_pre_send_term_token_to_last_blend_a050",
            "operator_recipe_id": bridge_recipe,
            "activation_patch_site": "resid_pre",
            "activation_patch_layer": 2,
            "activation_patch_alpha": 0.05,
            "activation_patch_source_localization": "source_term_token",
            "activation_patch_patch_mode": "blend",
            "activation_patch_actuator_class": "bridge_actuator",
            "actual_delta_class": "target_lift",
            "realized_lift_bundle_key": objective,
            "realized_lift_term": "budget",
            "counterfactual_delta": {
                "target_mass_delta": 0.0002,
                "focus_rank_delta": 4,
                "self_delta": 0.01,
                "cross_delta": 0.04,
                "alignment_margin": -0.03,
            },
            "promotable_to_candidate_compiler": False,
            "promotion_reason": "cross_bundle_bridge_search_direction_correct",
            "requires_bridge_plan": True,
            "production_apply_allowed": False,
            "certified_for_apply": False,
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
            "latest_diagnostic_results": [
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "activation_patch_candidate_pool": [
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "bridge_actuator",
                            "actual_delta_class": "target_lift",
                            "operator_recipe_id": "budget_recipe_that_lifts_send",
                            "realized_lift_bundle_key": actuator,
                            "self_delta": 0.01,
                            "cross_delta": 0.04,
                            "alignment_margin": -0.03,
                        }
                    ],
                    "production_apply_allowed": False,
                    "diagnostic_operator_supported": True,
                    "policy_candidate_ready": False,
                },
                {
                    "diagnostic": "cross_bundle_bridge_search",
                    "objective_bundle_key": objective,
                    "bridge_plan_shadow_actuator": shadow,
                    "cross_bundle_bridge_summary": {
                        "objective_bundle_key": objective,
                        "eligible_bridge_candidate_count": 1,
                        "status": "bridge_found",
                    },
                    "production_apply_allowed": False,
                },
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )

        meta = command["meta"]
        request = meta["diagnostic_request"]
        alternate = request["alternate_trial_candidate"]
        self.assertEqual(command["decision"], "noop")
        self.assertEqual(meta["next_action"], "request_activation_patch_candidate_review")
        self.assertEqual(meta["next_evidence_needed"], "bridge_plan_dual_layer_shadow_review")
        self.assertEqual(request["diagnostic"], "activation_patch_candidate_review")
        self.assertEqual(request["step_actuator_bundle_key"], actuator)
        self.assertEqual(alternate["operator_recipe_id"], bridge_recipe)
        self.assertEqual(alternate["objective_bundle_key"], objective)
        self.assertEqual(alternate["actuator_bundle_key"], actuator)
        self.assertTrue(meta["bridge_plan_available"])
        self.assertEqual(meta["bridge_plan_actuator_bundle_key"], actuator)
        self.assertFalse(alternate["production_apply_allowed"])

    def test_frontier_replay_requests_recipe_expansion_after_bridge_search_exhausted(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        actuator = "kv_pair:send:source_body:70:71"
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": "failed_recipe",
            "trial_effect_class": "regressing",
            "verdict": "harmful",
            "actuator_class": "dead_actuator",
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
            "latest_diagnostic_results": [
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "activation_patch_candidate_pool": [
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "bridge_actuator",
                            "operator_recipe_id": "budget_recipe_that_lifts_send",
                            "realized_lift_bundle_key": actuator,
                            "self_delta": 0.01,
                            "cross_delta": 0.04,
                        }
                    ],
                    "production_apply_allowed": False,
                    "diagnostic_operator_supported": True,
                    "policy_candidate_ready": False,
                },
                {
                    "diagnostic": "cross_bundle_bridge_search",
                    "objective_bundle_key": objective,
                    "status": "no_direction_correct_bridge",
                    "cross_bundle_bridge_summary": {
                        "objective_bundle_key": objective,
                        "matrix_row_count": 9,
                        "eligible_bridge_candidate_count": 0,
                        "direction_correct_bridge_count": 0,
                        "wrong_direction_bridge_count": 8,
                        "status": "no_direction_correct_bridge",
                    },
                    "production_apply_allowed": False,
                },
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )

        meta = command["meta"]
        request = meta["diagnostic_request"]
        self.assertEqual(command["decision"], "noop")
        self.assertEqual(meta["next_action"], "request_compare_extra_operator_diagnostics")
        self.assertEqual(meta["next_evidence_needed"], "post_bridge_exhaustion_recipe_expansion")
        self.assertTrue(meta["cross_bundle_bridge_search_exhausted"])
        self.assertEqual(meta["operator_recipe_expansion_mode"], "post_bridge_exhaustion")
        self.assertEqual(meta["blocked_by"], "cross_bundle_bridge_search_exhausted")
        self.assertEqual(request["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(request["operator_recipe_expansion_mode"], "post_bridge_exhaustion")
        self.assertTrue(request["post_bridge_exhaustion_recipe_expansion_requested"])
        self.assertEqual(
            request["cross_bundle_bridge_search_state"]["status"],
            "no_direction_correct_bridge",
        )

    def test_frontier_replay_does_not_repeat_recipe_expansion_after_bridge_search_exhausted(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": "failed_recipe",
            "trial_effect_class": "regressing",
            "verdict": "harmful",
            "actuator_class": "dead_actuator",
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
            "latest_diagnostic_results": [
                {
                    "diagnostic": "cross_bundle_bridge_search",
                    "objective_bundle_key": objective,
                    "status": "no_direction_correct_bridge",
                    "cross_bundle_bridge_summary": {
                        "objective_bundle_key": objective,
                        "matrix_row_count": 9,
                        "eligible_bridge_candidate_count": 0,
                        "direction_correct_bridge_count": 0,
                        "wrong_direction_bridge_count": 8,
                        "status": "no_direction_correct_bridge",
                    },
                    "production_apply_allowed": False,
                },
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                    "post_bridge_exhaustion_recipe_expansion_requested": True,
                    "activation_patch_candidate_pool": [],
                    "production_apply_allowed": False,
                    "diagnostic_operator_supported": False,
                    "policy_candidate_ready": False,
                },
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )

        meta = command["meta"]
        self.assertEqual(command["decision"], "noop")
        self.assertEqual(meta["next_action"], "noop")
        self.assertNotIn("diagnostic_request", meta)
        self.assertTrue(meta["cross_bundle_bridge_search_exhausted"])
        self.assertTrue(meta["operator_recipe_expansion_consumed"])
        self.assertEqual(meta["blocked_by"], "operator_recipe_expansion_exhausted")
        self.assertEqual(meta["next_evidence_needed"], "operator_recipe_expansion_exhausted")

    def test_frontier_replay_requests_readout_steering_deepening_after_rank_carrier_expansion(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        trial_outcome = {
            "apply_kind": "production_trial",
            "objective_bundle_key": objective,
            "bundle_key": objective,
            "operator_recipe_id": "failed_recipe",
            "trial_effect_class": "regressing",
            "verdict": "harmful",
            "actuator_class": "dead_actuator",
        }
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "recent_effect_summary": {
                "production_trial_outcome_ledger": [trial_outcome],
                "latest_effects": [trial_outcome],
            },
            "latest_diagnostic_results": [
                {
                    "diagnostic": "cross_bundle_bridge_search",
                    "objective_bundle_key": objective,
                    "status": "no_direction_correct_bridge",
                    "cross_bundle_bridge_summary": {
                        "objective_bundle_key": objective,
                        "matrix_row_count": 9,
                        "eligible_bridge_candidate_count": 0,
                        "direction_correct_bridge_count": 0,
                        "wrong_direction_bridge_count": 8,
                        "status": "no_direction_correct_bridge",
                    },
                    "production_apply_allowed": False,
                },
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                    "post_bridge_exhaustion_recipe_expansion_requested": True,
                    "next_evidence_needed": "readout_steering_deepening",
                    "operator_recipe_expansion_summary": {
                        "status": "rank_carrier_family_found",
                        "recommended_next_family": "readout_steering_deepening:readout_steering",
                        "operator_positive_memory": {
                            "readout_steering": {
                                "recipe_family": "readout_steering",
                                "traits": ["ownership_preserving", "target_reachable", "top20_gap_closer_candidate"],
                                "recommended_next_action": "deepen_local_gap_closer",
                                "best_recipe_name": "post_bridge_target_readout_patch_a040",
                                "best_target_top20_threshold_gap": 0.37,
                            }
                        },
                        "positive_memory_family_count": 1,
                        "best_positive_operator_family": "readout_steering",
                        "best_positive_operator_traits": [
                            "ownership_preserving",
                            "target_reachable",
                            "top20_gap_closer_candidate",
                        ],
                        "best_positive_operator_next_action": "deepen_local_gap_closer",
                        "positive_operator_deepening_plan": {
                            "kind": "positive_operator_deepening_plan",
                            "permission": "diagnostic_only",
                            "production_apply_allowed": False,
                            "policy_candidate_ready": False,
                            "recipe_family": "readout_steering",
                            "recipe_name": "post_bridge_target_readout_patch_a040",
                            "next_action": "deepen_local_gap_closer",
                            "suggested_next_evidence": "readout_steering_deepening",
                            "suggested_operator_recipe_expansion_mode": "readout_steering_deepening",
                            "deepening_axis": "target_top20_gap_closing",
                            "reason_code": "positive_memory_local_gap_closer",
                            "curiosity_signal": "positive_operator_memory_deepen_local_gap_closer",
                            "traits": [
                                "ownership_preserving",
                                "target_reachable",
                                "top20_gap_closer_candidate",
                            ],
                            "best_target_top20_threshold_gap": 0.37,
                        },
                        "best_readout_steering_rank_carrier_recipe_family": "readout_steering",
                        "best_readout_steering_rank_carrier_recipe_name": "post_bridge_target_readout_patch_a040",
                        "best_readout_steering_target_top20_threshold_gap": 0.37,
                        "production_apply_allowed": False,
                    },
                    "production_apply_allowed": False,
                    "diagnostic_operator_supported": False,
                    "policy_candidate_ready": False,
                },
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )

        meta = command["meta"]
        request = meta["diagnostic_request"]
        self.assertEqual(command["decision"], "noop")
        self.assertEqual(meta["next_action"], "request_compare_extra_operator_diagnostics")
        self.assertEqual(meta["next_evidence_needed"], "readout_steering_deepening")
        self.assertEqual(meta["operator_recipe_expansion_mode"], "readout_steering_deepening")
        self.assertTrue(meta["readout_steering_deepening_requested"])
        self.assertEqual(meta["blocked_by"], "readout_steering_rank_carrier_needs_target_lift")
        self.assertEqual(
            meta["readout_steering_deepening_state"]["best_readout_steering_target_top20_threshold_gap"],
            0.37,
        )
        self.assertEqual(meta["best_positive_operator_family"], "readout_steering")
        self.assertIn("top20_gap_closer_candidate", meta["best_positive_operator_traits"])
        self.assertEqual(meta["best_positive_operator_next_action"], "deepen_local_gap_closer")
        self.assertEqual(meta["controller_curiosity_signal"], "positive_operator_memory_deepen_local_gap_closer")
        self.assertEqual(
            meta["positive_operator_deepening_plan"]["reason_code"],
            "positive_memory_local_gap_closer",
        )
        self.assertEqual(
            meta["positive_operator_deepening_plan"]["suggested_operator_recipe_expansion_mode"],
            "readout_steering_deepening",
        )
        self.assertIn("readout_steering", meta["operator_positive_memory"])
        self.assertEqual(request["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(request["next_evidence_needed"], "readout_steering_deepening")
        self.assertEqual(request["operator_recipe_expansion_mode"], "readout_steering_deepening")
        self.assertTrue(request["readout_steering_deepening_requested"])
        self.assertIn("readout_steering", request["operator_positive_memory"])
        self.assertEqual(
            request["positive_operator_deepening_plan"]["deepening_axis"],
            "target_top20_gap_closing",
        )

    def test_effective_diagnostic_frontier_prefers_post_bridge_exhaustion_loop_state(self):
        objective = "kv_pair:budget:source_body:72:73"
        effective = _effective_diagnostic_frontier_summary(
            bridge_eval_summary={
                "diagnostic_frontier_bundle_key": objective,
                "diagnostic_frontier_request": "activation_patch_candidate_review",
                "diagnostic_frontier_next_evidence": "activation_patch_candidate_compiler_review",
                "diagnostic_frontier_reason_text": "old static frontier request",
            },
            recent_diagnostic_results=[
                {
                    "diagnostic": "cross_bundle_bridge_search",
                    "objective_bundle_key": objective,
                    "status": "no_direction_correct_bridge",
                    "cross_bundle_bridge_summary": {
                        "objective_bundle_key": objective,
                        "matrix_row_count": 9,
                        "eligible_bridge_candidate_count": 0,
                        "direction_correct_bridge_count": 0,
                        "status": "no_direction_correct_bridge",
                    },
                },
                {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "objective_bundle_key": objective,
                    "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                    "post_bridge_exhaustion_recipe_expansion_requested": True,
                },
            ],
            diagnostic_request_events=[],
        )

        self.assertEqual(effective["bundle_key"], objective)
        self.assertEqual(effective["request"], "compare_extra_operator_diagnostics")
        self.assertEqual(effective["next_evidence"], "post_bridge_exhaustion_recipe_expansion_observed")
        self.assertEqual(effective["state_source"], "diagnostic_loop_result")
        self.assertEqual(effective["loop_state"], "post_bridge_exhaustion_recipe_expansion_observed")
        self.assertTrue(effective["cross_bundle_bridge_search_exhausted"])
        self.assertTrue(effective["post_bridge_exhaustion_recipe_expansion_observed"])

    def test_worker_cross_bundle_bridge_search_builds_direction_correct_shadow(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "kv_pair:budget:source_body:72:73"
        actuator = "kv_pair:send:source_body:70:71"
        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "cross_bundle_bridge_search",
                "bundle_key": objective,
                "objective_bundle_key": objective,
                "step_actuator_bundle_key": objective,
                "next_evidence_needed": "direction_correct_bridge_plan_search",
            },
            source="unit_test",
            packet={
                "strategy_hints": {
                    "diagnostic_frontier_bundle_key": objective,
                    "diagnostic_evidence_ledger": [
                        {
                            "bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "bridge_actuator",
                            "actual_delta_class": "readout_gap_movement",
                            "operator_recipe_id": "budget_recipe_that_lifts_send",
                            "realized_lift_bundle_key": actuator,
                            "realized_lift_term": "send",
                            "self_delta": 0.01,
                            "cross_delta": 0.04,
                            "alignment_margin": -0.03,
                        },
                        {
                            "bundle_key": actuator,
                            "intended_bundle_key": actuator,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "cross_bound",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "resid_pre_send_term_token_to_last_blend_a050",
                            "operator_recipe_id": "send_recipe_that_lifts_budget",
                            "activation_patch_site": "resid_pre",
                            "activation_patch_layer": 2,
                            "activation_patch_alpha": 0.05,
                            "activation_patch_source_localization": "source_term_token",
                            "activation_patch_patch_mode": "blend",
                            "realized_lift_bundle_key": objective,
                            "realized_lift_term": "budget",
                            "target_mass_delta": 0.0002,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 4,
                            "self_delta": 0.01,
                            "cross_delta": 0.04,
                            "alignment_margin": -0.03,
                        },
                    ],
                }
            },
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["diagnostic"], "cross_bundle_bridge_search")
        self.assertEqual(result["diagnostic_role"], "cross_bundle_bridge_search")
        self.assertEqual(result["status"], "bridge_found")
        self.assertFalse(result["production_apply_allowed"])
        summary = result["cross_bundle_bridge_summary"]
        self.assertEqual(summary["eligible_bridge_candidate_count"], 1)
        self.assertEqual(summary["wrong_direction_bridge_count"], 1)
        shadow = result["bridge_plan_shadow_actuator"]
        self.assertEqual(shadow["objective_bundle_key"], objective)
        self.assertEqual(shadow["actuator_bundle_key"], actuator)
        self.assertTrue(shadow["requires_bridge_plan"])
        self.assertFalse(shadow["production_apply_allowed"])

    def test_worker_attention_probe_repeated_no_cache_becomes_unavailable_veto(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "entity_insert:send:source_body:weak_reachable"
        first = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "attention_readout_carrier_probe",
                "bundle_key": objective,
                "objective_bundle_key": objective,
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(first)
        assert first is not None
        self.assertEqual(first["status"], "no_cached_evidence")
        self.assertTrue(first["requires_cached_attention_rows"])
        self.assertEqual(first["cached_attention_row_count"], 0)
        self.assertTrue(first["no_cached_evidence_consumed"])
        self.assertFalse(first["same_objective_repeat_blocked"])

        runtime._diagnostic_results = [first]
        second = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "attention_readout_carrier_probe",
                "bundle_key": objective,
                "objective_bundle_key": objective,
            },
            source="unit_test",
            packet={"strategy_hints": {}},
        )

        self.assertIsNotNone(second)
        assert second is not None
        self.assertEqual(second["status"], "diagnostic_unavailable_veto")
        self.assertTrue(second["diagnostic_unavailable_veto"])
        self.assertEqual(second["diagnostic_unavailable_reason"], "requires_cached_attention_rows")
        self.assertEqual(second["next_evidence_needed"], "diagnostic_unavailable_veto")
        self.assertTrue(second["no_cached_evidence_consumed"])
        self.assertTrue(second["same_objective_repeat_blocked"])
        self.assertFalse(second["production_apply_allowed"])

    def test_worker_attention_probe_materializes_kv_feature_scan_rows(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "entity_insert:send:source_body:weak_reachable"

        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "attention_readout_carrier_probe",
                "bundle_key": objective,
                "objective_bundle_key": objective,
            },
            source="unit_test",
            packet={
                "strategy_hints": {},
                "latest_observer_check": {
                    "kv_feature_scan": {
                        "top_feature_hits": [
                            {
                                "feature": "send",
                                "site": "v_cache",
                                "layer": 4,
                                "head": 1,
                                "token_mode": "last",
                                "alignment": 0.71,
                                "source_positions": [{"position": 70}],
                                "source_piece": " send",
                                "source_segment_kind": "source_body",
                            }
                        ]
                    }
                },
            },
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["attention_scan_materialized_count"], 1)
        self.assertEqual(result["cached_attention_row_count"], 1)
        self.assertFalse(result["requires_cached_attention_rows"])
        self.assertTrue(result["rank_readout_carrier"])
        self.assertEqual(result["evidence_rows"][0]["evidence_kind"], "attention_readout_carrier")
        self.assertEqual(result["evidence_rows"][0]["attention_probe_source"], "observer_kv_feature_scan")
        self.assertEqual(result["evidence_rows"][0]["layer"], 4)
        self.assertEqual(result["evidence_rows"][0]["head"], 1)
        self.assertFalse(result["production_apply_allowed"])

    def test_worker_cross_bundle_bridge_search_uses_post_bridge_exhaustion_next_evidence(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "kv_pair:budget:source_body:72:73"
        stealer = "kv_pair:send:source_body:70:71"
        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "cross_bundle_bridge_search",
                "bundle_key": objective,
                "objective_bundle_key": objective,
                "step_actuator_bundle_key": objective,
                "next_evidence_needed": "direction_correct_bridge_plan_search",
            },
            source="unit_test",
            packet={
                "strategy_hints": {
                    "diagnostic_frontier_bundle_key": objective,
                    "diagnostic_evidence_ledger": [
                        {
                            "bundle_key": objective,
                            "intended_bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "blocked",
                            "actuator_class": "cross_bound",
                            "actual_delta_class": "target_lift",
                            "operator_recipe_id": "budget_recipe_that_lifts_send",
                            "realized_lift_bundle_key": stealer,
                            "realized_lift_term": "send",
                            "self_delta": 0.01,
                            "cross_delta": 0.04,
                            "alignment_margin": -0.03,
                        }
                    ],
                }
            },
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["diagnostic"], "cross_bundle_bridge_search")
        self.assertEqual(result["status"], "no_direction_correct_bridge")
        self.assertEqual(result["next_evidence_needed"], "post_bridge_exhaustion_recipe_expansion")
        self.assertFalse(result["production_apply_allowed"])
        summary = result["cross_bundle_bridge_summary"]
        self.assertEqual(summary["eligible_bridge_candidate_count"], 0)
        self.assertEqual(summary["wrong_direction_bridge_count"], 1)

    def test_worker_post_bridge_recipe_expansion_summarizes_failure_modes(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "kv_pair:budget:source_body:72:73"
        stealer = "kv_pair:send:source_body:70:71"
        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": objective,
                "objective_bundle_key": objective,
                "step_actuator_bundle_key": objective,
                "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                "post_bridge_exhaustion_recipe_expansion_requested": True,
                "next_evidence_needed": "post_bridge_exhaustion_recipe_expansion",
            },
            source="unit_test",
            packet={
                "strategy_hints": {
                    "diagnostic_frontier_bundle_key": objective,
                    "diagnostic_evidence_ledger": [
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "blocked",
                            "actuator_class": "cross_bound",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "post_bridge_resid_pre_term_to_last_blend_a030",
                            "operator_recipe_id": "recipe_wrong_direction",
                            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                            "post_bridge_exhaustion_recipe": True,
                            "activation_patch_site": "resid_pre",
                            "activation_patch_layer": 2,
                            "activation_patch_alpha": 0.03,
                            "activation_patch_source_localization": "source_term_token",
                            "activation_patch_patch_mode": "blend",
                            "realized_lift_bundle_key": stealer,
                            "self_delta": 0.002,
                            "cross_delta": 0.04,
                            "alignment_margin": -0.038,
                            "target_mass_delta": 0.00001,
                            "focus_rank_delta": 0,
                        },
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "observed",
                            "actuator_class": "noisy_or_harmful",
                            "actual_delta_class": "neutral",
                            "recipe_name": "post_bridge_mlp_out_centered_to_last_blend_a030",
                            "operator_recipe_id": "recipe_weak_nonharmful",
                            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                            "post_bridge_exhaustion_recipe": True,
                            "activation_patch_site": "mlp_out",
                            "activation_patch_layer": 2,
                            "activation_patch_alpha": 0.03,
                            "activation_patch_source_localization": "source_centered_pm1",
                            "activation_patch_patch_mode": "blend",
                            "realized_lift_bundle_key": objective,
                            "self_delta": 0.012,
                            "cross_delta": 0.004,
                            "alignment_margin": 0.008,
                            "target_mass_delta": 0.0,
                            "focus_rank_delta": 0,
                            "repeat_delta": 0,
                        },
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "blocked",
                            "actuator_class": "collapse_sharpener",
                            "actual_delta_class": "collapse_sharpener",
                            "recipe_name": "post_bridge_resid_post_span_to_last_blend_a030",
                            "operator_recipe_id": "recipe_collapse",
                            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                            "post_bridge_exhaustion_recipe": True,
                            "activation_patch_site": "resid_post",
                            "activation_patch_layer": 2,
                            "activation_patch_alpha": 0.03,
                            "activation_patch_source_localization": "source_span_mean",
                            "activation_patch_patch_mode": "blend",
                            "self_delta": 0.0,
                            "cross_delta": 0.0,
                            "alignment_margin": 0.0,
                            "target_mass_delta": -0.0001,
                            "focus_rank_delta": -2,
                            "repeat_delta": 1,
                            "entropy_delta": -0.04,
                            "top1_margin_delta": 0.01,
                        },
                    ],
                }
            },
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["diagnostic_role"], "operator_recipe_expansion_view")
        self.assertEqual(result["operator_recipe_expansion_mode"], "post_bridge_exhaustion")
        summary = result["operator_recipe_expansion_summary"]
        self.assertEqual(summary["matrix_row_count"], 3)
        self.assertEqual(summary["dedicated_recipe_row_count"], 3)
        self.assertEqual(summary["best_nonharmful_operator_recipe_id"], "recipe_weak_nonharmful")
        self.assertEqual(summary["best_nonharmful_recipe_family"], "mlp_out|source_centered_pm1|blend")
        self.assertEqual(summary["recommended_next_family"], "deepen:mlp_out|source_centered_pm1|blend")
        self.assertFalse(summary["production_apply_allowed"])
        failure_counts = summary["failure_mode_counts"]
        self.assertEqual(failure_counts["wrong_direction"], 1)
        self.assertEqual(failure_counts["weak_nonharmful"], 1)
        self.assertEqual(failure_counts["collapse_sharpener"], 1)
        matrix = result["operator_recipe_expansion_matrix"]
        self.assertEqual(matrix[0]["operator_recipe_id"], "recipe_weak_nonharmful")
        self.assertEqual(matrix[0]["failure_mode"], "weak_nonharmful")

    def test_worker_post_bridge_recipe_expansion_splits_rank_carrier_from_target_actuator(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "kv_pair:budget:source_body:72:73"
        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": objective,
                "objective_bundle_key": objective,
                "step_actuator_bundle_key": objective,
                "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                "post_bridge_exhaustion_recipe_expansion_requested": True,
            },
            source="unit_test",
            packet={
                "strategy_hints": {
                    "diagnostic_frontier_bundle_key": objective,
                    "diagnostic_evidence_ledger": [
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "post_bridge_resid_pre_term_to_last_blend_a030",
                            "operator_recipe_id": "recipe_rank_carrier",
                            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                            "post_bridge_exhaustion_recipe": True,
                            "activation_patch_site": "resid_pre",
                            "activation_patch_layer": 2,
                            "activation_patch_alpha": 0.03,
                            "activation_patch_source_localization": "source_term_token",
                            "activation_patch_patch_mode": "blend",
                            "realized_lift_bundle_key": objective,
                            "self_delta": 1.46,
                            "cross_delta": 1.44,
                            "alignment_margin": 0.02,
                            "target_mass_delta": 0.0,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 6,
                        }
                    ],
                }
            },
        )

        self.assertIsNotNone(result)
        assert result is not None
        summary = result["operator_recipe_expansion_summary"]
        self.assertEqual(summary["status"], "rank_carrier_family_found")
        self.assertEqual(summary["failure_mode_counts"]["self_rank_carrier"], 1)
        self.assertEqual(summary["ownership_role_counts"]["self"], 1)
        self.assertEqual(summary["effect_role_counts"]["rank_carrier"], 1)
        self.assertEqual(summary["safety_role_counts"]["neutral"], 1)
        self.assertEqual(summary["best_rank_carrier_recipe_family"], "resid_pre|source_term_token|blend")
        self.assertEqual(summary["recommended_next_family"], "convert_rank_carrier_to_target:resid_pre|source_term_token|blend")
        self.assertFalse(summary["production_apply_allowed"])
        matrix = result["operator_recipe_expansion_matrix"]
        self.assertEqual(matrix[0]["failure_mode"], "self_rank_carrier")
        self.assertEqual(matrix[0]["ownership_role"], "self")
        self.assertEqual(matrix[0]["effect_role"], "rank_carrier")
        self.assertEqual(matrix[0]["safety_role"], "neutral")

    def test_worker_post_bridge_recipe_expansion_reports_readout_steering_rank_gap(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "kv_pair:budget:source_body:72:73"
        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": objective,
                "objective_bundle_key": objective,
                "step_actuator_bundle_key": objective,
                "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                "post_bridge_exhaustion_recipe_expansion_requested": True,
            },
            source="unit_test",
            packet={
                "strategy_hints": {
                    "diagnostic_frontier_bundle_key": objective,
                    "diagnostic_evidence_ledger": [
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "evidence_kind": "operator_probe",
                            "diagnostic_family": "readout_steering",
                            "operator_axis": "readout_steering",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "post_bridge_target_readout_patch_a040",
                            "operator_recipe_id": "readout_recipe",
                            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                            "post_bridge_exhaustion_recipe": True,
                            "recipe_family": "readout_steering",
                            "readout_steering_kind": "target_readout",
                            "realized_lift_bundle_key": objective,
                            "self_delta": 0.15,
                            "cross_delta": 0.0,
                            "alignment_margin": 0.15,
                            "target_mass_delta": 0.0,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 4,
                            "target_piece": " budget",
                            "target_piece_logit_delta": 0.12,
                            "target_piece_prob_delta": 0.00001,
                            "target_rank_after": 42,
                            "target_top20_threshold_gap_baseline": 0.49,
                            "target_top20_threshold_gap": 0.37,
                            "target_top20_threshold_gap_after": 0.37,
                            "target_top20_threshold_gap_delta": -0.12,
                            "target_top20_margin": -0.37,
                            "readout_gap_closer_recipe": True,
                            "readout_gap_closer_axis": "target_top20_gap",
                        }
                    ],
                }
            },
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["next_evidence_needed"], "readout_steering_deepening")
        summary = result["operator_recipe_expansion_summary"]
        self.assertEqual(summary["status"], "rank_carrier_family_found")
        self.assertEqual(summary["failure_mode_counts"]["self_rank_carrier"], 1)
        self.assertEqual(summary["best_readout_steering_rank_carrier_recipe_family"], "readout_steering")
        self.assertEqual(summary["best_readout_steering_rank_carrier_recipe_name"], "post_bridge_target_readout_patch_a040")
        self.assertEqual(summary["best_readout_steering_target_top20_threshold_gap"], 0.37)
        self.assertEqual(summary["readout_gap_closer_recipe_count"], 1)
        self.assertEqual(summary["readout_gap_probe_recipe_count"], 1)
        self.assertEqual(summary["readout_gap_closer_candidate_count"], 1)
        self.assertEqual(summary["readout_gap_closer_certified_count"], 1)
        self.assertEqual(summary["best_readout_gap_closer_recipe_name"], "post_bridge_target_readout_patch_a040")
        self.assertEqual(summary["best_readout_gap_closer_target_top20_threshold_gap"], 0.37)
        self.assertEqual(summary["best_readout_gap_closer_target_top20_threshold_gap_delta"], -0.12)
        self.assertEqual(summary["recommended_next_family"], "readout_steering_deepening:readout_steering")
        self.assertEqual(summary["best_positive_operator_family"], "readout_steering")
        self.assertIn("ownership_preserving", summary["best_positive_operator_traits"])
        self.assertIn("top20_gap_measured", summary["best_positive_operator_traits"])
        self.assertIn("top20_gap_closer_candidate", summary["best_positive_operator_traits"])
        self.assertIn("top20_gap_closer_certified", summary["best_positive_operator_traits"])
        self.assertEqual(summary["best_positive_operator_next_action"], "deepen_local_gap_closer")
        plan = summary["positive_operator_deepening_plan"]
        self.assertEqual(plan["kind"], "positive_operator_deepening_plan")
        self.assertEqual(plan["permission"], "diagnostic_only")
        self.assertFalse(plan["production_apply_allowed"])
        self.assertEqual(plan["recipe_family"], "readout_steering")
        self.assertEqual(plan["next_action"], "deepen_local_gap_closer")
        self.assertEqual(plan["suggested_next_evidence"], "readout_steering_deepening")
        self.assertEqual(plan["deepening_axis"], "target_top20_gap_closing")
        self.assertEqual(plan["reason_code"], "positive_memory_local_gap_closer")
        self.assertEqual(plan["gap_closer_recipe_name"], "post_bridge_target_readout_patch_a040")
        self.assertEqual(plan["gap_closer_target_top20_threshold_gap"], 0.37)
        self.assertEqual(plan["gap_closer_target_top20_threshold_gap_delta"], -0.12)
        self.assertEqual(plan["ttl_steps"], 2)
        self.assertTrue(plan["stale_after_context_change"])
        memory = summary["operator_positive_memory"]["readout_steering"]
        self.assertEqual(memory["recommended_next_action"], "deepen_local_gap_closer")
        self.assertIn("target_reachable", memory["traits"])
        self.assertIn("top20_gap_closer_certified", memory["traits"])
        self.assertEqual(memory["best_target_top20_threshold_gap"], 0.37)
        self.assertEqual(memory["best_target_top20_threshold_gap_delta"], -0.12)
        self.assertEqual(memory["scope"]["objective_bundle_key"], objective)
        self.assertEqual(memory["scope"]["target_piece"], " budget")
        self.assertEqual(memory["ttl_steps"], 2)
        self.assertFalse(summary["production_apply_allowed"])
        matrix = result["operator_recipe_expansion_matrix"]
        self.assertEqual(matrix[0]["recipe_family"], "readout_steering")
        self.assertEqual(matrix[0]["failure_mode"], "self_rank_carrier")
        self.assertIn("positive_traits", matrix[0])
        self.assertIn("top20_gap_measured", matrix[0]["positive_traits"])
        self.assertIn("top20_gap_closer_candidate", matrix[0]["positive_traits"])
        self.assertIn("top20_gap_closer_certified", matrix[0]["positive_traits"])
        self.assertEqual(matrix[0]["target_piece"], " budget")
        self.assertEqual(matrix[0]["target_rank_after"], 42)
        self.assertEqual(matrix[0]["target_top20_threshold_gap_baseline"], 0.49)
        self.assertEqual(matrix[0]["target_top20_threshold_gap"], 0.37)
        self.assertEqual(matrix[0]["target_top20_threshold_gap_after"], 0.37)
        self.assertEqual(matrix[0]["target_top20_threshold_gap_delta"], -0.12)
        self.assertEqual(matrix[0]["target_top20_margin"], -0.37)
        self.assertTrue(matrix[0]["readout_gap_closer_recipe"])
        self.assertEqual(matrix[0]["readout_gap_closer_axis"], "target_top20_gap")
        self.assertIn("readout_steering", result["operator_positive_memory"])

    def test_default_operator_recipe_specs_include_readout_gap_closer_sweep(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        specs = runtime._default_operator_recipe_specs()
        gap_specs = [
            spec
            for spec in specs
            if isinstance(spec, dict) and spec.get("readout_gap_closer_recipe")
        ]
        names = {str(spec.get("recipe_name")) for spec in gap_specs}
        self.assertIn("target_readout_patch_pure_a060_gap", names)
        self.assertIn("target_readout_patch_l005_a060_gap", names)
        self.assertIn("target_readout_patch_pure_a040_gap", names)
        self.assertIn("target_readout_patch_l025_a050_gap", names)
        self.assertIn("target_readout_patch_l075_a060_gap", names)
        self.assertIn("contrastive_readout_patch_l025_a060_gap", names)
        self.assertGreaterEqual(len(gap_specs), 12)
        self.assertTrue(all(spec.get("readout_gap_closer_axis") == "target_top20_gap" for spec in gap_specs))

    def test_worker_post_bridge_recipe_expansion_prioritizes_readout_steering_deepening_when_gap_exists(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "kv_pair:budget:source_body:72:73"
        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": objective,
                "objective_bundle_key": objective,
                "step_actuator_bundle_key": objective,
                "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                "post_bridge_exhaustion_recipe_expansion_requested": True,
            },
            source="unit_test",
            packet={
                "strategy_hints": {
                    "diagnostic_frontier_bundle_key": objective,
                    "diagnostic_evidence_ledger": [
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "post_bridge_resid_post_term_to_last_blend_a060",
                            "operator_recipe_id": "activation_rank_recipe",
                            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                            "post_bridge_exhaustion_recipe": True,
                            "activation_patch_site": "resid_post",
                            "activation_patch_layer": 6,
                            "activation_patch_alpha": 0.06,
                            "activation_patch_source_localization": "source_term_token",
                            "activation_patch_patch_mode": "blend",
                            "realized_lift_bundle_key": objective,
                            "self_delta": 1.2,
                            "cross_delta": 0.6,
                            "alignment_margin": 0.6,
                            "target_mass_delta": 0.0,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 20,
                        },
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "evidence_kind": "operator_probe",
                            "diagnostic_family": "readout_steering",
                            "operator_axis": "readout_steering",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "post_bridge_target_readout_patch_a060",
                            "operator_recipe_id": "readout_rank_recipe",
                            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                            "post_bridge_exhaustion_recipe": True,
                            "recipe_family": "readout_steering",
                            "readout_steering_kind": "target_readout",
                            "realized_lift_bundle_key": objective,
                            "self_delta": 0.15,
                            "cross_delta": 0.0,
                            "alignment_margin": 0.15,
                            "target_mass_delta": 0.0,
                            "target_top20_hit_delta": 0,
                            "focus_rank_delta": 4,
                            "target_top20_threshold_gap": 6.1,
                        },
                    ],
                }
            },
        )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["next_evidence_needed"], "readout_steering_deepening")
        summary = result["operator_recipe_expansion_summary"]
        self.assertEqual(summary["best_rank_carrier_recipe_family"], "resid_post|source_term_token|blend")
        self.assertEqual(summary["best_readout_steering_rank_carrier_recipe_family"], "readout_steering")
        self.assertEqual(summary["best_readout_steering_target_top20_threshold_gap"], 6.1)
        self.assertEqual(summary["recommended_next_family"], "readout_steering_deepening:readout_steering")
        self.assertIn("readout_steering", summary["operator_positive_memory"])
        self.assertEqual(summary["best_positive_operator_next_action"], "deepen_local_gap_closer")
        self.assertEqual(
            summary["positive_operator_deepening_plan"]["suggested_operator_recipe_expansion_mode"],
            "readout_steering_deepening",
        )

    def test_readout_steering_deepening_does_not_fallback_to_activation_patch_rows(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 0
        objective = "kv_pair:budget:source_body:72:73"
        result = runtime._execute_controller_diagnostic_request(
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "bundle_key": objective,
                "objective_bundle_key": objective,
                "step_actuator_bundle_key": objective,
                "operator_recipe_expansion_mode": "readout_steering_deepening",
                "next_evidence_needed": "readout_steering_deepening",
            },
            source="unit_test",
            packet={
                "strategy_hints": {
                    "diagnostic_frontier_bundle_key": objective,
                    "diagnostic_evidence_ledger": [
                        {
                            "bundle_key": objective,
                            "objective_bundle_key": objective,
                            "evidence_kind": "activation_patch_certification",
                            "status": "supportive",
                            "actuator_class": "self_actuator",
                            "actual_delta_class": "target_lift",
                            "recipe_name": "post_bridge_resid_post_term_to_last_blend_a060",
                            "operator_recipe_id": "activation_rank_recipe",
                            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                            "post_bridge_exhaustion_recipe": True,
                            "activation_patch_site": "resid_post",
                            "activation_patch_layer": 6,
                            "activation_patch_alpha": 0.06,
                            "target_mass_delta": 0.0002,
                            "target_top20_hit_delta": 0,
                        }
                    ],
                }
            },
        )

        self.assertIsNotNone(result)
        assert result is not None
        summary = result["operator_recipe_expansion_summary"]
        self.assertEqual(summary["status"], "no_readout_steering_rows")
        self.assertEqual(summary["matrix_row_count"], 0)
        self.assertEqual(summary["positive_memory_family_count"], 0)
        self.assertEqual(result["operator_recipe_expansion_matrix"], [])

    def test_activation_patch_candidate_review_blocks_rank_carrier_only_shadow(self):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        bundle_status = {
            "activation_patch_shadow_actuator": {
                "activation_patch_actuator_class": "self_actuator",
                "promotable_to_candidate_compiler": True,
                "objective_bundle_key": "kv_pair:budget:source_body:72:73",
                "actuator_bundle_key": "kv_pair:budget:source_body:72:73",
                "recipe_name": "resid_pre_source_term_token_minus_stealer_l050_to_last_blend_a050",
                "operator_recipe_id": "rank_carrier_recipe",
                "activation_patch_site": "resid_pre",
                "activation_patch_layer": 2,
                "activation_patch_alpha": 0.05,
                "activation_patch_source_localization": "source_term_token_minus_stealer_l050",
                "activation_patch_patch_mode": "blend",
                "actual_delta_class": "target_lift",
                "counterfactual_delta": {
                    "target_mass_delta": -0.000002,
                    "target_top20_hit_delta": 0,
                    "focus_rank_delta": 304,
                    "self_delta": 3.21,
                    "cross_delta": 3.04,
                    "alignment_margin": 0.17,
                },
            }
        }

        result = runtime._activation_patch_candidate_review(bundle_status)

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["status"], "bridge_plan_or_more_evidence_required")
        self.assertFalse(result["compile_preview_created"])
        self.assertEqual(result["compile_preview_blocked_reason"], "rank_carrier_not_target_actuator")
        self.assertEqual(result["ownership_role"], "self")
        self.assertEqual(result["effect_role"], "rank_carrier")
        self.assertEqual(result["safety_role"], "neutral")
        self.assertEqual(result["blueprint"]["effect_role"], "rank_carrier")
        self.assertEqual(result["ownership_gate"]["effect_role"], "rank_carrier")
        self.assertTrue(result["rank_carrier_only"])
        self.assertFalse(result["target_readout_effect_certified"])
        self.assertFalse(result["target_promotable_to_candidate_compiler"])

    def test_frontier_replay_requests_compare_after_rank_carrier_block(self):
        controller = _FrontierReplayControllerClient(replay_mode="diagnostic_request")
        objective = "kv_pair:budget:source_body:72:73"
        packet = {
            "strategy_hints": {
                "diagnostic_frontier_bundle_key": objective,
                "selected_bundle_key": objective,
            },
            "telemetry": {"diagnostic_call_budget_left": 2},
            "latest_diagnostic_results": [
                {
                    "diagnostic": "activation_patch_candidate_review",
                    "objective_bundle_key": objective,
                    "bundle_key": objective,
                    "activation_patch_compile_preview_created": False,
                    "activation_patch_compile_preview_blocked_reason": "rank_carrier_not_target_actuator",
                    "activation_patch_effect_role": "self_rank_carrier",
                    "activation_patch_promotable_to_candidate": False,
                    "diagnostic_operator_supported": False,
                    "policy_candidate_ready": False,
                    "production_apply_allowed": False,
                }
            ],
        }

        command = controller._diagnostic_request_command(
            packet=packet,
            strategy_hints=packet["strategy_hints"],
            frontier_bundle_key=objective,
            suggested_bundle_key=objective,
        )

        meta = command["meta"]
        request = meta["diagnostic_request"]
        self.assertEqual(command["decision"], "noop")
        self.assertEqual(meta["next_action"], "request_compare_extra_operator_diagnostics")
        self.assertEqual(meta["next_evidence_needed"], "rank_carrier_to_target_conversion")
        self.assertEqual(request["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(request["activation_patch_compile_preview_blocked_reason"], "rank_carrier_not_target_actuator")

    def test_focused_bridge_eval_recipe_specs_stay_small_and_ownership_oriented(self):
        recipe_names = [item["recipe_name"] for item in _focused_bridge_eval_recipe_specs()]

        self.assertEqual(
            recipe_names,
            [
                "baseline_span_mean",
                "term_token",
                "term_fused",
                "term_centered_pm1",
                "term_centered_pm1_v060_k020",
                "term_centered_pm1_v025_k045",
                "term_centered_pm1_minus_stealer_l025",
                "term_token_minus_stealer_l050",
                "term_centered_pm1_minus_stealer_l050",
                "term_centered_pm1_orthogonal_stealer",
            ],
        )
        centered = next(item for item in _focused_bridge_eval_recipe_specs() if item["recipe_name"] == "term_centered_pm1")
        self.assertIn("kv_v", centered["modes"])
        self.assertIn("kv_k", centered["modes"])
        self.assertIn("kv_pair_asymmetric", centered["modes"])

    def test_run_digit_transform_sweep_smoke(self):
        model, codec = self._make_model_and_codec()

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch(
                "SpiralInterventionLab.examples.digit_transform_e2e.create_controller_provider",
                return_value=_NoopProvider(),
            ):
                result = run_digit_transform_sweep(
                    provider_name="openai",
                    controller_model_name="fake-controller",
                    worker_model_name="tiny-random",
                    seeds=(3, 4),
                    worker_model=model,
                    codec=codec,
                    log_dir=tmpdir,
                )
            payload = result.to_dict()
            self.assertEqual(payload["summary"]["num_runs"], 2)
            self.assertEqual(len(payload["runs"]), 2)
            self.assertEqual(payload["seeds"], [3, 4])
            self.assertTrue(Path(tmpdir, "seed_3", "b0.jsonl").exists())
            self.assertTrue(Path(tmpdir, "seed_4", "c1.jsonl").exists())
            self.assertTrue(Path(tmpdir, "seed_3", "experiment_summary.json").exists())
            self.assertTrue(Path(tmpdir, "seed_4", "experiment_summary.json").exists())
            self.assertTrue(Path(tmpdir, "sweep_summary.json").exists())

    @patch("SpiralInterventionLab.examples.digit_transform_e2e._load_local_hooked_transformer_from_hf")
    @patch("SpiralInterventionLab.examples.digit_transform_e2e.AutoTokenizer")
    @patch("SpiralInterventionLab.examples.digit_transform_e2e.AutoModelForCausalLM")
    def test_load_worker_model_uses_local_hf_path_offline(
        self,
        auto_model_cls,
        auto_tokenizer_cls,
        load_local_hooked_transformer,
    ):
        local_dir = "/tmp/local-hf-worker"
        auto_model = object()
        tokenizer = object()
        sentinel = object()
        auto_model_cls.from_pretrained.return_value = auto_model
        auto_tokenizer_cls.from_pretrained.return_value = tokenizer
        load_local_hooked_transformer.return_value = sentinel

        model = load_worker_model(
            "gpt2",
            model_path=local_dir,
            tokenizer_path=local_dir,
            hf_offline=True,
            trust_remote_code=True,
            device="cpu",
        )

        self.assertIs(model, sentinel)
        auto_model_cls.from_pretrained.assert_called_once_with(
            local_dir,
            trust_remote_code=True,
            local_files_only=True,
            torch_dtype=torch.float32,
        )
        auto_tokenizer_cls.from_pretrained.assert_called_once_with(
            local_dir,
            trust_remote_code=True,
            local_files_only=True,
        )
        load_local_hooked_transformer.assert_called_once_with(
            model_ref=local_dir,
            hf_model=auto_model,
            tokenizer=tokenizer,
            device="cpu",
            dtype="float32",
            first_n_layers=None,
            move_to_device=True,
            local_files_only=True,
            trust_remote_code=True,
        )

    def test_resolve_worker_device_promotes_explicit_mps_in_conservative_mode(self):
        with patch("SpiralInterventionLab.examples.digit_transform_e2e.torch.backends.mps.is_available", return_value=True):
            self.assertIsNone(_resolve_worker_device(device=None, mps_mode="auto"))
            self.assertEqual(_resolve_worker_device(device=None, mps_mode="conservative"), "mps")

    @patch("SpiralInterventionLab.examples.digit_transform_e2e.torch.set_default_device")
    @patch("SpiralInterventionLab.examples.digit_transform_e2e.torch.get_default_device", return_value="mps:0")
    def test_configure_torch_default_device_for_worker_relaxes_auto_mps(self, get_default_device, set_default_device):
        changed = _configure_torch_default_device_for_worker(target_device="mps", mps_mode="conservative")

        self.assertTrue(changed)
        get_default_device.assert_called_once_with()
        set_default_device.assert_called_once_with("cpu")


class TestCarrierComposedConversion(unittest.TestCase):
    _OBJECTIVE_KEY = "kv_pair:budget:source_body:72:73"
    _CARRIER_FAMILY = "resid_pre|source_term_token|blend"

    def _make_runtime(self, *, convert_on_label: str | None = None):
        runtime = object.__new__(HookedTransformerWorkerRuntime)
        runtime._steps = 3

        def fake_trial_edit(candidate, *, trial_contract):
            return {
                "surface_id": "s_resid_pre_l11_last",
                "kind": "activation_patch",
                "bundle_key": candidate["bundle_key"],
                "target": {"surface_id": "s_resid_pre_l11_last"},
                "source": {"dtype": "vector", "expr": {"fn": "activation_patch_blend"}},
                "op": {"kind": "activation_patch", "alpha": candidate["alpha"]},
                "budget": {
                    "ttl_steps": 1,
                    "norm_clip": trial_contract["norm_clip"],
                    "step_size": candidate["step_size"],
                    "revertible": True,
                },
                "operator_recipe_id": candidate["operator_recipe_id"],
                "operator_family_key": f"readout_escape|activation_patch|{candidate['site']}",
            }

        def fake_readout_candidate(**kwargs):
            return {
                "surface_id": "s_resid_pre_l11_last",
                "kind": "resid_add",
                "bundle_key": kwargs["bundle_key"],
                "focus_feature": kwargs["intended_term"],
                "target": {"surface_id": "s_resid_pre_l11_last"},
                "source": {"dtype": "vector", "expr": {"fn": "readout_direction"}},
                "op": {"kind": "resid_add", "alpha": kwargs["alpha"]},
                "budget": {"ttl_steps": 1, "norm_clip": 1.0, "revertible": True},
                "operator_recipe_id": (
                    f"readout_escape|readout_steering|{kwargs['steering_kind']}|a{kwargs['alpha']:.4f}"
                ),
                "operator_family_key": "readout_escape|readout_steering|readout_direction",
            }

        def fake_replay(candidate_edits, **kwargs):
            label = str(kwargs.get("label") or "")
            if convert_on_label is not None and convert_on_label in label:
                return {
                    "status": "ok",
                    "label": label,
                    "actual_delta_class": "target_actuator",
                    "target_mass_delta": 0.0005,
                    "target_top20_hit_delta": 1,
                    "target_piece": " budget",
                    "target_piece_logit_delta": 0.4,
                    "target_rank_after": 14,
                    "target_top20_threshold_gap_delta": -0.8,
                    "focus_rank_delta": 22,
                    "repeat_flag_delta": 0,
                    "entropy_delta": 0.0,
                    "top1_margin_delta": 0.0,
                    "candidate_fingerprint": {"bundle_key": candidate_edits[0]["bundle_key"]},
                    "eval_context_fingerprint": {"decode_step": 0},
                }
            return {
                "status": "ok",
                "label": label,
                "actual_delta_class": "rank_carrier",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "target_piece": " budget",
                "target_piece_logit_delta": 0.02,
                "target_rank_after": 55,
                "target_top20_threshold_gap_delta": -0.05,
                "focus_rank_delta": 6,
                "repeat_flag_delta": 0,
                "entropy_delta": 0.0,
                "top1_margin_delta": 0.0,
                "candidate_fingerprint": {"bundle_key": candidate_edits[0]["bundle_key"]},
                "eval_context_fingerprint": {"decode_step": 0},
            }

        runtime._activation_patch_trial_edit_from_candidate = fake_trial_edit
        runtime._readout_steering_candidate = fake_readout_candidate
        runtime.replay_candidate_edits_actual_delta = fake_replay
        runtime._term_readout_lift_score = lambda replay: 0.05
        return runtime

    def _carrier_seed_row(self):
        return {
            "objective_bundle_key": self._OBJECTIVE_KEY,
            "bundle_key": self._OBJECTIVE_KEY,
            "intended_term": "budget",
            "diagnostic_family": "activation_patch",
            "recipe_family": self._CARRIER_FAMILY,
            "recipe_name": "activation_patch_resid_pre_source_term_token",
            "operator_recipe_id": "readout_escape|activation_patch|resid_pre|L11|source_body|source_term_token|blend|a0.0500",
            "activation_patch_site": "resid_pre",
            "activation_patch_layer": 11,
            "activation_patch_alpha": 0.05,
            "activation_patch_step_size": 0.05,
            "activation_patch_source_localization": "source_term_token",
            "actual_delta_class": "rank_carrier",
            "effect_role": "rank_carrier",
            "ownership_role": "self",
            "safety_role": "neutral",
            "positive_traits": ["rank_carrier"],
            "focus_rank_delta": 9,
            "target_mass_delta": 0.0,
            "self_delta": 0.06,
        }

    def test_composed_rows_hold_carrier_and_stay_diagnostic_only(self):
        runtime = self._make_runtime(convert_on_label="carrier_hold_plus_target_l025_a050")
        request = {
            "diagnostic": "carrier_to_actuator_conversion_sweep",
            "objective_bundle_key": self._OBJECTIVE_KEY,
            "objective_term": "budget",
            "operator_recipe_expansion_mode": "carrier_to_actuator_conversion_sweep",
            "carrier_recipe_family": self._CARRIER_FAMILY,
        }
        rows = runtime._carrier_composed_conversion_rows(request, [self._carrier_seed_row()])

        self.assertEqual(len(rows), 4)
        for row in rows:
            self.assertTrue(row["carrier_composed_conversion"])
            self.assertTrue(row["carrier_to_actuator_conversion_variant"])
            self.assertTrue(row["diagnostic_only"])
            self.assertFalse(row["production_apply_allowed"])
            self.assertFalse(row["policy_candidate_ready"])
            self.assertEqual(row["edit_count"], 2)
            self.assertEqual(row["operator_axis"], "carrier_to_actuator_conversion_sweep")
            self.assertEqual(row["carrier_seed_recipe_family"], self._CARRIER_FAMILY)
            self.assertEqual(row["activation_patch_site"], "resid_pre")
            self.assertEqual(row["activation_patch_layer"], 11)
            self.assertTrue(str(row["recipe_family"]).startswith("carrier_composed|"))

        converted = [row for row in rows if row["conversion_role"] == "converted_target_actuator"]
        self.assertEqual(len(converted), 1)
        self.assertEqual(converted[0]["recipe_name"], "carrier_hold_plus_target_l025_a050")
        self.assertIn("carrier_to_actuator_converted", converted[0]["positive_traits"])
        self.assertEqual(converted[0]["status"], "supportive")

        still_carriers = [row for row in rows if row["conversion_role"] == "still_rank_carrier"]
        self.assertEqual(len(still_carriers), 3)
        suppress_rows = [row for row in rows if row["candidate_kind"] == "suppress_then_carrier"]
        self.assertEqual(len(suppress_rows), 1)

    def test_composed_rows_fall_back_to_requested_family_without_seed(self):
        runtime = self._make_runtime()
        request = {
            "objective_bundle_key": self._OBJECTIVE_KEY,
            "objective_term": "budget",
            "carrier_recipe_family": "resid_pre|source_term_token_to_last|blend|a0.050",
        }
        rows = runtime._carrier_composed_conversion_rows(request, [])

        self.assertEqual(len(rows), 4)
        for row in rows:
            self.assertEqual(row["activation_patch_site"], "resid_pre")
            self.assertEqual(row["activation_patch_source_localization"], "source_term_token")
            self.assertEqual(row["conversion_role"], "still_rank_carrier")

    def test_composed_rows_deduplicate_and_require_carrier_identity(self):
        runtime = self._make_runtime()
        request = {
            "objective_bundle_key": self._OBJECTIVE_KEY,
            "objective_term": "budget",
            "carrier_recipe_family": self._CARRIER_FAMILY,
        }
        already_row = {
            "objective_bundle_key": self._OBJECTIVE_KEY,
            "carrier_composed_conversion": True,
        }
        self.assertEqual(runtime._carrier_composed_conversion_rows(request, [already_row]), [])

        bare_request = {"objective_bundle_key": self._OBJECTIVE_KEY, "objective_term": "budget"}
        self.assertEqual(runtime._carrier_composed_conversion_rows(bare_request, []), [])


class TestCarrierConversionControllerWiring(unittest.TestCase):
    _OBJECTIVE_KEY = "kv_pair:budget:source_body:72:73"

    def test_conversion_plan_extracted_from_post_bridge_summary(self):
        results = [
            {
                "diagnostic": "compare_extra_operator_diagnostics",
                "objective_bundle_key": self._OBJECTIVE_KEY,
                "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                "operator_recipe_expansion_summary": {
                    "status": "rank_carrier_family_found",
                    "recommended_next_family": "convert_rank_carrier_to_target:resid_pre|source_term_token|blend",
                    "best_rank_carrier_recipe_name": "activation_patch_resid_pre_source_term_token",
                },
            }
        ]
        plan = _FrontierReplayControllerClient._carrier_conversion_plan_from_results(
            results, objective_bundle_key=self._OBJECTIVE_KEY
        )
        self.assertIsNotNone(plan)
        assert plan is not None
        self.assertEqual(plan["carrier_recipe_family"], "resid_pre|source_term_token|blend")
        self.assertEqual(plan["carrier_recipe_name"], "activation_patch_resid_pre_source_term_token")
        self.assertEqual(plan["status"], "rank_carrier_family_found")

    def test_conversion_plan_ignores_readout_steering_and_non_post_bridge(self):
        readout_steering_result = {
            "diagnostic": "compare_extra_operator_diagnostics",
            "objective_bundle_key": self._OBJECTIVE_KEY,
            "operator_recipe_expansion_mode": "post_bridge_exhaustion",
            "operator_recipe_expansion_summary": {
                "recommended_next_family": "convert_rank_carrier_to_target:readout_steering|target_readout",
            },
        }
        self.assertIsNone(
            _FrontierReplayControllerClient._carrier_conversion_plan_from_results(
                [readout_steering_result], objective_bundle_key=self._OBJECTIVE_KEY
            )
        )
        non_post_bridge_result = {
            "diagnostic": "compare_extra_operator_diagnostics",
            "objective_bundle_key": self._OBJECTIVE_KEY,
            "operator_recipe_expansion_mode": "readout_steering_deepening",
            "operator_recipe_expansion_summary": {
                "recommended_next_family": "convert_rank_carrier_to_target:resid_pre|source_term_token|blend",
            },
        }
        self.assertIsNone(
            _FrontierReplayControllerClient._carrier_conversion_plan_from_results(
                [non_post_bridge_result], objective_bundle_key=self._OBJECTIVE_KEY
            )
        )

    def test_diagnostic_next_action_maps_conversion_sweep(self):
        self.assertEqual(
            _FrontierReplayControllerClient._diagnostic_next_action("carrier_to_actuator_conversion_sweep"),
            "request_carrier_to_actuator_conversion_sweep",
        )

    def test_conversion_sweep_seen_is_scoped_to_objective(self):
        results = [
            {
                "diagnostic": "carrier_to_actuator_conversion_sweep",
                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
            }
        ]

        self.assertTrue(
            _FrontierReplayControllerClient._diagnostic_seen_in_results(
                results,
                "carrier_to_actuator_conversion_sweep",
                objective_bundle_key="entity_insert:mira:source_body:near_reachable",
            )
        )
        self.assertFalse(
            _FrontierReplayControllerClient._diagnostic_seen_in_results(
                results,
                "carrier_to_actuator_conversion_sweep",
                objective_bundle_key=self._OBJECTIVE_KEY,
            )
        )


if __name__ == "__main__":
    unittest.main()
