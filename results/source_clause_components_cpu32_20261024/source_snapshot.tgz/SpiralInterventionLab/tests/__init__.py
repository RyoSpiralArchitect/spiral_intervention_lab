"""Tests for SpiralInterventionLab."""
