from copy import deepcopy
from types import SimpleNamespace
from unittest.mock import patch

import pytest
import torch

from SpiralInterventionLab.examples.replay_source_clause_trajectory import main, verify_reference
from SpiralInterventionLab.runtime import clause_actuation, clause_trajectory, diagnostic_budget
from SpiralInterventionLab.runtime.response_probe import state_identity, tensor_identity
from SpiralInterventionLab.tests.test_clause_actuation import make_worker


STAGES = ["resid_pre:11", "resid_post:11"]


def worker_and_records():
    worker = make_worker()
    old_read = worker.adapter.read_ref
    worker.adapter.read_ref = lambda ref, ctx: old_read(
        {**ref, "token": {"mode": "index", "value": -1}} if ref["token"]["mode"] == "last" else ref, ctx)
    return worker, clause_trajectory.measure(worker, [1, 3], stages=STAGES)


def test_existing_probes_capture_without_extra_forwards_or_authority():
    worker = make_worker()
    old_read = worker.adapter.read_ref
    worker.adapter.read_ref = lambda ref, ctx: old_read(
        {**ref, "token": {"mode": "index", "value": -1}} if ref["token"]["mode"] == "last" else ref, ctx)
    before, budget = state_identity(worker), diagnostic_budget.left(worker)
    with patch.object(worker, "_simulate_decode", wraps=worker._simulate_decode) as simulate:
        records = clause_trajectory.measure(worker, [1, 3], stages=STAGES)
    assert simulate.call_count == 16 == sum(len(r["frames"]) for r in records)
    assert all("policy_override" not in call.kwargs for call in simulate.call_args_list)
    assert diagnostic_budget.left(worker) == budget - 4
    assert before == state_identity(worker) and worker._steps == 1
    assert "run_with_cache" not in vars(worker.runtime_state)
    assert not worker._collect_active_edits() and not worker._frozen_diagnostic_candidates
    summary = clause_trajectory.summarize(records)
    assert summary["status"] == "ok" and not summary["production_apply_allowed"]
    surface = summary["surfaces"][0]
    assert max(max(r["expected_vs_captured_residual_norms"]) for r in surface["capture_checks"]) < 1e-6
    assert len(surface["stages"]) == 3
    assert surface["stages"][0]["self_copy_delta_norm_max"] == 0
    # The old fake model changes logits merely because a hook is registered.
    # This must be visible as a nonzero downstream null, not a proof of causality.
    assert surface["stages"][-1]["self_copy_delta_norm_max"] > 0
    compact = clause_trajectory.compact_record(records[1])
    assert "sha256" in compact["frames"][0]["vectors"][STAGES[0]]


@pytest.mark.parametrize("failure", ["count", "context", "site", "pre_patch_cache", "missing_stage", "not_restored"])
def test_incomparable_or_pre_patch_capture_fails_closed(failure):
    _, records = worker_and_records()
    bad = deepcopy(records)
    if failure == "count":
        bad[0]["frames"].pop()
    elif failure == "context":
        bad[0]["result"]["operator_rows"][0]["context_fingerprint"] = "other"
    elif failure == "site":
        bad[0]["result"]["operator_rows"][0]["surface"]["alpha"] = 0.2
    elif failure == "pre_patch_cache":
        for i in range(2):
            bad[1]["frames"][i + 2]["vectors"][STAGES[0]] = bad[1]["frames"][i]["vectors"][STAGES[0]].clone()
    elif failure == "missing_stage":
        del bad[1]["frames"][2]["vectors"][STAGES[0]]
    else:
        bad[0]["result"]["state_restored"] = False
    with pytest.raises(ValueError):
        clause_trajectory.summarize(bad)


def test_geometry_is_displacement_not_large_shared_background_or_probability_sign():
    assert clause_trajectory.geometry(torch.tensor([1., 0.]), torch.tensor([0., 1.]))["cosine"] == 0
    assert clause_trajectory.geometry(torch.tensor([1., 0.]), torch.tensor([2., 0.]))["cosine"] == 1
    assert clause_trajectory.geometry(torch.zeros(2), torch.ones(2))["cosine"] is None
    with pytest.raises(ValueError):
        clause_trajectory.geometry(torch.tensor([float("nan")]), torch.ones(1))


def test_capture_restores_instance_override_after_missing_stage_or_prefix_failure():
    tokens = torch.tensor([[1, 2]])
    original = lambda x, **kwargs: (torch.zeros(1, 2, 3), {})
    runtime = SimpleNamespace(run_with_cache=original)
    with pytest.raises(ValueError, match="stage_missing"):
        with clause_trajectory.capture_forwards(runtime, tokens, ["missing"]):
            runtime.run_with_cache(tokens)
    assert runtime.run_with_cache is original
    with pytest.raises(ValueError, match="prefix_changed"):
        with clause_trajectory.capture_forwards(runtime, tokens, ["missing"]):
            runtime.run_with_cache(torch.tensor([[1, 3]]))
    assert runtime.run_with_cache is original


def test_packet_canaries_are_separate_from_replays_and_total_counted():
    worker = make_worker()
    old_read = worker.adapter.read_ref
    worker.adapter.read_ref = lambda ref, ctx: old_read(
        {**ref, "token": {"mode": "index", "value": -1}} if ref["token"]["mode"] == "last" else ref, ctx)
    original_packet = worker.build_controller_packet

    def packet_with_canary():
        worker.runtime_state.run_with_cache(worker._current_token_tensor())
        return original_packet()

    with patch.object(worker, "build_controller_packet", side_effect=packet_with_canary):
        with clause_trajectory.count_forwards(worker.runtime_state) as counts:
            records = clause_trajectory.measure(worker, [1, 3], stages=STAGES)
    assert counts == {"attempted": 28, "completed": 28}
    assert all(len(r["frames"]) == 7 and len(clause_trajectory.replay_frames(r)) == 4 for r in records)
    summary = clause_trajectory.summarize(records)
    assert summary["captured_replay_forward_count"] == 16
    assert summary["captured_preparation_forward_count"] == 12
    assert all(r["preparation_vs_baseline_norm_max"] == 0 for r in summary["surfaces"][0]["stages"])
    assert "run_with_cache" not in vars(worker.runtime_state)
    assert "_simulate_decode" not in vars(worker)


def test_counting_retains_failed_attempts_and_restores_method():
    runtime = SimpleNamespace(run_with_cache=lambda *a, **kw: (_ for _ in ()).throw(ValueError("failed")))
    original = runtime.run_with_cache
    with pytest.raises(ValueError, match="failed"):
        with clause_trajectory.count_forwards(runtime) as counts:
            runtime.run_with_cache(None)
    assert counts == {"attempted": 1, "completed": 0}
    assert runtime.run_with_cache is original


def test_transformerlens_cache_is_post_hook_and_instrumentation_adds_no_hook():
    tl = pytest.importorskip("transformer_lens")
    from SpiralInterventionLab.runtime.tlens_runtime import HookedTransformerRuntimeState

    cfg = tl.HookedTransformerConfig(n_layers=2, d_model=12, n_ctx=8, d_head=6,
                                    n_heads=2, d_mlp=24, d_vocab=32, act_fn="relu", seed=0)
    model = tl.HookedTransformer(cfg)
    runtime = HookedTransformerRuntimeState(model)
    tokens = torch.tensor([[1, 2, 3]])
    stages = clause_trajectory.stage_names(2)
    _, before = runtime.run_with_cache(tokens)
    hook = "blocks.0.hook_resid_pre"

    def edit(act, hook):
        changed = act.clone()
        changed[0, -1, 0] += 0.08
        return changed

    runtime.register_hook(hook_name=hook, hook_fn=edit, edit_id="test", ttl_steps=1, revertible=True)
    hook_count = sum(len(h.fwd_hooks) for h in model.hook_dict.values())
    with clause_trajectory.capture_forwards(runtime, tokens, stages) as frames:
        runtime.run_with_cache(tokens)
    assert len(frames) == 1
    assert sum(len(h.fwd_hooks) for h in model.hook_dict.values()) == hook_count
    delta = frames[0]["vectors"][hook] - before[hook][0, -1]
    assert float(delta[0]) == pytest.approx(0.08)
    assert torch.count_nonzero(delta).item() == 1
    runtime.remove_edit("test")


@pytest.mark.parametrize("cause", ["budget", "unknown_token", "duplicate", "stale_cache", "missing_stage"])
def test_measurement_preflights_before_any_forward(cause):
    worker = make_worker()
    ids, stages = [1, 3], STAGES
    if cause == "budget":
        worker._diagnostic_calls_used = worker.max_diagnostic_calls_per_run - 3
    elif cause == "unknown_token":
        ids = [1, 400]
    elif cause == "duplicate":
        ids = [1, 1]
    elif cause == "stale_cache":
        worker.runtime_state.last_tokens = torch.tensor([[1]])
    else:
        stages = ["not_a_stage"]
    with patch.object(worker.runtime_state, "run_with_cache", side_effect=AssertionError("preflight only")):
        with pytest.raises(ValueError):
            clause_trajectory.measure(worker, ids, stages=stages)


def test_reference_matches_tokens_and_source_bindings_not_just_prefix_text():
    worker = make_worker()
    candidates = clause_actuation.offer(worker)["candidates"]
    reference = {"status": "complete", "device": "mps", "dtype": "float16",
                 "cache_alignment": {"tokens_identity": tensor_identity(worker._current_token_tensor())},
                 "measurements": [{"prefix": worker.final_text(), "operator_measurements": [
                     {"result": {"status": "ok", "candidate_binding": c}} for c in candidates]}]}
    assert verify_reference(worker, reference, [1, 3])["status"] == "matched"
    reference["cache_alignment"]["tokens_identity"]["sha256"] = "different"
    with pytest.raises(ValueError, match="prefix_or_tokens"):
        verify_reference(worker, reference, [1, 3])


def test_cli_rejects_unspecified_pair_without_loading_a_model():
    args = ["--source-jsonl", "unused", "--source-manifest", "unused", "--reference-receipt", "unused",
            "--worker-model-path", "unused", "--position", "8", "--source-token-ids", "11,11", "--output-dir", "unused"]
    with patch("SpiralInterventionLab.examples.replay_source_clause_trajectory.load_worker_model",
               side_effect=AssertionError("invalid arguments")):
        with pytest.raises(SystemExit) as exc:
            main(args)
    assert exc.value.code == 2
