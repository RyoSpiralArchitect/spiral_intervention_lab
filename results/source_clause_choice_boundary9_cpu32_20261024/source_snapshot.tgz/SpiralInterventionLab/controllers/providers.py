from __future__ import annotations

from typing import Any, Mapping

from .base import ControllerProvider, ControllerProviderRequest, ControllerProviderResponse

try:
    from openai import OpenAI
except Exception:  # pragma: no cover - optional dependency at import time
    OpenAI = None  # type: ignore[assignment]

try:
    from anthropic import Anthropic
except Exception:  # pragma: no cover - optional dependency at import time
    Anthropic = None  # type: ignore[assignment]

try:
    from mistralai import Mistral
except Exception:  # pragma: no cover - optional dependency at import time
    Mistral = None  # type: ignore[assignment]

try:
    from google import genai
except Exception:  # pragma: no cover - optional dependency at import time
    genai = None  # type: ignore[assignment]


def _coerce_metadata_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _coerce_metadata_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_coerce_metadata_value(item) for item in value]
    try:
        return {str(key): _coerce_metadata_value(item) for key, item in vars(value).items()}
    except Exception:
        return str(value)


def _compact_metadata(**items: Any) -> Mapping[str, Any]:
    return {
        key: _coerce_metadata_value(value)
        for key, value in items.items()
        if value is not None and value != {}
    }


def _usage_dict(raw: Any) -> Mapping[str, Any]:
    usage = getattr(raw, "usage", None)
    if usage is None:
        return {}
    if isinstance(usage, Mapping):
        return dict(usage)
    try:
        return dict(vars(usage))
    except Exception:
        return {}


def _anthropic_text(raw: Any) -> str:
    blocks = getattr(raw, "content", None) or []
    texts: list[str] = []
    for block in blocks:
        text = getattr(block, "text", None)
        if text:
            texts.append(str(text))
    return "".join(texts).strip()


def _mistral_text(raw: Any) -> str:
    choices = getattr(raw, "choices", None) or []
    if not choices:
        return ""
    message = getattr(choices[0], "message", None)
    content = getattr(message, "content", "")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        texts = []
        for item in content:
            if isinstance(item, str):
                texts.append(item)
                continue
            text = getattr(item, "text", None)
            if text:
                texts.append(str(text))
        return "".join(texts).strip()
    return str(content).strip()


def _google_text(raw: Any) -> str:
    text = getattr(raw, "text", None)
    if text:
        return str(text).strip()
    candidates = getattr(raw, "candidates", None) or []
    chunks: list[str] = []
    for candidate in candidates:
        content = getattr(candidate, "content", None)
        parts = getattr(content, "parts", None) or []
        for part in parts:
            part_text = getattr(part, "text", None)
            if part_text:
                chunks.append(str(part_text))
    return "".join(chunks).strip()


def _openai_metadata(raw: Any) -> Mapping[str, Any]:
    return _compact_metadata(
        response_id=getattr(raw, "id", None),
        status=getattr(raw, "status", None),
        incomplete_details=getattr(raw, "incomplete_details", None),
    )


def _anthropic_metadata(raw: Any) -> Mapping[str, Any]:
    return _compact_metadata(
        response_id=getattr(raw, "id", None),
        stop_reason=getattr(raw, "stop_reason", None),
        stop_sequence=getattr(raw, "stop_sequence", None),
        response_type=getattr(raw, "type", None),
    )


def _anthropic_model_accepts_temperature(model: str) -> bool:
    # Opus 4.8 and the Claude 5 family reject temperature ("deprecated for
    # this model"); keep the exclusion narrow so existing Anthropic controller
    # behavior remains unchanged for older models.
    name = str(model or "")
    if name.startswith("claude-opus-4-8"):
        return False
    family_and_rest = name.split("-", 1)
    if len(family_and_rest) == 2:
        segments = family_and_rest[1].split("-")
        # claude-<family>-5[-...] e.g. claude-sonnet-5, claude-fable-5-20260301.
        # The alphabetic family guard keeps claude-3-5-sonnet (version-first
        # naming) on the old temperature-accepting path.
        if len(segments) >= 2 and segments[0].isalpha() and segments[1] == "5":
            return False
    return True


def _mistral_metadata(raw: Any) -> Mapping[str, Any]:
    choice = (getattr(raw, "choices", None) or [None])[0]
    return _compact_metadata(
        response_id=getattr(raw, "id", None),
        finish_reason=getattr(choice, "finish_reason", None),
    )


def _google_metadata(raw: Any) -> Mapping[str, Any]:
    candidates = getattr(raw, "candidates", None) or []
    finish_reasons = [getattr(candidate, "finish_reason", None) for candidate in candidates]
    finish_reasons = [reason for reason in finish_reasons if reason is not None]
    return _compact_metadata(
        response_id=getattr(raw, "response_id", None),
        prompt_feedback=getattr(raw, "prompt_feedback", None),
        finish_reasons=finish_reasons or None,
    )


class OpenAIControllerProvider(ControllerProvider):
    def __init__(
        self,
        *,
        model: str,
        api_key: str | None = None,
        client: Any | None = None,
        base_url: str | None = None,
    ) -> None:
        if client is None:
            if OpenAI is None:
                raise ImportError("openai is not installed; install the 'controllers' extra to use OpenAIControllerProvider")
            client = OpenAI(api_key=api_key, base_url=base_url)
        self.client = client
        self._model_name = model

    @property
    def provider_name(self) -> str:
        return "openai"

    @property
    def model_name(self) -> str:
        return self._model_name

    def _text_verbosity(self) -> str:
        model = self.model_name.lower()
        if model.startswith("gpt-4.1"):
            return "medium"
        return "low"

    def _supports_temperature(self) -> bool:
        model = self.model_name.lower()
        return not model.startswith("gpt-5")

    def _reasoning_config(self) -> dict[str, Any] | None:
        model = self.model_name.lower()
        if model.startswith("gpt-5"):
            return {"effort": "low"}
        return None

    def complete(self, request: ControllerProviderRequest) -> ControllerProviderResponse:
        text_config: dict[str, Any] = {"verbosity": self._text_verbosity()}
        if request.expect_json:
            text_config["format"] = {"type": "json_object"}
        payload_text = request.payload_text()
        if request.expect_json:
            payload_text = f"JSON packet:\n{payload_text}"
        request_kwargs: dict[str, Any] = {
            "model": self.model_name,
            "instructions": request.effective_system_prompt(),
            "input": payload_text,
            "max_output_tokens": request.max_output_tokens,
            "metadata": dict(request.metadata),
            "text": text_config,
        }
        if self._supports_temperature():
            request_kwargs["temperature"] = request.temperature
        reasoning_config = self._reasoning_config()
        if reasoning_config is not None:
            request_kwargs["reasoning"] = reasoning_config
        raw = self.client.responses.create(**request_kwargs)
        text = getattr(raw, "output_text", None) or ""
        return ControllerProviderResponse(
            text=str(text).strip(),
            provider=self.provider_name,
            model=self.model_name,
            raw=raw,
            usage=_usage_dict(raw),
            metadata=_openai_metadata(raw),
        )


class AnthropicControllerProvider(ControllerProvider):
    def __init__(
        self,
        *,
        model: str,
        api_key: str | None = None,
        client: Any | None = None,
    ) -> None:
        if client is None:
            if Anthropic is None:
                raise ImportError("anthropic is not installed; install the 'controllers' extra to use AnthropicControllerProvider")
            client = Anthropic(api_key=api_key)
        self.client = client
        self._model_name = model

    @property
    def provider_name(self) -> str:
        return "anthropic"

    @property
    def model_name(self) -> str:
        return self._model_name

    def complete(self, request: ControllerProviderRequest) -> ControllerProviderResponse:
        request_kwargs: dict[str, Any] = {
            "model": self.model_name,
            "max_tokens": request.max_output_tokens,
            "system": request.effective_system_prompt(),
            "messages": [{"role": "user", "content": request.payload_text()}],
        }
        if _anthropic_model_accepts_temperature(self.model_name):
            request_kwargs["temperature"] = request.temperature
        raw = self.client.messages.create(**request_kwargs)
        return ControllerProviderResponse(
            text=_anthropic_text(raw),
            provider=self.provider_name,
            model=self.model_name,
            raw=raw,
            usage=_usage_dict(raw),
            metadata=_anthropic_metadata(raw),
        )


class MistralControllerProvider(ControllerProvider):
    def __init__(
        self,
        *,
        model: str,
        api_key: str | None = None,
        client: Any | None = None,
    ) -> None:
        if client is None:
            if Mistral is None:
                raise ImportError("mistralai is not installed; install the 'controllers' extra to use MistralControllerProvider")
            client = Mistral(api_key=api_key)
        self.client = client
        self._model_name = model

    @property
    def provider_name(self) -> str:
        return "mistral"

    @property
    def model_name(self) -> str:
        return self._model_name

    def complete(self, request: ControllerProviderRequest) -> ControllerProviderResponse:
        raw = self.client.chat.complete(
            model=self.model_name,
            messages=[
                {"role": "system", "content": request.effective_system_prompt()},
                {"role": "user", "content": request.payload_text()},
            ],
            temperature=request.temperature,
            max_tokens=request.max_output_tokens,
        )
        return ControllerProviderResponse(
            text=_mistral_text(raw),
            provider=self.provider_name,
            model=self.model_name,
            raw=raw,
            usage=_usage_dict(raw),
            metadata=_mistral_metadata(raw),
        )


class GoogleGenAIControllerProvider(ControllerProvider):
    def __init__(
        self,
        *,
        model: str,
        api_key: str | None = None,
        client: Any | None = None,
    ) -> None:
        if client is None:
            if genai is None:
                raise ImportError("google-genai is not installed; install the 'controllers' extra to use GoogleGenAIControllerProvider")
            client = genai.Client(api_key=api_key)
        self.client = client
        self._model_name = model

    @property
    def provider_name(self) -> str:
        return "google"

    @property
    def model_name(self) -> str:
        return self._model_name

    def complete(self, request: ControllerProviderRequest) -> ControllerProviderResponse:
        config = genai.types.GenerateContentConfig(
            systemInstruction=request.effective_system_prompt(),
            temperature=request.temperature,
            maxOutputTokens=request.max_output_tokens,
            responseMimeType="application/json" if request.expect_json else "text/plain",
        )
        raw = self.client.models.generate_content(
            model=self.model_name,
            contents=request.payload_text(),
            config=config,
        )
        return ControllerProviderResponse(
            text=_google_text(raw),
            provider=self.provider_name,
            model=self.model_name,
            raw=raw,
            usage=_usage_dict(raw),
            metadata=_google_metadata(raw),
        )
