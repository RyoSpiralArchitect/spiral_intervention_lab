from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from dataclasses import asdict, is_dataclass
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping
from typing import Sequence

from ..controllers.base import ControllerProvider, ControllerProviderRequest
from ..runtime.edit_budget import estimate_edit_cost
from ..runtime.schema import ControllerCommand, parse_controller_command
from ..runtime import operation_cards, prefix_control


def load_prompt_asset(asset_name: str) -> str:
    path = Path(__file__).resolve().parents[1] / "prompts" / asset_name
    return path.read_text(encoding="utf-8")


_COMPACT_PACKET_VIEWS = {"full", "compact"}


def _payload_for_provider(packet: Any, *, packet_view: str = "full") -> Any:
    if is_dataclass(packet):
        packet = asdict(packet)
    normalized_view = str(packet_view or "full").strip().lower().replace("-", "_")
    if normalized_view == "compact":
        return _compact_controller_payload(packet)
    return packet


def _stable_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True)
    except Exception:
        return str(value)


def _stable_hash(value: Any) -> str:
    text = _stable_text(value)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _serialized_char_count(value: Any) -> int:
    return len(_stable_text(value))


def _rough_token_estimate_from_chars(char_count: int) -> int:
    return max(1, (max(0, int(char_count)) + 3) // 4)


def _truncate_text(text: Any, limit: int = 240) -> str:
    value = str(text)
    if len(value) <= limit:
        return value
    return f"{value[:limit]}..."


def _json_ready(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_json_ready(item) for item in value]
    try:
        return {str(key): _json_ready(item) for key, item in vars(value).items()}
    except Exception:
        return str(value)


def _bounded_json(
    value: Any,
    *,
    max_depth: int = 4,
    max_items: int = 8,
    max_string: int = 320,
) -> Any:
    if max_depth <= 0:
        if isinstance(value, Mapping):
            return {"__truncated__": "mapping", "key_count": len(value)}
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            return {"__truncated__": "sequence", "item_count": len(value)}
        return _truncate_text(value, max_string)
    if value is None or isinstance(value, (int, float, bool)):
        return value
    if isinstance(value, str):
        return _truncate_text(value, max_string)
    if isinstance(value, Mapping):
        items = list(value.items())
        compact: dict[str, Any] = {}
        for key, item in items[:max_items]:
            compact[str(key)] = _bounded_json(
                item,
                max_depth=max_depth - 1,
                max_items=max_items,
                max_string=max_string,
            )
        omitted = len(items) - len(compact)
        if omitted > 0:
            compact["__omitted_key_count"] = omitted
        return compact
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        items = list(value)
        compact_items = [
            _bounded_json(item, max_depth=max_depth - 1, max_items=max_items, max_string=max_string)
            for item in items[:max_items]
        ]
        omitted = len(items) - len(compact_items)
        if omitted > 0:
            compact_items.append({"__omitted_item_count": omitted})
        return compact_items
    return _truncate_text(value, max_string)


def _list_of_ids(items: Any, key: str) -> list[str]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    values: list[str] = []
    for item in items:
        if isinstance(item, Mapping):
            value = item.get(key)
            if value is not None:
                values.append(str(value))
    return values


def _compact_surface_catalog(items: Any, *, limit: int = 20) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    compact: list[dict[str, Any]] = []
    for item in list(items)[:limit]:
        if not isinstance(item, Mapping):
            continue
        row: dict[str, Any] = {
            key: _bounded_json(item.get(key), max_depth=3, max_items=8, max_string=160)
            for key in ("surface_id", "target", "caps", "allowed_ops", "notes")
            if item.get(key) not in (None, "", [])
        }
        if row:
            compact.append(row)
    omitted = len(items) - len(compact)
    if omitted > 0:
        compact.append({"__omitted_surface_count": omitted})
    return compact


def _compact_probe_frames(items: Any, *, limit: int = 12) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    frames: list[dict[str, Any]] = []
    for item in list(items)[:limit]:
        if not isinstance(item, Mapping):
            continue
        row: dict[str, Any] = {}
        if item.get("surface_id") not in (None, ""):
            row["surface_id"] = item.get("surface_id")
        stats = item.get("stats")
        if isinstance(stats, Mapping):
            row["stats"] = {
                key: stats.get(key)
                for key in (
                    "norm",
                    "delta_prev",
                    "cache_drift",
                    "cosine_to_best_success",
                    "cosine_to_last_success",
                    "cosine_to_paired_baseline",
                )
                if stats.get(key) is not None
            }
        if row:
            frames.append(row)
    omitted = len(items) - len(frames)
    if omitted > 0:
        frames.append({"__omitted_probe_frame_count": omitted})
    return frames


def _compact_trace_bank(items: Any, *, limit: int = 6) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    traces: list[dict[str, Any]] = []
    for item in list(items)[:limit]:
        if not isinstance(item, Mapping):
            continue
        row = {
            key: item.get(key)
            for key in ("trace_id", "kind", "score", "partial_score", "label", "recorded_step")
            if item.get(key) not in (None, "", [])
        }
        if row:
            traces.append(row)
    omitted = len(items) - len(traces)
    if omitted > 0:
        traces.append({"__omitted_trace_count": omitted})
    return traces


_STRATEGY_HINT_PRIORITY_KEYS: tuple[str, ...] = (
    "evidence_inspection_catalog",
    "evidence_inspection_calls_left",
    "selected_bundle_key",
    "controller_focus_term",
    "controller_focus_source",
    "semantic_focus_term",
    "reachable_focus_term",
    "reachable_focus_rank",
    "target_mass",
    "target_top20_hits",
    "attractor_family_mass",
    "attractor_family_overlap_tokens",
    "readout_escape_needed",
    "readout_escape_reason",
    "readout_escape_block_reason",
    "diagnostic_frontier_bundle_key",
    "diagnostic_frontier_next_evidence",
    "diagnostic_frontier_request",
    "diagnostic_frontier_operator_recipe_expansion_mode",
    "diagnostic_frontier_canonical_request",
    "diagnostic_frontier_blocked_reason",
    "diagnostic_call_budget_left",
    "diagnostic_budget_exhausted",
    "diagnostic_budget_block_reason",
    "available_next_diagnostics",
    "blocked_next_diagnostics",
    "diagnostic_unavailable_vetoes",
    "diagnostic_unavailable_veto_count",
    "diagnostic_frontier_reason_text",
    "target_entity_insertion_probe_recommended",
    "entity_insertion_operator_candidate_review_recommended",
    "entity_candidate_review_availability",
    "entity_probe_refresh",
    "source_clause_structure",
    "source_clause_activation_patch",
    "entity_insertion_operator_replay_recommended",
    "entity_insertion_operator_deepening_recommended",
    "bridge_plan_available",
    "bridge_plan_required",
    "bridge_plan_report",
    "bridge_plan_objective_bundle_key",
    "bridge_plan_actuator_bundle_key",
    "bridge_plan_reason",
    "bridge_plan_unavailable_reason",
    "diagnostic_evidence_ledger",
    "diagnostic_review_reuse",
    "candidate_diagnostic_choices",
    "candidate_handoff",
    "generation_control",
    "candidate_trial_handoffs",
    "candidate_trial_offer",
    "bundle_diagnostic_status",
    "activation_patch_compile_preview",
    "activation_patch_compile_preview_blocked_reason",
    "activation_patch_production_denial_dossier",
    "activation_patch_production_shadow_dossier",
    "activation_patch_production_trial_dossier",
    "activation_patch_production_trial_candidate",
    "production_trial_allowed",
    "production_apply_allowed",
    "certified_for_apply",
    "diagnostic_operator_supported",
    "policy_candidate_ready",
    "positive_operator_deepening_plan",
    "readout_deepening_review_status",
    "readout_deepening_review_summary",
    "readout_deepening_best_candidate_role",
    "readout_deepening_recommended_next_action",
    "readout_deepening_production_trial_eligible",
    "readout_steering_deepening_followup_status",
    "readout_steering_deepening_followup_count",
    "confirmed_gap_only_objectives",
    "confirmed_gap_only_terms",
    "confirmed_gap_only_count",
    "objective_rotation_excluded_terms",
    "objective_rotation_exclusion_reason",
    "objective_rotation_needed",
    "objective_rotation_reason",
    "objective_rotation_from_term",
    "objective_rotation_candidates",
    "objective_rotation_canonical_request",
    "objective_rotation_pipeline_recommended",
    "objective_rotation_probe_consumed",
    "rotated_entity_operator_deepening_recommended",
    "diagnostic_budget_reserved_for_rotation",
    "rotation_budget_reserve_reason",
    "rotation_budget_reserved_diagnostics",
    "diagnostic_budget_reserved_for_conversion",
    "conversion_budget_reserve_reason",
    "readout_gap_confirmation_skipped_for_conversion",
    "readout_gap_confirmation_skip_reason",
    "carrier_to_actuator_conversion_sweep_recommended",
    "carrier_to_actuator_conversion_reason",
    "carrier_to_actuator_conversion_objective_count",
    "carrier_to_actuator_conversion_canonical_request",
    "operator_family_shift_status",
    "operator_family_shift_reason",
    "operator_family_shift_preview_rows",
    "operator_family_shift_canonical_request",
    "operator_family_shift_recommended",
    "finish_budget_reserve_suggested",
    "same_family_alpha_escalation_requires_gain",
    "suggested_noop_reason",
)


def _compact_strategy_hints(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        return {}
    compact: dict[str, Any] = {}
    for key in _STRATEGY_HINT_PRIORITY_KEYS:
        if key in value and value.get(key) not in (None, "", []):
            if key in {"source_clause_structure", "source_clause_activation_patch"}:
                compact[key] = _bounded_json(value[key], max_depth=5, max_items=16, max_string=260)
                continue
            if key in {"candidate_diagnostic_choices", "candidate_handoff", "candidate_trial_handoffs", "candidate_trial_offer", "generation_control"}:
                # Runtime bounds the catalog; preserve nested executable IDs.
                compact[key] = _bounded_json(value[key], max_depth=8, max_items=12, max_string=260)
                continue
            compact[key] = _bounded_json(value.get(key), max_depth=4, max_items=8, max_string=260)
    for key, item in value.items():
        if key in compact or item in (None, "", []):
            continue
        if str(key).endswith("_count") or str(key).endswith("_counts") or str(key).endswith("_status"):
            compact[str(key)] = _bounded_json(item, max_depth=2, max_items=6, max_string=160)
    omitted = len([key for key, item in value.items() if key not in compact and item not in (None, "", [])])
    if omitted > 0:
        compact["__omitted_hint_key_count"] = omitted
    return compact


def _compact_controller_payload(payload: Any) -> Any:
    if not isinstance(payload, Mapping):
        return payload
    task_view = payload.get("task_view") if isinstance(payload.get("task_view"), Mapping) else {}
    worker_view = payload.get("worker_view") if isinstance(payload.get("worker_view"), Mapping) else {}
    latest_observer_check = _compact_observer_check(payload.get("latest_observer_check"))
    recent_observer_checks = _observer_check_summaries(payload.get("recent_observer_checks"))
    if latest_observer_check is not None and recent_observer_checks:
        recent_observer_checks = recent_observer_checks[:-1]
    compact: dict[str, Any] = {
        "packet_view": "compact_v1",
        "compaction_note": (
            "Raw rows remain in JSONL logs; this controller view keeps bounded top-k summaries, "
            "omitted counts, and stable digests."
        ),
        "source_packet_sha256": _stable_hash(payload),
        "version": payload.get("version"),
        "run_id": payload.get("run_id"),
        "episode_id": payload.get("episode_id"),
        "worker_id": payload.get("worker_id"),
        "step": payload.get("step"),
        "horizon": _bounded_json(payload.get("horizon"), max_depth=2, max_items=8, max_string=160),
        "task_view": {
            key: task_view.get(key)
            for key in ("task_id", "mode", "prompt_hash", "constraints", "allowed_summary")
            if task_view.get(key) not in (None, "", [])
        },
        "worker_view": {
            key: _bounded_json(worker_view.get(key), max_depth=3, max_items=8, max_string=360)
            for key in (
                "status",
                "generated_tail",
                "answer_readout_canary",
                "readout_sidecar_capture_summary",
                "readout_analyzer_capture_summary",
                "readout_sidecar_hints",
                "readout_analyzer_hints",
            )
            if worker_view.get(key) not in (None, "", [])
        },
        "telemetry": _bounded_json(payload.get("telemetry"), max_depth=2, max_items=64, max_string=160),
        "task_feedback": _bounded_json(payload.get("task_feedback"), max_depth=3, max_items=32, max_string=220),
        "budget": _bounded_json(payload.get("budget"), max_depth=2, max_items=32, max_string=160),
        "control_phase_hint": payload.get("control_phase_hint"),
        "surface_catalog": _compact_surface_catalog(payload.get("surface_catalog")),
        "surface_ids": _list_of_ids(payload.get("surface_catalog"), "surface_id"),
        "probe_frames": _compact_probe_frames(payload.get("probe_frames")),
        "trace_bank": _compact_trace_bank(payload.get("trace_bank")),
        "trace_ids": _list_of_ids(payload.get("trace_bank"), "trace_id"),
        "active_edits": _bounded_json(payload.get("active_edits"), max_depth=4, max_items=8, max_string=220),
        "recent_effects": _recent_effect_summaries(payload.get("recent_effects"))[-5:],
        "recent_effect_summary": _bounded_json(payload.get("recent_effect_summary"), max_depth=4, max_items=16, max_string=260),
        "tool_catalog": _compact_tool_catalog(payload.get("tool_catalog")),
        "latest_tool_results": _tool_result_summaries(payload.get("latest_tool_results"))[-3:],
        "recent_tool_results": _tool_result_summaries(payload.get("recent_tool_results"))[-5:],
        "latest_diagnostic_results": _diagnostic_result_summaries(payload.get("latest_diagnostic_results"))[-3:],
        "recent_diagnostic_results": _diagnostic_result_summaries(payload.get("recent_diagnostic_results"))[-6:],
        "controller_memory": _controller_memory_summaries(payload.get("controller_memory"))[-5:],
        "strategy_hints": _compact_strategy_hints(payload.get("strategy_hints")),
        "latest_observer_check": latest_observer_check,
        "recent_observer_checks": recent_observer_checks[-3:],
    }
    return {key: item for key, item in compact.items() if item not in (None, "", [], {})}


def _compact_controller_memory(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    summary: dict[str, Any] = {}
    for key in (
        "hypothesis",
        "micro_rationale",
        "expected_effect",
        "observed_outcome",
        "why_failed_or_helped",
        "blocked_by",
        "next_change",
        "next_evidence_needed",
        "diagnostic_request",
        "next_trigger",
        "next_action",
        "stop_condition",
        "noop_reason",
        "apply_block_reason",
        "surface_family_key",
        "focus_term",
        "objective_bundle_key",
        "step_actuator_bundle_key",
        "why_not_apply",
        "decision",
        "recorded_step",
    ):
        if key in value and value.get(key) not in (None, ""):
            summary[key] = value.get(key)
    confidence = value.get("confidence")
    if isinstance(confidence, (int, float)) and not isinstance(confidence, bool):
        summary["confidence"] = float(confidence)
    for key in ("transfer_confidence", "same_family_escalation_risk"):
        numeric = value.get(key)
        if isinstance(numeric, (int, float)) and not isinstance(numeric, bool):
            summary[key] = float(numeric)
    finish_budget_reserved = value.get("finish_budget_reserved")
    if isinstance(finish_budget_reserved, (bool, int, float)) and not (
        isinstance(finish_budget_reserved, float) and finish_budget_reserved != finish_budget_reserved
    ):
        summary["finish_budget_reserved"] = finish_budget_reserved
    bullets = value.get("evidence_bullets")
    if isinstance(bullets, Sequence) and not isinstance(bullets, (str, bytes, bytearray)):
        compact_bullets = [str(item) for item in bullets[:4] if str(item).strip()]
        if compact_bullets:
            summary["evidence_bullets"] = compact_bullets
    shadow_proposals = value.get("shadow_proposals")
    if isinstance(shadow_proposals, Sequence) and not isinstance(shadow_proposals, (str, bytes, bytearray)):
        compact_shadow: list[dict[str, Any]] = []
        for item in shadow_proposals[:2]:
            if not isinstance(item, Mapping):
                continue
            proposal = {
                key: item.get(key)
                for key in ("kind", "bundle_key", "objective_bundle_key", "actuator_bundle_key", "reason", "decision")
                if key in item and item.get(key) not in (None, "")
            }
            if proposal:
                compact_shadow.append(proposal)
        if compact_shadow:
            summary["shadow_proposals"] = compact_shadow
    return summary or None


def _controller_memory_summaries(items: Any) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    summaries: list[dict[str, Any]] = []
    for item in items:
        summary = _compact_controller_memory(item)
        if summary is not None:
            summaries.append(summary)
    return summaries


def _compact_latent_feature_scan(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    summary: dict[str, Any] = {}
    for key in ("prototype_mode", "surface_count", "group_count", "mean_alignment", "max_alignment"):
        if key in value and value.get(key) not in (None, ""):
            summary[key] = value.get(key)

    groups_value = value.get("groups")
    if isinstance(groups_value, Sequence) and not isinstance(groups_value, (str, bytes, bytearray)):
        groups: list[dict[str, Any]] = []
        for item in groups_value[:2]:
            if not isinstance(item, Mapping):
                continue
            group_summary: dict[str, Any] = {}
            for key in ("group", "polarity", "feature_kind", "feature_count", "mean_alignment"):
                if key in item and item.get(key) not in (None, ""):
                    group_summary[key] = item.get(key)
            top_features_value = item.get("top_features")
            if isinstance(top_features_value, Sequence) and not isinstance(top_features_value, (str, bytes, bytearray)):
                top_features: list[dict[str, Any]] = []
                for feature in top_features_value[:1]:
                    if not isinstance(feature, Mapping):
                        continue
                    feature_summary = {
                        key: feature.get(key)
                        for key in ("feature", "polarity", "surface_id", "alignment", "coverage_progress")
                        if key in feature and feature.get(key) not in (None, "")
                    }
                    if feature_summary:
                        top_features.append(feature_summary)
                if top_features:
                    group_summary["top_features"] = top_features
            if group_summary:
                groups.append(group_summary)
        if groups:
            summary["groups"] = groups

    top_hits_value = value.get("top_feature_hits")
    if isinstance(top_hits_value, Sequence) and not isinstance(top_hits_value, (str, bytes, bytearray)):
        top_hits: list[dict[str, Any]] = []
        for item in top_hits_value[:4]:
            if not isinstance(item, Mapping):
                continue
            hit_summary = {
                key: item.get(key)
                for key in ("group", "feature", "polarity", "surface_id", "alignment", "coverage_progress")
                if key in item and item.get(key) not in (None, "")
            }
            if hit_summary:
                top_hits.append(hit_summary)
        if top_hits:
            summary["top_feature_hits"] = top_hits

    return summary or None


def _compact_kv_feature_scan(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    summary: dict[str, Any] = {}
    for key in ("projection_mode", "surface_count", "group_count", "mean_alignment", "max_alignment"):
        if key in value and value.get(key) not in (None, ""):
            summary[key] = value.get(key)

    groups_value = value.get("groups")
    if isinstance(groups_value, Sequence) and not isinstance(groups_value, (str, bytes, bytearray)):
        groups: list[dict[str, Any]] = []
        for item in groups_value[:3]:
            if not isinstance(item, Mapping):
                continue
            group_summary: dict[str, Any] = {}
            for key in ("group", "polarity", "feature_kind", "feature_count", "mean_alignment"):
                if key in item and item.get(key) not in (None, ""):
                    group_summary[key] = item.get(key)
            top_features_value = item.get("top_features")
            if isinstance(top_features_value, Sequence) and not isinstance(top_features_value, (str, bytes, bytearray)):
                top_features: list[dict[str, Any]] = []
                for feature in top_features_value[:2]:
                    if not isinstance(feature, Mapping):
                        continue
                    feature_summary = {
                        key: feature.get(key)
                        for key in (
                            "feature",
                            "polarity",
                            "site",
                            "layer",
                            "head",
                            "token_mode",
                            "surface_id",
                            "alignment",
                            "coverage_progress",
                            "argmax_pos",
                            "argmax_relative_index",
                            "argmax_piece",
                            "argmax_segment_kind",
                        )
                        if key in feature and feature.get(key) not in (None, "")
                    }
                    source_positions = feature.get("source_positions")
                    if isinstance(source_positions, Sequence) and not isinstance(source_positions, (str, bytes, bytearray)):
                        compact_positions = []
                        for position in source_positions[:1]:
                            if not isinstance(position, Mapping):
                                continue
                            compact_positions.append(
                                {
                                    key: position.get(key)
                                    for key in ("position", "relative_index", "segment_kind", "piece", "alignment")
                                    if key in position and position.get(key) not in (None, "")
                                }
                            )
                        if compact_positions:
                            feature_summary["source_positions"] = compact_positions
                    if feature_summary:
                        top_features.append(feature_summary)
                if top_features:
                    group_summary["top_features"] = top_features
            if group_summary:
                groups.append(group_summary)
        if groups:
            summary["groups"] = groups

    top_hits_value = value.get("top_feature_hits")
    if isinstance(top_hits_value, Sequence) and not isinstance(top_hits_value, (str, bytes, bytearray)):
        top_hits: list[dict[str, Any]] = []
        for item in top_hits_value[:4]:
            if not isinstance(item, Mapping):
                continue
            hit_summary = {
                key: item.get(key)
                for key in (
                    "group",
                    "feature",
                    "polarity",
                    "site",
                    "layer",
                    "head",
                    "token_mode",
                    "surface_id",
                    "alignment",
                    "coverage_progress",
                    "argmax_pos",
                    "argmax_relative_index",
                    "argmax_piece",
                    "argmax_segment_kind",
                )
                if key in item and item.get(key) not in (None, "")
            }
            source_positions = item.get("source_positions")
            if isinstance(source_positions, Sequence) and not isinstance(source_positions, (str, bytes, bytearray)):
                compact_positions = []
                for position in source_positions[:1]:
                    if not isinstance(position, Mapping):
                        continue
                    compact_positions.append(
                        {
                            key: position.get(key)
                            for key in ("position", "relative_index", "segment_kind", "piece", "alignment")
                            if key in position and position.get(key) not in (None, "")
                        }
                    )
                if compact_positions:
                    hit_summary["source_positions"] = compact_positions
            if hit_summary:
                top_hits.append(hit_summary)
        if top_hits:
            summary["top_feature_hits"] = top_hits

    return summary or None


def _compact_observer_check(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    summary: dict[str, Any] = {}
    for key in (
        "check_type",
        "trigger",
        "verdict",
        "score",
        "raw_score",
        "coverage_signal",
        "coverage_weight",
        "delta_vs_last_check",
        "recorded_step",
    ):
        if key in value and value.get(key) not in (None, ""):
            summary[key] = value.get(key)
    latent_feature_scan = _compact_latent_feature_scan(value.get("latent_feature_scan"))
    if latent_feature_scan is not None:
        summary["latent_feature_scan"] = latent_feature_scan
    kv_feature_scan = _compact_kv_feature_scan(value.get("kv_feature_scan"))
    if kv_feature_scan is not None:
        summary["kv_feature_scan"] = kv_feature_scan
    return summary or None


def _observer_check_summaries(items: Any) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    summaries: list[dict[str, Any]] = []
    for item in items:
        summary = _compact_observer_check(item)
        if summary is not None:
            summaries.append(summary)
    return summaries


def _compact_observer_check_request(value: Any) -> dict[str, Any] | None:
    if value is True:
        return {"kind": "semantic_progress"}
    if not isinstance(value, Mapping):
        return None
    summary: dict[str, Any] = {}
    for key in ("kind", "reason", "trigger"):
        if key in value and value.get(key) not in (None, ""):
            summary[key] = value.get(key)
    return summary or None


def _compact_tool_request(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    tool_name = value.get("tool") or value.get("name") or value.get("kind")
    if not tool_name:
        return None
    summary: dict[str, Any] = {"tool": str(tool_name)}
    if isinstance(value.get("terms"), Sequence) and not isinstance(value.get("terms"), (str, bytes, bytearray)):
        terms = [str(item) for item in value.get("terms", [])[:4]]
        if terms:
            summary["terms"] = terms
            summary["term_count"] = len(value.get("terms", []))
    if value.get("candidate") not in (None, ""):
        summary["candidate_preview"] = _truncate_text(value.get("candidate"), 80)
    if isinstance(value.get("candidate_edit"), Mapping):
        candidate_edit = value["candidate_edit"]
        if candidate_edit.get("surface_id") is not None:
            summary["surface_id"] = candidate_edit.get("surface_id")
        elif isinstance(candidate_edit.get("target"), Mapping) and candidate_edit["target"].get("surface_id") is not None:
            summary["surface_id"] = candidate_edit["target"].get("surface_id")
        op_kind = candidate_edit.get("kind")
        if op_kind is None and isinstance(candidate_edit.get("op"), Mapping):
            op_kind = candidate_edit["op"].get("kind")
        if op_kind is not None:
            summary["kind"] = op_kind
        if candidate_edit.get("alpha") is not None:
            summary["alpha"] = candidate_edit.get("alpha")
        elif isinstance(candidate_edit.get("op"), Mapping) and candidate_edit["op"].get("alpha") is not None:
            summary["alpha"] = candidate_edit["op"].get("alpha")
    if value.get("max_new_tokens") is not None:
        summary["max_new_tokens"] = value.get("max_new_tokens")
    if value.get("reason") not in (None, ""):
        summary["reason"] = value.get("reason")
    return summary


def _tool_request_summaries(items: Any) -> list[dict[str, Any]]:
    if isinstance(items, Mapping):
        items = [items]
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    summaries: list[dict[str, Any]] = []
    for item in items:
        summary = _compact_tool_request(item)
        if summary is not None:
            summaries.append(summary)
    return summaries


def _compact_tool_catalog(items: Any) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    summaries: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, Mapping):
            continue
        summary = {
            key: item.get(key)
            for key in ("tool", "available", "cost_hint", "budget_left")
            if key in item and item.get(key) not in (None, "")
        }
        if summary:
            summaries.append(summary)
    return summaries


def _compact_tool_result(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    tool_name = value.get("tool")
    if not tool_name:
        return None
    summary: dict[str, Any] = {"tool": str(tool_name)}
    for key in (
        "status",
        "recorded_step",
        "requested_by",
        "term_count",
        "required_term_recall",
        "forbidden_clean",
        "brevity_score",
        "semantic_progress_score",
        "entropy_delta",
        "repeat_flag_delta",
        "required_term_recall_delta",
        "required_term_span_progress_delta",
        "semantic_progress_delta",
        "target_mass_delta",
        "target_mass_edited",
        "target_top20_hit_delta",
        "target_top20_hits_edited",
        "focus_logit_delta",
        "focus_prob_delta",
        "focus_rank_delta",
        "focus_rank_edited",
        "rank_focus_delta",
        "rank_focus_rank_edited",
    ):
        if key in value and value.get(key) not in (None, ""):
            summary[key] = value.get(key)
    candidate_edit = value.get("candidate_edit")
    if isinstance(candidate_edit, Mapping):
        for source_key, summary_key in (
            ("surface_id", "candidate_surface_id"),
            ("site", "candidate_site"),
            ("focus_feature", "candidate_focus_feature"),
            ("retry_stage", "retry_stage"),
        ):
            if candidate_edit.get(source_key) not in (None, ""):
                summary[summary_key] = candidate_edit.get(source_key)
    if value.get("candidate_preview") not in (None, ""):
        summary["candidate_preview"] = _truncate_text(value.get("candidate_preview"), 80)
    for key in (
        "single_token_terms",
        "multi_piece_terms",
        "soft_logit_bias_ok_terms",
        "needs_sequence_support_terms",
        "span_progress_watch_terms",
    ):
        raw_items = value.get(key)
        if isinstance(raw_items, Sequence) and not isinstance(raw_items, (str, bytes, bytearray)):
            compact_items = [str(item) for item in raw_items[:4] if str(item)]
            if compact_items:
                summary[key] = compact_items
    if isinstance(value.get("terms"), Sequence) and not isinstance(value.get("terms"), (str, bytes, bytearray)):
        term_profiles = []
        for item in value.get("terms", [])[:4]:
            if not isinstance(item, Mapping):
                continue
            profile = {
                key: item.get(key)
                for key in ("term", "piece_count", "is_single_token", "control_profile")
                if key in item and item.get(key) not in (None, "")
            }
            if profile:
                term_profiles.append(profile)
        if term_profiles:
            summary["term_profiles"] = term_profiles
    if isinstance(value.get("sampled_continuations"), Sequence) and not isinstance(
        value.get("sampled_continuations"), (str, bytes, bytearray)
    ):
        summary["sampled_continuations"] = [
            {
                "variant": item.get("variant"),
                "text": _truncate_text(item.get("text"), 60),
            }
            for item in value.get("sampled_continuations", [])[:2]
            if isinstance(item, Mapping)
        ]
    if isinstance(value.get("topk_token_diff"), Sequence) and not isinstance(value.get("topk_token_diff"), (str, bytes, bytearray)):
        summary["topk_token_diff"] = [
            {
                key: item.get(key)
                for key in ("piece", "prob_delta", "logit_delta")
                if key in item and item.get(key) not in (None, "")
            }
            for item in value.get("topk_token_diff", [])[:4]
            if isinstance(item, Mapping)
        ]
    for key in (
        "probe_family",
        "probe_phase_profile",
        "probe_label",
        "probe_score",
        "readout_probe_score",
        "constraint_probe_score",
        "trajectory_probe_score",
    ):
        if value.get(key) not in (None, ""):
            summary[key] = value.get(key)
    for key in ("positive_axes", "actionable_axes"):
        raw_items = value.get(key)
        if isinstance(raw_items, Sequence) and not isinstance(raw_items, (str, bytes, bytearray)):
            compact_items = [str(item) for item in raw_items[:4] if str(item)]
            if compact_items:
                summary[key] = compact_items
    if isinstance(value.get("probe_summary"), Mapping):
        summary["probe_summary"] = {
            key: value["probe_summary"].get(key)
            for key in (
                "probe_family",
                "probe_phase_profile",
                "label",
                "score",
                "readout_score",
                "constraint_score",
                "trajectory_score",
                "semantic_focus_term",
                "reachable_focus_term",
                "reachable_focus_rank",
                "positive_axes",
                "actionable_axes",
            )
            if key in value["probe_summary"] and value["probe_summary"].get(key) not in (None, "", [])
        }
    return summary


def _tool_result_summaries(items: Any) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    summaries: list[dict[str, Any]] = []
    for item in items:
        summary = _compact_tool_result(item)
        if summary is not None:
            summaries.append(summary)
    return summaries


def _compact_diagnostic_result(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    if value.get("diagnostic") == "source_clause_activation_patch_probe":
        summary = {key: _bounded_json(value[key], max_depth=4, max_items=16, max_string=220)
            for key in ("diagnostic", "status", "recorded_step", "structure_context_id",
                "structure_operator_id", "candidate_binding", "evidence_scope", "state_restored",
                "caps_unchanged", "error", "blocked_reason", "diagnostic_call_cost",
                "diagnostic_budget_charged", "budget_before", "budget_after", "new_measurement_count",
                "physical_replay_count", "physical_replays_upper_bound", "edited_replay_count",
                "production_apply_allowed", "certified_for_apply", "policy_candidate_ready") if key in value}
        summary["operator_rows"] = [
            {key: _bounded_json(row[key], max_depth=4, max_items=16, max_string=220)
             for key in ("candidate_fingerprint", "surface", "source_tensor_identity", "runtime_telemetry",
                 "paired_deltas", "baseline_repeat_variation", "edited_repeat_variation",
                 "metric_repeat_floors", "effect_role", "ownership_role", "realized_lift_token_id",
                 "self_delta", "cross_delta", "alignment_margin", "alignment_repeat_floor",
                 "ownership_scope", "safety_deltas", "collapse_sharpening_signal", "semantic_safety",
                 "clause_correctness", "target_readout_effect_certified", "production_apply_allowed") if key in row}
            for row in value.get("operator_rows", [])[:2]]
        return summary
    if value.get("diagnostic") == "source_clause_structure_probe":
        return {key: _bounded_json(value[key], max_depth=4, max_items=16, max_string=220)
                for key in ("diagnostic", "status", "recorded_step", "generated_tokens",
                    "active_edit_count",
                    "structure_context_id", "requested_structure_context_id", "structure_readout_rows",
                    "greedy_token_id", "greedy_piece", "readout_stage", "ordering", "evidence_scope",
                    "state_restored", "error", "blocked_reason", "diagnostic_call_cost",
                    "diagnostic_budget_charged", "budget_before", "budget_after", "new_measurement_count",
                    "physical_replay_count", "edited_replay_count", "production_apply_allowed",
                    "certified_for_apply", "policy_candidate_ready") if key in value}
    summary: dict[str, Any] = {}
    if value.get("diagnostic") == "target_entity_insertion_probe":
        summary.update({key: _bounded_json(value[key], max_depth=2, max_items=6, max_string=200)
            for key in ("recorded_step", "requested_terms", "probe_refresh_id", "probe_kind", "refresh_status",
                "evidence_scope", "diagnostic_call_cost", "diagnostic_budget_charged", "budget_before", "budget_after",
                "model_forward_count", "new_measurement_count", "physical_replay_count", "readout_cache_restored")
            if key in value})
    if value.get("diagnostic") == "entity_insertion_operator_candidate_review":
        return {key: _bounded_json(value[key], max_depth=4, max_items=8, max_string=260)
                for key in ("diagnostic", "status", "recorded_step", "focus_terms", "candidate_terms",
                    "candidate_blueprint_count", "new_candidate_blueprint_count", "review_matrix",
                    "candidate_blueprint_ids", "new_candidate_blueprint_ids", "reused_candidate_blueprint_count",
                    "review_outputs_unchanged", "candidate_novelty_scope",
                    "entity_candidate_review_input_id", "source_probe_id", "source_probe_recorded_step",
                    "source_probe_is_current_prefix", "evidence_scope", "review_reused",
                    "diagnostic_call_cost", "diagnostic_budget_charged", "diagnostic_budget_charge_reason",
                    "budget_before", "budget_after", "physical_replay_count", "new_measurement_count",
                    "next_evidence_needed", "production_apply_allowed", "certified_for_apply") if key in value}
    if value.get("diagnostic") == "candidate_action":
        compact = {key: _bounded_json(value[key], max_depth=4, max_items=24, max_string=260)
                for key in ("diagnostic", "status", "action_id", "requested_action", "executed_action",
                    "candidate_id", "current_context_id", "measurement_context_id", "blocked_reason",
                    "parent_candidate_id", "candidate_derivation", "inherits_measurement",
                    "transaction_status", "required_diagnostic_calls", "diagnostic_call_cost",
                    "confirmation_status", "confirmation_blocked_reasons", "trial_authorization_id",
                    "production_trial_allowed",
                    "requested_position",
                    "candidate_trial_handoff", "same_prefix_followup_available", "next_evidence_needed",
                    "evidence_scope", "diagnostic_budget_charged", "budget_before", "budget_after",
                    "physical_replay_count", "new_measurement_count", "cached_measurement_count",
                    "production_apply_allowed", "certified_for_apply") if key in value}
        evidence = value.get("evidence")
        if isinstance(evidence, Mapping):
            compact["evidence"] = {key: _bounded_json(evidence[key], max_depth=3, max_items=20, max_string=260)
                for key in ("measurement_context_id", "observed_at_step", "worker_step", "target_piece",
                    "measurement_position",
                    "target_piece_token_id", "source_tensor_identity", "metrics", "state_restored",
                    "no_edit_control", "repeat_control", "continuation_identical", "measurement_origin", "error", "readout_failure_details")
                if key in evidence}
        return compact
    if value.get("review_reused"):
        return {key: _bounded_json(value[key], max_depth=2, max_items=8, max_string=200)
                for key in ("diagnostic", "status", "objective_bundle_key", "review_reused",
                    "reviewed_at_step", "recorded_step", "prefix_changed_since_review", "evidence_scope",
                    "measurement_context_id", "evidence_ids", "compile_preview_blocked_reason",
                    "diagnostic_budget_charged", "budget_before", "budget_after", "new_measurement_count",
                    "physical_replay_count", "explicit_measurement_diagnostic", "measurement_choices_hint", "next_evidence_needed",
                    "production_apply_allowed", "certified_for_apply") if key in value}
    if value.get("diagnostic") == "inspect_evidence":
        return {key: _bounded_json(value[key], max_depth=4, max_items=40, max_string=260)
                for key in ("diagnostic", "status", "rows", "evidence_scope", "budget_before", "budget_after",
                            "new_measurement_count", "physical_replay_count", "cached_measurement_count",
                            "newly_visible_row_count", "new_gate_fact_count", "retry_preconditions",
                            "gate_context", "gate_context_changed", "gate_fact_scope", "executable_diagnostic_ids",
                            "missing_evidence", "production_apply_allowed") if key in value}
    matrix = value.get("target_piece_binding_seed_matrix_summary")
    if isinstance(matrix, Mapping):
        summary["target_piece_binding_seed_matrix_summary"] = {
            key: matrix[key] for key in ("status", "measurement_mode", "row_count", "dose_grid",
                "measurement_context_id", "new_measurement_count", "physical_replay_count",
                "observable_count", "state_restored", "unavailable_reason", "no_edit_max_abs_logit_delta",
                "comparison_axis", "source_direction_comparisons") if key in matrix}
    for key in ("response_promotion_readiness", "confirmation", "confirmation_scope", "blocked_reasons", "evidence_id",
                "same_prefix_followup_available", "trial_authorization_id", "production_trial_allowed"):
        if key in value:
            summary[key] = _bounded_json(value[key], max_depth=3, max_items=24, max_string=160)
    for key in (
        "diagnostic",
        "status",
        "bundle_key",
        "objective_bundle_key",
        "step_actuator_bundle_key",
        "next_evidence_needed",
        "operator_certified",
        "readout_reachable",
        "head_sensitive",
        "feature_supported",
        "certified_for_apply",
        "production_apply_allowed",
        "production_trial_allowed",
        "feature_backend",
        "top20_reachable_count",
        "near_reachable_count",
        "source_body_span_count",
        "reviewed_term_count",
        "candidate_blueprint_count",
        "entity_operator_materialization_count",
        "entity_operator_materialization_status",
        "entity_operator_deepening_reason",
        "entity_operator_deepening_next_evidence",
        "readout_deepening_review_status",
        "required_term_recall",
        "required_term_span_progress",
    ):
        if value.get(key) not in (None, "", []):
            summary[key] = value.get(key)
    if value.get("production_trial_allowed") is True:
        trial_candidate = value.get("production_trial_candidate")
        if isinstance(trial_candidate, Mapping) and isinstance(trial_candidate.get("trial_edit"), Mapping):
            summary["production_trial_candidate"] = {
                key: deepcopy(trial_candidate[key])
                for key in ("kind", "apply_kind", "operator_recipe_id", "objective_bundle_key", "trial_edit")
                if key in trial_candidate
            }
            trial_contract = value.get("production_trial_contract")
            if isinstance(trial_contract, Mapping):
                summary["production_trial_contract"] = deepcopy(trial_contract)
    focus_terms = value.get("focus_terms")
    if isinstance(focus_terms, Sequence) and not isinstance(focus_terms, (str, bytes, bytearray)):
        compact_terms = [str(item) for item in focus_terms[:6] if str(item)]
        if compact_terms:
            summary["focus_terms"] = compact_terms
    term_rows = value.get("term_readout_rows")
    if isinstance(term_rows, Sequence) and not isinstance(term_rows, (str, bytes, bytearray)):
        rows: list[dict[str, Any]] = []
        for item in term_rows[:4]:
            if not isinstance(item, Mapping):
                continue
            rows.append(
                {
                    key: item.get(key)
                    for key in (
                        "term",
                        "first_piece",
                        "rank",
                        "prob",
                        "top20_hit",
                        "span_progress",
                        "source_provenance",
                        "readout_status",
                    )
                    if item.get(key) not in (None, "", [])
                }
            )
        if rows:
            summary["term_readout_rows"] = rows
    candidate_terms = value.get("candidate_terms")
    if isinstance(candidate_terms, Sequence) and not isinstance(candidate_terms, (str, bytes, bytearray)):
        compact_candidate_terms = [str(item) for item in candidate_terms[:6] if str(item)]
        if compact_candidate_terms:
            summary["candidate_terms"] = compact_candidate_terms
    candidate_blueprints = value.get("candidate_blueprints")
    if isinstance(candidate_blueprints, Sequence) and not isinstance(candidate_blueprints, (str, bytes, bytearray)):
        compact_blueprints: list[dict[str, Any]] = []
        for item in candidate_blueprints[:4]:
            if not isinstance(item, Mapping):
                continue
            compact_blueprints.append(
                {
                    key: item.get(key)
                    for key in (
                        "kind",
                        "objective_term",
                        "first_piece",
                        "readout_status",
                        "rank",
                        "source_provenance",
                        "candidate_status",
                        "recommended_operator_families",
                        "recommended_next_diagnostic",
                    )
                    if item.get(key) not in (None, "", [])
                }
            )
        if compact_blueprints:
            summary["candidate_blueprints"] = compact_blueprints
    review_matrix = value.get("review_matrix")
    if isinstance(review_matrix, Sequence) and not isinstance(review_matrix, (str, bytes, bytearray)):
        compact_review_rows: list[dict[str, Any]] = []
        for item in review_matrix[:4]:
            if not isinstance(item, Mapping):
                continue
            compact_review_rows.append(
                {
                    key: item.get(key)
                    for key in (
                        "term",
                        "rank",
                        "readout_status",
                        "source_provenance",
                        "review_decision",
                        "blocked_by",
                        "recommended_operator_families",
                    )
                    if item.get(key) not in (None, "", [])
                }
            )
        if compact_review_rows:
            summary["entity_candidate_review_rows"] = compact_review_rows
    blocked_by = value.get("blocked_by")
    if isinstance(blocked_by, Sequence) and not isinstance(blocked_by, (str, bytes, bytearray)):
        compact_blocked = [str(item) for item in blocked_by[:4] if str(item)]
        if compact_blocked:
            summary["blocked_by"] = compact_blocked
    entity_plan = value.get("entity_operator_deepening_plan")
    if isinstance(entity_plan, Mapping):
        compact_entity_plan = {
            key: entity_plan.get(key)
            for key in (
                "kind",
                "source",
                "permission",
                "objective_bundle_key",
                "step_actuator_bundle_key",
                "intended_term",
                "recipe_family",
                "recipe_name",
                "operator_recipe_id",
                "next_action",
                "suggested_next_evidence",
                "suggested_operator_recipe_expansion_mode",
                "deepening_axis",
                "reason_code",
                "best_target_top20_threshold_gap_delta",
                "best_target_piece_logit_delta",
                "best_focus_rank_delta",
                "traits",
            )
            if entity_plan.get(key) not in (None, "", [])
        }
        if compact_entity_plan:
            summary["entity_operator_deepening_plan"] = compact_entity_plan
    canonical_followup = value.get("canonical_followup_request")
    if isinstance(canonical_followup, Mapping):
        compact_followup = {
            key: canonical_followup.get(key)
            for key in (
                "diagnostic",
                "bundle_key",
                "objective_bundle_key",
                "step_actuator_bundle_key",
                "next_evidence_needed",
                "operator_recipe_expansion_mode",
                "seed_operator_recipe_id",
                "seed_recipe_family",
                "seed_recipe_name",
                "reason",
                "permission",
            )
            if canonical_followup.get(key) not in (None, "", [])
        }
        if compact_followup:
            summary["canonical_followup_request"] = compact_followup
    readout_review = value.get("readout_deepening_review_summary")
    if isinstance(readout_review, Mapping):
        compact_review = {
            key: readout_review.get(key)
            for key in (
                "readout_deepening_review_status",
                "objective_bundle_key",
                "best_candidate_role",
                "best_recipe_id",
                "best_recipe_name",
                "best_recipe_family",
                "gap_delta",
                "target_piece_logit_delta",
                "target_mass_delta",
                "target_top20_hit_delta",
                "collapse_safe",
                "production_trial_eligible",
                "why_not_trial",
                "recommended_next_action",
                "recommended_next_evidence",
                "recommended_operator_recipe_expansion_mode",
            )
            if readout_review.get(key) not in (None, "", [])
        }
        if compact_review:
            summary["readout_deepening_review_summary"] = compact_review
    positive_plan = value.get("positive_operator_deepening_plan")
    if isinstance(positive_plan, Mapping):
        compact_positive_plan = {
            key: positive_plan.get(key)
            for key in (
                "kind",
                "source",
                "permission",
                "objective_bundle_key",
                "intended_term",
                "recipe_family",
                "recipe_name",
                "next_action",
                "suggested_next_evidence",
                "suggested_operator_recipe_expansion_mode",
                "deepening_axis",
                "reason_code",
                "curiosity_signal",
                "traits",
            )
            if positive_plan.get(key) not in (None, "", [])
        }
        if compact_positive_plan:
            summary["positive_operator_deepening_plan"] = compact_positive_plan
    evidence_rows = value.get("evidence_rows")
    if isinstance(evidence_rows, Sequence) and not isinstance(evidence_rows, (str, bytes, bytearray)):
        rows: list[dict[str, Any]] = []
        for item in evidence_rows[:4]:
            if not isinstance(item, Mapping):
                continue
            rows.append(
                {
                    key: item.get(key)
                    for key in (
                        "evidence_kind",
                        "diagnostic_family",
                        "status",
                        "actuator_class",
                        "ownership_role",
                        "effect_role",
                        "safety_role",
                        "operator_axis",
                        "recipe_family",
                        "recipe_name",
                        "actual_delta_class",
                        "target_mass_delta",
                        "target_top20_hit_delta",
                        "target_piece_logit_delta",
                        "target_top20_threshold_gap_delta",
                        "focus_rank_delta",
                        "support_score",
                        "positive_traits",
                        "blocked_by",
                    )
                    if item.get(key) not in (None, "", [])
                }
            )
        if rows:
            summary["evidence_rows"] = rows
    return summary or None


def _diagnostic_result_summaries(items: Any) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    summaries: list[dict[str, Any]] = []
    for item in items:
        summary = _compact_diagnostic_result(item)
        if summary is not None:
            summaries.append(summary)
    return summaries


def _recent_effect_summaries(items: Any) -> list[dict[str, Any]]:
    if not isinstance(items, Sequence) or isinstance(items, (str, bytes, bytearray)):
        return []
    summaries: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, Mapping):
            continue
        delta = item.get("delta", {})
        summary = {
            "edit_id": item.get("edit_id"),
            "surface_id": item.get("surface_id"),
            "verdict": item.get("verdict"),
        }
        if isinstance(delta, Mapping):
            summary["delta"] = {
                key: delta.get(key)
                for key in (
                    "entropy",
                    "top1_margin",
                    "repetition_score",
                    "partial_score",
                    "semantic_progress_score",
                    "required_term_span_progress",
                )
                if key in delta
            }
        summaries.append(summary)
    return summaries


def _observation_summary(payload: Any) -> dict[str, Any]:
    summary = {
        "packet_sha256": _stable_hash(payload),
        "payload_kind": type(payload).__name__,
    }
    if not isinstance(payload, Mapping):
        summary["payload_preview"] = _truncate_text(payload)
        return summary

    task_view = payload.get("task_view") if isinstance(payload.get("task_view"), Mapping) else {}
    worker_view = payload.get("worker_view") if isinstance(payload.get("worker_view"), Mapping) else {}
    summary.update(
        {
            "packet_view": payload.get("packet_view"),
            "source_packet_sha256": payload.get("source_packet_sha256"),
            "run_id": payload.get("run_id"),
            "episode_id": payload.get("episode_id"),
            "worker_id": payload.get("worker_id"),
            "task_id": task_view.get("task_id"),
            "step": payload.get("step"),
            "task_mode": task_view.get("mode"),
            "prompt_hash": task_view.get("prompt_hash"),
            "worker_status": worker_view.get("status"),
            "generated_tail": worker_view.get("generated_tail"),
            "telemetry": dict(payload.get("telemetry", {})) if isinstance(payload.get("telemetry"), Mapping) else {},
            "task_feedback": dict(payload.get("task_feedback", {})) if isinstance(payload.get("task_feedback"), Mapping) else {},
            "budget": dict(payload.get("budget", {})) if isinstance(payload.get("budget"), Mapping) else {},
            "surface_ids": _list_of_ids(payload.get("surface_catalog"), "surface_id"),
            "trace_ids": _list_of_ids(payload.get("trace_bank"), "trace_id"),
            "active_edit_ids": _list_of_ids(payload.get("active_edits"), "edit_id"),
            "control_phase_hint": payload.get("control_phase_hint"),
            "strategy_hints": dict(payload.get("strategy_hints", {})) if isinstance(payload.get("strategy_hints"), Mapping) else {},
            "recent_effects": _recent_effect_summaries(payload.get("recent_effects")),
            "recent_effect_summary": dict(payload.get("recent_effect_summary", {}))
            if isinstance(payload.get("recent_effect_summary"), Mapping)
            else {},
            "latest_observer_check": _compact_observer_check(payload.get("latest_observer_check")),
            "recent_observer_checks": _observer_check_summaries(payload.get("recent_observer_checks")),
            "tool_catalog": _compact_tool_catalog(payload.get("tool_catalog")),
            "latest_tool_results": _tool_result_summaries(payload.get("latest_tool_results")),
            "recent_tool_results": _tool_result_summaries(payload.get("recent_tool_results")),
            "latest_diagnostic_results": _diagnostic_result_summaries(payload.get("latest_diagnostic_results")),
            "recent_diagnostic_results": _diagnostic_result_summaries(payload.get("recent_diagnostic_results")),
            "controller_memory": _controller_memory_summaries(payload.get("controller_memory")),
        }
    )
    return summary


def _target_label(target: Any) -> str | None:
    if target is None:
        return None
    surface_id = getattr(target, "surface_id", None)
    if surface_id:
        return str(surface_id)
    kind = getattr(target, "kind", None)
    layer = getattr(target, "layer", None)
    site = getattr(target, "site", None)
    module = getattr(target, "module", None)
    suffix = module or site
    if kind and layer is not None and suffix:
        return f"{kind}:{suffix}:l{layer}"
    if kind and layer is not None:
        return f"{kind}:l{layer}"
    return None


def _decision_summary(command: ControllerCommand) -> dict[str, Any]:
    hypotheses = []
    confidences = []
    edit_ids: list[str] = []
    targets: list[str] = []
    ops: list[str] = []
    step_sizes: list[float] = []
    total_alpha = 0.0
    total_edit_cost = 0.0

    meta = getattr(command, "meta", None)
    controller_memory = None
    micro_rationale = None
    next_trigger = None
    next_action = None
    observer_check_request = None
    tool_requests = None
    objective_bundle_key = None
    step_actuator_bundle_key = None
    why_not_apply = None
    shadow_proposals = None
    if isinstance(meta, Mapping):
        if meta.get("hypothesis"):
            hypotheses.append(str(meta["hypothesis"]))
        if meta.get("confidence") is not None:
            confidences.append(float(meta["confidence"]))
        if isinstance(meta.get("controller_memory"), Mapping):
            controller_memory = dict(meta["controller_memory"])
        else:
            controller_memory = {}
        for key in (
            "noop_reason",
            "apply_block_reason",
            "surface_family_key",
            "focus_term",
            "objective_bundle_key",
            "step_actuator_bundle_key",
            "blocked_by",
            "next_evidence_needed",
            "diagnostic_request",
            "why_not_apply",
            "transfer_confidence",
            "same_family_escalation_risk",
            "finish_budget_reserved",
            "evidence_bullets",
        ):
            if meta.get(key) is not None and key not in controller_memory:
                controller_memory[key] = meta.get(key)
        if not controller_memory:
            controller_memory = None
        if meta.get("micro_rationale") is not None:
            micro_rationale = str(meta["micro_rationale"])
        if meta.get("next_trigger") is not None:
            next_trigger = str(meta["next_trigger"])
        if meta.get("next_action") is not None:
            next_action = str(meta["next_action"])
        observer_check_request = meta.get("observer_check_request")
        tool_requests = meta.get("tool_requests")
        if meta.get("objective_bundle_key") not in (None, ""):
            objective_bundle_key = str(meta["objective_bundle_key"])
        if meta.get("step_actuator_bundle_key") not in (None, ""):
            step_actuator_bundle_key = str(meta["step_actuator_bundle_key"])
        if meta.get("why_not_apply") not in (None, ""):
            why_not_apply = str(meta["why_not_apply"])
        if isinstance(meta.get("shadow_proposals"), Sequence) and not isinstance(meta.get("shadow_proposals"), (str, bytes, bytearray)):
            shadow_proposals = _compact_controller_memory({"shadow_proposals": meta.get("shadow_proposals")})
    elif meta is not None:
        if getattr(meta, "hypothesis", None):
            hypotheses.append(str(meta.hypothesis))
        if getattr(meta, "confidence", None) is not None:
            confidences.append(float(meta.confidence))

    for edit in getattr(command, "edits", ()) or ():
        edit_ids.append(edit.id)
        target_label = _target_label(edit.target)
        if target_label is not None:
            targets.append(target_label)
        op_kind = edit.op.kind
        ops.append(op_kind)
        alpha = float(getattr(edit.op, "alpha", 0.0))
        total_alpha += abs(alpha)
        step_size = edit.budget.step_size
        if step_size is not None:
            step_sizes.append(float(step_size))
        total_edit_cost += estimate_edit_cost(
            op_kind=op_kind,
            alpha=alpha,
            ttl_steps=edit.budget.ttl_steps,
            step_size=step_size,
            rank_cap=edit.budget.rank_cap,
        )

    summary = {
        "decision": command.decision,
        "hypothesis": hypotheses[0] if hypotheses else None,
        "confidence": confidences[0] if confidences else None,
        "edit_ids": edit_ids,
        "rollback_ids": list(command.rollback_ids or ()),
        "targets": targets,
        "ops": ops,
        "step_sizes": step_sizes,
        "total_alpha": total_alpha,
        "total_edit_cost": total_edit_cost,
    }
    if micro_rationale:
        summary["micro_rationale"] = micro_rationale
    compact_observer_request = _compact_observer_check_request(observer_check_request)
    if compact_observer_request is not None:
        summary["observer_check_request"] = compact_observer_request
    compact_tool_requests = _tool_request_summaries(tool_requests)
    if compact_tool_requests:
        summary["tool_requests"] = compact_tool_requests
    compact_memory = _compact_controller_memory(controller_memory)
    if compact_memory is not None:
        summary["controller_memory"] = compact_memory
        if next_trigger is None and compact_memory.get("next_trigger") is not None:
            next_trigger = str(compact_memory["next_trigger"])
        if next_action is None and compact_memory.get("next_action") is not None:
            next_action = str(compact_memory["next_action"])
    if next_trigger:
        summary["next_trigger"] = next_trigger
    if next_action:
        summary["next_action"] = next_action
    if objective_bundle_key is not None:
        summary["objective_bundle_key"] = objective_bundle_key
    if step_actuator_bundle_key is not None:
        summary["step_actuator_bundle_key"] = step_actuator_bundle_key
    if objective_bundle_key is not None or step_actuator_bundle_key is not None:
        summary["plan_mode"] = (
            "dual_layer"
            if objective_bundle_key not in (None, "")
            and step_actuator_bundle_key not in (None, "")
            and objective_bundle_key != step_actuator_bundle_key
            else "single_layer"
        )
    if why_not_apply is not None:
        summary["why_not_apply"] = why_not_apply
    if isinstance(shadow_proposals, Mapping) and shadow_proposals.get("shadow_proposals"):
        summary["shadow_proposals"] = shadow_proposals["shadow_proposals"]
    return summary


def _extract_json_object(text: str) -> str:
    stripped = str(text).strip()
    if stripped.startswith("```"):
        lines = stripped.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        stripped = "\n".join(lines).strip()
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start < 0 or end < start:
        raise ValueError("provider response does not contain a JSON object")
    return stripped[start : end + 1]


def _normalize_controller_payload(value: Any) -> Any:
    if isinstance(value, list):
        return [_normalize_controller_payload(item) for item in value]
    if not isinstance(value, dict):
        return value

    normalized = {key: _normalize_controller_payload(item) for key, item in value.items()}

    if "decision" in normalized and "version" not in normalized:
        normalized["version"] = "0.1"

    if "edit_id" in normalized and "id" not in normalized:
        normalized["id"] = normalized.pop("edit_id")

    command_like = any(key in normalized for key in ("decision", "edits", "rollback_ids"))
    meta = normalized.get("meta")
    if command_like:
        if meta is None:
            meta = {}
        if isinstance(meta, dict):
            if "controller_memory" in normalized and "controller_memory" not in meta:
                meta["controller_memory"] = normalized.pop("controller_memory")
            if "reflection_log" in normalized and "controller_memory" not in meta:
                meta["controller_memory"] = normalized.pop("reflection_log")
            if "reflection_log" in meta and "controller_memory" not in meta:
                meta["controller_memory"] = meta.pop("reflection_log")
            if "request_observer_check" in normalized and "observer_check_request" not in meta:
                meta["observer_check_request"] = normalized.pop("request_observer_check")
            if "observer_check_request" in normalized and "observer_check_request" not in meta:
                meta["observer_check_request"] = normalized.pop("observer_check_request")
            if "request_observer_check" in meta and "observer_check_request" not in meta:
                meta["observer_check_request"] = meta.pop("request_observer_check")
            if "request_tools" in normalized and "tool_requests" not in meta:
                meta["tool_requests"] = normalized.pop("request_tools")
            if "tool_requests" in normalized and "tool_requests" not in meta:
                meta["tool_requests"] = normalized.pop("tool_requests")
            if "request_tools" in meta and "tool_requests" not in meta:
                meta["tool_requests"] = meta.pop("request_tools")
            if isinstance(meta.get("tool_requests"), Mapping):
                meta["tool_requests"] = [dict(meta["tool_requests"])]
            if "request_diagnostic" in normalized and "diagnostic_request" not in meta:
                meta["diagnostic_request"] = normalized.pop("request_diagnostic")
            if "diagnostic_request" in normalized and "diagnostic_request" not in meta:
                meta["diagnostic_request"] = normalized.pop("diagnostic_request")
            if "request_diagnostic" in meta and "diagnostic_request" not in meta:
                meta["diagnostic_request"] = meta.pop("request_diagnostic")
            for source_key, target_key in (
                ("objective_bundle_key", "objective_bundle_key"),
                ("objective_bundle", "objective_bundle_key"),
                ("step_actuator_bundle_key", "step_actuator_bundle_key"),
                ("actuator_bundle_key", "step_actuator_bundle_key"),
                ("actuator_bundle", "step_actuator_bundle_key"),
                ("why_not_apply", "why_not_apply"),
                ("not_apply_reason", "why_not_apply"),
                ("shadow_proposals", "shadow_proposals"),
                ("shadow_plan", "shadow_proposals"),
            ):
                if source_key in normalized and target_key not in meta:
                    meta[target_key] = normalized.pop(source_key)
            controller_memory = meta.get("controller_memory")
            if isinstance(controller_memory, Mapping):
                for key in (
                    "noop_reason",
                    "apply_block_reason",
                    "surface_family_key",
                    "focus_term",
                    "objective_bundle_key",
                    "step_actuator_bundle_key",
                    "blocked_by",
                    "next_evidence_needed",
                    "diagnostic_request",
                    "why_not_apply",
                    "transfer_confidence",
                    "same_family_escalation_risk",
                    "finish_budget_reserved",
                    "evidence_bullets",
                ):
                    if key not in meta and controller_memory.get(key) is not None:
                        meta[key] = controller_memory.get(key)
                if "shadow_proposals" not in meta and isinstance(controller_memory.get("shadow_proposals"), Sequence) and not isinstance(
                    controller_memory.get("shadow_proposals"),
                    (str, bytes, bytearray),
                ):
                    meta["shadow_proposals"] = controller_memory.get("shadow_proposals")
            if "rationale" in normalized and "micro_rationale" not in meta:
                meta["micro_rationale"] = normalized.pop("rationale")
            if "micro_rationale" in normalized and "micro_rationale" not in meta:
                meta["micro_rationale"] = normalized.pop("micro_rationale")
            if "next_trigger" in normalized and "next_trigger" not in meta:
                meta["next_trigger"] = normalized.pop("next_trigger")
            if "next_action" in normalized and "next_action" not in meta:
                meta["next_action"] = normalized.pop("next_action")
            for key in (
                "noop_reason",
                "apply_block_reason",
                "surface_family_key",
                "focus_term",
                "objective_bundle_key",
                "step_actuator_bundle_key",
                "blocked_by",
                "next_evidence_needed",
                "diagnostic_request",
                "why_not_apply",
                "transfer_confidence",
                "same_family_escalation_risk",
                "finish_budget_reserved",
                "evidence_bullets",
            ):
                if key in normalized and key not in meta:
                    meta[key] = normalized.pop(key)
            if "shadow_proposals" in normalized and "shadow_proposals" not in meta:
                meta["shadow_proposals"] = normalized.pop("shadow_proposals")
            if meta:
                normalized["meta"] = meta

    if "surface_id" in normalized and "target" not in normalized and any(
        key in normalized for key in ("id", "source", "op", "budget", "ttl_steps")
    ):
        normalized["target"] = {"surface_id": normalized.pop("surface_id")}

    if isinstance(normalized.get("target"), str):
        normalized["target"] = {"surface_id": normalized["target"]}
    elif isinstance(normalized.get("target"), dict) and set(normalized["target"].keys()) == {"target"}:
        inner_target = normalized["target"].get("target")
        if isinstance(inner_target, dict):
            normalized["target"] = inner_target

    fn = normalized.get("fn")
    if fn in {"add", "sub", "mean"} and "args" not in normalized:
        if "a" in normalized and "b" in normalized:
            normalized["args"] = [normalized.pop("a"), normalized.pop("b")]
        elif "left" in normalized and "right" in normalized:
            normalized["args"] = [normalized.pop("left"), normalized.pop("right")]
    elif fn in {"project_parallel", "project_orthogonal"}:
        args = normalized.get("args")
        if isinstance(args, list) and len(args) >= 2:
            normalized.setdefault("arg", args[0])
            normalized.setdefault("basis", args[1])
        if "arg" not in normalized:
            for alias in ("input", "x"):
                if alias in normalized:
                    normalized["arg"] = normalized.pop(alias)
                    break
        if "basis" not in normalized:
            for alias in ("against", "reference", "direction", "onto"):
                if alias in normalized:
                    normalized["basis"] = normalized.pop(alias)
                    break

    if "ttl_steps" in normalized and "budget" not in normalized and "op" in normalized:
        normalized["budget"] = {
            "ttl_steps": normalized.pop("ttl_steps"),
            "revertible": True,
        }

    if "scope" in normalized and "tensor" in normalized:
        scope = normalized.get("scope")
        if scope in {"best_success", "last_success", "paired_baseline"}:
            normalized["scope"] = "trace"
            normalized.setdefault("trace_id", scope)
        elif scope == "running_stats":
            normalized["scope"] = "stats"

    if normalized.get("fn") == "scale" and "by" not in normalized:
        for alias in ("alpha", "factor", "weight"):
            if alias in normalized:
                normalized["by"] = normalized.pop(alias)
                break

    token = normalized.get("token")
    if isinstance(token, dict):
        mode = token.get("mode")
        if mode in {"prev", "previous"}:
            token["mode"] = "index"
            token.setdefault("value", -2)
        elif mode == "current":
            token["mode"] = "last"

    return normalized


def _normalization_delta(raw_value: Any, normalized_value: Any) -> dict[str, Any] | None:
    if not isinstance(raw_value, Mapping) or not isinstance(normalized_value, Mapping):
        return None
    raw_keys = [str(key) for key in raw_value.keys()]
    normalized_keys = [str(key) for key in normalized_value.keys()]
    raw_meta = raw_value.get("meta")
    normalized_meta = normalized_value.get("meta")
    delta: dict[str, Any] = {
        "raw_top_level_keys": raw_keys,
        "normalized_top_level_keys": normalized_keys,
    }
    if isinstance(normalized_meta, Mapping):
        normalized_meta_keys = [str(key) for key in normalized_meta.keys()]
        delta["normalized_meta_keys"] = normalized_meta_keys
        if isinstance(raw_meta, Mapping):
            raw_meta_keys = [str(key) for key in raw_meta.keys()]
            delta["raw_meta_keys"] = raw_meta_keys
            moved = [key for key in normalized_meta_keys if key not in raw_meta_keys and key in raw_keys]
            if moved:
                delta["moved_into_meta"] = moved
        else:
            moved = [key for key in normalized_meta_keys if key in raw_keys]
            if moved:
                delta["moved_into_meta"] = moved
    controller_memory = normalized_value.get("meta", {}).get("controller_memory") if isinstance(normalized_value.get("meta"), Mapping) else None
    if isinstance(controller_memory, Mapping):
        delta["normalized_controller_memory_keys"] = [str(key) for key in controller_memory.keys()]
    return delta


def _controller_output_token_budget(payload: Any, base_tokens: int) -> int:
    limit = int(base_tokens)
    if not isinstance(payload, Mapping):
        return limit
    control_phase_hint = str(payload.get("control_phase_hint", "") or "").strip().lower()
    if control_phase_hint != "readout_escape":
        return limit
    strategy_hints = payload.get("strategy_hints")
    compare_bonus = 0
    if isinstance(strategy_hints, Mapping):
        if strategy_hints.get("gate_report_challenger_bundle_key") not in (None, ""):
            compare_bonus += 64
        if strategy_hints.get("bridge_plan_available") is True:
            compare_bonus += 64
    return max(limit, min(limit + compare_bonus + 64, limit + 192))


def _controller_model_output_token_floor(model_name: str) -> int:
    model = str(model_name or "").strip().lower()
    if model.startswith("gpt-5"):
        return 1600
    if model.startswith("claude-"):
        segments = model.split("-")[1:]
        # Claude 5 family (claude-<family>-5[-...]) reasons adaptively before
        # emitting text, so a small max_tokens can be consumed entirely by
        # thinking and return an empty text body. Keep version-first names
        # such as claude-3-5-sonnet on the default budget.
        if len(segments) >= 2 and segments[0].isalpha() and segments[1] == "5":
            return 4096
    return 0


class ProviderControllerClient:
    def __init__(
        self,
        provider: ControllerProvider,
        *,
        system_prompt: str | None = None,
        prompt_asset: str = "controller_v01.txt",
        packet_view: str = "full",
        action_view: str = "legacy",
        max_output_tokens: int = 800,
        temperature: float = 0.0,
        max_attempts: int = 2,
    ) -> None:
        self.provider = provider
        if action_view not in {"legacy", "cards"}:
            raise ValueError("action_view must be 'legacy' or 'cards'")
        self.action_view = action_view
        self.system_prompt = system_prompt or load_prompt_asset(
            "controller_operations_v1.txt" if action_view == "cards"
            and prompt_asset in {"controller_v01.txt", "controller_v01_compact.txt"} else prompt_asset)
        normalized_packet_view = str(packet_view or "full").strip().lower().replace("-", "_")
        if normalized_packet_view not in _COMPACT_PACKET_VIEWS:
            raise ValueError("packet_view must be 'full' or 'compact'")
        self.packet_view = normalized_packet_view
        self.max_output_tokens = int(max_output_tokens)
        self.temperature = float(temperature)
        self.max_attempts = max(1, int(max_attempts))
        self._last_trace: dict[str, Any] | None = None

    def latest_trace(self) -> dict[str, Any] | None:
        return self._last_trace

    def invoke(self, packet: Any) -> ControllerCommand:
        raw_payload = _payload_for_provider(packet, packet_view="full")
        payload = _payload_for_provider(packet, packet_view=self.packet_view)
        if self.action_view == "cards":
            payload = operation_cards.project_payload(payload, raw_payload)
        system_prompt = self.system_prompt
        if ((raw_payload.get("strategy_hints") or {}).get("generation_control") or {}).get("clock_mode") == "explicit":
            system_prompt += "\n\n" + load_prompt_asset("controller_clock_v1.txt")
        raw_payload_chars = _serialized_char_count(raw_payload)
        provider_payload_chars = _serialized_char_count(payload)
        system_prompt_chars = len(system_prompt)
        effective_max_output_tokens = max(
            _controller_output_token_budget(payload, self.max_output_tokens),
            _controller_model_output_token_floor(self.provider.model_name),
        )
        trace: dict[str, Any] = {
            "provider": self.provider.provider_name,
            "model": self.provider.model_name,
            "max_attempts": self.max_attempts,
            "effective_max_output_tokens": effective_max_output_tokens,
            "packet_view": self.packet_view,
            "action_view": self.action_view,
            "operation_menu": payload.get("operation_menu") if isinstance(payload, Mapping) else None,
            "raw_payload_char_count": raw_payload_chars,
            "provider_payload_char_count": provider_payload_chars,
            "payload_reduction_ratio": round(provider_payload_chars / raw_payload_chars, 6)
            if raw_payload_chars > 0
            else None,
            "system_prompt_char_count": system_prompt_chars,
            "rough_input_token_estimate": _rough_token_estimate_from_chars(
                system_prompt_chars + provider_payload_chars
            ),
            "system_prompt_sha256": _stable_hash(system_prompt),
            "observation": _observation_summary(payload),
            "attempts": [],
            "decision": None,
            "success": False,
        }
        self._last_trace = trace
        retry_note: str | None = None
        last_error: Exception | None = None
        for attempt_index in range(1, self.max_attempts + 1):
            request = ControllerProviderRequest(
                system_prompt=system_prompt,
                payload=payload,
                max_output_tokens=effective_max_output_tokens,
                temperature=self.temperature,
                expect_json=True,
                retry_note=retry_note,
            )
            started = perf_counter()
            response = self.provider.complete(request)
            latency_ms = (perf_counter() - started) * 1000.0
            effective_system_prompt_chars = len(request.effective_system_prompt())
            attempt_trace: dict[str, Any] = {
                "attempt": attempt_index,
                "latency_ms": round(latency_ms, 3),
                "request": {
                    "expect_json": True,
                    "max_output_tokens": effective_max_output_tokens,
                    "temperature": self.temperature,
                    "retry_note": retry_note,
                    "packet_view": self.packet_view,
                    "payload_char_count": provider_payload_chars,
                    "raw_payload_char_count": raw_payload_chars,
                    "system_prompt_char_count": system_prompt_chars,
                    "effective_system_prompt_char_count": effective_system_prompt_chars,
                    "rough_input_token_estimate": _rough_token_estimate_from_chars(
                        effective_system_prompt_chars + provider_payload_chars
                    ),
                },
                "provider": response.provider,
                "model": response.model,
                "usage": _json_ready(dict(response.usage)),
                "response_metadata": _json_ready(dict(getattr(response, "metadata", {}) or {})),
                "response_char_count": len(str(response.text)),
                "rough_response_token_estimate": _rough_token_estimate_from_chars(len(str(response.text))),
                "response_sha256": _stable_hash(response.text),
                "response_text": str(response.text),
            }
            try:
                raw_json_object = json.loads(_extract_json_object(response.text))
                parsed = _normalize_controller_payload(raw_json_object)
                attempt_trace["raw_json_object"] = _json_ready(raw_json_object)
                attempt_trace["normalized_payload"] = _json_ready(parsed)
                attempt_trace["normalization_delta"] = _json_ready(_normalization_delta(raw_json_object, parsed))
                command = parse_controller_command(parsed)
                prefix_control.validate_clock_command(raw_payload, parsed)
                if self.action_view == "cards":
                    operation_cards.validate_card_command(raw_payload, parsed)
                elif "operation_id" in (parsed.get("meta") or {}):
                    operation_cards.resolve(raw_payload, command)
                attempt_trace["parse_ok"] = True
                trace["attempts"].append(attempt_trace)
                trace["decision"] = _decision_summary(command)
                trace["success"] = True
                trace["attempt_count"] = attempt_index
                self._last_trace = trace
                return command
            except Exception as exc:
                attempt_trace["parse_ok"] = False
                attempt_trace["parse_error"] = str(exc)
                trace["attempts"].append(attempt_trace)
                self._last_trace = trace
                last_error = exc
                retry_note = f"Previous reply was invalid. Return only one compact JSON object matching ControllerCommand. Error: {exc}"
                if self.action_view == "cards" and str(exc) == "unknown_or_stale_operation_id":
                    available = [
                        {key: card.get(key) for key in ("operation_id", "diagnostic", "action")}
                        for card in payload["operation_menu"]["cards"] if card.get("available")
                    ]
                    retry_note += (
                        " Copy an operation_id exactly from the unchanged current menu, or choose no diagnostic."
                        " IDs are not corrected or substituted automatically. Available IDs (first 32, original order): "
                        + json.dumps(available[:32], separators=(",", ":"))
                    )
        trace["error"] = str(last_error) if last_error is not None else "unknown provider error"
        self._last_trace = trace
        raise ValueError(f"provider '{self.provider.provider_name}' failed to return valid ControllerCommand JSON") from last_error


class ProviderPromptHintController:
    def __init__(
        self,
        provider: ControllerProvider,
        *,
        system_prompt: str | None = None,
        prompt_asset: str = "prompt_hint_v01.txt",
        max_output_tokens: int = 160,
        temperature: float = 0.0,
    ) -> None:
        self.provider = provider
        self.system_prompt = system_prompt or load_prompt_asset(prompt_asset)
        self.max_output_tokens = int(max_output_tokens)
        self.temperature = float(temperature)
        self._last_trace: dict[str, Any] | None = None

    def latest_trace(self) -> dict[str, Any] | None:
        return self._last_trace

    def invoke(self, packet: Any) -> str | None:
        payload = _payload_for_provider(packet)
        request = ControllerProviderRequest(
            system_prompt=self.system_prompt,
            payload=payload,
            max_output_tokens=self.max_output_tokens,
            temperature=self.temperature,
            expect_json=False,
        )
        started = perf_counter()
        response = self.provider.complete(request)
        latency_ms = (perf_counter() - started) * 1000.0
        text = str(response.text).strip()
        if not text:
            self._last_trace = {
                "provider": response.provider,
                "model": response.model,
                "system_prompt_sha256": _stable_hash(self.system_prompt),
                "observation": _observation_summary(payload),
                "attempts": [
                    {
                        "attempt": 1,
                        "latency_ms": round(latency_ms, 3),
                        "request": {
                            "expect_json": False,
                            "max_output_tokens": self.max_output_tokens,
                            "temperature": self.temperature,
                            "retry_note": None,
                        },
                        "provider": response.provider,
                        "model": response.model,
                        "usage": _json_ready(dict(response.usage)),
                        "response_metadata": _json_ready(dict(getattr(response, "metadata", {}) or {})),
                        "response_sha256": _stable_hash(response.text),
                        "response_text": str(response.text),
                        "parse_ok": True,
                    }
                ],
                "decision": {"advice": None, "advice_length": 0},
                "success": True,
                "attempt_count": 1,
            }
            return None
        if text.startswith("```"):
            lines = text.splitlines()
            if lines and lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip().startswith("```"):
                lines = lines[:-1]
            text = "\n".join(lines).strip()
        self._last_trace = {
            "provider": response.provider,
            "model": response.model,
            "system_prompt_sha256": _stable_hash(self.system_prompt),
            "observation": _observation_summary(payload),
            "attempts": [
                {
                    "attempt": 1,
                    "latency_ms": round(latency_ms, 3),
                    "request": {
                        "expect_json": False,
                        "max_output_tokens": self.max_output_tokens,
                        "temperature": self.temperature,
                        "retry_note": None,
                    },
                    "provider": response.provider,
                    "model": response.model,
                    "usage": _json_ready(dict(response.usage)),
                    "response_metadata": _json_ready(dict(getattr(response, "metadata", {}) or {})),
                    "response_sha256": _stable_hash(response.text),
                    "response_text": str(response.text),
                    "parse_ok": True,
                }
            ],
            "decision": {"advice": text, "advice_length": len(text)},
            "success": True,
            "attempt_count": 1,
        }
        return text
