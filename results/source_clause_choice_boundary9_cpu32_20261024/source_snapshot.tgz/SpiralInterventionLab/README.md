# SpiralInterventionLab

This package is the minimal experiment scaffold for:

"Can a controller LLM improve a smaller worker model only through bounded internal interventions?"

The code is still intentionally bounded, but it has moved beyond the first scaffold.
The current focus is readout-escape control: detecting answer-boundary collapse,
compiling executable candidates, and separating candidate selection from operator
certification.

- `schema.py`
  Parses the JSON DSL and controller observation packet into typed dataclasses.
- `policy.py`
  Enforces the harness: bounded ops, bounded alpha, rollback-only surfaces, trace compatibility.
- `compiler.py`
  Compiles the DSL into executable hooks or overlays.
- `codecs.py`
  Keeps text/token conversion swappable so the runner does not depend on one tokenizer path.
- `adapter.py`
  Defines the adapter interface and a HookedTransformer-oriented binding layer.
- `rank1_bridge.py`
  Absorbs `u/v` length mismatches before parameter patches land on a concrete weight tensor.
- `tlens_runtime.py`
  Manages live TransformerLens hook registrations, cache snapshots, traces, TTL, and rollback.
- `overlays.py`
  Holds temporary runtime-only overlays such as rank-1 linear patches.
- `effects.py`
  Computes compact edit verdicts from before/after telemetry.
- `trace_recorder.py`
  Records step-aligned selected-surface traces and exposes aligned replay for paired baselines.
- `worker.py`
  Runs a token-by-token worker loop, builds controller packets, tracks budgets, and records recent edit effects.
- `sidecar.py`
  Defines offline readout analyzer captures and bounded feature-emitter hints.
- `baselines.py`
  Provides the minimal B0/B1/C1 execution paths plus an activation-only C1 harness.
- `loop.py`
  Runs the episode loop with structured logging, controller selection reports, and diagnostic/noop explanations.
- `backends/`
  Holds capability-based local worker backends plus a generic worker runtime for B0/B1 on non-mechanistic stacks.
- `controllers/`
  Holds black-box API provider adapters for controller models.
- `bridge/`
  Loads prompt assets and converts provider text into validated controller commands or prompt hints.
- `examples/`
  Holds runnable end-to-end examples. The first one is `digit_transform_e2e.py`.
- `tasks/`
  Holds real, seed-reproducible `TaskEnv` implementations. The first one is `SpiralDigitTransformEnv`.

## Current cut

This is a scaffold, not a full benchmark suite yet.

- The controller DSL supports `resid_add`, `kv_mix`, and `rank1_patch`.
- The controller DSL also supports diagnostic `activation_patch` blend edits on
  activation surfaces. These are executable hooks, not disguised `resid_add`
  probes, and production permission remains gated separately.
- The runtime assumes edits are reversible and TTL-scoped to an episode.
- The default policy follows the v0 constraints: one edit per step, small alpha budget, no free-form answer channel.
- The HookedTransformer path now has a real runtime state for cache reads and hook lifecycle management.
- Paired traces can now be recorded step-by-step and replayed at the controller's current step instead of collapsing to a final-cache snapshot.
- Rank-1 parameter patches now pass through a bridge layer: exact-size match first, parameter-aware lift second, deterministic resample last. This makes `mlp_out` and other non-square-ish cases much more portable without exposing raw tensor writes.
- The worker runtime can now step autoregressively, build the observation packet schema directly, and track edit spend / recent effects across an episode.
- The baseline layer now has concrete runners for B0, B1, and C1. B1 appends bounded text hints into prompt context, while C1 locks the harness down to `resid_add` only.
- The package now includes a first real task environment: `SpiralDigitTransformEnv`, a seeded exact-match rewrite task with `task_feedback()` and `stop_checker()` helpers for worker wiring.
- There is now a capability-based local backend layer. `HFTransformersBackend` is the main local path, while `MLXLMBackend` and `LlamaCppBackend` start as shallow comparison backends.
- There is now a black-box controller layer plus bridge clients, so OpenAI / Anthropic / Mistral / Google responses can be normalized into the same `ControllerCommand` path used by the compiler.
- There is now a first end-to-end example runner that wires a black-box controller provider into a HookedTransformer worker on the digit-transform task.
- That runner now executes `B1` by default and can load the worker from a fully local Hugging Face directory with `local_files_only` semantics.
- The readout-escape path now has provenance-aware candidate compilation, source-body-first priority, same-term/family dedupe, and bundle metadata.
- Operator replay can classify recipes as `self_actuator`, `bridge_actuator`, `cross_bound`, `dead_actuator`, `collapse_sharpener`, or `noisy_or_harmful`.
- Bridge eval and extra diagnostics now feed a `diagnostic_evidence_ledger` and `bundle_diagnostic_status` table for each frontier bundle.
- Diagnostic-only tools include readout-local first-piece probes, attention readout-carrier probes with shadow-actuator counterfactuals, and a scaffolded `sae_scaffold` readout analyzer backend.
- The controller can now request bounded diagnostics through `meta.diagnostic_request`; the runtime returns `latest_diagnostic_results` / `recent_diagnostic_results` on later packets.
- These diagnostics are evidence for the controller, not production apply permission. The controller remains the policy owner.
- Activation-patch diagnostics now include local step-size sweeps and forced
  canonical cap-response curves. A diagnostic-only cap release can measure
  `step_size=0.16/0.20` without widening production apply authority.

## Current bottleneck

The system can now see more than it can safely touch.

Recent direct-scan readout-escape runs show a plausible `budget` frontier where:

- readout-local probes can lift the target signal
- attention head ablation is non-dead as a diagnostic signal
- SAE-style feature hints can support the bundle
- focused operator replay still classifies the available runtime recipes as dead or unsafe

That means the main bottleneck is no longer candidate visibility alone. It is
finding a certified self or bridge actuator that can move the answer boundary
without handing policy ownership to the operator/certification layer.

The latest direct-scan diagnostic-request replay confirms that this loop is now
wired end to end:

- controller requests `operator_diagnostic_replay`
- runtime returns one diagnostic result
- the result is visible on later controller observations
- `diagnostic_operator_supported` records diagnostic support separately from production permission
- `policy_candidate_ready` records whether a quarantine candidate reached policy review
- `production_apply_allowed` remains false
- `activation_patch_production_denial_dossier` records the five reasons
  production can remain closed after diagnostic support:
  `ownership_not_live_certified`, `safety_not_certified`,
  `context_equivalence_missing`, `rollback_contract_missing`, and
  `effect_size_too_small`
- `activation_patch_production_shadow_replay` can then emit an
  `activation_patch_production_shadow_dossier` for same-packet shadow checks;
  this may clear denial axes but still does not grant production apply
- `activation_patch_production_trial_gate_review` can review a cleared shadow
  dossier and emit a bounded `activation_patch_production_trial_dossier`; this
  is trial-only evidence with `ttl_steps=1`, rollback/norm limits, and a separate
  trial budget, not production apply permission
- a controller may spend that contract as `apply_kind="production_trial"` once;
  the trial edit survives one generated token, records a `controller_effect`,
  and still keeps `production_apply_allowed=false`
- bounded trial effects are summarized in `production_trial_outcome_ledger`;
  harmful/regressing/collapse-sharpener outcomes veto the tested recipe family,
  neutral outcomes request alternate/confirm evidence, and helpful outcomes
  require confirmation replay before production policy review. Ledger rows also
  carry `promotion_ladder_stage` for the next alternate-candidate pass
- after a harmful/regressing production trial, the diagnostic-request replay can
  now request `compare_extra_operator_diagnostics`, extract an alternate
  activation-patch recipe that is not the failed `operator_recipe_id`, and pass
  that alternate shadow through `activation_patch_candidate_review` and
  `activation_patch_runtime_support_probe`
- the frontier is still blocked by `dead_actuator / all_dead_actuator`

So the current win is not task-score improvement yet. It is cleaner agency:
the controller can ask for better evidence without gaining extra apply power.

In local GPT-2 direct-scan replay, the current ladder reaches:

```text
activation_patch_candidate_review
-> activation_patch_runtime_support_probe
-> activation_patch_promotion_gate_review
-> activation_patch_production_shadow_replay
-> activation_patch_production_trial_gate_review
-> compare_extra_operator_diagnostics
-> activation_patch_candidate_review
-> activation_patch_runtime_support_probe
```

The second candidate/replay pair is the important new step: it preserves the
trial failure as a veto and carries a lower-alpha alternate recipe forward
instead of quietly restarting the stale failed recipe.

The next useful observation is whether that alternate recipe can complete the
same ladder as the failed trial: promotion review, production shadow replay,
trial gate review, and outcome comparison. If it cannot, the failure should stay
recipe-local rather than becoming a broad family ban.

The newest local GPT-2 replay completes that observation. With an explicitly
widened replay-only trial budget, `a0.050` keeps its recipe identity through
promotion review, production shadow replay, trial gate review, and a bounded
production trial. It still returns `trial_effect_class="regressing"` /
`verdict="harmful"`. The result is a negative operator-quality finding, not a
control-plane failure: lower alpha alone does not make this activation-patch
recipe safe, but the ladder can now compare failed recipes without stale
candidate identity.

The follow-up recipe-family shift is also negative. The alternate selector can
now prefer a different family, choosing
`resid_pre|source_span_to_last|blend|a0.050` instead of another failed-family
`resid_post` variant. That candidate also reaches bounded trial and also returns
`regressing/harmful`, which points suspicion at the current
`source_span_to_last|blend` recipe rather than only at alpha or `resid_post`.

The next pass changes source localization instead of only site or alpha.
Activation-patch diagnostics now carry a compact candidate pool so
`source_term_token_to_last` and `source_centered_pm1_to_last` are not lost behind
truncated evidence rows. A local GPT-2 replay then moves the initial ladder to
`resid_pre|source_term_token_to_last|blend|a0.050`; that bounded trial is still
`regressing/harmful`, but the negative result is now recipe-local and comparable.

The follow-up source-local contrastive pass now preserves `contrast_mode`,
`contrast_scale`, and `stealer_term` through the diagnostic ledger. In a local
GPT-2 replay, the first bounded trial still regresses on
`source_term_token_to_last`, but the post-trial alternate selector switches to
`resid_pre|source_centered_pm1_minus_stealer_l025_to_last|blend|a0.050`
(`self_delta=5.057`, `alignment_margin=3.992`). This is still not production
permission; it is a cleaner controller-owned recipe ladder after a harmful
trial.

That ladder now has a real second-trial budget rather than a replay-only
budget widening. A local GPT-2 direct-scan replay spends the first bounded trial
as `production_trial_budget_class="primary"` on
`source_term_token_to_last`, observes `regressing/harmful`, then spends one
separate `production_trial_budget_class="alternate_followup"` trial on
`source_centered_pm1_minus_stealer_l025_to_last`. The follow-up effect is
`trial_effect_class="neutral"` / `signal_profile="flat"`, with production apply
still closed. This is not a solved actuator, but it proves the controller can
run a recipe-local post-harmful alternate trial without treating the alternate
as production permission.

The next activation-patch pass promotes the operator from review language to
runtime evidence. Blend-mode `activation_patch` edits can now be materialized,
compiled, replayed, and summarized as their own op kind. A forced canonical
cap-response curve measured `mlp_out L11 source_term_token` at `step_size=0.16`
and `0.20`, plus `resid_pre L11 source_term_token` at `0.16`. In the latest
GPT-2 constrained-rewrite live run, all three points were `dead_actuator` with
no target mass/top-20 lift and no collapse. That weakens the hypothesis that
the earlier failure was only a surface-cap artifact; this canonical source-term
blend appears executable but not sufficient as a target actuator on that live
state.

For local larger-worker checks, provide the local Hugging Face export on the CLI
with `worker_model_path` / `--worker-model-path`. Keep clone-specific model
directories outside the repo; for example, set `SPIRAL_WORKER_MODEL_PATH` in your
shell and pass it through the CLI instead of hardcoding an absolute path.

## Ownership rule

The package follows a strict control split:

- controller: policy owner for `apply / noop / rollback / diagnostic request`
- analyzer: bounded evidence emitter
- gate: evaluation/report layer
- operator replay: certification evidence, not a shadow controller
- runtime guardrails: mechanical safety invariants such as budget, shape, dtype, TTL, and compile validity

If an operator diagnostic can explain that a recipe is dead or collapse-sharpening,
that is useful evidence. It still should not silently decide the episode.

## Near-term direction

The next phase keeps the control contract stable while improving the evidence:

- keep operator certification under controller ownership
- freeze selector/gate behavior unless a log contract is broken
- search for a `budget` self-actuator recipe
- use failed production trials as recipe-specific vetoes and alternate-candidate
  search triggers
- carry alternate activation-patch candidates through candidate review and
  runtime support before considering any further trial
- compare lower-alpha alternates against the failed trial outcome before
  treating diagnostic support as policy readiness
- continue ownership-first recipe sweeps
- promote bridge plans only once a safe bridge actuator is certified
- expand SAE-style analysis only as a feature emitter, not as a second policy owner

## Smoke path

Run the targeted unit tests:

```bash
python3 -m pytest -q SpiralInterventionLab/tests
```

Or with stdlib only:

```bash
python3 -m unittest discover -s SpiralInterventionLab/tests -q
```
