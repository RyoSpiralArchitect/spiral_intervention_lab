# Readout Escape Research Observations

Status date: 2026-06-28

This note summarizes the current research state of the readout-escape line. It is intentionally about observations and interpretation, not just implementation history.

## Core Question

Can a controller improve a worker model through bounded internal interventions while preserving the worker as the actor?

For the current phase, that question has narrowed:

> Can the system find a bounded, auditable operator that improves first-token answer readout, and can the resulting lift stay owned by the intended bundle?

The latest experiments are mostly on GPT-2. They should be read as measurement-system development, not as a claim that a specific GPT-2 recipe will transfer to larger models.

## Current Architecture Contract

The project is converging on a strict control split:

| Component | Role | Not allowed to do |
| --- | --- | --- |
| Controller | Own policy, select actions, request diagnostics, decide noop/apply/trial | Delegate final policy to helpers |
| Analyzer / sidecar | Emit bounded evidence and feature hints | Override, promote, veto, or select |
| Gate | Evaluate controller-provided rules and expose reasons | Become a hidden selector |
| Operator replay | Produce certification evidence | Grant production apply by itself |
| Runtime guardrail | Enforce physical invariants: budget, dtype, shape, TTL, compile validity | Make semantic policy choices |

The practical rule is:

> If an action changes the worker, the controller log must be able to explain why in structured fields without relying on helper mystique.

## What Is No Longer the Main Bottleneck

The system is no longer primarily blocked on seeing the frontier.

Recent direct-scan readout-escape packets can expose a plausible `budget` frontier with:

- source-body provenance
- reachable/readout-local signals
- attention-head sensitivity
- feature support from the readout analyzer path
- operator diagnostic rows
- per-bundle diagnostic status

This means the stack can now often say:

- what term is relevant
- where it appears in the source
- which diagnostic families are non-dead
- why a candidate is still not production-ready

That is real progress. Earlier failures mixed visibility, candidate generation, and unsafe application into one foggy failure mode. They are now separated.

## Main Current Bottleneck

The bottleneck is operator quality at the answer boundary.

More precisely:

1. The selector can nominate plausible challengers.
2. The diagnostics can find support for those challengers.
3. But the available runtime operators often fail to make the intended bundle win.
4. Some operators move the distribution while still moving it in the wrong way.

The important distinction is now:

| Question | Current answer |
| --- | --- |
| Can the system see `budget`? | Often yes |
| Can it nominate `budget`? | Often yes |
| Can it compile a bounded candidate? | Often yes |
| Can it certify a safe self-actuator? | Usually no |
| Can it avoid applying unsafe candidates? | Increasingly yes |

## Ownership Findings

A major observation is that "the logits moved" is not enough.

Ownership-aware replay distinguishes:

- `self_actuator`: intended bundle receives the lift
- `bridge_actuator`: another bundle can act as a useful bridge for the objective
- `cross_bound`: some lift exists, but another bundle steals more of it
- `dead_actuator`: no meaningful movement
- `collapse_sharpener`: intervention sharpens a bad basin
- `noisy_or_harmful`: movement is not interpretable as safe progress

This has changed the research target. The goal is not raw activation movement; it is target-owned, phase-appropriate movement.

## Production Trial Ladder

The current activation-patch ladder is:

```text
activation_patch_candidate_review
-> activation_patch_runtime_support_probe
-> activation_patch_promotion_gate_review
-> activation_patch_production_shadow_replay
-> activation_patch_production_trial_gate_review
-> production_trial
-> production_trial_outcome_ledger
-> alternate evidence / confirmation / veto
```

The important control invariant:

`production_trial` is not production apply.

It has:

- `ttl_steps=1`
- explicit rollback/norm limits
- separate budget accounting
- `production_apply_allowed=false`
- `certified_for_apply=false`
- ledgered outcome evidence

This lets the controller test one bounded step without turning a diagnostic into a general permission slip.

## GPT-2 Observation: Follow-Up Trial Ladder

The recent direct-scan replay established a two-stage trial comparison.

### Primary Trial

Recipe:

```text
readout_escape|activation_patch|resid_pre|L6|source_term_token_to_last|blend|a0.050
```

Outcome:

```text
production_trial_budget_class = primary
trial_effect_class = regressing
verdict = harmful
signal_profile = regressing
source_localization = source_term_token
contrast_mode = none
```

Interpretation:

The source-local term-token recipe is not safe as a first bounded trial. It still moves the worker toward a bad basin rather than task progress.

### Follow-Up Trial

Recipe:

```text
readout_escape|activation_patch|resid_pre|L6|source_centered_pm1_minus_stealer_l025_to_last|blend|a0.050
```

Outcome:

```text
production_trial_budget_class = alternate_followup
production_trial_followup_allowed = true
trial_effect_class = neutral
verdict = neutral
signal_profile = flat
source_localization = source_centered_pm1_minus_stealer_l025
contrast_mode = minus_stealer
stealer_term = send
```

Interpretation:

This is not task success. But it is a meaningful negative-to-neutral shift:

- the primary source-local recipe regressed
- the contrastive follow-up did not immediately regress
- the follow-up used a separate trial budget, not a widened primary budget
- production apply remained closed

That makes the comparison cleaner. The system can now say:

> The first source-local actuator was harmful. A contrastive source-local alternate was bounded and neutral. Continue searching around contrastive/source-centered recipes, but do not treat this as production permission.

## Why This Matters

The latest win is not better task output. It is better research hygiene.

Before this split, a failed trial could easily cause one of three bad interpretations:

- "the controller should try harder"
- "the whole surface family is bad"
- "the helper should get more authority"

The current logs support a better interpretation:

- a specific recipe was harmful
- the controller requested alternate evidence
- the alternate recipe was reviewed, shadowed, gated, and trialed
- the alternate was neutral, not certified
- no production permission was granted

That is a clean measurement loop.

## Working Hypotheses

### 1. Visibility Is Ahead Of Actuation

The system can gather more evidence than it can safely execute. This is healthy as long as evidence does not become hidden policy.

### 2. Broad Span Means Are Too Shared-Context Heavy

`source_span_mean` tends to carry too much shared sentence context. It can move the distribution without producing target-owned lift.

Source-local and contrastive variants are more promising because they try to preserve carrier structure while reducing stealer overlap.

### 3. Contrastive Recipes Are Not Dead

The contrastive follow-up moving from harmful/regressing to neutral/flat suggests that subtracting a stealer direction can reduce collapse risk. It does not yet prove target lift.

### 4. Attention Head Ablation Is Diagnostic First

Attention diagnostics can show rank/readout carrier sensitivity, but the current evidence does not justify treating attention ablation as a production actuator.

### 5. SAE / Readout Analyzer Belongs On The Evidence Plane

SAE-style analysis is promising as a feature-emitter backend. It should stay on the analyzer side of the constitution:

- emit feature hints
- expose support and risk
- improve the controller's map
- avoid becoming a second generator or selector

## What Not To Claim Yet

Do not claim:

- GPT-2 recipes will transfer unchanged to larger models
- activation patch is currently a solved actuator
- neutral follow-up is success
- SAE-sidecar evidence is production certification
- attention head sensitivity means attention editing is safe
- the controller should get broader apply authority

The current claim is narrower:

> The measurement and control-plane contracts can now distinguish visibility, nomination, diagnostic support, bounded trial, harmful effect, and neutral alternate follow-up without collapsing those into production apply.

## Current Best Research Reading

The project has moved from "can we see anything?" to:

> Can a rank/readout carrier be converted into a target-owned, safe runtime actuator?

The latest neutral follow-up is encouraging because it shows that recipe structure matters. It suggests there may be a gradient from:

```text
harmful span/term patch
-> neutral contrastive source-local patch
-> maybe target-lifting contrastive/source-centered patch
```

But the last arrow is not yet established.

## June 2026 Update: Gap-Only Carriers And Family Shift

The newest live runs sharpen the bottleneck again. The controller can now move
through this diagnostic sequence under the compact prompt:

```text
target_entity_insertion_probe
-> entity_insertion_operator_candidate_review
-> operator_diagnostic_replay
-> readout_steering_deepening
-> readout_gap_confirmation_or_variant_sweep
-> objective_rotation_pipeline
-> readout_steering_deepening on a rotated objective
-> carrier_to_actuator_conversion_sweep
```

The important change is not task success. It is routing discipline.

Earlier runs spent the final diagnostic slot confirming a second gap-only
objective, then discovered too late that `carrier_to_actuator_conversion_sweep`
was the next needed measurement. The current router now switches after:

```text
one confirmed_gap_only_no_target_lift objective
+ one additional gap_closer_candidate
```

That saves one diagnostic call and lets the conversion sweep run before the
episode closes.

### Observed Local Run

In the latest GPT-5.5-controller / local GPT-2 compact run, the stack reached:

```text
budget readout_steering_deepening
-> budget gap confirmation
-> objective rotation
-> Mira readout_steering_deepening
-> carrier_to_actuator_conversion_sweep
```

The conversion sweep produced four variants and returned:

```text
best_candidate_role = carrier_only_no_target_actuator
target_mass_delta ~= 0.000003
target_top20_hit_delta = 0
production_trial_eligible = false
recommended_next_action = request_non_kv_operator_search
recommended_next_evidence = operator_family_shift_after_gap_carrier_conversion_failed
```

This is a better negative result than the previous budget-exhausted run. The
system no longer merely says "conversion would have been useful if budget
remained." It actually runs the conversion sweep and observes that the readout
steering family is still only a carrier, not a target actuator.

### Interpretation

The current readout-steering family can repeatedly produce small gap movement:

```text
target_top20_threshold_gap_delta < 0
target_mass_delta ~= tiny positive
target_top20_hit_delta = 0
```

That pattern is now stable enough to name:

```text
gap_closer_candidate != target_actuator_candidate
carrier_to_actuator_conversion_failed != no evidence
```

The model is not blind to the target. The problem is that the available
readout-steering primitive is not strong or geometrically direct enough to turn
visibility into answer-boundary target mass/top-20 lift.

### New Router State

The newest runtime state is:

```json
{
  "operator_family_shift_status": "needed_after_gap_carrier_conversion_failed",
  "operator_family_shift_reason": "conversion variants were carrier-only with no target mass/top20 lift",
  "recommended_next_action": "request_non_kv_operator_search",
  "production_apply_allowed": false
}
```

The result also carries diagnostic-only `operator_family_shift_preview_rows`:

- `resid_readout_direction_patch`
- `activation_patch_source_term_token`
- `anti_attractor_suppression_patch`
- `attention_route_carrier_probe`

These rows are not candidate applications. They are scaffolds for the next
measurement axis. The controller can request them through
`operator_family_shift_canonical_request`, but they do not grant production
apply permission.

### Updated Research Reading

The project has now moved from:

```text
can we see a frontier?
```

to:

```text
can a gap/rank carrier be converted into target-owned readout lift?
```

and now to:

```text
if readout steering cannot do that conversion, which non-KV operator family can?
```

This is a narrower and more useful failure mode. The current evidence suggests:

- term rotation is useful, but should not endlessly re-confirm the same
  gap-only pattern
- readout steering can find the edge of the target basin
- current readout-steering conversion variants still fail to create target
  mass/top-20 lift
- the next experimental axis should shift operator family, not keep rotating
  terms or scaling the same readout direction

### What This Does Not Claim

This update still does not claim that the task is solved, that GPT-2 recipes
transfer, or that non-KV preview rows are safe actuators.

The current claim is:

> The controller/runtime loop can now distinguish confirmed gap-only visibility,
> rotated objective visibility, failed carrier-to-actuator conversion, and the
> need for a bounded non-KV operator-family shift without turning any of those
> diagnostic states into production apply permission.

## Latest GPT-2 Observation: Rank Carrier Split

The newest direct-scan replay sharpens that last arrow.

The previous activation-patch diagnostics could label a recipe as a
`self_actuator` when it produced large ownership/rank movement:

```text
self_delta > 0
alignment_margin >= 0
focus_rank_delta > 0
```

That was too coarse. A recipe can move the intended bundle's rank without
moving the target token mass or creating a top-20 target hit. In the current
readout-escape setting, that is not yet a safe actuator.

The runtime now separates:

| Class | Meaning |
| --- | --- |
| `self_target_actuator` | Intended bundle owns lift and target mass/top20 improves |
| `self_rank_carrier` | Intended bundle owns rank/readout movement, but target mass/top20 does not improve |
| `wrong_direction` | Another bundle receives more useful lift |
| `collapse_sharpener` | Intervention sharpens a bad/repetitive basin |
| `dead` | No meaningful movement |

This split changed the live replay behavior. The earlier ladder could promote a
rank-moving activation patch into a bounded production trial; the latest ladder
blocks that path and requests more evidence instead.

Observed diagnostic sequence in local GPT-2 direct-scan replay:

```text
activation_patch_candidate_review
-> compare_extra_operator_diagnostics
-> cross_bundle_bridge_search
-> compare_extra_operator_diagnostics(post_bridge_exhaustion)
```

The important part is what did not happen:

```text
no production_trial
no production apply
no repeat of the same compare loop
```

The post-bridge expansion produced:

```json
{
  "status": "rank_carrier_family_found",
  "failure_mode_counts": {
    "self_rank_carrier": 3,
    "wrong_direction": 9
  },
  "best_target_actuator_recipe_family": null,
  "best_rank_carrier_recipe_family": "resid_pre|source_term_token|blend",
  "recommended_next_family": "convert_rank_carrier_to_target:resid_pre|source_term_token|blend"
}
```

Interpretation:

- `budget` is no longer merely invisible.
- Some recipes can move `budget` in rank/readout space.
- Those recipes still do not lift `budget` as a first-token target.
- Many expanded recipes are still stolen by the neighboring `send` bundle.
- The next operator problem is conversion, not broader controller authority.

This is a useful negative result. The system can now say:

> I found a rank/readout carrier for the objective, but not a target actuator.
> Production trial remains closed. Search for a recipe that converts the carrier
> into target mass/top20 lift.

That is a much better failure mode than either applying the carrier directly or
calling the entire family dead.

## Near-Term Experimental Plan

Recommended next experiments:

1. Convert the best rank carrier into a target actuator.
   The current best family is `resid_pre|source_term_token|blend`. The next
   sweep should ask whether that rank carrier can be turned into target
   mass/top20 lift without increasing collapse risk.

2. Continue the contrastive source-local recipe sweep.
   Try small variations around `source_centered_pm1_minus_stealer_l025` and
   `source_term_token_to_last` before opening larger search.

3. Add confirmation replay for neutral follow-ups.
   Neutral is not success, but it is a safer local neighborhood than harmful/regressing.

4. Compare centered and fused seeds.
   Keep the matrix small:
   `source_centered_pm1`, `source_centered_pm1_minus_stealer_l025`, `source_term_fused`, and one orthogonal variant.

5. Keep attention ablation diagnostic-only.
   Use it to identify carrier heads and rank sensitivity. Do not promote it to apply until it has ownership-style certification.

6. Strengthen the readout analyzer as a feature emitter.
   Improve evidence quality, not authority. Prefer backend-swappable feature vectors over controller-visible answer hints.

7. Preserve controller-owned explanations.
   Every noop, trial, veto, or follow-up should leave a one-sentence reason reconstructible from structured fields.

8. Treat GPT-2 as a measurement rig.
   The next larger-model step should test whether the classification axes transfer, not whether a specific recipe transfers.

## Open Questions

- Can the current `resid_pre|source_term_token|blend` rank carrier be converted into positive target lift?
- Can contrastive source-local activation patches produce positive target lift, or only avoid harm?
- Is `budget` inherently a payload term at this decode point, requiring a bridge actuator such as `send`?
- Which evidence type best predicts safe trial outcome: ownership replay, attention carrier score, SAE feature support, or first-piece reachability?
- Does neutral follow-up become helpful when combined with a later composition phase?
- How much loop slack should the controller get before it starts repeating stale diagnostic ladders?
- When scaling up, do `self_actuator / bridge_actuator / cross_bound / collapse_sharpener` remain useful categories?

## Current Summary

The system has not solved readout escape yet.

But it has made the failure much sharper:

- candidate visibility is much better
- helper authority is better contained
- unsafe apply is better blocked
- operator failures are now recipe-local rather than mystical
- a harmful primary trial can now lead to a bounded neutral alternate trial
- a rank-moving recipe can now be blocked as `self_rank_carrier` instead of mistaken for a production-safe self-actuator

The next breakthrough likely requires converting non-dead diagnostic carriers into target-owned actuators, not giving the controller broader apply power.

## Positive Operator Memory

The latest loop adds a small positive-memory layer for operator diagnostics.

This is intentionally not a permission system. It records bounded positive
traits such as:

- `ownership_preserving`
- `rank_carrier`
- `target_reachable`
- `top20_gap_measured`
- `top20_gap_closer_candidate`
- `top20_gap_closer_certified`
- `anti_collapse`
- `neutral_stable`
- `rank_to_mass_convertible`

The purpose is to keep the controller from learning only negative governance.
The harmful ledger, veto memory, bridge exhaustion, and collapse-sharpener
classes are good at saying "do not apply this." Positive operator memory adds a
separate, still diagnostic-only signal:

> This family is not certified, but it produced a non-harmful partial movement
> worth deepening locally.

Positive memory is deliberately scoped and short-lived. It carries the current
`objective_bundle_key`, objective term, target piece, recipe family,
`operator_recipe_id`, `ttl_steps`, and `stale_after_context_change=true` so a
local hint cannot quietly become a cross-prompt superstition.

The controller now receives a `positive_operator_deepening_plan` derived from
that memory. The plan is structured as diagnostic guidance:

```json
{
  "kind": "positive_operator_deepening_plan",
  "permission": "diagnostic_only",
  "production_apply_allowed": false,
  "ttl_steps": 2,
  "stale_after_context_change": true,
  "scope": {
    "objective_bundle_key": "kv_pair:budget:source_body:72:73",
    "target_piece": " budget",
    "operator_recipe_id": "post_bridge_target_readout_patch_l005_a060_gap"
  },
  "recipe_family": "readout_steering",
  "next_action": "deepen_local_gap_closer",
  "deepening_axis": "target_top20_gap_closing",
  "reason_code": "positive_memory_local_gap_closer"
}
```

This preserves the constitution:

- memory records promising partial effects
- the plan explains what to inspect next
- the controller decides whether to request that diagnostic
- production apply remains closed until a separate certification path passes

In the current GPT-2 replay, readout steering remains a `self_rank_carrier`
family rather than a target actuator. The useful progress is that the loop can
now say:

> Readout steering moved the target-owned readout signal without collapse, but
> the target top-20 gap remains large. Deepen local gap-closing diagnostics;
> do not treat this as production permission.

The next implementation step turns that plan into a small, auditable local
sweep. The readout-steering deepening path now marks gap-probe recipes with
`readout_gap_closer_recipe=true` for backwards-compatible visibility, but the
evidence is split into candidate vs. certified levels. A recipe is only a
certified closer when its top-20 threshold gap shrinks against the no-edit
baseline without collapse-sharpening.

```json
{
  "readout_gap_closer_recipe_count": 3,
  "readout_gap_probe_recipe_count": 3,
  "readout_gap_closer_candidate_count": 3,
  "readout_gap_closer_certified_count": 0,
  "best_readout_gap_closer_recipe_name": "target_readout_patch_l005_a060_gap",
  "best_readout_gap_closer_target_top20_threshold_gap": 6.09,
  "best_readout_gap_closer_target_top20_threshold_gap_delta": null
}
```

The key contract is:

- `top20_gap_measured`: the gap was observed
- `top20_gap_closer_candidate`: the target piece moved in a plausible direction, but baseline gap delta is not yet sufficient
- `top20_gap_closer_certified`: the gap shrank relative to baseline while staying collapse-safe

The first gap-closer sweep stays deliberately narrow:

- pure target readout at the current alpha cap
- target readout with very light attractor subtraction
- contrastive readout with a low competitor subtraction

The next local sweep keeps that same narrow scope and expands only around the
best observed target-readout neighborhood:

- `alpha`: `0.04`, `0.05`, `0.06`
- attractor `negative_scale`: `0.0`, `0.025`, `0.05`, `0.075`
- success gate: baseline-relative `target_top20_threshold_gap_delta < 0`
  while remaining collapse-safe

The research question is not "did this solve the task?" yet. It is:

> Did any bounded readout steering variant reduce the target top-20 gap without
> becoming a collapse sharpener or a wrong-direction bridge?

Latest shortened GPT-2 direct-scan replay with this expanded local sweep
produced:

```text
gap_rows = 42
unique_gap_recipes = 21
best_gap_recipe = post_bridge_target_readout_patch_a060
best_gap_baseline = 16.536804
best_gap_after = 16.508434
best_gap_delta = -0.028371
best_target_piece_logit_delta = 0.029538
```

The output still fell into the repetition basin (`the the the the`), so this is
not an escape success or production permission. The useful result is narrower:
the controller can now compare a small baseline-aware sweep of bounded readout
gap closers, observe a repeatable local gap reduction, and carry the best
candidate forward in the positive deepening plan without pretending it is a
target actuator.

## Runtime Surface Guardrails

The May 17 full GPT-2 live run with a GPT-5.5 controller showed a different
failure mode from the earlier repetition basin. The controller stayed
well-formed and cautious, but the worker fell into a source-copy continuation:

```text
In order to stay on schedule, the budget draft should be sent
score = 0.270833
```

This is not primarily a hidden-state steering failure. It is a surface
constraint failure: the forbidden phrases and word budget were being left to
the same activation interventions that were supposed to lift required terms.
The runtime now separates those concerns. Forbidden phrases and word budget are
treated as decoder-side physical guardrails, not as evidence that an activation
operator succeeded.

The guardrail contract is:

- `decoder_forbidden_phrase_guardrail_active`: a forbidden term or forbidden
  phrase continuation was masked.
- `decoder_forbidden_phrase_blocked_terms`: which forbidden terms produced
  blocked next-token continuations.
- `decoder_word_budget_guardrail_active`: max-word budget was reached and
  non-terminal continuations were masked.
- `decoder_word_budget_blocked_token_count`: how much of the vocabulary was
  physically excluded by the word-budget guardrail.

After adding the guardrail, the same GPT-5.5 / GPT-2 live run produced:

```text
In the case of a rewrite, the budget draft.
score = 0.5875
steps = 11
```

This is still not a task success: `Mira`, `send`, and `Omar` are missing. But
it is a cleaner failure. The forbidden phrases are gone, the word budget is
respected, and the remaining problem is back where the research question wants
it: how to turn visible target readout into required-term insertion. In other
words, the guardrail improved the combined task score without claiming any
mechanistic credit for the activation operator.

### Baseline Comparison

To keep the claim honest, compare against raw local GPT-2 greedy decoding on the
same prompt and seed:

| condition | output | score | required terms | forbidden / budget |
| --- | --- | ---: | --- | --- |
| raw GPT-2 greedy | `In order to stay on schedule, the budget draft should be sent to Omar before lunch.` | 0.319444 | `budget`, `Omar` | forbidden phrases present, over budget |
| GPT-5.5 controller before surface guardrail | `In order to stay on schedule, the budget draft should be sent` | 0.270833 | `budget` | forbidden phrases present, over budget |
| GPT-5.5 controller with surface guardrail | `In the case of a rewrite, the budget draft.` | 0.5875 | `budget` | forbidden clean, budget ok |

This is an important split. Raw GPT-2 naturally preserves more of the source
payload (`Omar`) because it simply continues the source-copy basin. The
controller plus guardrail does not yet solve payload insertion, but it does
turn a forbidden source-copy continuation into a legal short sentence. That
means the system is now moving one axis of the task in a controlled way:

- surface constraints are handled by runtime guardrails
- payload constraints remain the responsibility of readout/operator work
- combined score improves, but mechanistic insertion is not yet solved

This is exactly the intended dual-brain separation. The guardrail gets no
mechanistic credit for `budget`; it only blocks illegal continuations. The
remaining research question is narrower and cleaner: how to recover `Mira`,
`send`, and `Omar` without reopening the forbidden source-copy basin.

### Easier Calibration Benchmark

The hard constrained rewrite task mixes several difficulties at once:

- multi-token forbidden phrases such as `in order to`
- source-copy attraction
- four required payload terms
- a tight answer-start readout problem

To avoid treating every failure as the same failure, the repo now includes
`constrained_rewrite_easy`. It keeps the same scoring and feedback contract as
`constrained_rewrite`, but lowers the surface complexity:

- shorter source sentences
- single-token forbidden terms
- word budgets that a clean source-copy rewrite can satisfy
- the same required-term recall / forbidden-clean / word-budget score fields

For seed `7`, the easy episode is:

```text
SOURCE: Mira should send the budget draft to Omar before lunch.
Keep: Mira, send, budget, Omar
Avoid: should
Max words: 9
```

This gives the next set of runs a calibration rung between raw source-copy and
the harder readout-escape task. The intended interpretation is:

- if `constrained_rewrite_easy` fails, the current actuator/guardrail stack is
  still struggling with basic payload preservation under a single surface ban
- if `constrained_rewrite_easy` succeeds but `constrained_rewrite` fails, the
  remaining bottleneck is likely the harder task's multi-token forbidden phrase
  and answer-boundary readout geometry
- if both fail in the same way, the issue is probably not task difficulty but
  the operator recipe family itself

Initial easy-run observations added an important caveat: the worker backend
itself must be treated as part of the measurement apparatus.

On the easy seed-7 prompt, raw Hugging Face GPT-2 greedy decoding produced:

```text
The budget draft should be sent to Omar before lunch.
The budget draft should be sent
score = 0.319444
```

It preserved `budget` and `Omar`, but violated the forbidden term `should` and
the word budget. In contrast, the same local GPT-2 weights through the
HookedTransformer worker runtime on the default MPS/auto path produced:

```text
the the the the the the the the the.
score = 0.45
```

The GPT-5.5-controller live runs on that MPS/auto worker all shared the same
collapse:

| setting | output | score | key observation |
| --- | --- | ---: | --- |
| no loop-rescue budget | `the the the the the the the the the.` | 0.45 | controller tried loop-break edits, but runtime guardrail blocked them because rescue budget was zero |
| loop-rescue budget enabled | `the the the the the the the the the.` | 0.45 | four small loop-rescue edits were applied; all were harmful or dead |
| heuristic readout analyzer enabled | `the the the the the the the the the.` | 0.45 | `Mira` frontier became visible, but the same legal filler-token loop dominated |

This means the easy benchmark is already useful, but not for the first reason we
expected. It exposed two different bottlenecks:

1. **Worker parity bottleneck.** The default MPS/auto HookedTransformer worker
   does not match raw HF GPT-2 answer-start behavior on this prompt. A direct
   first-token top-k comparison showed HF/raw and HookedTransformer CPU agree on
   `The`, `If`, `Should`, `This`, `Mir`, `Omar`, and `Send` as high-rank
   continuations, while the MPS/auto worker ranked legal filler tokens such as
   `the`, newline, `.`, `a`, and `-` at the top.
2. **Payload bottleneck.** When the HookedTransformer worker is run on
   CPU/conservative mode, the repetition basin disappears, but the output is
   still only:

   ```text
   The budget draft is not a draft.
   score = 0.5875
   ```

   This satisfies the surface constraints and preserves `budget`, but still
   misses `Mira`, `send`, and `Omar`.

The research reading is therefore sharper:

- the `the the` live-run collapse should not be over-interpreted as an operator
  theorem until worker backend parity is enforced
- the real task bottleneck remains payload insertion once the backend is
  numerically sane
- future live intervention runs should either use CPU/conservative worker mode
  or run a first-token top-k parity check before drawing mechanistic conclusions

This is a useful failure. The easy benchmark did not merely lower task
difficulty; it revealed that the measurement stack has a backend-sanity axis
that must be controlled before operator conclusions are trusted.

## Activation Patch Runtime Operator v1

The latest implementation turns `activation_patch` into a first-class
diagnostic runtime operator rather than a review-language placeholder.

The v1 scope is intentionally narrow:

- `op.kind = "activation_patch"`
- `op.mode = "blend"`
- activation targets only: `resid_pre`, `resid_post`, `mlp_out`
- answer-boundary `last` token only
- `ttl_steps=1`
- diagnostic/shadow evidence only unless later promotion/trial gates certify it

The important design point is that activation patching is not normalized
`resid_add`. The hook moves the target activation toward a source activation by
a bounded interpolation, records activation-patch telemetry, and remains under
the same controller-owned policy contract:

```text
activation_patch evidence != production apply permission
```

The runtime now records:

- `activation_patch_op_kind`
- `activation_patch_mode`
- `activation_patch_source_localization`
- `activation_patch_runtime_supported`
- `activation_patch_effect_role`
- hook telemetry such as source/target norms, cosine, blend delta norm, and
  step-size saturation

This matters because the project can now test a different operator family
without letting the helper stack become a hidden controller.

## Forced Cap Response Curve

The first activation-patch response-curve result is a useful negative finding.

The immediate question was whether prior activation-patch failures were caused
by a surface `step_size` cap rather than by the operator recipe itself. To test
that, the runtime now supports a diagnostic-only forced/canonical response
curve:

```text
seed_source = observed_gap_carrier | forced_canonical | prior_run_replay
```

If no observed gap-carrier seed is available on the live trajectory, the runtime
can force canonical seeds:

- `mlp_out L11 source_term_token`
- `resid_pre L11 source_term_token`

These rows are explicitly marked as boundary measurements:

- `forced_seed = true`
- `seed_source = forced_canonical`
- `production_apply_allowed = false`
- `certified_for_apply = false`

The latest GPT-2 constrained-rewrite live run executed:

| site | layer | localization | step size | result |
| --- | ---: | --- | ---: | --- |
| `mlp_out` | 11 | `source_term_token` | 0.16 | `dead_actuator` |
| `mlp_out` | 11 | `source_term_token` | 0.20 | `dead_actuator` |
| `resid_pre` | 11 | `source_term_token` | 0.16 | `dead_actuator` |

The run did not solve the task. The output remained:

```text
the the the the the the the the the.
```

But the diagnostic conclusion is sharper:

- the response curve really executed
- policy no longer blocked the cap-release measurement
- the tested rows did not collapse
- the tested rows also did not move target mass or target top-20

Interpretation:

> This specific canonical source-term activation blend is executable and safe
> enough to measure, but it is not a target actuator on the observed live state.

That weakens the "surface cap was the main reason" hypothesis. The bottleneck
has shifted again: not `operator strength` alone, and not just `seed
availability`, but likely source/target localization or the need for a more
structured activation-patch source.

## Next Strategy After Forced Cap Deadness

The next operator workstream should avoid simply increasing dose again.

The response curve did not show target lift at 0.16 or 0.20, and it did not
show collapse. That means the curve is flat/dead for this canonical seed, not
obviously under-dosed.

The next candidate axes are:

1. **Localization shift.** Keep activation-patch v1, but change source from
   simple `source_term_token` to a more structured source such as
   `source_centered_pm1_minus_stealer`, `source_affordance_span`, or a
   blueprint-derived repair span.
2. **Target-site shift.** Keep the source fixed but measure nearby late
   residual/MLP sites under the same forced curve contract.
3. **Two-stage diagnostic only.** If anti-attractor suppression produces a
   non-harmful suppressor, test `anti-collapse -> activation_patch` as a
   diagnostic sequence before considering any trial gate.
4. **Backend sanity first.** Any operator conclusion on the `the the` basin
   should be paired with CPU/conservative or first-token top-k parity checks,
   because MPS/auto worker geometry can change the basin being measured.

The next PR should therefore be framed as:

> Activation patch v1 is executable and auditable; the first forced canonical
> cap-response curve is dead, so the next search should vary localization and
> staging rather than merely increasing step size.
