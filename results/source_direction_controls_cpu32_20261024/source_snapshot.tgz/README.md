# spiral_intervention_lab

Research scaffold for bounded runtime intervention experiments.

Core question:

> Can a controller LLM improve a smaller worker model only through bounded internal interventions, without directly generating the task answer itself?

The current project framing is closer to an inference-time intervention system or runtime control architecture than to ordinary prompting, RAG, or agent orchestration:

- the worker model remains the surface actor
- the controller emits typed intervention commands, not task answers
- the runtime/compiler resolves those commands into bounded edits
- task feedback and effect summaries are used to search over interventions
- auxiliary controls and sidecars are allowed only when they stay bounded, auditable, and clearly secondary to the worker

The repo has now moved beyond the initial v0 scaffold. It includes the intervention loop, structured reflection, multiple task environments, readout-collapse diagnostics, provenance-aware candidate compilation, ownership-aware operator replay, diagnostic evidence ledgers, and an offline readout analyzer path.

## Layout

- `SpiralInterventionLab/`
  Main Python package.
- `SpiralInterventionLab/runtime/`
  Runtime, compiler, adapter, worker, and baseline code.
- `SpiralInterventionLab/backends/`
  Capability-based local worker backends for HF Transformers, MLX, and llama.cpp.
- `SpiralInterventionLab/controllers/`
  Black-box controller provider adapters for OpenAI, Anthropic, Mistral, and Google.
- `SpiralInterventionLab/bridge/`
  Strict JSON controller clients that bridge provider responses into the runtime/compiler loop.
- `SpiralInterventionLab/examples/`
  End-to-end runnable examples that wire tasks, worker runtimes, and black-box controllers together.
- `SpiralInterventionLab/tasks/`
  Seeded task environments, including digit, rewrite, ordering, entailment, and structured-summary tasks.
- `SpiralInterventionLab/prompts/`
  Controller prompt assets.
- `SpiralInterventionLab/tests/`
  Focused smoke and integration tests.
- `docs/`
  Research notes and control-plane design docs.

Key current notes:

Source-response artifact availability and fresh-clone verification are described
in [`docs/source_response_artifacts.md`](docs/source_response_artifacts.md).

- [`docs/source_choice_boundary.md`](docs/source_choice_boundary.md)
  A fixed-source/cap CPU32 follow-up at the next natural token preserves signed
  comma/while contrast reversal, but common-component comma lift does not carry
  over. The actual winner is now ` sending`, outside the structural readout set.
  Fixed-baseline-winner margins separate relative improvement from token choice;
  all seven conditions retain the same greedy winner and no authority is added.

- [`docs/source_response_components.md`](docs/source_response_components.md)
  At the same prefix/site/cap, CPU/float32 replicates common-component comma lift
  and signed comma/while logit-contrast reversal seen in MPS/float16. Absolute
  probability changes are numerics-sensitive: positive difference on CPU mainly
  suppresses while, not lifts comma. Greedy ` before` is unchanged; relative
  preference is not lift ownership or permission. Original blocked/error receipts
  and the qualified signed-zero reanalysis remain alongside the completed CPU run.

- [`docs/source_response_trajectory.md`](docs/source_response_trajectory.md)
  Matched comma/while patches differ at input and retain distinct downstream
  displacements while both favor comma. CPU/float32 preserves the response
  direction, not the MPS/float16 effect size; greedy ` before` is unchanged.
  Read-only trajectory capture now separates packet canaries from diagnostic
  replays (31 actual forwards vs 18 declared replays in this diagnostic interval).
  No production permission or task-success claim is added.

- [`docs/source_clause_diagnostic.md`](docs/source_clause_diagnostic.md)
  Opt-in source-bound connective/punctuation observation for the controller.
  Exact current-prefix IDs, one unedited replay and unchanged caps separate
  structural readout visibility from operator efficacy or apply permission.
  The frozen-prefix harness has no provider calls or forced-token oracle.
  A separate opt-in connects measured SOURCE token IDs to normal-cap activation
  patch diagnostics, with repeated controls and cross-token response logs;
  neither readout movement nor these new cards grant production permission.
  The normal-cap Llama retry completed four source-token probes: comma
  probability increased, but all sources favored comma and greedy ` before`
  remained unchanged. Source specificity and clause rescue are not established.
  Matched controls reproduce zero self-copy response and a negative comma
  response to pure radial shrink. A stale-cache `last` reference initially
  invalidated the null control; explicit, budgeted cache alignment now guards
  that distinction. Direction matters locally, but source-specific actuation
  and task success remain unestablished.

- [`docs/clause_structure_survey.md`](docs/clause_structure_survey.md)
  Across the nine rewrite-ladder cases, three of six failures turn on the same
  choice after the first clause's recipient (` before` vs a separator ranked
  2-8); forcing the separator lets the worker write the missing clause itself.
  L2 failures are compression, not structure. Source-anchored activation
  patches can flip the L1 review decision, but only at L25-L27 with large edits.

- [`docs/operator_dose_response.md`](docs/operator_dose_response.md)
  Dose response on the L1 `Selim` case. Readout steering writes the name only at
  12-24% of the residual norm, where it is equivalent to forcing the token;
  source-anchored activation patches never reach and damage the state at high
  dose. The real bottleneck is clause structure: pushing `,` at 6% of the norm
  makes the worker write the full role-correct rewrite itself. Adds an offline
  role-binding check (not part of the legacy score).

- [`docs/orphan_blueprint_ceiling.md`](docs/orphan_blueprint_ceiling.md)
  Diagnostic-only ceiling for the three blueprints the 10-14 Llama retry never
  replayed. Forcing ` Sel` reaches 1.0 at four prefixes, but none of 1,116
  bounded first-token replays makes it the greedy token: where ` Sel` is within
  rank 5, the best lift is 31-41x smaller than the gap, and every activation
  patch was step-size-clipped. More budget or routing would not have helped;
  the evaluator also rewards role-incorrect insertions.

- [`docs/explicit_generation_clock.md`](docs/explicit_generation_clock.md)
  Opt-in `inspect_prefix` / `commit_token` actions separate bounded investigation
  from one-token generation, including before the first answer token. Failed
  diagnostics can be read at the same prefix; edit permission and budgets stay
  separate. Initial readout is prepared without emitting a token; unsupported
  backends fail closed in explicit mode. The legacy clock remains the default.
  GPT-2 and Llama paired runs exercise the new clock but show no task-score uplift
  or rollout edits; receipts retain the failed attempt and differing card arrival.

- [`docs/controller_operation_cards.md`](docs/controller_operation_cards.md)
  Opt-in common operation cards expose diagnostic purpose, prerequisites, cost,
  possible evidence and prefix timing. Exact IDs resolve existing requests;
  the fixed-prefix interface comparison preserves the underlying operations
  and records selected diagnostics separately from execution and task outcomes.

- [`docs/controller_transaction_design_audit.md`](docs/controller_transaction_design_audit.md)
  Design audit separates zero trial offers from refused offers. Its synthetic failures
  motivated a shared round dispatcher and a bounded normal-cap investigation that can
  measure, conditionally confirm, and return a trial offer before the prefix expires.
  Apply still needs a separate controller decision; live task uplift is unmeasured.

- [`docs/explicit_prefix_investigation.md`](docs/explicit_prefix_investigation.md)
  Explicit normal-cap remeasurement creates a new candidate, not inherited permission.
  Exact physical context is separated from helper-frontier preference. Controller-chosen
  hold-prefix diagnostics share existing handoff rounds without advancing token/TTL time;
  physical caps and trial safety/effect checks remain unchanged.

- [`docs/intervention_reachability_audit.md`](docs/intervention_reachability_audit.md)
  Separates observed no-apply choices from unreachable admission/execution paths.
  The matched Llama handoff run found readout lift blocked by diagnostic-versus-normal
  cap mismatch; the audit also fixes ordinary edit TTL before generation and
  preserves rejection reasons in memory/debriefs. No caps or apply gates are relaxed.

- [`docs/current_prefix_trial_handoff.md`](docs/current_prefix_trial_handoff.md)
  Current-prefix evidence can reach a bounded controller-chosen trial without
  advancing generation first. Exact source/site/dose, physical confirmation,
  one-token TTL and existing caps remain mandatory; diagnostic evidence alone
  still grants no apply permission. Includes harness budget/TTL audit corrections.

- [`docs/iteration_position_evidence.md`](docs/iteration_position_evidence.md)
  Prefix-only position facts and bounded same-candidate measurement history;
  the controller still chooses when to measure. A repeatable paired runner
  checks GPT-2 and Llama separately, with local checkpoint paths, sealed evidence,
  unchanged apply gates, and explicit measurement coverage in post-run interviews.
- [`docs/controller_candidate_actions.md`](docs/controller_candidate_actions.md)
  Explicit historical-review/current-prefix measurement choices with frozen
  source and token binding, context-bound request IDs and unchanged apply gates.
  Luna selected seven current-prefix measurements (28 replays, all restored);
  B0/C1 still match at 0.938889 with Selim missing. Tool execution is not task uplift.
- [`docs/llama_live_review_reuse.md`](docs/llama_live_review_reuse.md)
  Fresh Luna/Llama L1 pair: four historical reviews reused without a new charge,
  but all twelve diagnostic slots are still consumed and no explicit new-prefix
  measurement is requested. B0/C1 remain identical at 0.938889 with zero rollout
  edits. This is measured accounting progress, not task or API-token uplift.
- [`docs/llama_competition_completion.md`](docs/llama_competition_completion.md)
  Fixed-prefix follow-up: the same patch slightly narrows the `sending` versus
  ` Sel` gap but leaves natural output unchanged. Supplying ` Sel` only in a
  separate diagnostic branch permits name completion, but loses the deadline;
  conditional completion is not task success or apply permission.
- [`docs/llama_frozen_prefix_response.md`](docs/llama_frozen_prefix_response.md)
  Reuse closed diagnostic reviews without recharging them; explicitly remeasure
  changed prefixes. One frozen Llama activation patch was compared at three
  positions around a connective: identical logit lift, larger piece-probability
  movement after `before`, but unchanged final text and no apply promotion.
- [`docs/llama_rewrite_difficulty_ladder.md`](docs/llama_rewrite_difficulty_ladder.md)
  Opt-in L1/L2/L3 rewrite ladder: higher required-term load, tighter word budget,
  then additional lexical exclusions. Keeps the old success control and apply
  gates unchanged. Local Llama success is 2/3, 0/3, 1/3 respectively; L1's
  missing-actor failure reproduces in full B0. The matched L1 Luna run also
  misses Selim: score 0.938889, 12 diagnostics plus one inspection, zero rollout
  edits. Frozen-prefix readout movement is evidence, not task-level uplift.
- [`docs/llama_worker_return.md`](docs/llama_worker_return.md)
  Full-depth local Llama return: same-task B0 and Luna C1 both score 1.0,
  with no rollout edits. HF/runtime fidelity passes; GPT-2's same-FP16
  no-edit control remains constraint-violating. This is a worker comparison
  and integration check, not an intervention or architecture-only success.
- [`docs/source_direction_comparison.md`](docs/source_direction_comparison.md)
  Frozen-prefix, equal-dose source-construction comparison and an evidence-ID
  path into existing bounded trial reviews. Source changes affect token-form
  response; the measured candidates still have no certified target actuator.
- [`docs/luna_diagnostic_tooling_plan.md`](docs/luna_diagnostic_tooling_plan.md)
  Luna-centered matched-dose response probes, bounded evidence inspection, and
  event-anchored qualitative debriefs. Measurement remains separate from apply
  permission; equal materialized edits are aliases, not independent evidence.
- [`docs/readout_escape_research_observations.md`](docs/readout_escape_research_observations.md)
  Chronological research observations for the readout-escape line.
- [`docs/readout_escape_insight_taxonomy.md`](docs/readout_escape_insight_taxonomy.md)
  Structured split between mechanistic-interpretability value, engineering value, and findings that are both.
- [`docs/healthy_tweaking_control_planes.md`](docs/healthy_tweaking_control_planes.md)
  Control-plane framing for bounded helper authority.

## Current Status

The current implementation includes:

- a typed controller DSL with `resid_add`, `kv_mix`, `rank1_patch`, and blend-only `activation_patch`
- reversible, TTL-scoped runtime edits with strict budget validation
- structured controller reflection via `controller_memory`
- task-grounded effect labeling driven by `partial_score`, coverage, repetition, and violations
- multiple local bounded tools such as `dry_run_decode`, `constraint_scorer`, and `tokenize_terms`
- readout diagnostics for answer-start collapse, including attractor-family and reachable-focus signals
- provenance-aware candidate compilation with `source_body > answer_prefix > constraint_header > misc_prompt`
- same-term / same-family dominance pruning and clean `kv_pair` bundle metadata
- shot-mode and readout-escape phases, separated from loop-break / stabilization phases
- a minimal offline readout sidecar scaffold that can analyze captured sites and feed small hints back into candidate ranking
- a scaffolded SAE-style readout analyzer backend that emits feature hints without becoming a runtime dependency
- diagnostic-only readout tools, including first-piece logit probes and attention head ablation
- an early `target_entity_insertion_probe` diagnostic that inspects missing payload terms (`Mira`, `send`, `Omar`, etc.) for first-piece reachability and source-body spans before another blind entity/shot edit
- bounded observer checks even when no semantic critic backend is configured, using lexical coverage plus available feature scans as an explicit fallback
- runtime surface guardrails for forbidden phrase continuations and word-budget terminalization
- a bounded controller diagnostic request loop:
  - controller emits `meta.diagnostic_request`
  - runtime executes cached/bounded diagnostics
  - next packets expose `latest_diagnostic_results` and `recent_diagnostic_results`
  - production apply remains blocked unless independently certified
- a stricter `controller / analyzer / gate / runtime guardrail` separation with explicit logging of:
  - `sidecar_suggested_*`
  - `gate_report_*`
  - `controller_selected_bundle_key`
  - `controller_rejected_signals`
- operator-family and operator-recipe certification via actual-delta replay
- ownership-aware replay summaries that distinguish:
  - `self_actuator`
  - `bridge_actuator`
  - `cross_bound`
  - `dead_actuator`
  - `noisy_or_harmful`
- diagnostic evidence ledgers that summarize, per bundle:
  - `readout_reachable`
  - `head_sensitive`
  - `feature_supported`
  - `diagnostic_operator_supported`
  - `policy_candidate_ready`
  - `production_operator_certified`
  - `blocked_by`
  - the next diagnostic request the controller should ask for
- readout gap/deepening routers that distinguish:
  - `gap_closer_candidate`
  - `confirmed_gap_only_no_target_lift`
  - `carrier_only_no_target_actuator`
  - `operator_family_shift_after_gap_carrier_conversion_failed`
- diagnostic-only non-KV operator-family shift previews after carrier conversion fails, including residual readout-direction, source-term activation patch, anti-attractor suppression, and attention-route carrier probe scaffolds
- first-class diagnostic `activation_patch` runtime support with blend-mode hooks,
  step-size telemetry, forced/canonical cap-response curves, and JSONL summary
  extraction for activation-patch rows

## Current Bottleneck

The project is no longer stuck in a “nothing is visible” failure mode. The current bottleneck is narrower and more interesting:

- semantic support can often be detected
- source positions and candidate spans can be resolved
- some probes are weakly positive
- but first-token answer readout still often collapses into attractor basins such as repetition or junk subword families

In practice, this means the current system is better at:

- detecting collapse
- opening `readout_escape`
- compiling cleaner candidates
- reranking candidates with auxiliary evidence

than it is at:

- making those candidates win at the answer boundary
- escaping the attractor basin strongly enough to re-enter a healthy answer-start manifold
- ensuring that the selected bundle is also the bundle that actually receives the lift

The main research question has therefore sharpened from “can we intervene at all?” to:

> Which bounded, auditable runtime controls actually improve readout competitiveness at the answer boundary, and can that lift stay owned by the intended bundle?

The latest readout-escape line narrows this again:

> If readout steering can repeatedly produce gap/rank carriers but not target mass/top-20 lift, which non-KV operator family can convert that carrier into a target-owned actuator?

The newest activation-patch diagnostics narrow that one more step:

> If a source-term activation blend can be forced through larger diagnostic
> step sizes at the answer boundary, does it become a target actuator, a gap
> carrier, a collapse sharpener, or a dead actuator?

In the latest GPT-2 constrained-rewrite live run, forced canonical
`activation_patch` response-curve probes reached:

- `mlp_out L11 source_term_token` at `step_size=0.16`
- `mlp_out L11 source_term_token` at `step_size=0.20`
- `resid_pre L11 source_term_token` at `step_size=0.16`

All three remained `dead_actuator`, with no target mass/top-20 lift and no
collapse. This is a useful negative result: the immediate bottleneck is no
longer just the surface step-size cap. Canonical source-term activation blending
can be made executable and auditable, but this specific forced seed does not
convert a visible carrier into answer-boundary actuation.

The latest runs narrow this further. For the `budget` frontier in the constrained rewrite direct-scan replay, the diagnostic ledger reports:

- `readout_reachable = true`
- `head_sensitive = true`
- `feature_supported = true`
- `diagnostic_operator_supported = true/false` depending on diagnostic counterfactuals
- `policy_candidate_ready = false` unless a quarantine executable passes the promotion gate
- `production_operator_certified = false`
- `blocked_by = dead_actuator / all_dead_actuator`

That means the current bottleneck is not visibility. The stack can now see a plausible frontier and collect non-dead diagnostic signals, but it still lacks a certified self or bridge actuator that can safely move the worker at the answer boundary.

The newest diagnostic-request replay closes one more control-plane loop:

- the controller sees the `budget` frontier
- the controller asks for `operator_diagnostic_replay`
- runtime returns one diagnostic result in `latest_diagnostic_results`
- the result says `production_apply_allowed = false`
- the reason remains `blocked_by = dead_actuator / all_dead_actuator`

This is an important negative result. The controller can now request the next measurement without converting that measurement into apply authority.

## What We Have Learned

Several concrete lessons have come out of the recent runs:

- Stability is not progress. Lower entropy or higher margin can still reinforce a bad local attractor.
- Loop relief is useful but insufficient. It can improve local behavior without moving task score.
- Semantic focus and reachable focus are different. A term can be semantically relevant but unreachable at the current decode state.
- Candidate quality matters more than candidate count. Many nominally different candidates collapse into the same effect family.
- Source provenance matters. `SOURCE:` body spans are usually more useful than header-only constraint spans for escape and recall.
- Sidecars are promising when kept bounded. The best use so far is to improve candidate ranking and vetoes, not to become a hidden answer channel.
- Selector quality and operator quality are not the same problem. The current stack can now nominate challengers more cleanly than it can certify that those challengers actually win when applied.
- “Helpful” is not enough. We now explicitly distinguish between lift that belongs to the intended bundle and lift that gets stolen by another bundle.
- Ownership matters. A recipe can move logits while still being the wrong actuator if `realized_lift_bundle != intended_bundle`.
- Diagnostic signals are not apply permission. `logit_adjacent`, attention ablation, and SAE-style feature hints improve the controller's map, but they do not certify a runtime edit.
- Gap movement is not target actuation. A repeatable `target_top20_threshold_gap_delta < 0` can justify confirmation or family shift, but it does not justify production trial unless target mass or target top-20 lift appears.
- Term rotation is a measurement tool, not an endless loop. Once a term is `confirmed_gap_only_no_target_lift`, the controller should stop re-confirming it and shift the operator family.
- Operator certification is starting to look slightly over-powered if treated as a decision layer. It should be kept as evidence for the controller, not as a second policy owner.

## Readout Analyzer Status

The readout analyzer path is intentionally minimal and offline-oriented.

It currently:

- captures answer-boundary and source-body sites
- allows an external analyzer to inspect them
- feeds back only small hints such as:
  - `focus_term_override`
  - `term_anchor_strength_by_term`
  - `candidate_support_terms`
  - `candidate_support_scores`
  - `bundle_support_scores`
  - `bundle_evidence_vectors`
  - `sae_feature_hints`
  - optional family/key vetoes

It currently does **not**:

- inject raw feature vectors into the controller
- force task answers
- replace runtime actuation with a heavyweight analysis stack

This is deliberate. The analyzer is meant to improve the candidate compiler’s eyes, not to smuggle in a second generator.

The current `sae_scaffold` mode is not a full SAELens integration. It is a feature-emitter scaffold that marks evidence as `feature_backend="sae_sidecar"` and keeps policy ownership in the controller.

## Diagnostic Ledger

The latest control-plane addition is a diagnostic evidence ledger.

It collects bridge eval, operator replay, readout-local probes, attention head ablation, and analyzer feature hints into a bundle-indexed status table. A typical frontier status looks like:

```json
{
  "bundle_key": "kv_pair:budget:source_body:72:73",
  "readout_reachable": true,
  "head_sensitive": true,
  "rank_readout_carrier": true,
  "feature_supported": true,
  "diagnostic_operator_supported": false,
  "policy_candidate_ready": false,
  "production_operator_certified": false,
  "blocked_by": ["dead_actuator", "all_dead_actuator"],
  "next_evidence_needed": "certified_self_or_bridge_actuator",
  "diagnostic_request": "operator_diagnostic_replay"
}
```

This ledger gives the controller more room to reason about what evidence to request next while preserving the hard boundary:

- diagnostics may improve visibility
- diagnostics may suggest the next measurement
- attention diagnostics are treated as rank/readout carrier evidence, not attention-edit permission
- attention carrier hits may appear as `attention_shadow_actuator` counterfactuals, but remain `production_apply_allowed=false`
- diagnostics may block unsafe application
- diagnostics do not grant production apply permission

That last point is important. The current design intentionally lets the controller become more curious without letting helper modules become covert selectors.

When an activation-patch candidate reaches policy review, the runtime now emits
an `activation_patch_production_denial_dossier` instead of treating diagnostic
support as production permission. The dossier keeps five denial axes visible:
`ownership_not_live_certified`, `safety_not_certified`,
`context_equivalence_missing`, `rollback_contract_missing`, and
`effect_size_too_small`.
The follow-up `activation_patch_production_shadow_replay` diagnostic can replay
that candidate against the current controller packet and emit an
`activation_patch_production_shadow_dossier`, clearing any axes that are
certified in shadow while still leaving `production_apply_allowed=false`.
If the shadow replay clears those axes, `activation_patch_production_trial_gate_review`
may then emit an `activation_patch_production_trial_dossier` and a bounded
`activation_patch_production_trial_candidate`. This is only a trial contract:
`ttl_steps=1`, rollback/norm limits remain explicit, the trial uses a separate
budget, and `production_apply_allowed` / `production_operator_certified` remain
false. When the controller spends that contract, it must do so as
`meta.apply_kind="production_trial"`: the edit consumes the separate
production-trial budget, survives one generated token for measurement, emits a
`controller_effect` with `apply_kind="production_trial"`, and still does not
grant production apply permission.
Those effects now feed a `production_trial_outcome_ledger` in
`recent_effect_summary`. The ledger records `trial_effect_class` plus the
objective bundle, step actuator bundle, operator recipe, and surface family that
were tested. The controller folds that ledger back into the next decision:
harmful/regressing/collapse-sharpener trials veto the tested recipe family and
request alternate operator evidence, neutral trials request an alternate/confirm
comparison, and helpful trials still require confirmation replay before any
production policy review. Each row also carries a `promotion_ladder_stage`
(`trial_blocked_needs_alternate_operator`,
`trial_neutral_needs_alternate_candidate`, or
`trial_supported_needs_confirmation_replay`) so later alternate-candidate
generation can read one stable contract instead of reinterpreting raw deltas.

The newest direct-scan replay closes the first alternate-recipe loop after a
failed production trial:

1. a bounded production trial is allowed only as `apply_kind="production_trial"`
2. the effect returns `trial_effect_class="regressing"` / `verdict="harmful"`
3. the controller requests `compare_extra_operator_diagnostics`
4. the old tested recipe is vetoed by `operator_recipe_id` / surface family
5. the controller extracts a different activation-patch evidence row as an
   `alternate_trial_candidate`
6. that alternate candidate is reviewed through
   `activation_patch_candidate_review`
7. the same alternate shadow is carried into
   `activation_patch_runtime_support_probe`, instead of falling back to the
   stale failed recipe

In the current local GPT-2 direct-scan replay, this produces the sequence:

```text
activation_patch_candidate_review
-> activation_patch_runtime_support_probe
-> activation_patch_promotion_gate_review
-> activation_patch_production_shadow_replay
-> activation_patch_production_trial_gate_review
-> compare_extra_operator_diagnostics
-> activation_patch_candidate_review
-> activation_patch_runtime_support_probe
```

The important observation is not yet task success. It is control-plane progress:
after an unsafe `a0.150` trial, the loop can now preserve the failure evidence,
select a lower-alpha alternate recipe such as `a0.050`, and keep that alternate
identity attached through candidate review and runtime-support probing.

This reframes the next experiment. The immediate question is no longer whether
the controller can ask for another diagnostic; it can. The question is whether a
failed trial can create a clean recipe-local veto, whether the lower-alpha
alternate survives the same review/support/shadow ladder, and whether any
alternate produces a bounded effect that is less collapse-sharpening than the
failed high-alpha trial.

The first full ladder observation is now negative but useful. With a diagnostic
trial budget widened only inside the replay harness, the lower-alpha alternate
keeps its `operator_recipe_id` through:

```text
activation_patch_candidate_review(a0.050)
-> activation_patch_runtime_support_probe(a0.050)
-> activation_patch_promotion_gate_review(a0.050)
-> activation_patch_production_shadow_replay(a0.050)
-> activation_patch_production_trial_gate_review(a0.050)
-> production_trial(a0.050)
```

The outcome is still `trial_effect_class="regressing"` / `verdict="harmful"`.
So alpha reduction alone did not turn this activation-patch recipe into a safe
operator. The value of the run is that the result is now comparable: both
`a0.150` and `a0.050` fail inside the same controller-owned trial ladder, rather
than being mixed with stale candidate identity or broad-family vetoes.

The next recipe-family shift is also negative. When the alternate selector is
forced to prefer a different activation-patch family over a lower-alpha copy of
the failed family, the ladder chooses `resid_pre|source_span_to_last|blend|a0.050`
instead of `resid_post|source_span_to_last|blend|a0.050`. That candidate also
reaches bounded `production_trial`, and it also returns `regressing/harmful`.
This suggests the current failure is not just over-strong `resid_post`; the
`source_span_to_last|blend` activation-patch recipe itself is suspect.

The next source-localization pass keeps that contract but changes the structural
recipe family. Activation-patch diagnostics now include a compact pool for
`source_term_token_to_last`, `source_centered_pm1_to_last`, and a small span
baseline instead of hiding those rows behind the truncated `evidence_rows`
view. The controller-side compiler now prefers source-local evidence over broad
span evidence when the ownership score ties, and the first local GPT-2 replay
moves the initial ladder to
`resid_pre|source_term_token_to_last|blend|a0.050`. That bounded trial is still
`regressing/harmful`, but this is a better negative result: the source-local
recipe reached the same controller-owned trial path instead of being lost in
diagnostic compression.

The latest contrastive source-local pass keeps the same production-trial
guardrail and changes the follow-up selector. Diagnostics now emit
`source_term_token_minus_stealer_l025`,
`source_centered_pm1_minus_stealer_l025`, and
`source_term_token_orthogonal_stealer` rows with explicit `contrast_mode`,
`contrast_scale`, and `stealer_term` fields. After the first
`source_term_token_to_last` bounded trial regresses, the alternate selector now
uses ownership-first scoring and nominates
`resid_pre|source_centered_pm1_minus_stealer_l025_to_last|blend|a0.050`
(`self_delta=5.057`, `alignment_margin=3.992` in the local GPT-2 replay).
Production apply remains closed; the value is that the controller can now move
from a failed source-local recipe to a contrastive source-local recipe without
turning the analyzer or gate into a policy owner.

The follow-up trial path is now first-class instead of being simulated by
widening the primary trial budget. After the first
`source_term_token_to_last` production trial returns `regressing/harmful`, the
runtime exposes a separate `production_trial_followup` budget. The alternate
contrastive recipe then reaches a second bounded trial as
`production_trial_budget_class="alternate_followup"` with
`production_trial_followup_allowed=true`. In the local GPT-2 direct-scan replay,
that second trial preserves
`resid_pre|source_centered_pm1_minus_stealer_l025_to_last|blend|a0.050` and
returns `trial_effect_class="neutral"` / `signal_profile="flat"`. This is not
task success yet, but it is a cleaner operator-quality comparison: the
controller can now distinguish "primary source-local trial regressed" from
"contrastive follow-up was bounded but neutral" without opening production
apply.

The latest direct-scan GPT-2 replay splits rank/readout carrier evidence from a
true target actuator. A recipe can now be classified as `self_rank_carrier`
when it moves the intended bundle's rank/readout signal but does not improve
target mass or target top-20 hits. Such candidates stay diagnostic-only and do
not enter `production_trial`. With that split in place, the replay follows the
safer sequence:

```text
activation_patch_candidate_review
-> compare_extra_operator_diagnostics
-> cross_bundle_bridge_search
-> compare_extra_operator_diagnostics(post_bridge_exhaustion)
```

The current post-bridge expansion finds `self_rank_carrier: 3` and
`wrong_direction: 9`, but no `self_target_actuator`. The best observed carrier
family is `resid_pre|source_term_token|blend`, and the next evidence request is
`convert_rank_carrier_to_target:resid_pre|source_term_token|blend`. This keeps
the result honest: `budget` can be moved in rank space, but production apply is
still closed until that movement becomes target-owned mass/top20 lift.

The latest GPT-5.5-controller / local GPT-2 live comparison adds one important
surface-control result. Raw GPT-2 greedy decoding on the constrained rewrite
prompt preserves more source payload (`budget`, `Omar`) but copies forbidden
phrases and exceeds the word budget:

```text
In order to stay on schedule, the budget draft should be sent to Omar before lunch.
score = 0.319444
```

With runtime surface guardrails active, the controller/worker run does not yet
recover the missing payload terms, but it converts the source-copy continuation
into a legal short sentence:

```text
In the case of a rewrite, the budget draft.
score = 0.5875
```

This is not mechanistic insertion success. It is a cleaner decomposition:
decoder-side guardrails can carry forbidden-phrase and word-budget constraints,
while activation/readout work remains responsible for recovering `Mira`, `send`,
and `Omar`. The detailed comparison lives in
[`docs/readout_escape_research_observations.md`](docs/readout_escape_research_observations.md#baseline-comparison).

There is now also a slightly easier companion benchmark,
`constrained_rewrite_easy`, for this exact comparison. It keeps the same
feedback contract as `constrained_rewrite` but uses shorter source sentences,
single-token forbidden terms, and word budgets that a clean source-copy rewrite
can satisfy. For seed `7`, the easy variant keeps the `Mira/send/budget/Omar`
payload while removing the multi-token `in order to` trap:

```text
SOURCE: Mira should send the budget draft to Omar before lunch.
Keep: Mira, send, budget, Omar
Avoid: should
Max words: 9
```

This benchmark is not meant to replace the harder constrained rewrite task. It
is a calibration rung: if runtime guardrails plus readout/operator work cannot
recover payload on `constrained_rewrite_easy`, the hard task is probably still
too entangled for the current actuator set.

The controller can now ask for two early measurements on this rung without
turning either into apply permission:

- `request_observer_check` now triggers a bounded semantic-progress check even
  when the semantic critic is off; the fallback reports lexical coverage and any
  available latent/KV feature scans instead of silently doing nothing.
- `request_target_entity_insertion_probe` runs a diagnostic-only readout probe
  over missing payload terms, returning first-piece ranks/probabilities,
  top-20 reachability, source span provenance, and current span progress. This
  helps distinguish "payload term is visible but no actuator is certified" from
  "the controller has not looked at the entity frontier yet."
- `request_entity_insertion_operator_candidate_review` consumes those probe rows
  and emits shadow-only candidate blueprints for missing terms with source-body
  spans, such as `Mira`, `send`, and `Omar`. The review ranks candidate families
  like source-body KV, activation patch, and readout-direction patches, but still
  leaves `production_apply_allowed=false`; it is a bridge from visibility to
  operator replay, not an apply gate.
- `operator_diagnostic_replay` can now materialize those
  `entity_insertion_candidate_blueprint` rows into concrete, diagnostic-only
  readout-steering candidates and run actual-delta replay on them. The resulting
  rows are logged as `entity_insertion_materialized_candidate` evidence with
  ownership/effect/safety roles, while production apply remains closed until a
  later certification gate explicitly promotes a candidate.
- If materialized entity candidates produce self-owned rank/readout movement
  without target mass or top-20 lift, the runtime emits a diagnostic-only
  `positive_operator_deepening_plan` and recommends
  `readout_steering_deepening`. This connects "we found a carrier" to "now try
  to convert that carrier into a target actuator" without treating the carrier
  as apply permission.

For local non-tiny worker runs, pass a local Hugging Face model directory with
`worker_model_path` / `--worker-model-path` rather than relying on a named remote
model. The Hugging Face cache may be offline even when network is available, so
clone-specific model locations should stay outside the repo and be provided on
the CLI.

The replay harness now has a `diagnostic_request` controller mode for this contract. Early direct-scan GPT-2 replay produced:

```json
{
  "replay_mode": "directscan_diagnostic_request",
  "diagnostic_request_event_count": 1,
  "diagnostic_result_event_count": 1,
  "controller_diagnostic_request_names": ["operator_diagnostic_replay"],
  "latest_diagnostic_results": [
    {
      "diagnostic": "operator_diagnostic_replay",
      "bundle_key": "kv_pair:budget:source_body:72:73",
      "diagnostic_operator_supported": false,
      "policy_candidate_ready": false,
      "production_operator_certified": false,
      "production_apply_allowed": false,
      "blocked_by": ["dead_actuator", "all_dead_actuator"]
    }
  ]
}
```

## Decision Ownership

The current runtime is intentionally moving toward a stricter separation of powers:

- the `controller` is the only policy owner and is responsible for the final `apply / noop / rollback` decision
- the `readout analyzer` is an evidence emitter that may suggest focus terms or bundle support, but does not own final selection
- the `gate` is treated as an evaluation/report layer rather than a shadow selector
- runtime guardrails remain outside the controller for purely mechanical invariants such as budget, compile validity, and tensor safety

This split now also shows up in logs:

- `sidecar_suggested_*` records what the analyzer suggested
- `gate_report_*` records what the bounded runtime evaluation reported
- `diagnostic_evidence_ledger` records what has been measured about each frontier bundle
- `bundle_diagnostic_status` records what is still missing before a bundle can be treated as safe
- `controller_selected_bundle_key` and `controller_rejected_signals` record what the controller actually adopted or rejected

That distinction matters for research hygiene. If a bundle changes and we cannot explain the change from controller-visible evidence, the helper stack is too strong.

The operator layer is especially sensitive here. Operator replay and certification are allowed to say “this recipe is dead,” “this recipe sharpens collapse,” or “this recipe looks like a self/bridge actuator.” They should not silently decide the episode. The controller remains responsible for turning that evidence into `apply`, `noop`, `rollback`, or a diagnostic request.

## Near-Term Roadmap

The next steps are now fairly concrete:

1. Keep operator certification under controller ownership.
   Operator replay is now powerful enough to shape the agenda, so it must remain an auditable evidence source rather than an implicit policy layer.
2. Keep selector and gate mostly frozen while operator quality is the active workstream.
   The main measurement axis is now operator certification and ownership, not candidate churn.
3. Treat production-trial failure as structured evidence.
   A harmful or regressing trial should create an explicit recipe veto and an alternate-candidate search, not a retry of the same ladder.
4. Convert rank carriers into target actuators.
   Current replay can find self-owned entity/readout carriers, then route those
   rows into `readout_steering_deepening`, but not yet consistently produce
   `self_target_actuator` recipes with target mass/top20 lift.
5. Search for a `budget` self-actuator recipe.
   Current real-packet replay shows that several recipes move something, but the lift is often rank-only, stolen by `send`, or unsafe at production-trial strength.
6. Continue ownership-first operator sweeps.
   Current promising directions are:
   - more local positive seeds such as `exact_term_token`, fused seeds, and centered local windows
   - contrastive recipes such as `minus_stealer` and `orthogonal_stealer`
   - recipe-level certification keyed by operator recipe rather than broad family alone
7. Use alternate activation-patch candidates as a bounded ladder.
   The current loop can now descend from a failed high-alpha recipe to a lower-alpha alternate recipe while preserving controller ownership.
   The next run should follow that alternate through promotion review, shadow
   replay, and trial comparison without reusing the failed recipe identity.
8. If no `budget` self-actuator appears, promote an explicit bridge plan.
   In that branch the controller would treat `budget` as the objective term and a certified `send` bridge as the readout-escape actuator, rather than pretending the lift already belongs to `budget`.
9. Expand the readout analyzer backend carefully.
   SAELens can move from scaffold to real backend only if it stays a feature emitter that returns small, auditable hints rather than becoming a runtime dependency or hidden generator.

## Design Guardrails

The current design tries hard not to drift into hidden-answer injection.

- The worker remains the main actor.
- The controller chooses bounded interventions, not free-form answers.
- Auxiliary controls stay soft, local, and inspectable.
- Sidecars are allowed to emit evidence, focus suggestions, and veto signals, but not to become covert channels or de facto policy owners.

For the current “healthy tweaking” framing, see [healthy_tweaking_control_planes.md](docs/healthy_tweaking_control_planes.md).

## Quick start

```bash
python3 -m pytest -q SpiralInterventionLab/tests
```

To run the first end-to-end experiment once your controller API key is set:

```bash
python3 -m SpiralInterventionLab.examples.digit_transform_e2e \
  --provider openai \
  --controller-model gpt-4.1-mini \
  --worker-model gpt2-small \
  --seed 7
```

To enable the current heuristic readout analyzer while keeping it strictly bounded:

```bash
python3 -m SpiralInterventionLab.examples.digit_transform_e2e \
  --provider openai \
  --controller-model gpt-4.1-mini \
  --worker-model gpt2-small \
  --task constrained_rewrite \
  --readout-analyzer heuristic \
  --seed 7
```

Controller API calls use the compact prompt and compact packet view by default
from the CLI. The raw evidence remains in JSONL logs, while the controller sees
bounded top-k summaries plus omitted counts and prompt-size telemetry in
`controller_provider_attempt.request`. Use `--controller-prompt-profile full`
and/or `--controller-packet-view full` when you need the older full-context
behavior for debugging.

To ask the controller provider for a quarantined qualitative memo after a run,
add a log directory and enable the post-run debrief:

```bash
python3 -m SpiralInterventionLab.examples.digit_transform_e2e \
  --provider openai \
  --controller-model gpt-4.1-mini \
  --worker-model gpt2-small \
  --task constrained_rewrite_easy \
  --log-dir results/easy_debrief \
  --post-run-debrief controller
```

This writes `post_run_debrief.md` and `post_run_debrief.json` under the log
directory. The debrief is intentionally qualitative: it is not used for scoring,
not fed into the next run, and not treated as paper-ready evidence. Its job is
to produce an audit-style memo about what the controller trajectory made hard to
solve, what evidence supports that reading, and what diagnostics look worth
trying next. The memo also includes a short `Controller-perspective note` section
for first-person trajectory interpretation, but that section is explicitly an
interpretation layer rather than evidence or hidden chain-of-thought.

The bounded interview view includes missing-term refreshes, blueprint reviews,
diagnostic-budget exhaustion, signed bound-piece responses and task constraints.
It distinguishes a final-output task check from older prefix feedback. A failed
positive-response gate does not, by itself, establish noisy or irreproducible
measurements. To audit a previous interview's input without another model call:

```bash
python3 -m SpiralInterventionLab.examples.rebuild_post_run_debrief \
  --log-dir results/easy_debrief \
  --output-dir results/easy_debrief_input_audit
```

The output directory must be new. This writes a rebuilt input and a coverage /
accounting comparison, not a new interview; original logs and memos remain intact.

For a lighter constrained-rewrite calibration run:

```bash
python3 -m SpiralInterventionLab.examples.digit_transform_e2e \
  --provider openai \
  --controller-model gpt-4.1-mini \
  --worker-model gpt2 \
  --task constrained_rewrite_easy \
  --seed 7
```

`--readout-sidecar-analyzer` remains available as a backward-compatible alias, but
`--readout-analyzer` is now the preferred public name.

To enable the current SAE-style scaffold without adding SAELens as a dependency:

```bash
python3 -m SpiralInterventionLab.examples.digit_transform_e2e \
  --provider openai \
  --controller-model gpt-4.1-mini \
  --worker-model gpt2-small \
  --task constrained_rewrite \
  --readout-analyzer sae_scaffold \
  --seed 7
```

This mode emits feature-like evidence only. It does not perform production SAE steering.

To force a fully local Hugging Face worker load:

```bash
python3 -m SpiralInterventionLab.examples.digit_transform_e2e \
  --provider openai \
  --controller-model gpt-4.1-mini \
  --worker-model gpt2 \
  --worker-model-path "$SPIRAL_WORKER_MODEL_PATH" \
  --worker-hf-offline \
  --seed 7
```

When using `--worker-model-path`, keep `--worker-model` set to the matching
TransformerLens-supported family name such as `gpt2`. If the tokenizer is stored
separately, also pass `--worker-tokenizer-path "$SPIRAL_WORKER_TOKENIZER_PATH"`.

or:

```bash
python3 -m unittest discover -s SpiralInterventionLab/tests -q
```

## Notes

- `torch` is a base dependency.
- `transformers`, `mlx-lm`, `openai`, `anthropic`, `mistralai`, and `google-genai` now live behind optional extras so local/backend and controller stacks can be installed independently.
- `transformer-lens` is optional, but required for the real HookedTransformer path.
- The package directory is still `SpiralInterventionLab/` for now to keep the initial extraction low-risk. We can normalize that later once the dedicated repo settles.
