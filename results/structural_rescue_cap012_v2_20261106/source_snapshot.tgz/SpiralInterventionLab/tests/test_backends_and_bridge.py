import unittest
from importlib.util import find_spec
from unittest.mock import patch

import numpy as np
import torch

from SpiralInterventionLab.backends.base import (
    AutoregressiveBackend,
    BackendCapabilities,
    BackendStepResult,
    LocalBackendWorkerRuntime,
)
from SpiralInterventionLab.backends.hf_transformers import HFTransformersBackend
from SpiralInterventionLab.backends.mlx_lm import MLXLMBackend
from SpiralInterventionLab.bridge.controller_clients import (
    ProviderControllerClient,
    ProviderPromptHintController,
    _normalize_controller_payload,
    load_prompt_asset,
)
from SpiralInterventionLab.controllers.base import ControllerProvider, ControllerProviderRequest, ControllerProviderResponse
from SpiralInterventionLab.controllers.providers import AnthropicControllerProvider, OpenAIControllerProvider
from SpiralInterventionLab.runtime.baselines import run_b1
from SpiralInterventionLab.runtime.codecs import CharacterCodec
from SpiralInterventionLab.runtime.schema import parse_observation_packet

HAS_TRANSFORMERS = bool(find_spec("transformers"))
if HAS_TRANSFORMERS:
    from transformers import GPT2Config, GPT2LMHeadModel


class _FakeProvider(ControllerProvider):
    def __init__(self, *responses: str, model_name: str = "fake-model"):
        self.responses = list(responses)
        self._model_name = str(model_name)
        self.requests: list[ControllerProviderRequest] = []

    @property
    def provider_name(self) -> str:
        return "fake"

    @property
    def model_name(self) -> str:
        return self._model_name

    def complete(self, request: ControllerProviderRequest) -> ControllerProviderResponse:
        self.requests.append(request)
        text = self.responses.pop(0) if self.responses else ""
        return ControllerProviderResponse(text=text, provider=self.provider_name, model=self.model_name)


class _FakeLocalBackend(AutoregressiveBackend):
    def __init__(self) -> None:
        self.codec = CharacterCodec(" pabc")
        self.capabilities = BackendCapabilities(backend_name="fake_local", device="cpu", supports_logits=True)
        self.prompt = ""
        self.context_ids: list[int] = []
        self.output_ids: list[int] = []
        self.last_logits: torch.Tensor | None = None

    def reset(self, prompt: str) -> None:
        self.prompt = prompt
        self.context_ids = self.codec.encode(prompt).tolist()
        self.output_ids = []
        self.last_logits = None

    def step(self) -> BackendStepResult:
        emit_b = "b" in self.codec.decode(self.context_ids)
        token_id = 3 if emit_b else 2
        logits = torch.tensor([0.1, 0.2, 0.8 if not emit_b else 0.1, 0.8 if emit_b else 0.1, 0.0], dtype=torch.float32)
        self.context_ids.append(token_id)
        self.output_ids.append(token_id)
        self.last_logits = logits
        return BackendStepResult(token_id=token_id, token_text=self.decode_tokens([token_id]), logits=logits)

    def append_prompt_hint(self, hint: str) -> bool:
        token_ids = self.codec.encode(hint).tolist()
        if not token_ids:
            return False
        self.context_ids.extend(token_ids)
        return True

    def current_tokens(self) -> torch.Tensor:
        return torch.tensor([self.context_ids], dtype=torch.long)

    def output_token_ids(self) -> list[int]:
        return list(self.output_ids)

    def decode_tokens(self, token_ids):
        return self.codec.decode(token_ids)

    def final_text(self) -> str:
        return self.codec.decode(self.output_ids)

    def last_logits_tensor(self) -> torch.Tensor | None:
        return None if self.last_logits is None else self.last_logits.detach().clone()


class _SingleHintTaskEnv:
    def reset(self, seed: int) -> str:
        self.seed = seed
        return "p"

    def score(self, output: str) -> float:
        return 1.0 if "b" in output else 0.0

    def done(self, output: str) -> bool:
        return len(output) >= 2


class _FakeTokenizer:
    def encode(self, text: str):
        return [ord(char) % 11 for char in text]

    def decode(self, token_ids):
        if isinstance(token_ids, torch.Tensor):
            token_ids = token_ids.detach().reshape(-1).tolist()
        return "".join(chr(97 + (int(token_id) % 26)) for token_id in token_ids)


class _FakeMLXResponse:
    def __init__(self, token: int, text: str, *, finish_reason=None):
        self.token = token
        self.text = text
        self.logprobs = np.array([0.1, 0.2, 0.7], dtype=np.float32)
        self.finish_reason = finish_reason


class _FakeOpenAIResponsesAPI:
    def __init__(self) -> None:
        self.calls: list[dict] = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return type("FakeResponse", (), {"output_text": "{\"version\":\"0.1\",\"decision\":\"noop\"}", "usage": {}})()


class _FakeOpenAIClient:
    def __init__(self) -> None:
        self.responses = _FakeOpenAIResponsesAPI()


class _FakeAnthropicMessagesAPI:
    def __init__(self) -> None:
        self.calls: list[dict] = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        block = type("FakeAnthropicBlock", (), {"text": "{\"version\":\"0.1\",\"decision\":\"noop\"}"})()
        return type("FakeAnthropicResponse", (), {"content": [block], "usage": {}})()


class _FakeAnthropicClient:
    def __init__(self) -> None:
        self.messages = _FakeAnthropicMessagesAPI()


class TestBackendsAndBridge(unittest.TestCase):
    def test_provider_controller_client_retries_until_valid_json(self):
        provider = _FakeProvider("not json", "```json\n{\"version\":\"0.1\",\"decision\":\"noop\"}\n```")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=2)

        command = client.invoke({"step": 1})
        trace = client.latest_trace()

        self.assertEqual(command.decision, "noop")
        self.assertEqual(len(provider.requests), 2)
        self.assertIn("Previous reply was invalid", provider.requests[-1].effective_system_prompt())
        self.assertIsNotNone(trace)
        self.assertEqual(trace["observation"]["step"], 1)
        self.assertEqual(len(trace["attempts"]), 2)
        self.assertFalse(trace["attempts"][0]["parse_ok"])
        self.assertTrue(trace["attempts"][1]["parse_ok"])
        self.assertEqual(trace["decision"]["decision"], "noop")

    def test_provider_controller_client_backfills_missing_version(self):
        provider = _FakeProvider("{\"decision\":\"noop\"}")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})

        self.assertEqual(command.version, "0.1")
        self.assertEqual(command.decision, "noop")

    def test_provider_controller_client_expands_output_budget_in_readout_escape(self):
        provider = _FakeProvider("{\"version\":\"0.1\",\"decision\":\"noop\"}")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1, max_output_tokens=200)

        client.invoke(
            {
                "step": 1,
                "control_phase_hint": "readout_escape",
                "strategy_hints": {
                    "gate_report_challenger_bundle_key": "kv_pair:send:source_body:8:10",
                    "bridge_plan_available": True,
                },
            }
        )

        self.assertGreater(provider.requests[0].max_output_tokens, 200)
        self.assertEqual(client.latest_trace()["effective_max_output_tokens"], provider.requests[0].max_output_tokens)

    def test_provider_controller_client_uses_gpt5_output_floor(self):
        provider = _FakeProvider("{\"version\":\"0.1\",\"decision\":\"noop\"}", model_name="gpt-5.5")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1, max_output_tokens=800)

        client.invoke({"step": 1})

        self.assertEqual(provider.requests[0].max_output_tokens, 1600)
        self.assertEqual(client.latest_trace()["effective_max_output_tokens"], 1600)

    def test_provider_controller_client_uses_claude5_output_floor(self):
        provider = _FakeProvider("{\"version\":\"0.1\",\"decision\":\"noop\"}", model_name="claude-sonnet-5")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1, max_output_tokens=800)

        client.invoke({"step": 1})

        self.assertEqual(provider.requests[0].max_output_tokens, 4096)
        self.assertEqual(client.latest_trace()["effective_max_output_tokens"], 4096)

    def test_provider_controller_client_keeps_default_budget_for_version_first_claude(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\"}",
            model_name="claude-3-5-sonnet-20241022",
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1, max_output_tokens=800)

        client.invoke({"step": 1})

        self.assertEqual(provider.requests[0].max_output_tokens, 800)

    def test_provider_controller_client_compact_packet_view_summarizes_payload(self):
        provider = _FakeProvider("{\"version\":\"0.1\",\"decision\":\"noop\"}")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1, packet_view="compact")

        client.invoke(
            {
                "version": "0.1",
                "step": 2,
                "task_view": {"task_id": "toy_task", "mode": "redacted", "prompt_hash": "sha256:test"},
                "worker_view": {"generated_tail": "the the", "status": "acting"},
                "task_feedback": {"done": False, "partial_score": 0.45},
                "surface_catalog": [
                    {"surface_id": "s_resid_pre_l4_last", "target": {"kind": "activation"}, "caps": {"alpha": 0.08}}
                ],
                "probe_frames": [{"surface_id": "s_resid_pre_l4_last", "stats": {"norm": 1.2, "delta_prev": 0.1}}],
                "trace_bank": [{"trace_id": "paired_baseline", "score": 0.45}],
                "recent_effects": [],
                "recent_effect_summary": {"window_size": 0},
                "telemetry": {},
                "budget": {},
                "control_phase_hint": "readout_escape",
                "strategy_hints": {
                    "selected_bundle_key": "bundle_a",
                    "diagnostic_frontier_operator_recipe_expansion_mode": "readout_steering_deepening",
                    "diagnostic_frontier_canonical_request": {
                        "diagnostic": "compare_extra_operator_diagnostics",
                        "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                        "operator_recipe_expansion_mode": "readout_steering_deepening",
                    },
                    "available_next_diagnostics": [
                        {
                            "diagnostic": "compare_extra_operator_diagnostics",
                            "request": {
                                "diagnostic": "compare_extra_operator_diagnostics",
                                "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                                "operator_recipe_expansion_mode": "readout_steering_deepening",
                            },
                        }
                    ],
                    "blocked_next_diagnostics": [
                        {
                            "diagnostic": "attention_readout_carrier_probe",
                            "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                            "reason": "requires_cached_attention_rows",
                            "suggested_alternate_diagnostic": "attention_head_ablation_on_frontier",
                        }
                    ],
                    "diagnostic_unavailable_vetoes": [
                        {
                            "diagnostic": "attention_readout_carrier_probe",
                            "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                            "reason": "requires_cached_attention_rows",
                        }
                    ],
                    "readout_deepening_review_status": "complete",
                    "readout_deepening_review_summary": {
                        "readout_deepening_review_status": "complete",
                        "best_candidate_role": "gap_closer_candidate",
                        "production_trial_eligible": False,
                        "recommended_next_action": "request_readout_gap_confirmation_or_variant_sweep",
                        "recommended_next_evidence": "readout_gap_confirmation_or_variant_sweep",
                    },
                    "readout_deepening_recommended_next_action": "request_readout_gap_confirmation_or_variant_sweep",
                    "rotated_entity_operator_deepening_recommended": True,
                    "diagnostic_budget_reserved_for_rotation": True,
                    "rotation_budget_reserve_reason": "rotated_entity_operator_replay_needs_readout_steering_deepening",
                    "rotation_budget_reserved_diagnostics": ["compare_extra_operator_diagnostics"],
                    "positive_operator_deepening_plan": {"recipe_name": "r1", "traits": ["rank_carrier"]},
                    "large_unneeded_blob": [{"x": index} for index in range(30)],
                },
                "latest_diagnostic_results": [
                    {
                        "diagnostic": "compare_extra_operator_diagnostics",
                        "canonical_followup_request": {
                            "diagnostic": "compare_extra_operator_diagnostics",
                            "objective_bundle_key": "entity_insert:mira:source_body:near_reachable",
                            "operator_recipe_expansion_mode": "readout_steering_deepening",
                        },
                        "readout_deepening_review_status": "complete",
                        "readout_deepening_review_summary": {
                            "readout_deepening_review_status": "complete",
                            "best_candidate_role": "gap_closer_candidate",
                            "recommended_next_action": "request_readout_gap_confirmation_or_variant_sweep",
                            "recommended_operator_recipe_expansion_mode": "readout_gap_confirmation_or_variant_sweep",
                        },
                        "evidence_rows": [
                            {"recipe_name": f"r{index}", "target_top20_threshold_gap_delta": -0.1}
                            for index in range(10)
                        ],
                    }
                ],
            }
        )

        sent_payload = provider.requests[0].payload
        trace = client.latest_trace()

        self.assertEqual(sent_payload["packet_view"], "compact_v1")
        self.assertEqual(sent_payload["control_phase_hint"], "readout_escape")
        self.assertIn("source_packet_sha256", sent_payload)
        self.assertEqual(sent_payload["strategy_hints"]["selected_bundle_key"], "bundle_a")
        self.assertEqual(
            sent_payload["strategy_hints"]["diagnostic_frontier_operator_recipe_expansion_mode"],
            "readout_steering_deepening",
        )
        self.assertEqual(
            sent_payload["strategy_hints"]["diagnostic_frontier_canonical_request"]["objective_bundle_key"],
            "entity_insert:mira:source_body:near_reachable",
        )
        self.assertEqual(
            sent_payload["strategy_hints"]["available_next_diagnostics"][0]["request"][
                "operator_recipe_expansion_mode"
            ],
            "readout_steering_deepening",
        )
        self.assertEqual(
            sent_payload["strategy_hints"]["blocked_next_diagnostics"][0]["diagnostic"],
            "attention_readout_carrier_probe",
        )
        self.assertEqual(
            sent_payload["strategy_hints"]["diagnostic_unavailable_vetoes"][0]["reason"],
            "requires_cached_attention_rows",
        )
        self.assertEqual(
            sent_payload["latest_diagnostic_results"][0]["canonical_followup_request"][
                "operator_recipe_expansion_mode"
            ],
            "readout_steering_deepening",
        )
        self.assertEqual(
            sent_payload["strategy_hints"]["readout_deepening_review_summary"]["best_candidate_role"],
            "gap_closer_candidate",
        )
        self.assertTrue(sent_payload["strategy_hints"]["rotated_entity_operator_deepening_recommended"])
        self.assertTrue(sent_payload["strategy_hints"]["diagnostic_budget_reserved_for_rotation"])
        self.assertEqual(
            sent_payload["strategy_hints"]["rotation_budget_reserved_diagnostics"],
            ["compare_extra_operator_diagnostics"],
        )
        self.assertEqual(
            sent_payload["latest_diagnostic_results"][0]["readout_deepening_review_summary"][
                "recommended_operator_recipe_expansion_mode"
            ],
            "readout_gap_confirmation_or_variant_sweep",
        )
        self.assertIn("__omitted_hint_key_count", sent_payload["strategy_hints"])
        self.assertIn("surface_catalog", sent_payload)
        self.assertLess(trace["provider_payload_char_count"], trace["raw_payload_char_count"])
        self.assertEqual(trace["packet_view"], "compact")
        self.assertIn("rough_input_token_estimate", trace["attempts"][0]["request"])

    def test_provider_controller_client_observation_includes_task_feedback(self):
        provider = _FakeProvider("{\"version\":\"0.1\",\"decision\":\"noop\"}")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        client.invoke(
            {
                "step": 1,
                "task_view": {"task_id": "toy_task", "mode": "redacted", "prompt_hash": "sha256:test"},
                "worker_view": {"generated_tail": "12", "status": "acting"},
                "task_feedback": {"done": False, "partial_score": 0.5, "progress_label": "progressing"},
                "surface_catalog": [],
                "trace_bank": [],
                "active_edits": [],
                "recent_effects": [],
                "recent_effect_summary": {"window_size": 0},
                "telemetry": {},
                "budget": {},
            }
        )
        trace = client.latest_trace()

        self.assertIsNotNone(trace)
        self.assertEqual(trace["observation"]["task_feedback"]["partial_score"], 0.5)
        self.assertEqual(trace["observation"]["task_feedback"]["progress_label"], "progressing")

    def test_provider_controller_client_observation_includes_latest_observer_check(self):
        provider = _FakeProvider("{\"version\":\"0.1\",\"decision\":\"noop\"}")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        client.invoke(
            {
                "step": 1,
                "task_view": {"task_id": "toy_task", "mode": "redacted", "prompt_hash": "sha256:test"},
                "worker_view": {"generated_tail": "12", "status": "acting"},
                "task_feedback": {"done": False, "partial_score": 0.5, "progress_label": "progressing"},
                "latest_observer_check": {
                    "check_type": "semantic_progress",
                    "trigger": "coverage_progress",
                    "verdict": "baseline",
                    "score": 0.77,
                    "coverage_weight": 1.0,
                    "latent_feature_scan": {
                        "prototype_mode": "token_embedding_mean",
                        "surface_count": 2,
                        "group_count": 1,
                        "groups": [
                            {
                                "group": "required_terms",
                                "polarity": "promote",
                                "feature_count": 2,
                                "mean_alignment": 0.18,
                                "top_features": [
                                    {"feature": "Mira", "surface_id": "s_resid_pre_l4_last", "alignment": 0.24}
                                ],
                            }
                        ],
                    },
                    "kv_feature_scan": {
                        "projection_mode": "attn_weight_head_projection",
                        "surface_count": 4,
                        "group_count": 1,
                        "groups": [
                            {
                                "group": "required_terms",
                                "polarity": "promote",
                                "feature_count": 2,
                                "mean_alignment": 0.15,
                                "top_features": [
                                    {"feature": "Mira", "site": "v_cache", "layer": 4, "head": 1, "alignment": 0.22}
                                ],
                            }
                        ],
                    },
                },
                "recent_observer_checks": [
                    {
                        "check_type": "semantic_progress",
                        "trigger": "coverage_progress",
                        "verdict": "baseline",
                        "score": 0.77,
                    }
                ],
                "surface_catalog": [],
                "trace_bank": [],
                "active_edits": [],
                "recent_effects": [],
                "recent_effect_summary": {"window_size": 0},
                "telemetry": {"observer_check_count": 1},
                "budget": {},
            }
        )
        trace = client.latest_trace()

        self.assertIsNotNone(trace)
        self.assertEqual(trace["observation"]["latest_observer_check"]["trigger"], "coverage_progress")
        self.assertEqual(trace["observation"]["recent_observer_checks"][0]["score"], 0.77)
        self.assertEqual(
            trace["observation"]["latest_observer_check"]["latent_feature_scan"]["groups"][0]["group"],
            "required_terms",
        )
        self.assertEqual(
            trace["observation"]["latest_observer_check"]["kv_feature_scan"]["groups"][0]["top_features"][0]["site"],
            "v_cache",
        )

    def test_provider_controller_client_observation_includes_tool_catalog_and_results(self):
        provider = _FakeProvider("{\"version\":\"0.1\",\"decision\":\"noop\"}")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        client.invoke(
            {
                "step": 1,
                "task_view": {"task_id": "toy_task", "mode": "redacted", "prompt_hash": "sha256:test"},
                "worker_view": {"generated_tail": "12", "status": "acting"},
                "surface_catalog": [],
                "trace_bank": [],
                "active_edits": [],
                "recent_effects": [],
                "recent_effect_summary": {"window_size": 0},
                "telemetry": {"tool_call_count": 2},
                "control_phase_hint": "entity_insertion",
                "strategy_hints": {
                    "loop_severity": "low",
                    "prefer_space_prefixed_logit_bias": True,
                    "prefer_auxiliary_entity_bias": True,
                    "direct_entity_edit_gate": "auxiliary_first",
                    "easy_entity_terms": ["budget"],
                    "hard_entity_terms": ["Mira"],
                    "shot_mode_ready": False,
                    "shot_probe_needed": False,
                    "kv_probe_needed": True,
                    "shot_candidate_edits": [
                        {"surface_id": "s_resid_pre_l3_prev", "kind": "resid_add", "alpha": 0.04, "ttl_steps": 1, "step_size": 0.04, "role": "shot_prev_anchor"}
                    ],
                    "kv_candidate_edits": [
                        {
                            "surface_id": "s_v_cache_l4_h1_last_promoted",
                            "kind": "kv_mix",
                            "site": "v_cache",
                            "layer": 4,
                            "head": 1,
                            "source_position": 12,
                            "source_relative_index": -6,
                            "source_piece": " budget",
                            "source_segment_kind": "prompt",
                            "canary_checked": True,
                            "canary_pass": True,
                            "canary_focus_piece": " budget",
                            "canary_focus_logit_delta": 0.012,
                            "source": {
                                "dtype": "cache_pair",
                                "v": {
                                    "ref": {
                                        "scope": "runtime",
                                        "worker": "os_0",
                                        "tensor": "v_cache",
                                        "layer": 4,
                                        "head": 1,
                                        "token": {"mode": "index", "value": 12},
                                    }
                                },
                            },
                            "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
                            "budget": {"ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.04, "revertible": True},
                            "role": "kv_shot_v_source_anchor",
                        }
                    ],
                    "preferred_shot_surface_id": "s_resid_pre_l3_prev",
                    "preferred_kv_surface_id": "s_v_cache_l4_h1_last_promoted",
                    "loop_break_attempt_count": 1,
                    "stabilizing_only_count": 0,
                    "l4_term_nudge_cooldown": True,
                },
                "budget": {},
                "tool_catalog": [
                    {"tool": "tokenize_terms", "available": True, "cost_hint": "cheap", "budget_left": 4},
                    {"tool": "dry_run_decode", "available": True, "cost_hint": "expensive", "budget_left": 4},
                ],
                "latest_tool_results": [
                    {
                        "tool": "tokenize_terms",
                        "status": "ok",
                        "term_count": 2,
                        "terms": [
                            {"term": "Mira", "piece_count": 2, "control_profile": "sequence_bias_plus_patience"},
                            {"term": "budget", "piece_count": 1, "control_profile": "single_token_bias_ok"},
                        ],
                        "soft_logit_bias_ok_terms": ["budget"],
                        "needs_sequence_support_terms": ["Mira"],
                    },
                    {
                        "tool": "dry_run_decode",
                        "status": "ok",
                        "entropy_delta": -0.1,
                        "required_term_recall_delta": 0.25,
                        "probe_family": "kv_v",
                        "probe_phase_profile": "readout_escape",
                        "probe_label": "weak_positive_subthreshold",
                        "positive_axes": ["readout"],
                        "probe_summary": {
                            "probe_family": "kv_v",
                            "probe_phase_profile": "readout_escape",
                            "label": "weak_positive_subthreshold",
                            "score": 0.7,
                            "readout_score": 0.8,
                            "constraint_score": 0.0,
                            "trajectory_score": 0.1,
                            "semantic_focus_term": "Mira",
                            "reachable_focus_term": "budget",
                            "reachable_focus_rank": 420,
                            "positive_axes": ["readout"],
                        },
                        "topk_token_diff": [{"piece": "M", "prob_delta": 0.2}],
                    },
                ],
                "latest_diagnostic_results": [
                    {
                        "diagnostic": "operator_diagnostic_replay",
                        "status": "ok",
                        "bundle_key": "kv_pair:budget:source_body:72:73",
                        "next_evidence_needed": "certified_self_or_bridge_actuator",
                        "operator_certified": False,
                        "production_apply_allowed": False,
                        "blocked_by": ["dead_actuator"],
                        "evidence_rows": [
                            {
                                "evidence_kind": "operator_replay",
                                "status": "blocked",
                                "actuator_class": "dead_actuator",
                            }
                        ],
                    }
                ],
            }
        )
        trace = client.latest_trace()

        self.assertEqual(trace["observation"]["tool_catalog"][0]["tool"], "tokenize_terms")
        self.assertEqual(trace["observation"]["control_phase_hint"], "entity_insertion")
        self.assertEqual(trace["observation"]["strategy_hints"]["loop_severity"], "low")
        self.assertTrue(trace["observation"]["strategy_hints"]["prefer_auxiliary_entity_bias"])
        self.assertEqual(trace["observation"]["strategy_hints"]["direct_entity_edit_gate"], "auxiliary_first")
        self.assertFalse(trace["observation"]["strategy_hints"]["shot_mode_ready"])
        self.assertFalse(trace["observation"]["strategy_hints"]["shot_probe_needed"])
        self.assertTrue(trace["observation"]["strategy_hints"]["kv_probe_needed"])
        self.assertEqual(trace["observation"]["strategy_hints"]["preferred_shot_surface_id"], "s_resid_pre_l3_prev")
        self.assertEqual(trace["observation"]["strategy_hints"]["preferred_kv_surface_id"], "s_v_cache_l4_h1_last_promoted")
        self.assertEqual(trace["observation"]["strategy_hints"]["shot_candidate_edits"][0]["surface_id"], "s_resid_pre_l3_prev")
        self.assertEqual(trace["observation"]["strategy_hints"]["kv_candidate_edits"][0]["surface_id"], "s_v_cache_l4_h1_last_promoted")
        self.assertEqual(trace["observation"]["strategy_hints"]["kv_candidate_edits"][0]["op"]["kind"], "kv_mix")
        self.assertTrue(trace["observation"]["strategy_hints"]["kv_candidate_edits"][0]["canary_pass"])
        self.assertEqual(trace["observation"]["strategy_hints"]["kv_candidate_edits"][0]["source_position"], 12)
        self.assertTrue(trace["observation"]["strategy_hints"]["l4_term_nudge_cooldown"])
        self.assertEqual(trace["observation"]["latest_tool_results"][0]["tool"], "tokenize_terms")
        self.assertEqual(trace["observation"]["latest_tool_results"][0]["soft_logit_bias_ok_terms"], ["budget"])
        self.assertEqual(trace["observation"]["latest_tool_results"][0]["needs_sequence_support_terms"], ["Mira"])
        self.assertEqual(trace["observation"]["latest_tool_results"][0]["term_profiles"][0]["control_profile"], "sequence_bias_plus_patience")
        self.assertEqual(trace["observation"]["latest_tool_results"][1]["tool"], "dry_run_decode")
        self.assertEqual(trace["observation"]["latest_tool_results"][1]["probe_family"], "kv_v")
        self.assertEqual(trace["observation"]["latest_tool_results"][1]["probe_summary"]["label"], "weak_positive_subthreshold")
        self.assertEqual(trace["observation"]["latest_tool_results"][1]["topk_token_diff"][0]["piece"], "M")
        self.assertEqual(trace["observation"]["latest_diagnostic_results"][0]["diagnostic"], "operator_diagnostic_replay")
        self.assertEqual(trace["observation"]["latest_diagnostic_results"][0]["blocked_by"], ["dead_actuator"])

    def test_provider_controller_client_observation_includes_controller_memory(self):
        provider = _FakeProvider("{\"version\":\"0.1\",\"decision\":\"noop\"}")
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        client.invoke(
            {
                "step": 2,
                "task_view": {"task_id": "toy_task", "mode": "redacted", "prompt_hash": "sha256:test"},
                "worker_view": {"generated_tail": "12", "status": "acting"},
                "task_feedback": {"done": False, "partial_score": 0.5, "progress_label": "progressing"},
                "surface_catalog": [],
                "trace_bank": [],
                "active_edits": [],
                "recent_effects": [],
                "recent_effect_summary": {"window_size": 0},
                "controller_memory": [
                    {
                        "hypothesis": "small_resid_loop_rescue",
                        "micro_rationale": "avoid another blind nudge",
                        "focus_term": "Omar",
                        "observed_outcome": "harmful",
                        "noop_reason": "hold_finish_budget",
                        "apply_block_reason": "same_family_escalation_without_gain",
                        "surface_family_key": "resid_add_s_resid_pre_l5_last",
                        "transfer_confidence": 0.22,
                        "same_family_escalation_risk": 0.81,
                        "finish_budget_reserved": 1,
                        "evidence_bullets": [
                            "helpful_on=budget@l5_last alpha=0.06",
                            "missing_term=Omar remains unproven",
                        ],
                        "next_change": "prefer noop",
                        "next_trigger": "loop_relief_without_coverage",
                        "next_action": "request_observer_check",
                        "confidence": 0.74,
                    }
                ],
                "telemetry": {},
                "budget": {},
            }
        )
        trace = client.latest_trace()

        self.assertIsNotNone(trace)
        self.assertEqual(trace["observation"]["controller_memory"][0]["hypothesis"], "small_resid_loop_rescue")
        self.assertEqual(trace["observation"]["controller_memory"][0]["micro_rationale"], "avoid another blind nudge")
        self.assertEqual(trace["observation"]["controller_memory"][0]["focus_term"], "Omar")
        self.assertEqual(trace["observation"]["controller_memory"][0]["observed_outcome"], "harmful")
        self.assertEqual(trace["observation"]["controller_memory"][0]["noop_reason"], "hold_finish_budget")
        self.assertEqual(
            trace["observation"]["controller_memory"][0]["apply_block_reason"],
            "same_family_escalation_without_gain",
        )
        self.assertEqual(trace["observation"]["controller_memory"][0]["surface_family_key"], "resid_add_s_resid_pre_l5_last")
        self.assertAlmostEqual(trace["observation"]["controller_memory"][0]["transfer_confidence"], 0.22)
        self.assertAlmostEqual(trace["observation"]["controller_memory"][0]["same_family_escalation_risk"], 0.81)
        self.assertEqual(trace["observation"]["controller_memory"][0]["finish_budget_reserved"], 1)
        self.assertEqual(
            trace["observation"]["controller_memory"][0]["evidence_bullets"][0],
            "helpful_on=budget@l5_last alpha=0.06",
        )
        self.assertEqual(trace["observation"]["controller_memory"][0]["next_trigger"], "loop_relief_without_coverage")
        self.assertEqual(trace["observation"]["controller_memory"][0]["next_action"], "request_observer_check")

    def test_provider_controller_client_normalizes_common_edit_shorthand(self):
        provider = _FakeProvider(
            "{\"decision\":\"apply\",\"edits\":[{\"edit_id\":\"e1\",\"surface_id\":\"s_resid_l1_last\",\"source\":{\"dtype\":\"vector\",\"expr\":{\"fn\":\"sub\",\"a\":{\"ref\":{\"scope\":\"runtime\",\"worker\":\"os_0\",\"tensor\":\"hidden\",\"layer\":1,\"token\":{\"mode\":\"last\"}}},\"b\":{\"ref\":{\"scope\":\"runtime\",\"worker\":\"os_0\",\"tensor\":\"hidden\",\"layer\":1,\"token\":{\"mode\":\"last\"}}}}},\"op\":{\"kind\":\"resid_add\",\"alpha\":0.1},\"ttl_steps\":1}]}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})

        self.assertEqual(command.version, "0.1")
        self.assertEqual(command.decision, "apply")
        self.assertEqual(command.edits[0].id, "e1")
        self.assertEqual(command.edits[0].budget.ttl_steps, 1)

    def test_provider_controller_client_moves_controller_memory_into_meta(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\",\"controller_memory\":{\"hypothesis\":\"rescue\",\"observed_outcome\":\"harmful\",\"next_change\":\"noop\",\"confidence\":0.5}}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})
        trace = client.latest_trace()

        self.assertEqual(command.meta["controller_memory"]["hypothesis"], "rescue")
        self.assertEqual(trace["decision"]["controller_memory"]["observed_outcome"], "harmful")

    def test_provider_controller_client_lifts_dual_plan_fields_from_controller_memory(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\",\"controller_memory\":{\"objective_bundle_key\":\"budget_bundle\",\"step_actuator_bundle_key\":\"send_bridge\",\"why_not_apply\":\"bridge remains shadow_only until certified_for_apply\",\"shadow_proposals\":[{\"kind\":\"bridge_shadow\",\"bundle_key\":\"send_bridge\",\"objective_bundle_key\":\"budget_bundle\",\"actuator_bundle_key\":\"send_bridge\",\"reason\":\"bridge remains shadow_only until certified_for_apply\",\"decision\":\"shadow\"}]}}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})
        trace = client.latest_trace()

        self.assertEqual(command.meta["objective_bundle_key"], "budget_bundle")
        self.assertEqual(command.meta["step_actuator_bundle_key"], "send_bridge")
        self.assertEqual(command.meta["why_not_apply"], "bridge remains shadow_only until certified_for_apply")
        self.assertEqual(command.meta["shadow_proposals"][0]["bundle_key"], "send_bridge")
        self.assertEqual(trace["decision"]["objective_bundle_key"], "budget_bundle")
        self.assertEqual(trace["decision"]["step_actuator_bundle_key"], "send_bridge")
        self.assertEqual(trace["decision"]["plan_mode"], "dual_layer")
        self.assertEqual(trace["decision"]["shadow_proposals"][0]["bundle_key"], "send_bridge")

    def test_provider_controller_client_attempt_trace_includes_normalized_payload_diff(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\",\"controller_memory\":{\"objective_bundle_key\":\"budget_bundle\",\"step_actuator_bundle_key\":\"send_bridge\"},\"shadow_plan\":[{\"bundle_key\":\"send_bridge\",\"decision\":\"shadow\"}]}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        client.invoke({"step": 1})
        trace = client.latest_trace()

        attempt = trace["attempts"][0]
        self.assertIn("raw_json_object", attempt)
        self.assertIn("normalized_payload", attempt)
        self.assertIn("normalization_delta", attempt)
        self.assertIn("moved_into_meta", attempt["normalization_delta"])
        self.assertIn("controller_memory", attempt["normalization_delta"]["moved_into_meta"])
        self.assertEqual(
            attempt["normalized_payload"]["meta"]["objective_bundle_key"],
            "budget_bundle",
        )
        self.assertEqual(
            attempt["normalized_payload"]["meta"]["shadow_proposals"][0]["bundle_key"],
            "send_bridge",
        )

    def test_provider_controller_client_moves_endgame_memory_fields_into_meta(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\",\"noop_reason\":\"hold_finish_budget\",\"apply_block_reason\":\"same_family_escalation_without_gain\",\"focus_term\":\"Omar\",\"surface_family_key\":\"resid_add_s_resid_pre_l5_last\",\"transfer_confidence\":0.2,\"same_family_escalation_risk\":0.8,\"finish_budget_reserved\":1,\"evidence_bullets\":[\"helpful_on=budget@l5_last alpha=0.06\",\"missing_term=Omar remains unproven\"]}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})
        trace = client.latest_trace()

        self.assertEqual(command.meta["noop_reason"], "hold_finish_budget")
        self.assertEqual(command.meta["apply_block_reason"], "same_family_escalation_without_gain")
        self.assertEqual(command.meta["focus_term"], "Omar")
        self.assertEqual(command.meta["surface_family_key"], "resid_add_s_resid_pre_l5_last")
        self.assertAlmostEqual(command.meta["transfer_confidence"], 0.2)
        self.assertAlmostEqual(command.meta["same_family_escalation_risk"], 0.8)
        self.assertEqual(command.meta["finish_budget_reserved"], 1)
        self.assertEqual(command.meta["evidence_bullets"][0], "helpful_on=budget@l5_last alpha=0.06")
        self.assertEqual(trace["decision"]["controller_memory"]["noop_reason"], "hold_finish_budget")
        self.assertEqual(trace["decision"]["controller_memory"]["focus_term"], "Omar")
        self.assertEqual(trace["decision"]["controller_memory"]["finish_budget_reserved"], 1)

    def test_provider_controller_client_normalizes_observer_request_and_micro_rationale_into_meta(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\",\"request_observer_check\":{\"kind\":\"semantic_progress\",\"reason\":\"fresh semantic read after loop relief\"},\"micro_rationale\":\"Loop eased, but coverage is still zero.\"}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})
        trace = client.latest_trace()

        self.assertEqual(command.meta["observer_check_request"]["kind"], "semantic_progress")
        self.assertEqual(command.meta["micro_rationale"], "Loop eased, but coverage is still zero.")
        self.assertEqual(trace["decision"]["observer_check_request"]["kind"], "semantic_progress")
        self.assertEqual(trace["decision"]["micro_rationale"], "Loop eased, but coverage is still zero.")

    def test_provider_controller_client_normalizes_tool_requests_into_meta(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\",\"request_tools\":[{\"tool\":\"tokenize_terms\",\"terms\":[\"Mira\",\"Omar\"]},{\"tool\":\"dry_run_decode\",\"candidate_edit\":{\"surface_id\":\"s_resid_pre_l4_last\",\"kind\":\"resid_add\",\"alpha\":0.04,\"ttl_steps\":1},\"max_new_tokens\":4}]}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})
        trace = client.latest_trace()

        self.assertEqual(command.meta["tool_requests"][0]["tool"], "tokenize_terms")
        self.assertEqual(command.meta["tool_requests"][1]["tool"], "dry_run_decode")
        self.assertEqual(trace["decision"]["tool_requests"][0]["term_count"], 2)
        self.assertEqual(trace["decision"]["tool_requests"][1]["surface_id"], "s_resid_pre_l4_last")

    def test_provider_controller_client_normalizes_diagnostic_request_into_meta(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\",\"request_diagnostic\":\"operator_diagnostic_replay\",\"next_evidence_needed\":\"certified_self_or_bridge_actuator\",\"next_action\":\"request_operator_diagnostic\"}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})
        trace = client.latest_trace()

        self.assertEqual(command.meta["diagnostic_request"], "operator_diagnostic_replay")
        self.assertEqual(command.meta["next_evidence_needed"], "certified_self_or_bridge_actuator")
        self.assertEqual(trace["decision"]["controller_memory"]["diagnostic_request"], "operator_diagnostic_replay")

    def test_provider_controller_client_normalizes_next_trigger_and_action_into_meta(self):
        provider = _FakeProvider(
            "{\"version\":\"0.1\",\"decision\":\"noop\",\"micro_rationale\":\"wait for a clearer shift\",\"next_trigger\":\"loop relief without coverage\",\"next_action\":\"request observer check\"}"
        )
        client = ProviderControllerClient(provider, system_prompt="sys", max_attempts=1)

        command = client.invoke({"step": 1})
        trace = client.latest_trace()

        self.assertEqual(command.meta["next_trigger"], "loop relief without coverage")
        self.assertEqual(command.meta["next_action"], "request observer check")
        self.assertEqual(trace["decision"]["next_trigger"], "loop relief without coverage")
        self.assertEqual(trace["decision"]["next_action"], "request observer check")

    def test_normalize_controller_payload_keeps_target_surface_id_flat(self):
        normalized = _normalize_controller_payload(
            {
                "version": "0.1",
                "decision": "apply",
                "edits": [
                    {
                        "id": "e1",
                        "target": {"surface_id": "s_resid_l1_last"},
                        "source": {
                            "dtype": "vector",
                            "expr": {
                                "fn": "normalize",
                                "arg": {
                                    "ref": {
                                        "scope": "runtime",
                                        "worker": "os_0",
                                        "tensor": "hidden",
                                        "layer": 1,
                                        "token": {"mode": "last"},
                                    }
                                },
                            },
                        },
                        "op": {"kind": "resid_add", "alpha": 0.1},
                        "budget": {"ttl_steps": 1, "revertible": True},
                    }
                ],
            }
        )

        self.assertEqual(
            normalized["edits"][0]["target"],
            {"surface_id": "s_resid_l1_last"},
        )

    def test_normalize_controller_payload_accepts_project_orthogonal_aliases(self):
        normalized = _normalize_controller_payload(
            {
                "fn": "project_orthogonal",
                "input": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "hidden", "layer": 1, "token": {"mode": "last"}}},
                "against": {"ref": {"scope": "trace", "trace_id": "paired_baseline", "worker": "os_0", "tensor": "hidden", "layer": 1, "token": {"mode": "last"}}},
            }
        )

        self.assertEqual(normalized["fn"], "project_orthogonal")
        self.assertIn("arg", normalized)
        self.assertIn("basis", normalized)

    def test_normalize_controller_payload_rewrites_trace_scope_aliases(self):
        normalized = _normalize_controller_payload(
            {
                "ref": {
                    "scope": "paired_baseline",
                    "worker": "os_0",
                    "tensor": "hidden",
                    "layer": 1,
                    "token": {"mode": "last"},
                }
            }
        )

        self.assertEqual(normalized["ref"]["scope"], "trace")
        self.assertEqual(normalized["ref"]["trace_id"], "paired_baseline")

    def test_normalize_controller_payload_accepts_scale_alpha_alias(self):
        normalized = _normalize_controller_payload(
            {
                "fn": "scale",
                "alpha": -0.25,
                "arg": {
                    "ref": {
                        "scope": "runtime",
                        "worker": "os_0",
                        "tensor": "hidden",
                        "layer": 1,
                        "token": {"mode": "last"},
                    }
                },
            }
        )

        self.assertEqual(normalized["fn"], "scale")
        self.assertEqual(normalized["by"], -0.25)
        self.assertNotIn("alpha", normalized)

    def test_normalize_controller_payload_rewrites_prev_token_alias(self):
        normalized = _normalize_controller_payload(
            {
                "ref": {
                    "scope": "runtime",
                    "worker": "os_0",
                    "tensor": "hidden",
                    "layer": 1,
                    "token": {"mode": "prev"},
                }
            }
        )

        self.assertEqual(normalized["ref"]["token"]["mode"], "index")
        self.assertEqual(normalized["ref"]["token"]["value"], -2)

    def test_provider_prompt_hint_controller_trims_plain_text(self):
        provider = _FakeProvider("  try the digit near the end  \n")
        controller = ProviderPromptHintController(provider, system_prompt="sys")

        hint = controller.invoke({"step": 2})
        trace = controller.latest_trace()

        self.assertEqual(hint, "try the digit near the end")
        self.assertIsNotNone(trace)
        self.assertEqual(trace["observation"]["step"], 2)
        self.assertEqual(trace["decision"]["advice"], "try the digit near the end")

    def test_controller_prompt_asset_mentions_effect_summary_and_partial_score(self):
        prompt = load_prompt_asset("controller_v01.txt")

        self.assertIn("recent_effect_summary", prompt)
        self.assertIn("hypothesis_stats", prompt)
        self.assertIn("latest_effects", prompt)
        self.assertIn("partial_score", prompt)
        self.assertIn("semantic_progress_score", prompt)
        self.assertIn("latest_observer_check", prompt)
        self.assertIn("recent_observer_checks", prompt)
        self.assertIn("tool_catalog", prompt)
        self.assertIn("latest_tool_results", prompt)
        self.assertIn("recent_tool_results", prompt)
        self.assertIn("latent_feature_scan", prompt)
        self.assertIn("kv_feature_scan", prompt)
        self.assertIn("top_feature_hits", prompt)
        self.assertIn("k_cache/v_cache", prompt)
        self.assertIn("forbidden_phrases", prompt)
        self.assertIn("choose between provided surfaces", prompt)
        self.assertIn("s_resid_pre_l4_last", prompt)
        self.assertIn("research telemetry only", prompt)
        self.assertIn("latent_scan_prefers_l4_for_required_terms", prompt)
        self.assertIn("observer_check_budget_left", prompt)
        self.assertIn("tool_call_budget_left", prompt)
        self.assertIn("meta.observer_check_request", prompt)
        self.assertIn("meta.tool_requests", prompt)
        self.assertIn("meta.micro_rationale", prompt)
        self.assertIn("required_term_recall", prompt)
        self.assertIn("required_term_span_progress", prompt)
        self.assertIn("forbidden_term_clean", prompt)
        self.assertIn("budget_ok", prompt)
        self.assertIn("mean_progress_delta", prompt)
        self.assertIn("mean_required_term_recall_delta", prompt)
        self.assertIn("mean_required_term_span_progress_delta", prompt)
        self.assertIn("after_is_looping", prompt)
        self.assertIn("after_task_violation_count", prompt)
        self.assertIn("edits_left_this_run", prompt)
        self.assertIn("progress beats stability", prompt.lower())
        self.assertIn("Safe v0 apply subset", prompt)
        self.assertIn('the field name must be "by"', prompt)
        self.assertIn('Do not use "ref.stat" in v0.', prompt)
        self.assertIn('If none of the safe templates fit, choose noop', prompt)
        self.assertIn("controller_memory", prompt)
        self.assertIn("structured reflection", prompt.lower())
        self.assertIn("decoder_rescue_active", prompt)
        self.assertIn("decoder_control_track", prompt)
        self.assertIn("decoder_constraint_target_count", prompt)
        self.assertIn("decoder_entity_prior_active", prompt)
        self.assertIn("decoder_entity_target_count", prompt)
        self.assertIn("decoder_entity_prefix_depth", prompt)
        self.assertIn("decoder_logit_bias_active", prompt)
        self.assertIn("decoder_logit_bias_term_count", prompt)
        self.assertIn("decoder_logit_bias_token_count", prompt)
        self.assertIn("decoder_logit_bias_focus_term_count", prompt)
        self.assertIn("loop_rescue_edits_left_this_run", prompt)
        self.assertIn("loop_rescue_alpha_left_total", prompt)
        self.assertIn("do not treat this as a hard noop gate", prompt)
        self.assertIn("budget_only_loop_rescue", prompt)
        self.assertIn("micro_rationale", prompt)
        self.assertIn("measure whether the local shift improved semantic grounding", prompt)
        self.assertIn("tokenize_terms", prompt)
        self.assertIn("constraint_scorer", prompt)
        self.assertIn("dry_run_decode", prompt)
        self.assertIn("soft_logit_bias_ok_terms", prompt)
        self.assertIn("needs_sequence_support_terms", prompt)
        self.assertIn("control_phase_hint", prompt)
        self.assertIn("loop_severity", prompt)
        self.assertIn("shot_mode", prompt)
        self.assertIn("shot_probe_needed", prompt)
        self.assertIn("kv_probe_needed", prompt)
        self.assertIn("kv_retry_needed", prompt)
        self.assertIn("shot_candidate_edits", prompt)
        self.assertIn("kv_candidate_edits", prompt)
        self.assertIn("kv_retry_candidate_edits", prompt)
        self.assertIn("preferred_shot_surface_id", prompt)
        self.assertIn("preferred_kv_surface_id", prompt)
        self.assertIn("preferred_kv_retry_surface_id", prompt)
        self.assertIn("semantic_focus_term", prompt)
        self.assertIn("reachable_focus_term", prompt)
        self.assertIn("reachable_focus_rank", prompt)
        self.assertIn("controller_focus_term", prompt)
        self.assertIn("controller_focus_source", prompt)
        self.assertIn("target_mass", prompt)
        self.assertIn("target_top20_hits", prompt)
        self.assertIn("attractor_family_mass", prompt)
        self.assertIn("attractor_family_overlap_tokens", prompt)
        self.assertIn("kv_effect_family_collapsed", prompt)
        self.assertIn("readout_escape_needed", prompt)
        self.assertIn("readout_escape_block_reason", prompt)
        self.assertIn("kv_candidate_builder_output_count", prompt)
        self.assertIn("kv_candidate_builder_prune_reasons", prompt)
        self.assertIn("escape_builder_called", prompt)
        self.assertIn("escape_builder_target_terms", prompt)
        self.assertIn("escape_builder_candidates_before_prune", prompt)
        self.assertIn("escape_builder_candidate_families", prompt)
        self.assertIn("candidate_provenance_counts_before_prune", prompt)
        self.assertIn("candidate_provenance_counts_after_prune", prompt)
        self.assertIn("dominance_prune_drops", prompt)
        self.assertIn("same_term_family_drops", prompt)
        self.assertIn("readout_analyzer_capture_summary", prompt)
        self.assertIn("readout_analyzer_report", prompt)
        self.assertIn("readout_analyzer_hints", prompt)
        self.assertIn("readout_analyzer_suggested_focus_term", prompt)
        self.assertIn("readout_analyzer_suggested_bundle_key", prompt)
        self.assertIn("feature_backend=\"sae_sidecar\"", prompt)
        self.assertIn("request_attention_head_ablation", prompt)
        self.assertIn("attention_shadow_actuator_class", prompt)
        self.assertIn("attention_shadow_promotable_to_certification_replay", prompt)
        self.assertIn("promotable_to_certification_replay", prompt)
        self.assertIn("attention_guided_operator_certification", prompt)
        self.assertIn("activation_patch_shadow_actuator", prompt)
        self.assertIn("request_activation_patch_candidate_review", prompt)
        self.assertIn("activation_patch_candidate_review", prompt)
        self.assertIn("activation_patch_compile_preview", prompt)
        self.assertIn("activation_patch_compile_preview_blocked_reason", prompt)
        self.assertIn("production_activation_patch_operator_support", prompt)
        self.assertIn("request_activation_patch_runtime_support_probe", prompt)
        self.assertIn("activation_patch_runtime_support_probe", prompt)
        self.assertIn("activation_patch_executable_shadow", prompt)
        self.assertIn("request_activation_patch_promotion_gate_review", prompt)
        self.assertIn("activation_patch_promotion_gate_review", prompt)
        self.assertIn("request_activation_patch_production_shadow_replay", prompt)
        self.assertIn("activation_patch_production_shadow_replay", prompt)
        self.assertIn("request_activation_patch_production_trial_gate_review", prompt)
        self.assertIn("activation_patch_production_trial_gate_review", prompt)
        self.assertIn("activation_patch_production_apply_candidate", prompt)
        self.assertIn("diagnostic_operator_supported", prompt)
        self.assertIn("policy_candidate_ready", prompt)
        self.assertIn("production_operator_certified", prompt)
        self.assertIn("activation_patch_production_denial_dossier", prompt)
        self.assertIn("activation_patch_production_shadow_dossier", prompt)
        self.assertIn("activation_patch_production_trial_dossier", prompt)
        self.assertIn("production_trial_allowed", prompt)
        self.assertIn("production_trial_outcome_ledger", prompt)
        self.assertIn("trial_effect_class", prompt)
        self.assertIn("promotion_ladder_stage", prompt)
        self.assertIn("ownership_not_live_certified", prompt)
        self.assertIn("safety_not_certified", prompt)
        self.assertIn("context_equivalence_missing", prompt)
        self.assertIn("rollback_contract_missing", prompt)
        self.assertIn("effect_size_too_small", prompt)
        self.assertIn("gate_report_open", prompt)
        self.assertIn("gate_report_reasons", prompt)
        self.assertIn("gate_report_frontier_bundle_key", prompt)
        self.assertIn("meta.objective_bundle_key", prompt)
        self.assertIn("meta.step_actuator_bundle_key", prompt)
        self.assertIn("meta.shadow_proposals", prompt)
        self.assertIn("meta.why_not_apply", prompt)
        self.assertIn("candidate_family_vetoes", prompt)
        self.assertIn("bundle_inputs", prompt)
        self.assertIn("finish_budget_reserve_suggested", prompt)
        self.assertIn("same_family_alpha_escalation_requires_gain", prompt)
        self.assertIn("suggested_noop_reason", prompt)
        self.assertIn("weak_positive_subthreshold", prompt)
        self.assertIn("noop_reason", prompt)
        self.assertIn("apply_block_reason", prompt)
        self.assertIn("surface_family_key", prompt)
        self.assertIn("focus_term", prompt)
        self.assertIn("transfer_confidence", prompt)
        self.assertIn("same_family_escalation_risk", prompt)
        self.assertIn("finish_budget_reserved", prompt)
        self.assertIn("evidence_bullets", prompt)
        self.assertIn("source_positions", prompt)
        self.assertIn("argmax_pos", prompt)
        self.assertIn("canary_pass", prompt)
        self.assertIn("canary_focus_logit_delta", prompt)
        self.assertIn("canary_space_focus_logit_delta", prompt)
        self.assertIn("canary_prefix_depth_delta", prompt)
        self.assertIn("l4_term_nudge_cooldown", prompt)
        self.assertIn("prefer_auxiliary_entity_bias", prompt)
        self.assertIn("direct_entity_edit_gate", prompt)
        self.assertIn("stabilizing_only", prompt)
        self.assertIn("loop_break, entity_insertion, shot_mode, readout_escape", prompt)
        self.assertIn("s_resid_pre_l3_prev", prompt)
        self.assertIn("dry_run_decode on one kv_candidate_edits probe", prompt)
        self.assertIn("weak-but-promising on first-token readout", prompt)
        self.assertIn("runtime promoted a bounded cache surface", prompt)
        self.assertIn("prompt/hint anchors over output junk", prompt)
        self.assertIn("every kv candidate already failed its runtime canary", prompt)
        self.assertIn("retrieval-side probe", prompt)
        self.assertIn("two-token canary evidence", prompt)
        self.assertIn("alignment and readout are out of sync", prompt)
        self.assertIn("same decode basin", prompt)
        self.assertIn("same-family alpha escalation", prompt)
        self.assertIn("hold_finish_budget", prompt)
        self.assertIn("stop repeating recall probes", prompt)
        self.assertIn("leave the junk answer-start basin", prompt)
        self.assertIn("top-2 frontier comparison", prompt)
        self.assertIn("shadow proposals are notes, not extra apply rights", prompt)
        self.assertIn("canary alone", prompt)
        self.assertIn("reachable-first candidate compiler output", prompt)
        self.assertIn("phase_objective=\"readout_escape\"", prompt)
        self.assertIn("exact_prompt_span_mean", prompt)
        self.assertIn("source_body provenance", prompt)
        self.assertIn("clean k/v pairing plan", prompt)
        self.assertNotIn("include meta.hypothesis and meta.confidence when useful", prompt)

    def test_compact_controller_prompt_keeps_permission_boundary(self):
        prompt = load_prompt_asset("controller_v01_compact.txt")

        self.assertIn("rank_carrier != target_actuator", prompt)
        self.assertIn("diagnostic support is not permission", prompt.lower())
        self.assertIn("production_apply_allowed=true", prompt)
        self.assertIn("certified_for_apply=true", prompt)
        self.assertIn("request_compare_extra_operator_diagnostics", prompt)
        self.assertIn("readout_deepening_review_status=complete", prompt)
        self.assertIn("request_readout_gap_confirmation_or_variant_sweep", prompt)
        self.assertIn("readout_gap_confirmation_or_variant_sweep", prompt)
        self.assertIn("blocked_next_diagnostics", prompt)
        self.assertIn("requires cached attention rows", prompt)
        self.assertIn("Safe v0 apply subset", prompt)

    def test_openai_controller_provider_requests_json_mode_for_json_expected(self):
        client = _FakeOpenAIClient()
        provider = OpenAIControllerProvider(model="gpt-5.2", client=client)

        provider.complete(
            ControllerProviderRequest(
                system_prompt="sys",
                payload={"step": 1},
                expect_json=True,
            )
        )

        self.assertEqual(client.responses.calls[0]["text"]["format"]["type"], "json_object")
        self.assertEqual(client.responses.calls[0]["text"]["verbosity"], "low")
        self.assertTrue(client.responses.calls[0]["input"].startswith("JSON packet:\n"))
        self.assertNotIn("temperature", client.responses.calls[0])
        self.assertEqual(client.responses.calls[0]["reasoning"]["effort"], "low")

    def test_openai_controller_provider_uses_supported_gpt41_verbosity(self):
        client = _FakeOpenAIClient()
        provider = OpenAIControllerProvider(model="gpt-4.1-mini", client=client)

        provider.complete(
            ControllerProviderRequest(
                system_prompt="sys",
                payload={"step": 1},
                expect_json=True,
            )
        )

        self.assertEqual(client.responses.calls[0]["text"]["verbosity"], "medium")
        self.assertIn("temperature", client.responses.calls[0])

    def test_anthropic_controller_provider_omits_temperature_for_opus48(self):
        client = _FakeAnthropicClient()
        provider = AnthropicControllerProvider(model="claude-opus-4-8", client=client)

        provider.complete(
            ControllerProviderRequest(
                system_prompt="sys",
                payload={"step": 1},
                expect_json=True,
                temperature=0.2,
            )
        )

        self.assertNotIn("temperature", client.messages.calls[0])
        self.assertEqual(client.messages.calls[0]["model"], "claude-opus-4-8")

    def test_anthropic_controller_provider_keeps_temperature_for_older_models(self):
        client = _FakeAnthropicClient()
        provider = AnthropicControllerProvider(model="claude-opus-4-7", client=client)

        provider.complete(
            ControllerProviderRequest(
                system_prompt="sys",
                payload={"step": 1},
                expect_json=True,
                temperature=0.2,
            )
        )

        self.assertEqual(client.messages.calls[0]["temperature"], 0.2)

    def test_anthropic_controller_provider_omits_temperature_for_claude5_family(self):
        for model in ("claude-sonnet-5", "claude-fable-5", "claude-fable-5-20260301"):
            client = _FakeAnthropicClient()
            provider = AnthropicControllerProvider(model=model, client=client)

            provider.complete(
                ControllerProviderRequest(
                    system_prompt="sys",
                    payload={"step": 1},
                    expect_json=True,
                    temperature=0.2,
                )
            )

            self.assertNotIn("temperature", client.messages.calls[0], model)

    def test_anthropic_controller_provider_keeps_temperature_for_version_first_names(self):
        for model in ("claude-3-5-sonnet-20241022", "claude-haiku-4-5-20251001"):
            client = _FakeAnthropicClient()
            provider = AnthropicControllerProvider(model=model, client=client)

            provider.complete(
                ControllerProviderRequest(
                    system_prompt="sys",
                    payload={"step": 1},
                    expect_json=True,
                    temperature=0.2,
                )
            )

            self.assertEqual(client.messages.calls[0]["temperature"], 0.2, model)

    def test_local_backend_worker_runtime_packet_is_schema_shaped(self):
        runtime = LocalBackendWorkerRuntime(
            backend=_FakeLocalBackend(),
            task_id="local_task",
            goal_hint="emit b when useful",
            constraints=("be short",),
            max_generated_tokens=2,
        )
        runtime.reset("p")
        runtime.step()

        packet = runtime.build_controller_packet()
        parsed = parse_observation_packet(packet)

        self.assertEqual(parsed.task_view["task_id"], "local_task")
        self.assertEqual(packet["worker_view"]["generated_tail"], "a")
        self.assertEqual(packet["surface_catalog"], [])
        self.assertEqual(packet["budget"]["edits_left_this_run"], 0)

    def test_run_b1_works_with_local_backend_runtime(self):
        runtime = LocalBackendWorkerRuntime(
            backend=_FakeLocalBackend(),
            task_id="hint_task",
            goal_hint="emit b when useful",
            max_generated_tokens=2,
        )
        controller = ProviderPromptHintController(_FakeProvider("b"), system_prompt="sys")

        result = run_b1(_SingleHintTaskEnv(), runtime, controller, max_hints_per_run=1)

        self.assertEqual(result.output, "ab")
        self.assertEqual(result.score, 1.0)

    def test_mlx_backend_step_can_be_smoked_with_patched_stream_generate(self):
        def fake_stream_generate(_model, _tokenizer, prompt, max_tokens, temp, top_p):
            self.assertEqual(prompt, "hello")
            self.assertEqual(max_tokens, 1)
            yield _FakeMLXResponse(4, "x")

        with patch("SpiralInterventionLab.backends.mlx_lm.stream_generate", new=fake_stream_generate):
            backend = MLXLMBackend(model=object(), tokenizer=_FakeTokenizer())
            backend.reset("hello")
            result = backend.step()

        self.assertEqual(result.token_id, 4)
        self.assertEqual(result.token_text, "x")
        self.assertEqual(backend.output_token_ids(), [4])
        self.assertIsInstance(backend.last_logits_tensor(), torch.Tensor)


@unittest.skipUnless(HAS_TRANSFORMERS, "transformers is not installed")
class TestHFTransformersBackend(unittest.TestCase):
    def _make_backend(self) -> HFTransformersBackend:
        codec = CharacterCodec(" pabc!?")
        torch.manual_seed(0)
        model = GPT2LMHeadModel(
            GPT2Config(
                vocab_size=len(codec.alphabet),
                n_positions=16,
                n_embd=16,
                n_layer=2,
                n_head=2,
                eos_token_id=1,
            )
        )
        model.eval()
        return HFTransformersBackend(model=model, codec=codec, device="cpu", eos_token_id=1)

    def test_hf_backend_steps_and_accepts_prompt_hints(self):
        backend = self._make_backend()
        backend.reset("p")

        first = backend.step()
        appended = backend.append_prompt_hint(" b")
        second = backend.step()

        self.assertIsInstance(first.logits, torch.Tensor)
        self.assertTrue(appended)
        self.assertEqual(tuple(backend.current_tokens().shape[:1]), (1,))
        self.assertEqual(len(backend.output_token_ids()), 2)
        self.assertIsInstance(second.token_text, str)


if __name__ == "__main__":
    unittest.main()
