from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Any, Iterable, Mapping

from .edit_budget import (
    LOOP_RESCUE_EDIT_BUDGET_POOL,
    MAIN_EDIT_BUDGET_POOL,
    PRODUCTION_TRIAL_EDIT_BUDGET_POOL,
    PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL,
    classify_edit_budget_pool,
    estimate_edit_cost,
    relative_write_cap,
)
from .schema import (
    ActivationPatchOp,
    CachePairSource,
    ControllerCommand,
    ControllerObservationPacket,
    HarnessControllerView,
    KvMixOp,
    Rank1PatchOp,
    READOUT_DIRECTION_MAX_NEGATIVE_TOKEN_IDS,
    READOUT_DIRECTION_MAX_SCALE,
    READOUT_DIRECTION_MAX_TARGET_TOKEN_IDS,
    READOUT_DIRECTION_MIN_SCALE,
    SchemaError,
    Source,
    SurfaceInfo,
    SurfaceTargetRef,
    Target,
    TargetRef,
    VectorSource,
    parse_controller_command,
    parse_observation_packet,
)


class PolicyViolation(ValueError):
    pass


@dataclass(frozen=True)
class DenyTargetRule:
    kind: str
    layers: str | None = None


@dataclass(frozen=True)
class GlobalBudget:
    max_edits_per_step: int = 1
    max_edits_per_run: int = 4
    max_total_alpha: float = 0.5
    max_total_edit_cost: float = 0.5
    max_loop_rescue_edits_per_run: int = 4
    max_loop_rescue_total_alpha: float = 0.24
    max_loop_rescue_total_edit_cost: float = 0.24
    max_production_trial_edits_per_run: int = 1
    max_production_trial_total_alpha: float = 0.15
    max_production_trial_total_edit_cost: float = 0.15
    max_production_trial_followup_edits_per_run: int = 1
    max_production_trial_followup_total_alpha: float = 0.05
    max_production_trial_followup_total_edit_cost: float = 0.05
    max_rank_per_edit: int = 1


WRITE_CONTRACT_OPS = ("resid_add", "activation_patch")
WRITE_CONTRACT_SITES = ("resid_pre", "resid_post")
_WRITE_CONTRACT_EXPR_FNS = frozenset({
    "add", "sub", "mean", "scale", "normalize", "zero_mean", "sign", "clip_norm", "mix",
    "project_parallel", "project_orthogonal", "readout_direction",
})


@dataclass(frozen=True)
class WriteContract:
    """Opt-in replacement of absolute caps for one structural edit per command.

    The hook clips each write to relative_write_cap times the edited residual
    norm. Readout targets and source refs are allowlisted per prompt, so names
    and required terms can be excluded before any controller sees a recipe.
    """
    relative_write_cap: float = 0.08
    readout_token_ids: tuple[int, ...] = ()
    source_positions: tuple[int, ...] = ()
    # Bounds the raw request so fp16 arithmetic stays finite before the guard.
    max_resid_add_alpha: float = 1024.0


@dataclass(frozen=True)
class HarnessPolicy:
    version: str = "0.1"
    controller_view: HarnessControllerView = field(default_factory=HarnessControllerView)
    allow_ops: tuple[str, ...] = ("resid_add", "kv_mix", "rank1_patch", "activation_patch")
    deny_targets: tuple[DenyTargetRule, ...] = (
        DenyTargetRule(kind="embedding"),
        DenyTargetRule(kind="logits"),
        DenyTargetRule(kind="weight", layers="last2"),
    )
    global_budget: GlobalBudget = field(default_factory=GlobalBudget)
    max_expr_depth: int = 6
    max_expr_args: int = 4
    write_contract: WriteContract | None = None

    @classmethod
    def default_v0(cls) -> "HarnessPolicy":
        return cls()


def _packet_and_command(
    command: ControllerCommand | Mapping[str, Any],
    packet: ControllerObservationPacket | Mapping[str, Any],
) -> tuple[ControllerCommand, ControllerObservationPacket]:
    cmd = parse_controller_command(command) if isinstance(command, Mapping) else command
    pkt = parse_observation_packet(packet) if isinstance(packet, Mapping) else packet
    return cmd, pkt


def _resolve_surface(packet: ControllerObservationPacket, target_ref: TargetRef) -> SurfaceInfo:
    if isinstance(target_ref, SurfaceTargetRef):
        surface_map = packet.surface_map()
        if target_ref.surface_id not in surface_map:
            raise PolicyViolation(f"surface_id '{target_ref.surface_id}' is not available")
        return surface_map[target_ref.surface_id]
    for surface in packet.surface_catalog:
        if surface.target == target_ref:
            return surface
    raise PolicyViolation(f"target is not available in this observation packet: {target_ref!r}")


def _iter_expr_nodes(expr: Mapping[str, Any], depth: int = 0) -> Iterable[tuple[int, Mapping[str, Any]]]:
    yield depth, expr
    if "ref" in expr:
        return
    fn = expr.get("fn")
    if fn in {"add", "sub", "mean"}:
        for arg in expr.get("args", []):
            yield from _iter_expr_nodes(arg, depth + 1)
    elif fn in {"scale", "normalize", "zero_mean", "sign", "clip_norm"}:
        yield from _iter_expr_nodes(expr["arg"], depth + 1)
    elif fn == "mix":
        yield from _iter_expr_nodes(expr["left"], depth + 1)
        yield from _iter_expr_nodes(expr["right"], depth + 1)
    elif fn in {"project_parallel", "project_orthogonal"}:
        yield from _iter_expr_nodes(expr["arg"], depth + 1)
        yield from _iter_expr_nodes(expr["basis"], depth + 1)
    elif fn == "readout_direction":
        return


def _walk_source_exprs(source: Source) -> Iterable[Mapping[str, Any]]:
    if isinstance(source, VectorSource):
        yield source.expr
    elif source.dtype == "rank1":
        yield source.u
        yield source.v
    elif isinstance(source, CachePairSource):
        if source.k is not None:
            yield source.k
        if source.v is not None:
            yield source.v


def _validate_expr_budget(
    source: Source,
    policy: HarnessPolicy,
    *,
    max_expr_depth: int | None = None,
) -> None:
    expr_depth_limit = policy.max_expr_depth if max_expr_depth is None else int(max_expr_depth)
    for expr in _walk_source_exprs(source):
        for depth, node in _iter_expr_nodes(expr):
            if depth > expr_depth_limit:
                raise PolicyViolation(f"expression exceeds max depth {expr_depth_limit}")
            if node.get("fn") in {"add", "sub", "mean"} and len(node.get("args", [])) > policy.max_expr_args:
                raise PolicyViolation(f"expression exceeds max arg count {policy.max_expr_args}")
            if node.get("fn") == "readout_direction":
                target_ids = node.get("target_token_ids") or ()
                negative_ids = node.get("negative_token_ids") or ()
                if any(int(token_id) < 0 for token_id in target_ids):
                    raise PolicyViolation("readout_direction target_token_ids must be >= 0")
                if any(int(token_id) < 0 for token_id in negative_ids):
                    raise PolicyViolation("readout_direction negative_token_ids must be >= 0")
                if len(target_ids) > READOUT_DIRECTION_MAX_TARGET_TOKEN_IDS:
                    raise PolicyViolation("readout_direction exceeds target_token_ids cap")
                if len(negative_ids) > READOUT_DIRECTION_MAX_NEGATIVE_TOKEN_IDS:
                    raise PolicyViolation("readout_direction exceeds negative_token_ids cap")
                for scale_key in ("target_scale", "negative_scale"):
                    if scale_key not in node:
                        continue
                    try:
                        scale = float(node[scale_key])
                    except Exception as exc:
                        raise PolicyViolation(f"readout_direction.{scale_key} must be numeric") from exc
                    if scale < READOUT_DIRECTION_MIN_SCALE or scale > READOUT_DIRECTION_MAX_SCALE:
                        raise PolicyViolation(
                            f"readout_direction.{scale_key} must be between "
                            f"{READOUT_DIRECTION_MIN_SCALE:g} and {READOUT_DIRECTION_MAX_SCALE:g}"
                        )


def _validate_trace_access(source: Source, packet: ControllerObservationPacket) -> None:
    trace_map = packet.trace_map()
    for expr in _walk_source_exprs(source):
        for _depth, node in _iter_expr_nodes(expr):
            ref = node.get("ref")
            if not ref or ref.get("scope") != "trace":
                continue
            trace_id = ref.get("trace_id")
            trace = trace_map.get(trace_id)
            if trace is None:
                raise PolicyViolation(f"trace '{trace_id}' is not available")
            if not trace.compatible:
                raise PolicyViolation(f"trace '{trace_id}' is marked incompatible")


def _declared_write_cap(edit: Any) -> float | None:
    try:
        return relative_write_cap(edit)
    except ValueError as exc:
        raise PolicyViolation(f"edit '{edit.id}' {exc}") from exc


def _validate_write_contract(
    edit: Any,
    surface: SurfaceInfo,
    command: ControllerCommand,
    policy: HarnessPolicy,
    cap: float,
) -> None:
    contract = policy.write_contract
    if contract is None:
        raise PolicyViolation(f"edit '{edit.id}' declares a write contract this policy does not enable")
    if cap > contract.relative_write_cap:
        raise PolicyViolation(f"edit '{edit.id}' exceeds policy relative_write_cap")
    if len(command.edits) != 1:
        raise PolicyViolation("write contract commands carry exactly one edit")
    edit_meta = edit.meta if isinstance(getattr(edit, "meta", None), Mapping) else {}
    command_meta = command.meta if isinstance(getattr(command, "meta", None), Mapping) else {}
    apply_kind = str(edit_meta.get("apply_kind") or command_meta.get("apply_kind") or "").strip().lower()
    if apply_kind == "production_trial":
        raise PolicyViolation(f"edit '{edit.id}' write contract edits are not production trials")
    target = surface.target
    token_mode = str(getattr(getattr(target, "token", None), "mode", "") or "")
    if (edit.op.kind not in WRITE_CONTRACT_OPS or getattr(target, "kind", None) != "activation"
            or getattr(target, "site", None) not in WRITE_CONTRACT_SITES or token_mode != "last"):
        raise PolicyViolation(f"edit '{edit.id}' write contract requires a last-token residual add or blend")
    if edit.budget.ttl_steps != 1:
        raise PolicyViolation(f"edit '{edit.id}' write contract requires ttl_steps=1")
    if edit.budget.step_size is not None:
        raise PolicyViolation(f"edit '{edit.id}' write contract replaces the absolute step_size")
    alpha = float(edit.op.alpha)
    alpha_cap = 1.0 if isinstance(edit.op, ActivationPatchOp) else float(contract.max_resid_add_alpha)
    if not math.isfinite(alpha) or not 0 < alpha <= alpha_cap:
        raise PolicyViolation(f"edit '{edit.id}' write contract alpha must be in (0, {alpha_cap:g}]")
    if not isinstance(edit.source, VectorSource):
        raise PolicyViolation(f"edit '{edit.id}' write contract requires a vector source")
    readout_ids, positions = set(contract.readout_token_ids), set(contract.source_positions)
    for _depth, node in _iter_expr_nodes(edit.source.expr):
        ref = node.get("ref")
        if ref is not None:
            token = ref.get("token") or {}
            index = token.get("value")
            indexed = (token.get("mode") == "index" and isinstance(index, int)
                       and not isinstance(index, bool) and index in positions)
            if ref.get("scope") != "runtime" or not (token.get("mode") == "last" or indexed):
                raise PolicyViolation(f"edit '{edit.id}' source ref is outside the structural allowlist")
            continue
        fn = node.get("fn")
        if fn not in _WRITE_CONTRACT_EXPR_FNS:
            raise PolicyViolation(f"edit '{edit.id}' write contract does not admit expression '{fn}'")
        if fn == "readout_direction":
            targets = {int(token_id) for token_id in node.get("target_token_ids") or ()}
            if not targets or node.get("negative_token_ids") or not targets <= readout_ids:
                raise PolicyViolation(f"edit '{edit.id}' readout target is outside the structural allowlist")


def _check_deny_rules(target: Target, packet: ControllerObservationPacket, policy: HarnessPolicy) -> None:
    max_weight_layer = max(
        (surface.target.layer for surface in packet.surface_catalog if getattr(surface.target, "kind", None) == "weight"),
        default=None,
    )
    for rule in policy.deny_targets:
        if getattr(target, "kind", None) != rule.kind:
            continue
        if rule.kind != "weight":
            raise PolicyViolation(f"target kind '{rule.kind}' is denied by policy")
        if rule.layers == "last2" and max_weight_layer is not None and target.layer >= max_weight_layer - 1:
            raise PolicyViolation("editing the last two weight layers is denied by policy")


def validate_command_against_packet(
    command: ControllerCommand | Mapping[str, Any],
    packet: ControllerObservationPacket | Mapping[str, Any],
    policy: HarnessPolicy | None = None,
) -> None:
    cmd, pkt = _packet_and_command(command, packet)
    pol = policy or HarnessPolicy.default_v0()

    if cmd.decision == "noop":
        return

    if cmd.decision == "rollback":
        unknown = [rollback_id for rollback_id in cmd.rollback_ids if rollback_id not in pkt.budget.rollbackable_ids]
        if unknown:
            raise PolicyViolation(f"rollback ids are not currently revertible: {unknown}")
        return

    if pol.write_contract is None:
        # Name the missing opt-in instead of reporting the raw request as over budget.
        for edit in cmd.edits:
            if _declared_write_cap(edit) is not None:
                raise PolicyViolation(f"edit '{edit.id}' declares a write contract this policy does not enable")

    usage = command_budget_usage(cmd, pkt, policy=pol)
    budget_reason = budget_violation_reason(cmd, pkt, policy=pol, usage=usage)
    if budget_reason is not None:
        raise PolicyViolation(budget_reason)

    rank_patch_count = 0

    for edit in cmd.edits:
        surface = _resolve_surface(pkt, edit.target)
        _check_deny_rules(surface.target, pkt, pol)
        if edit.op.kind not in pol.allow_ops:
            raise PolicyViolation(f"op '{edit.op.kind}' is denied by policy")
        if edit.op.kind not in surface.allow_ops:
            raise PolicyViolation(f"surface '{surface.surface_id}' does not allow op '{edit.op.kind}'")
        if edit.budget.ttl_steps > surface.caps.max_ttl_steps:
            raise PolicyViolation(f"edit '{edit.id}' exceeds surface ttl cap")
        if surface.caps.revertible_only and not edit.budget.revertible:
            raise PolicyViolation(f"edit '{edit.id}' must be revertible on this surface")

        edit_meta = edit.meta if isinstance(getattr(edit, "meta", None), Mapping) else {}
        apply_kind = str(
            edit_meta.get("apply_kind")
            or cmd.meta.get("apply_kind")
            or ""
        ).strip().lower()
        production_trial_budget_class = str(
            edit_meta.get("production_trial_budget_class")
            or cmd.meta.get("production_trial_budget_class")
            or ""
        ).strip().lower()
        diagnostic_step_size_cap_release = (
            isinstance(edit.op, ActivationPatchOp)
            and apply_kind == "diagnostic_probe"
            and production_trial_budget_class == "diagnostic_only"
            and bool(edit_meta.get("step_size_cap_release_allowed", False))
            and not bool(edit_meta.get("production_apply_allowed", False))
            and not bool(edit_meta.get("certified_for_apply", False))
        )

        contract_cap = _declared_write_cap(edit)
        if contract_cap is not None:
            # The hook-time relative cap supersedes the absolute alpha and step caps.
            _validate_write_contract(edit, surface, cmd, pol, contract_cap)
        elif float(edit.op.alpha) > surface.caps.max_alpha:
            raise PolicyViolation(f"edit '{edit.id}' exceeds surface alpha cap")
        if edit.budget.norm_clip is not None and surface.caps.norm_clip is not None:
            if edit.budget.norm_clip > surface.caps.norm_clip:
                raise PolicyViolation(f"edit '{edit.id}' exceeds surface norm clip cap")
        if edit.budget.step_size is not None and surface.caps.step_size is not None:
            if edit.budget.step_size > surface.caps.step_size and not diagnostic_step_size_cap_release:
                raise PolicyViolation(f"edit '{edit.id}' exceeds surface step_size cap")

        if isinstance(edit.op, Rank1PatchOp):
            rank_patch_count += 1
            requested_rank = edit.budget.rank_cap or 1
            if requested_rank > pol.global_budget.max_rank_per_edit:
                raise PolicyViolation(f"edit '{edit.id}' exceeds policy rank cap")
            if surface.caps.rank_cap is not None and requested_rank > surface.caps.rank_cap:
                raise PolicyViolation(f"edit '{edit.id}' exceeds surface rank cap")

        if isinstance(edit.op, ActivationPatchOp):
            if getattr(surface.target, "kind", None) != "activation":
                raise PolicyViolation(f"edit '{edit.id}' activation_patch requires an activation target")
            if getattr(surface.target, "site", None) not in {"resid_pre", "resid_post", "mlp_out"}:
                raise PolicyViolation(f"edit '{edit.id}' activation_patch target site is unsupported")
            token = getattr(surface.target, "token", None)
            if token is None or str(getattr(token, "mode", "") or "") != "last":
                raise PolicyViolation(f"edit '{edit.id}' activation_patch requires answer-boundary last token")
            if edit.budget.ttl_steps != 1:
                raise PolicyViolation(f"edit '{edit.id}' activation_patch requires ttl_steps=1")
            if not isinstance(edit.source, VectorSource):
                raise PolicyViolation(f"edit '{edit.id}' activation_patch requires a vector source")

        if isinstance(edit.op, KvMixOp):
            if edit.op.which == "k" and not getattr(edit.source, "k", None) and edit.source.dtype == "cache_pair":
                raise PolicyViolation(f"edit '{edit.id}' requires source.k for kv_mix which='k'")
            if edit.op.which == "v" and not getattr(edit.source, "v", None) and edit.source.dtype == "cache_pair":
                raise PolicyViolation(f"edit '{edit.id}' requires source.v for kv_mix which='v'")
            if edit.op.which == "kv" and edit.source.dtype != "cache_pair":
                raise PolicyViolation(f"edit '{edit.id}' requires cache_pair source for kv_mix which='kv'")

        expr_depth_limit = pol.max_expr_depth
        if apply_kind == "production_trial" and production_trial_budget_class == "alternate_followup":
            expr_depth_limit = max(expr_depth_limit, 8)
        _validate_expr_budget(edit.source, pol, max_expr_depth=expr_depth_limit)
        _validate_trace_access(edit.source, pkt)
    if rank_patch_count > pkt.budget.active_patch_slots_left:
        raise PolicyViolation("command exceeds packet active_patch_slots_left")


def command_budget_usage(
    command: ControllerCommand | Mapping[str, Any],
    packet: ControllerObservationPacket | Mapping[str, Any],
    *,
    policy: HarnessPolicy | None = None,
) -> dict[str, dict[str, float]]:
    cmd, pkt = _packet_and_command(command, packet)
    contract_enabled = policy is not None and policy.write_contract is not None
    usage = {
        MAIN_EDIT_BUDGET_POOL: {"edit_count": 0.0, "alpha": 0.0, "edit_cost": 0.0},
        LOOP_RESCUE_EDIT_BUDGET_POOL: {"edit_count": 0.0, "alpha": 0.0, "edit_cost": 0.0},
        PRODUCTION_TRIAL_EDIT_BUDGET_POOL: {"edit_count": 0.0, "alpha": 0.0, "edit_cost": 0.0},
        PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL: {
            "edit_count": 0.0,
            "alpha": 0.0,
            "edit_cost": 0.0,
        },
    }
    for edit in cmd.edits:
        surface = _resolve_surface(pkt, edit.target)
        pool = classify_edit_budget_pool(edit=edit, packet=pkt, surface=surface, command_meta=cmd.meta)
        if pool not in usage:
            pool = MAIN_EDIT_BUDGET_POOL
        usage[pool]["edit_count"] += 1.0
        contract_cap = _declared_write_cap(edit) if contract_enabled else None
        if contract_cap is not None:
            # Charged in relative units: the guard writes at most cap * ||h||.
            usage[pool]["alpha"] += contract_cap
            usage[pool]["edit_cost"] += estimate_edit_cost(
                op_kind=edit.op.kind,
                alpha=contract_cap,
                ttl_steps=edit.budget.ttl_steps,
                step_size=contract_cap,
                rank_cap=edit.budget.rank_cap,
            )
            continue
        usage[pool]["alpha"] += float(edit.op.alpha)
        effective_step_size = edit.budget.step_size if edit.budget.step_size is not None else surface.caps.step_size
        usage[pool]["edit_cost"] += estimate_edit_cost(
            op_kind=edit.op.kind,
            alpha=edit.op.alpha,
            ttl_steps=edit.budget.ttl_steps,
            step_size=effective_step_size,
            rank_cap=edit.budget.rank_cap,
        )
    return usage


def budget_violation_reason(
    command: ControllerCommand | Mapping[str, Any],
    packet: ControllerObservationPacket | Mapping[str, Any],
    *,
    policy: HarnessPolicy | None = None,
    usage: dict[str, dict[str, float]] | None = None,
) -> str | None:
    cmd, pkt = _packet_and_command(command, packet)
    pol = policy or HarnessPolicy.default_v0()

    if cmd.decision != "apply":
        return None

    usage = usage or command_budget_usage(cmd, pkt, policy=pol)
    usage.setdefault(
        PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL,
        {"edit_count": 0.0, "alpha": 0.0, "edit_cost": 0.0},
    )

    if len(cmd.edits) > pkt.budget.edits_left_this_step:
        return "command exceeds packet.edits_left_this_step"
    if len(cmd.edits) > pol.global_budget.max_edits_per_step:
        return "command exceeds policy.max_edits_per_step"
    if usage[MAIN_EDIT_BUDGET_POOL]["edit_count"] > pkt.budget.edits_left_this_run:
        return "command exceeds packet.edits_left_this_run"
    if usage[MAIN_EDIT_BUDGET_POOL]["edit_count"] > pol.global_budget.max_edits_per_run:
        return "command exceeds policy.max_edits_per_run"
    if usage[LOOP_RESCUE_EDIT_BUDGET_POOL]["edit_count"] > pkt.budget.loop_rescue_edits_left_this_run:
        return "command exceeds packet.loop_rescue_edits_left_this_run"
    if usage[LOOP_RESCUE_EDIT_BUDGET_POOL]["edit_count"] > pol.global_budget.max_loop_rescue_edits_per_run:
        return "command exceeds policy.max_loop_rescue_edits_per_run"
    production_trial_budget = getattr(pkt.budget, "production_trial_edits_left_this_run", 0)
    production_trial_alpha_left = getattr(pkt.budget, "production_trial_alpha_left_total", 0.0)
    production_trial_cost_left = getattr(pkt.budget, "production_trial_edit_cost_left_total", 0.0)
    production_trial_followup_budget = getattr(pkt.budget, "production_trial_followup_edits_left_this_run", 0)
    production_trial_followup_alpha_left = getattr(
        pkt.budget,
        "production_trial_followup_alpha_left_total",
        0.0,
    )
    production_trial_followup_cost_left = getattr(
        pkt.budget,
        "production_trial_followup_edit_cost_left_total",
        0.0,
    )
    if usage[PRODUCTION_TRIAL_EDIT_BUDGET_POOL]["edit_count"] > production_trial_budget:
        return "command exceeds packet.production_trial_edits_left_this_run"
    if usage[PRODUCTION_TRIAL_EDIT_BUDGET_POOL]["edit_count"] > pol.global_budget.max_production_trial_edits_per_run:
        return "command exceeds policy.max_production_trial_edits_per_run"
    if usage[PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL]["edit_count"] > production_trial_followup_budget:
        return "command exceeds packet.production_trial_followup_edits_left_this_run"
    if (
        usage[PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL]["edit_count"]
        > pol.global_budget.max_production_trial_followup_edits_per_run
    ):
        return "command exceeds policy.max_production_trial_followup_edits_per_run"

    main_alpha = float(usage[MAIN_EDIT_BUDGET_POOL]["alpha"])
    main_edit_cost = float(usage[MAIN_EDIT_BUDGET_POOL]["edit_cost"])
    if main_alpha > pkt.budget.alpha_left_total:
        return "command exceeds packet alpha budget"
    if main_alpha > pol.global_budget.max_total_alpha:
        return "command exceeds policy total alpha budget"
    if pkt.budget.edit_cost_left_total is not None and main_edit_cost > pkt.budget.edit_cost_left_total:
        return "command exceeds packet edit cost budget"
    if main_edit_cost > pol.global_budget.max_total_edit_cost:
        return "command exceeds policy total edit cost budget"

    rescue_alpha = float(usage[LOOP_RESCUE_EDIT_BUDGET_POOL]["alpha"])
    rescue_edit_cost = float(usage[LOOP_RESCUE_EDIT_BUDGET_POOL]["edit_cost"])
    if rescue_alpha > pkt.budget.loop_rescue_alpha_left_total:
        return "command exceeds packet loop_rescue alpha budget"
    if rescue_alpha > pol.global_budget.max_loop_rescue_total_alpha:
        return "command exceeds policy loop_rescue total alpha budget"
    if rescue_edit_cost > pkt.budget.loop_rescue_edit_cost_left_total:
        return "command exceeds packet loop_rescue edit cost budget"
    if rescue_edit_cost > pol.global_budget.max_loop_rescue_total_edit_cost:
        return "command exceeds policy loop_rescue total edit cost budget"

    trial_alpha = float(usage[PRODUCTION_TRIAL_EDIT_BUDGET_POOL]["alpha"])
    trial_edit_cost = float(usage[PRODUCTION_TRIAL_EDIT_BUDGET_POOL]["edit_cost"])
    if trial_alpha > production_trial_alpha_left:
        return "command exceeds packet production_trial alpha budget"
    if trial_alpha > pol.global_budget.max_production_trial_total_alpha:
        return "command exceeds policy production_trial total alpha budget"
    if trial_edit_cost > production_trial_cost_left:
        return "command exceeds packet production_trial edit cost budget"
    if trial_edit_cost > pol.global_budget.max_production_trial_total_edit_cost:
        return "command exceeds policy production_trial total edit cost budget"

    trial_followup_alpha = float(usage[PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL]["alpha"])
    trial_followup_edit_cost = float(usage[PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL]["edit_cost"])
    if trial_followup_alpha > production_trial_followup_alpha_left:
        return "command exceeds packet production_trial_followup alpha budget"
    if trial_followup_alpha > pol.global_budget.max_production_trial_followup_total_alpha:
        return "command exceeds policy production_trial_followup total alpha budget"
    if trial_followup_edit_cost > production_trial_followup_cost_left:
        return "command exceeds packet production_trial_followup edit cost budget"
    if trial_followup_edit_cost > pol.global_budget.max_production_trial_followup_total_edit_cost:
        return "command exceeds policy production_trial_followup total edit cost budget"

    return None
