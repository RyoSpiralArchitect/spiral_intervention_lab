"""Frozen structural-rescue pilot; role annotations are evaluation-only."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import re
from typing import Any

from .language_tasks import SpiralConstrainedRewriteEnv, _contains_term, _strip_output, _word_count
from .role_binding import action_forms, check_role_frames

# Substitution evidence: common verbs a 3B model substitutes for the required
# action. Small closed list — anything else stays a plain incomplete_frame.
_COMMON_ENGLISH_VERBS = frozenset({
    "finish", "finishes", "finished", "complete", "completes", "completed",
    "make", "makes", "made", "do", "does", "done", "get", "gets", "got",
    "handle", "handles", "handled", "fix", "fixes", "fixed", "prepare", "prepares",
})


@dataclass(frozen=True)
class RescueCase:
    case_id: str
    split: str
    source: str
    frames: tuple[tuple[str, str, str, str], ...]
    deadline: str


CASES = (
    RescueCase("cal_delivery", "calibration",
        "In order to be ready before noon, Mira should send the budget to Omar, while Leena should bring the contract to Priya.",
        (("Mira", "send", "budget", "Omar"), ("Leena", "bring", "contract", "Priya")), "before noon"),
    RescueCase("cal_review", "calibration",
        "In order to finish before dusk, Nora should take the sample to Ivo, while Selim should send the report to Yara.",
        (("Nora", "take", "sample", "Ivo"), ("Selim", "send", "report", "Yara")), "before dusk"),
    RescueCase("cal_workshop", "calibration",
        "In order to start before lunch, Ada should bring the cable to Niko, while Rami should send the diagram to Vera.",
        (("Ada", "bring", "cable", "Niko"), ("Rami", "send", "diagram", "Vera")), "before lunch"),
    RescueCase("confirm_names_a", "confirmation",
        "In order to finish before dusk, Elise should take the parcel to Hugo, while Tomas should send the invoice to Lena.",
        (("Elise", "take", "parcel", "Hugo"), ("Tomas", "send", "invoice", "Lena")), "before dusk"),
    RescueCase("confirm_names_b", "confirmation",
        "In order to be ready before noon, Iris should send the schedule to Luca, while Pavel should bring the folder to Mina.",
        (("Iris", "send", "schedule", "Luca"), ("Pavel", "bring", "folder", "Mina")), "before noon"),
    RescueCase("confirm_order_a", "confirmation",
        "In order to finish before dusk, Tomas should send the invoice to Lena, while Elise should take the parcel to Hugo.",
        (("Tomas", "send", "invoice", "Lena"), ("Elise", "take", "parcel", "Hugo")), "before dusk"),
    RescueCase("confirm_order_b", "confirmation",
        "In order to be ready before noon, Pavel should bring the folder to Mina, while Iris should send the schedule to Luca.",
        (("Pavel", "bring", "folder", "Mina"), ("Iris", "send", "schedule", "Luca")), "before noon"),
    RescueCase("confirm_paraphrase_a", "confirmation",
        "Before lunch, Hana should bring the sketch to Emil; meanwhile, Dario should send the notice to Cora.",
        (("Hana", "bring", "sketch", "Emil"), ("Dario", "send", "notice", "Cora")), "before lunch"),
    RescueCase("confirm_paraphrase_b", "confirmation",
        "Before dusk, Bruno should take the packet to Anya, whereas Nadia should send the memo to Leon.",
        (("Bruno", "take", "packet", "Anya"), ("Nadia", "send", "memo", "Leon")), "before dusk"),
)


class StructuralRescueEnv(SpiralConstrainedRewriteEnv):
    """Same lexical score and prompt contract as the ladder, with explicit case IDs."""
    def __init__(self, case: RescueCase):
        super().__init__()
        self.case = case
        self.task_id = "structural_rescue_v1:" + case.case_id
        terms = tuple(value for frame in case.frames for value in frame) + (case.deadline,)
        self._SCENARIOS = ({"source_text": case.source, "required_terms": terms,
                            "forbidden_terms": ("in order to", "should"), "max_words": 18},)

    def stop_checker(self, output: str) -> bool:
        text = _strip_output(output)
        return text.endswith((".", "!", "?")) and _word_count(text) >= 3

    def worker_runtime_kwargs(self) -> dict[str, Any]:
        return {**super().worker_runtime_kwargs(), "max_generated_tokens": 64,
                "max_observer_checks_per_run": 0}

    def evaluate(self, output: str) -> dict[str, Any]:
        feedback = self.task_feedback(output)
        # A required action term counts when any recognized inflection appears:
        # "giving Yusuf the ticket" satisfies "give". Coverage is recorded so a
        # lexical-pass-through-inflection stays visible in receipts.
        action_terms = {str(frame[1]) for frame in self.case.frames}
        required = tuple(self._SCENARIOS[0]["required_terms"])
        uncovered = [term for term in required if not _contains_term(output, term)
                     and not (term in action_terms
                              and any(_contains_term(output, form) for form in action_forms(term)))]
        inflected = sorted(term for term in required
                           if term in action_terms and not _contains_term(output, term)
                           and term not in uncovered)
        if inflected and not uncovered and "missing_required_terms" in feedback["constraint_violations"]:
            violations = [v for v in feedback["constraint_violations"] if v != "missing_required_terms"]
            feedback = {**feedback, "constraint_violations": violations}
        roles = check_role_frames(output, self.case.frames)
        words = re.findall(r"[A-Za-z]+(?:'s)?", output.casefold())
        unknown = []
        for frame, report in zip(self.case.frames, roles["frames"], strict=True):
            if sum(word in action_forms(frame[1]) for word in words) > 1:
                unknown.append("repeated_action:" + frame[1])
            if report["status"] in {"action_missing", "partially_bound"}:
                unknown.append("incomplete_frame:" + frame[1])
            # Name the substitution when a different verb occupies the slot
            # ("finishes her drawing"), and a possessive when the recipient
            # is folded into the theme ("Felix's permit").
            if report["status"] in {"action_missing", "partially_bound"} and re.search(
                    re.escape(str(frame[3]).casefold()) + r"'s\b", output.casefold()):
                unknown.append("recipient_possessive:" + frame[3])
        # Substituted actions are tagged even when the frame binds a wrong
        # action ("finishes roster" reads as a send of roster by the checker).
        window = re.findall(r"[a-z]+", re.sub(r"'s\b", "", output.casefold()))
        alien = sorted({w for w in window if w in _COMMON_ENGLISH_VERBS
                        and all(w not in action_forms(str(f[1])) for f in self.case.frames)})
        if alien and (roles["role_violations"] or unknown):
            unknown.append("action_substituted:" + ",".join(alien))
        # The nearest-agent heuristic cannot establish subjects of passives or
        # relative clauses. Preserve uncertainty instead of promoting a lexical pass.
        if re.search(r"\b(who|whom|whose|which|by)\b", output, re.I):
            unknown.append("unsupported_clause_or_voice")
        status = "fail" if roles["role_violations"] else "unknown" if unknown else "pass"
        text = output.strip()
        surface_notes = []
        if inflected:
            surface_notes.append("required_action_covered_by_inflection:" + ",".join(inflected))
        if re.search(r"[a-z]+\s+(while|whereas|and)\s+[A-Z]", text):
            surface_notes.append("asyndetic_connective_no_comma")
        sentence_ok = (text.endswith((".", "!", "?"))
                       and len(re.findall(r"[.!?](?:\s|$)", text)) == 1
                       and "\n" not in text)
        constraints_ok = bool(self.done(output)) and sentence_ok
        return {"output": output, "legacy_score": self.score(output),
                "constraint_violations": feedback["constraint_violations"],
                "missing_terms_lexical": feedback.get("missing_terms_lexical", []),
                "constraints_ok": constraints_ok, "single_sentence_ok": sentence_ok,
                "role_status": status, "role_unknown_reasons": unknown,
                "role_report": roles, "joint_success": constraints_ok and status == "pass",
                "surface_notes": surface_notes,
                "evaluation_scope": "lexical_constraints_plus_conservative_surface_role_heuristic"}


def benchmark_manifest() -> dict[str, Any]:
    cases = []
    for case in CASES:
        task = StructuralRescueEnv(case)
        prompt = task.reset(0)
        cases.append({"case_id": case.case_id, "split": case.split, "source": case.source,
                      "frames_evaluation_only": case.frames, "deadline": case.deadline,
                      "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest()})
    return {"version": "structural_rescue_v1", "cases": cases,
            "confirmation_status": "predeclared_before_this_pilot_not_a_population_sample",
            "max_words": 18, "max_generated_tokens": 64,
            "boundary_rule": "first_natural_prefix_ending_in_to_first_source_recipient",
            "policy_seeds": [17], "diagnostic_forward_cap_per_policy": 24,
            "continuation_forward_cap_per_policy": 64,
            "components": ["common", "common_parallel", "common_orthogonal"],
            "fixed_rule": "common_orthogonal_of_first_source_pair",
            "random_rule": "sha256(case_id,seed)_mod_catalog_size",
            "max_controller_calls_per_case": 1, "max_controller_output_tokens": 1600,
            "baseline_repeats_before_each_branch": 2,
            "apply_scope": "restored_normal_cap_diagnostic_branch_only",
            "production_apply_allowed": False}


def manifest_bytes() -> bytes:
    return (json.dumps(benchmark_manifest(), indent=2, sort_keys=True) + "\n").encode()
