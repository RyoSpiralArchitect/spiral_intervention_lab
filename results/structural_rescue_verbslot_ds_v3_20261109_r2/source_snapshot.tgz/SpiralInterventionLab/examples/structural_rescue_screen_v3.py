"""Third pre-registered B0 screen: extended role check plus restricted verbs.

Two v1-screen lessons are applied, both pre-registered before any model call:
the generator gains participial-second-clause and agent-relative source
families, and `give` returns now that the evaluator binds double-object
datives. The candidate count stays 120 so the selection limit of 12 is
reachable if harder sources fail more often. --prepare freezes the
generator version, seed, count, selection rule and follow-up; --run decodes
each candidate once at the v2 boundary without edits.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from ..tasks.structural_rescue import RescueCase
from ..tasks.structural_rescue_generator import (
    CONNECTIVES, DEADLINES, FAMILIES_V3, GENERATOR_VERSION_V3, NAMES, OBJECTS, VERBS_V3,
    candidate_rows, generate,
)
from .structural_rescue_screen import DISK_FLOOR_GIB, SELECTION_LIMIT, SELECTION_RULE, execute


SEED = 20261107
COUNT = 120


def manifest() -> dict[str, Any]:
    return {"version": "structural_rescue_screen_v3", "generator": GENERATOR_VERSION_V3,
            "seed": SEED, "count": COUNT, "candidates": candidate_rows(generate(SEED, COUNT, VERBS_V3, FAMILIES_V3)),
            "pools": {"names": NAMES, "objects": OBJECTS, "verbs": VERBS_V3, "deadlines": DEADLINES,
                      "connectives": CONNECTIVES, "families": FAMILIES_V3},
            "screen": "greedy_b0_from_the_v2_boundary_no_edits_no_controller",
            "boundary_rule": "first_natural_prefix_ending_in_to_first_source_recipient",
            "selection_rule": SELECTION_RULE, "selection_limit": SELECTION_LIMIT,
            "selected_split": "rescue_v3",
            "evaluator_changes_since_screen_v2":
                ["required_action_terms_covered_by_action_forms_inflections",
                 "regular_and_irregular_past_tense_action_forms",
                 "generator_adds_participial_and_relative_families_and_restores_give"],
            "follow_up": "structural_rescue_v2_norm_relative_contract_datasheet_or_unchanged_contract_on_selected_cases",
            "analysis_plan": {"primary": "joint_success_count_per_policy_on_the_rescue_v3_split",
                              "comparison": "controller_vs_fixed_readout_paired_by_case",
                              # Frozen as executed: this wording predates the run's
                              # review; changing it would break receipt binding.
                              "harm_check": "losses_vs_b0_on_the_v1_confirmation_split",
                              "b0_reproduction": "a_selected_case_where_b0_succeeds_is_reported_not_dropped",
                              "exploratory": "b0_failures_by_type_constraint_vs_role",
                              "inference": "descriptive_counts_only_no_significance_claims_at_n_le_12"},
            "max_words": 18, "max_generated_tokens": 64, "disk_floor_gib": DISK_FLOOR_GIB,
            "production_apply_allowed": False}


def manifest_bytes() -> bytes:
    return (json.dumps(manifest(), indent=2, sort_keys=True) + "\n").encode()


def selected_cases(screen_dir: Path) -> tuple[tuple[RescueCase, ...], dict[str, Any]]:
    """Rebuild the v2-selected cases and bind them to the frozen screen receipts."""
    frozen = manifest_bytes()
    if (screen_dir / "manifest.json").read_bytes() != frozen:
        raise ValueError("screen_manifest_differs_from_generator_v2")
    results_bytes = (screen_dir / "results.json").read_bytes()
    results = json.loads(results_bytes)
    if results.get("status") != "complete" or results.get("manifest_sha256") != hashlib.sha256(frozen).hexdigest():
        raise ValueError("screen_incomplete_or_unbound")
    by_id = {case.case_id: case for case in generate(SEED, COUNT, VERBS_V3, FAMILIES_V3)}
    cases = tuple(RescueCase(case_id, "rescue_v3", by_id[case_id].source, by_id[case_id].frames,
                             by_id[case_id].deadline) for case_id in results["selected_case_ids"])
    return cases, {"screen_manifest_sha256": hashlib.sha256(frozen).hexdigest(),
                   "screen_results_sha256": hashlib.sha256(results_bytes).hexdigest(),
                   "selected_case_ids": list(results["selected_case_ids"])}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--run", action="store_true")
    parser.add_argument("--manifest-sha256")
    parser.add_argument("--worker-model-path", type=Path)
    parser.add_argument("--checkpoint-manifest", type=Path)
    parser.add_argument("--worker-model", default="meta-llama/Llama-3.2-3B-Instruct")
    parser.add_argument("--device", choices=("cpu", "mps", "cuda"), default="mps")
    parser.add_argument("--dtype", default="float16", choices=("float16", "float32"))
    parser.add_argument("--mps-memory-fraction", type=float, default=0.85)
    args = parser.parse_args(argv)
    return execute(args, seed=SEED, count=COUNT, verbs=VERBS_V3, families=FAMILIES_V3, frozen=manifest_bytes())


if __name__ == "__main__":
    raise SystemExit(main())
