import gc
import unittest
import weakref
from collections.abc import Mapping
from importlib.util import find_spec
from unittest.mock import patch

import torch

from SpiralInterventionLab.runtime.adapter import BoundSurface, HookedTransformerAdapter, ModelAdapter
from SpiralInterventionLab.runtime.baselines import activation_only_policy, run_b0, run_b1, run_c1, run_minimal_baseline_suite
from SpiralInterventionLab.runtime.codecs import CharacterCodec
from SpiralInterventionLab.runtime.compiler import StepContext, _readout_matrix, compile_command, compile_expr
from SpiralInterventionLab.runtime.edit_budget import (
    PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL,
    prepare_direction,
)
from SpiralInterventionLab.runtime.effects import build_edit_effect, summarize_effects
from SpiralInterventionLab.runtime.loop import (
    InMemoryStructuredLogger,
    _extract_diagnostic_requests,
    run_episode,
)
from SpiralInterventionLab.runtime.overlays import OverlayHandle
from SpiralInterventionLab.runtime.policy import (
    GlobalBudget,
    HarnessPolicy,
    PolicyViolation,
    budget_violation_reason,
    command_budget_usage,
    validate_command_against_packet,
)
from SpiralInterventionLab.runtime.rank1_bridge import HybridRank1VectorBridge, Rank1Geometry
from SpiralInterventionLab.runtime.sidecar import (
    ReadoutSidecarCapture,
    ReadoutSidecarSiteCapture,
    build_heuristic_readout_sidecar_analyzer,
)
from SpiralInterventionLab.runtime.tlens_runtime import HookedTransformerRuntimeState
from SpiralInterventionLab.runtime.trace_recorder import StepAlignedTrace
from SpiralInterventionLab.runtime.worker import HookedTransformerWorkerRuntime, _TargetTokenSequence
from SpiralInterventionLab.runtime.schema import (
    ControllerCommand,
    ControllerObservationPacket,
    SchemaError,
    SurfaceTargetRef,
    parse_controller_command,
    parse_observation_packet,
)

HAS_TRANSFORMER_LENS = bool(find_spec("transformer_lens"))
if HAS_TRANSFORMER_LENS:
    from transformer_lens import HookedTransformer, HookedTransformerConfig


def _make_packet(*, rollbackable_ids=None):
    rollbackable_ids = rollbackable_ids or []
    return {
        "version": "0.1",
        "run_id": "run_0001",
        "episode_id": "ep_0001",
        "worker_id": "os_0",
        "step": 0,
        "horizon": {
            "generated_tokens": 1,
            "max_generated_tokens": 16,
            "done": False,
        },
        "task_view": {
            "mode": "redacted",
            "task_id": "toy_task",
            "prompt_hash": "sha256:test",
            "goal_hint": "toy task",
            "constraints": ["stay concise"],
        },
        "worker_view": {
            "generated_tail": "looping...",
            "status": "looping",
        },
        "telemetry": {
            "entropy": 2.1,
            "top1_margin": 0.05,
            "repetition_score": 0.4,
            "repeat_flag": True,
            "no_progress_steps": 2,
        },
        "surface_catalog": [
            {
                "surface_id": "s_resid_l11_last",
                "target": {
                    "kind": "activation",
                    "worker": "os_0",
                    "site": "resid_pre",
                    "layer": 11,
                    "token": {"mode": "last"},
                },
                "allow_ops": ["resid_add", "activation_patch"],
                "caps": {
                    "max_alpha": 0.2,
                    "max_ttl_steps": 3,
                    "norm_clip": 1.5,
                    "revertible_only": True,
                },
            },
            {
                "surface_id": "s_weight_l7_mlp",
                "target": {
                    "kind": "weight",
                    "worker": "os_0",
                    "module": "mlp_out",
                    "layer": 7,
                },
                "allow_ops": ["rank1_patch"],
                "caps": {
                    "max_alpha": 0.08,
                    "max_ttl_steps": 4,
                    "rank_cap": 1,
                    "revertible_only": True,
                },
            },
            {
                "surface_id": "s_weight_l10_mlp",
                "target": {
                    "kind": "weight",
                    "worker": "os_0",
                    "module": "mlp_out",
                    "layer": 10,
                },
                "allow_ops": ["rank1_patch"],
                "caps": {
                    "max_alpha": 0.08,
                    "max_ttl_steps": 4,
                    "rank_cap": 1,
                    "revertible_only": True,
                },
            },
            {
                "surface_id": "s_weight_l11_mlp",
                "target": {
                    "kind": "weight",
                    "worker": "os_0",
                    "module": "mlp_out",
                    "layer": 11,
                },
                "allow_ops": ["rank1_patch"],
                "caps": {
                    "max_alpha": 0.08,
                    "max_ttl_steps": 4,
                    "rank_cap": 1,
                    "revertible_only": True,
                },
            },
        ],
        "probe_frames": [
            {
                "surface_id": "s_resid_l11_last",
                "stats": {
                    "norm": 18.3,
                    "delta_prev": 1.9,
                    "anomaly_score": 0.61,
                    "cosine_to_best_success": 0.34,
                },
            }
        ],
        "trace_bank": [
            {
                "trace_id": "best_success",
                "origin": "best_success",
                "compatible": True,
                "similarity_hint": 0.71,
                "tags": ["successful"],
            },
            {
                "trace_id": "paired_baseline",
                "origin": "paired_baseline",
                "compatible": True,
                "similarity_hint": 0.88,
                "tags": ["same_seed"],
            },
        ],
        "active_edits": [],
        "recent_effects": [],
        "budget": {
            "edits_left_this_step": 1,
            "edits_left_this_run": 4,
            "alpha_left_total": 0.5,
            "edit_cost_left_total": 0.5,
            "loop_rescue_edits_left_this_run": 0,
            "loop_rescue_alpha_left_total": 0.0,
            "loop_rescue_edit_cost_left_total": 0.0,
            "active_patch_slots_left": 2,
            "rollbackable_ids": rollbackable_ids,
        },
        "task_feedback": {
            "done": False,
            "progress_label": "stalled",
        },
    }


def _resid_command():
    return {
        "version": "0.1",
        "decision": "apply",
        "meta": {"hypothesis": "rescue", "confidence": 0.6},
        "edits": [
            {
                "id": "e_rescue",
                "target": {"surface_id": "s_resid_l11_last"},
                "source": {
                    "dtype": "vector",
                    "expr": {
                        "ref": {
                            "scope": "runtime",
                            "worker": "os_0",
                            "tensor": "hidden",
                            "layer": 11,
                            "token": {"mode": "last"},
                        }
                    },
                },
                "op": {"kind": "resid_add", "alpha": 0.2},
                "budget": {"ttl_steps": 2, "norm_clip": 1.5, "revertible": True},
                "meta": {"expected_effect": "break_loop"},
            }
        ],
    }


def _activation_patch_command():
    return {
        "version": "0.1",
        "decision": "apply",
        "meta": {"hypothesis": "activation_patch_probe", "confidence": 0.6},
        "edits": [
            {
                "id": "e_activation_patch",
                "target": {"surface_id": "s_resid_l11_last"},
                "source": {
                    "dtype": "vector",
                    "expr": {
                        "ref": {
                            "scope": "runtime",
                            "worker": "os_0",
                            "tensor": "hidden",
                            "layer": 11,
                            "token": {"mode": "last"},
                        }
                    },
                },
                "op": {"kind": "activation_patch", "alpha": 0.2, "mode": "blend"},
                "budget": {"ttl_steps": 1, "revertible": True},
                "meta": {
                    "expected_effect": "activation_patch_blend_probe",
                    "activation_patch_op_kind": "activation_patch",
                    "activation_patch_mode": "blend",
                    "source_localization": "source_term_token",
                    "patch_mode": "blend",
                },
            }
        ],
    }


def _loop_rescue_command(*, alpha: float = 0.06, step_size: float = 0.06, edit_id: str = "e_loop_rescue"):
    return {
        "version": "0.1",
        "decision": "apply",
        "meta": {"hypothesis": "small_loop_rescue", "confidence": 0.6},
        "edits": [
            {
                "id": edit_id,
                "target": {"surface_id": "s_resid_l11_last"},
                "source": {
                    "dtype": "vector",
                    "expr": {
                        "ref": {
                            "scope": "runtime",
                            "worker": "os_0",
                            "tensor": "hidden",
                            "layer": 11,
                            "token": {"mode": "last"},
                        }
                    },
                },
                "op": {"kind": "resid_add", "alpha": alpha},
                "budget": {"ttl_steps": 1, "norm_clip": 1.5, "step_size": step_size, "revertible": True},
                "meta": {"expected_effect": "break_loop"},
            }
        ],
    }


def _production_trial_followup_command():
    command = _loop_rescue_command(alpha=0.05, step_size=0.05, edit_id="e_trial_followup")
    command["meta"] = {
        "hypothesis": "activation_patch_production_trial_apply",
        "apply_kind": "production_trial",
        "production_trial_budget_class": "alternate_followup",
    }
    command["edits"][0]["meta"].update(
        {
            "apply_kind": "production_trial",
            "production_trial_budget_class": "alternate_followup",
            "production_trial_followup_allowed": True,
            "production_trial_allowed": True,
            "production_apply_allowed": False,
            "certified_for_apply": False,
        }
    )
    return command


def _resid_command_with_memory():
    command = _resid_command()
    command["meta"] = dict(command["meta"]) | {
        "controller_memory": {
            "hypothesis": "small_rescue",
            "micro_rationale": "test a small reversible rescue first",
            "focus_term": "budget",
            "expected_effect": "break_loop",
            "observed_outcome": "unknown",
            "why_failed_or_helped": "first attempt; no effect observed yet",
            "surface_family_key": "resid_add_s_resid_l11_last",
            "transfer_confidence": 0.35,
            "same_family_escalation_risk": 0.4,
            "finish_budget_reserved": 1,
            "evidence_bullets": [
                "helpful_on=budget@l11",
                "reserve last edit until transfer is proven",
            ],
            "next_change": "wait for effect before stacking",
            "next_trigger": "loop_relief_without_coverage",
            "next_action": "request_observer_check",
            "stop_condition": "if no progress improves, stop",
            "confidence": 0.55,
        }
    }
    return command


def _noop_command_with_observer_request():
    return {
        "version": "0.1",
        "decision": "noop",
        "meta": {
            "hypothesis": "loop_relief_but_coverage_zero",
            "micro_rationale": "Loop eased, but coverage is still zero.",
            "next_trigger": "observer_flat_after_loop_relief",
            "next_action": "apply",
            "observer_check_request": {
                "kind": "semantic_progress",
                "reason": "fresh semantic read after loop relief",
            },
        },
    }


def _noop_command_with_tool_requests():
    return {
        "version": "0.1",
        "decision": "noop",
        "meta": {
            "hypothesis": "need_local_tools_before_next_apply",
            "micro_rationale": "Gather local evidence before the next edit.",
            "tool_requests": [
                {"tool": "tokenize_terms", "terms": ["Mira", "budget"]},
                {
                    "tool": "dry_run_decode",
                    "candidate_edit": {
                        "surface_id": "s_resid_l11_last",
                        "kind": "resid_add",
                        "alpha": 0.04,
                        "ttl_steps": 1,
                        "step_size": 0.04,
                    },
                    "max_new_tokens": 3,
                },
            ],
        },
    }


def _noop_command_with_diagnostic_request():
    return {
        "version": "0.1",
        "decision": "noop",
        "meta": {
            "hypothesis": "need_operator_evidence_before_apply",
            "micro_rationale": "Frontier is visible, but needs bounded diagnostic evidence.",
            "objective_bundle_key": "kv_pair:budget:source_body:72:73",
            "step_actuator_bundle_key": "kv_pair:budget:source_body:72:73",
            "diagnostic_request": "operator_diagnostic_replay",
            "next_evidence_needed": "certified_self_or_bridge_actuator",
            "next_action": "request_operator_diagnostic",
            "why_not_apply": "frontier visible but no certified actuator",
            "controller_memory": {
                "hypothesis": "need_operator_evidence_before_apply",
                "diagnostic_request": "operator_diagnostic_replay",
                "next_evidence_needed": "certified_self_or_bridge_actuator",
                "next_action": "request_operator_diagnostic",
            },
        },
    }


def _rank1_command():
    return {
        "version": "0.1",
        "decision": "apply",
        "edits": [
            {
                "id": "e_rank1",
                "target": {"surface_id": "s_weight_l7_mlp"},
                "source": {
                    "dtype": "rank1",
                    "u": {
                        "ref": {
                            "scope": "runtime",
                            "worker": "os_0",
                            "tensor": "hidden",
                            "layer": 7,
                            "token": {"mode": "last"},
                        }
                    },
                    "v": {
                        "ref": {
                            "scope": "trace",
                            "trace_id": "paired_baseline",
                            "worker": "os_0",
                            "tensor": "hidden",
                            "layer": 7,
                            "token": {"mode": "last"},
                        }
                    },
                },
                "op": {"kind": "rank1_patch", "alpha": 0.05},
                "budget": {"ttl_steps": 4, "rank_cap": 1, "revertible": True},
            }
        ],
    }


def _attn_rank1_command():
    return {
        "version": "0.1",
        "decision": "apply",
        "edits": [
            {
                "id": "e_attn_rank1",
                "target": {"surface_id": "s_weight_l0_attn"},
                "source": {
                    "dtype": "rank1",
                    "u": {
                        "ref": {
                            "scope": "runtime",
                            "worker": "os_0",
                            "tensor": "resid_post",
                            "layer": 0,
                            "token": {"mode": "last"},
                        }
                    },
                    "v": {
                        "ref": {
                            "scope": "trace",
                            "trace_id": "paired_baseline",
                            "worker": "os_0",
                            "tensor": "resid_post",
                            "layer": 0,
                            "token": {"mode": "last"},
                        }
                    },
                },
                "op": {"kind": "rank1_patch", "alpha": 0.05},
                "budget": {"ttl_steps": 3, "rank_cap": 1, "revertible": True},
            }
        ],
    }


def _mlp_rank1_command():
    return {
        "version": "0.1",
        "decision": "apply",
        "edits": [
            {
                "id": "e_mlp_rank1",
                "target": {"surface_id": "s_weight_l0_mlp"},
                "source": {
                    "dtype": "rank1",
                    "u": {
                        "ref": {
                            "scope": "runtime",
                            "worker": "os_0",
                            "tensor": "resid_post",
                            "layer": 0,
                            "token": {"mode": "last"},
                        }
                    },
                    "v": {
                        "ref": {
                            "scope": "trace",
                            "trace_id": "paired_baseline",
                            "worker": "os_0",
                            "tensor": "resid_post",
                            "layer": 0,
                            "token": {"mode": "last"},
                        }
                    },
                },
                "op": {"kind": "rank1_patch", "alpha": 0.05},
                "budget": {"ttl_steps": 3, "rank_cap": 1, "revertible": True},
            }
        ],
    }


class DummyOverlayHandle(OverlayHandle):
    def __init__(self, u, v, alpha):
        self.u = u
        self.v = v
        self.alpha = alpha
        self.attached = False
        self.detached = False

    def attach(self):
        self.attached = True

    def detach(self):
        self.detached = True

    def tick(self):
        return None


class FakeRuntimeState:
    def __init__(self):
        self.seed = 17
        self.hooks = {}
        self.overlays = {}
        self.model = None
        self.tensors = {
            ("runtime", None, "hidden", 11): torch.tensor([1.0, 2.0, 3.0]),
            ("runtime", None, "hidden", 7): torch.tensor([0.3, 0.4, 0.5]),
            ("trace", "paired_baseline", "hidden", 7): torch.tensor([0.6, 0.2, 0.1]),
        }

    def read_tensor(self, ref, _ctx):
        return self.tensors[(ref["scope"], ref.get("trace_id"), ref["tensor"], ref["layer"])]

    def register_hook(self, *, hook_name, hook_fn, edit_id, ttl_steps, revertible, metadata=None):
        self.hooks[edit_id] = {
            "hook_name": hook_name,
            "hook_fn": hook_fn,
            "ttl_steps": ttl_steps,
            "revertible": revertible,
            "metadata": dict(metadata or {}),
        }

    def register_overlay(self, *, edit_id, handle, ttl_steps, revertible, metadata=None):
        handle.attach()
        self.overlays[edit_id] = {
            "handle": handle,
            "ttl_steps": ttl_steps,
            "revertible": revertible,
            "metadata": dict(metadata or {}),
        }

    def remove_edit(self, edit_id):
        hook = self.hooks.pop(edit_id, None)
        if hook is not None:
            return
        overlay = self.overlays.pop(edit_id, None)
        if overlay is not None:
            overlay["handle"].detach()

    def tick_ttl(self):
        expired = []
        for edit_id, record in list(self.hooks.items()):
            record["ttl_steps"] -= 1
            if record["ttl_steps"] <= 0:
                expired.append(edit_id)
        for edit_id, record in list(self.overlays.items()):
            record["ttl_steps"] -= 1
            record["handle"].tick()
            if record["ttl_steps"] <= 0:
                expired.append(edit_id)
        for edit_id in expired:
            self.remove_edit(edit_id)

    def cleanup_expired(self):
        return None

    def has_edit(self, edit_id):
        return edit_id in self.hooks or edit_id in self.overlays

    def clear_edits(self):
        for edit_id in list(self.hooks):
            self.remove_edit(edit_id)
        for edit_id in list(self.overlays):
            self.remove_edit(edit_id)


class FakeAdapter(ModelAdapter):
    def bind_surface(self, surface):
        target = surface.target
        hook_name = None
        module_ref = None
        if target.kind == "activation":
            hook_name = f"{target.site}:{target.layer}"
        elif target.kind == "cache":
            hook_name = f"{target.site}:{target.layer}"
        else:
            module_ref = object()
        site = getattr(target, "site", getattr(target, "module", "unknown"))
        token_selector = getattr(target, "token", None)
        return BoundSurface(
            surface_id=surface.surface_id,
            kind=target.kind,
            hook_name=hook_name,
            module_ref=module_ref,
            layer=target.layer,
            site=site,
            token_selector=token_selector,
            head=getattr(target, "head", None),
            caps=surface.caps,
            allow_ops=list(surface.allow_ops),
            target=target,
        )

    def read_ref(self, ref, ctx):
        return ctx.runtime_state.read_tensor(ref, ctx)

    def make_activation_hook(self, surface, op_kind, tensor_fn, alpha, budget):
        self._last_activation_args = (surface, op_kind, alpha, budget)

        def hook_fn(act, _hook):
            vec = tensor_fn(self._current_step_ctx)
            vec = prepare_direction(vec, alpha=alpha, norm_clip=budget.get("norm_clip"), step_size=budget.get("step_size"))
            return self._add_to_selected_tokens(act, vec, surface.token_selector, alpha)

        return surface.hook_name, hook_fn

    def make_activation_patch_hook(self, surface, tensor_fn, alpha, mode, budget, telemetry=None):
        self._last_activation_patch_args = (surface, mode, alpha, budget, telemetry)

        def hook_fn(act, _hook):
            if telemetry is not None:
                telemetry["hook_call_count"] = int(telemetry.get("hook_call_count", 0) or 0) + 1
            vec = tensor_fn(self._current_step_ctx)
            return self._blend_selected_tokens(
                act,
                vec,
                surface.token_selector,
                alpha,
                step_size=budget.get("step_size"),
                telemetry=telemetry,
            )

        return surface.hook_name, hook_fn

    def make_kv_hook(self, surface, tensor_fn, alpha, which, budget):
        self._last_kv_args = (surface, which, alpha, budget)

        def hook_fn(act, _hook):
            vec = tensor_fn(self._current_step_ctx)
            vec = prepare_direction(vec, alpha=alpha, norm_clip=budget.get("norm_clip"), step_size=budget.get("step_size"))
            return self._mix_selected_tokens(act, vec, surface.token_selector, alpha)

        return surface.hook_name, hook_fn

    def make_rank1_overlay(self, surface, u_fn, v_fn, alpha, budget):
        self._last_rank1_args = (surface, alpha, budget)
        return DummyOverlayHandle(u_fn(self._current_step_ctx), v_fn(self._current_step_ctx), alpha)


class TestSchemaAndPolicy(unittest.TestCase):
    def test_parse_controller_command_uses_surface_alias(self):
        command = parse_controller_command(_resid_command())
        self.assertIsInstance(command, ControllerCommand)
        self.assertEqual(command.decision, "apply")
        self.assertIsInstance(command.edits[0].target, SurfaceTargetRef)
        self.assertEqual(command.edits[0].budget.ttl_steps, 2)

    def test_parse_activation_patch_blend_command(self):
        command = parse_controller_command(_activation_patch_command())
        self.assertEqual(command.edits[0].op.kind, "activation_patch")
        self.assertEqual(command.edits[0].op.mode, "blend")

    def test_activation_patch_rejects_unsupported_mode(self):
        command = _activation_patch_command()
        command["edits"][0]["op"]["mode"] = "delta"
        with self.assertRaises(SchemaError):
            parse_controller_command(command)

    def test_activation_patch_policy_requires_activation_last_surface(self):
        packet = _make_packet()
        packet["surface_catalog"][0]["allow_ops"] = ["resid_add", "activation_patch"]
        command = _activation_patch_command()
        validate_command_against_packet(command, packet)

        weight_command = _activation_patch_command()
        weight_command["edits"][0]["target"] = {"surface_id": "s_weight_l7_mlp"}
        weight_command["edits"][0]["op"]["alpha"] = 0.05
        packet["surface_catalog"][1]["allow_ops"] = ["rank1_patch", "activation_patch"]
        with self.assertRaisesRegex(PolicyViolation, "activation target"):
            validate_command_against_packet(weight_command, packet)

        prev_packet = _make_packet()
        prev_packet["surface_catalog"][0]["target"]["token"] = {"mode": "index", "value": -2}
        prev_packet["surface_catalog"][0]["allow_ops"] = ["resid_add", "activation_patch"]
        with self.assertRaisesRegex(PolicyViolation, "last token"):
            validate_command_against_packet(command, prev_packet)

        ttl_command = _activation_patch_command()
        ttl_command["edits"][0]["budget"]["ttl_steps"] = 2
        with self.assertRaisesRegex(PolicyViolation, "ttl_steps=1"):
            validate_command_against_packet(ttl_command, packet)

    def test_parse_observation_packet(self):
        packet = parse_observation_packet(_make_packet())
        self.assertIsInstance(packet, ControllerObservationPacket)
        self.assertEqual(packet.surface_catalog[0].surface_id, "s_resid_l11_last")
        self.assertEqual(packet.trace_bank[0].trace_id, "best_success")

    def test_policy_rejects_surface_alpha_violation(self):
        packet = _make_packet()
        command = _resid_command()
        command["edits"][0]["op"]["alpha"] = 0.25
        with self.assertRaises(PolicyViolation):
            validate_command_against_packet(command, packet)

    def test_policy_rejects_unknown_rollback_id(self):
        packet = _make_packet(rollbackable_ids=["known"])
        command = {"version": "0.1", "decision": "rollback", "rollback_ids": ["missing"]}
        with self.assertRaises(PolicyViolation):
            validate_command_against_packet(command, packet)

    def test_policy_rejects_step_size_above_surface_cap(self):
        packet = _make_packet()
        packet["surface_catalog"][0]["caps"]["step_size"] = 0.05
        command = _resid_command()
        command["edits"][0]["budget"]["step_size"] = 0.08
        with self.assertRaises(PolicyViolation):
            validate_command_against_packet(command, packet)

    def test_policy_allows_loop_rescue_edit_when_main_run_budget_is_exhausted(self):
        packet = _make_packet()
        packet["budget"]["edits_left_this_run"] = 0
        packet["budget"]["alpha_left_total"] = 0.0
        packet["budget"]["edit_cost_left_total"] = 0.0
        packet["budget"]["loop_rescue_edits_left_this_run"] = 2
        packet["budget"]["loop_rescue_alpha_left_total"] = 0.12
        packet["budget"]["loop_rescue_edit_cost_left_total"] = 0.12

        validate_command_against_packet(_loop_rescue_command(), packet)

    def test_policy_accounts_production_trial_followup_separately(self):
        packet = _make_packet()
        packet["budget"].update(
            {
                "edits_left_this_run": 0,
                "alpha_left_total": 0.0,
                "edit_cost_left_total": 0.0,
                "production_trial_edits_left_this_run": 0,
                "production_trial_alpha_left_total": 0.0,
                "production_trial_edit_cost_left_total": 0.0,
                "production_trial_followup_edits_left_this_run": 1,
                "production_trial_followup_alpha_left_total": 0.05,
                "production_trial_followup_edit_cost_left_total": 0.05,
            }
        )
        command = _production_trial_followup_command()
        deep_expr = {
            "ref": {
                "scope": "runtime",
                "worker": "os_0",
                "tensor": "hidden",
                "layer": 11,
                "token": {"mode": "last"},
            }
        }
        for _ in range(8):
            deep_expr = {"fn": "scale", "by": 1.0, "arg": deep_expr}
        command["edits"][0]["source"]["expr"] = deep_expr

        usage = command_budget_usage(command, packet)
        self.assertEqual(usage[PRODUCTION_TRIAL_FOLLOWUP_EDIT_BUDGET_POOL]["edit_count"], 1.0)
        self.assertIsNone(budget_violation_reason(command, packet, usage=usage))
        validate_command_against_packet(command, packet)

        packet["budget"]["production_trial_followup_edits_left_this_run"] = 0
        self.assertEqual(
            budget_violation_reason(command, packet),
            "command exceeds packet.production_trial_followup_edits_left_this_run",
        )


class TestCompiler(unittest.TestCase):
    def test_compile_resid_add_registers_hook(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)

        compiled = compile_command(_resid_command(), packet, ctx)
        self.assertEqual(len(compiled), 1)
        compiled[0].apply(ctx)
        self.assertTrue(runtime_state.has_edit("e_rescue"))

        act = torch.zeros(1, 4, 3)
        hook_fn = runtime_state.hooks["e_rescue"]["hook_fn"]
        out = hook_fn(act, None)
        expected_vec = prepare_direction(
            torch.tensor([1.0, 2.0, 3.0]),
            alpha=0.2,
            norm_clip=1.5,
            step_size=None,
        )

        self.assertTrue(torch.allclose(out[0, -1], 0.2 * expected_vec))
        self.assertTrue(torch.allclose(out[0, 0], torch.zeros(3)))

    def test_compile_activation_patch_registers_blend_hook(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet_payload = _make_packet()
        packet_payload["surface_catalog"][0]["allow_ops"] = ["resid_add", "activation_patch"]
        packet = parse_observation_packet(packet_payload)
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)

        compiled = compile_command(_activation_patch_command(), packet, ctx)
        self.assertEqual(len(compiled), 1)
        self.assertEqual(compiled[0].kind, "activation_patch")
        compiled[0].apply(ctx)
        self.assertTrue(runtime_state.has_edit("e_activation_patch"))

        hook_record = runtime_state.hooks["e_activation_patch"]
        self.assertEqual(hook_record["metadata"]["op"], "activation_patch")
        self.assertEqual(hook_record["metadata"]["activation_patch_mode"], "blend")
        self.assertEqual(hook_record["metadata"]["source_localization"], "source_term_token")
        self.assertIn("activation_patch_telemetry", hook_record["metadata"])
        act = torch.full((1, 4, 3), 10.0)
        out = hook_record["hook_fn"](act, None)
        expected_last = (0.8 * torch.tensor([10.0, 10.0, 10.0])) + (0.2 * torch.tensor([1.0, 2.0, 3.0]))
        self.assertTrue(torch.allclose(out[0, -1], expected_last))
        self.assertTrue(torch.allclose(out[0, 0], torch.full((3,), 10.0)))
        telemetry = hook_record["metadata"]["activation_patch_telemetry"]
        self.assertEqual(telemetry["hook_call_count"], 1)
        self.assertGreater(telemetry["blend_delta_norm"], 0.0)
        self.assertFalse(telemetry["step_size_clip_saturated"])

    def test_activation_patch_blends_toward_raw_source_activation(self):
        adapter = HookedTransformerAdapter(model=object())
        runtime_state = FakeRuntimeState()
        packet_payload = _make_packet()
        packet = parse_observation_packet(packet_payload)
        surface = adapter.bind_surface(packet.surface_catalog[0])
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        adapter.set_step_context(ctx)
        telemetry: dict[str, object] = {}

        _hook_name, hook_fn = adapter.make_activation_patch_hook(
            surface,
            lambda _ctx: torch.tensor([100.0, 0.0, 0.0]),
            alpha=0.2,
            mode="blend",
            budget={"norm_clip": 1.0, "step_size": None},
            telemetry=telemetry,
        )

        out = hook_fn(torch.zeros(1, 4, 3), None)

        self.assertTrue(torch.allclose(out[0, -1], torch.tensor([20.0, 0.0, 0.0])))
        self.assertEqual(telemetry["hook_call_count"], 1)
        self.assertEqual(telemetry["source_norm"], 100.0)
        self.assertFalse(telemetry["step_size_clip_saturated"])

    def test_compile_rank1_patch_registers_overlay_and_rolls_back(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        permissive_policy = HarnessPolicy(deny_targets=())

        compiled = compile_command(_rank1_command(), packet, ctx, policy=permissive_policy)
        compiled[0].apply(ctx)
        self.assertIn("e_rank1", runtime_state.overlays)
        overlay = runtime_state.overlays["e_rank1"]["handle"]
        self.assertTrue(overlay.attached)

        compiled[0].rollback(ctx)
        self.assertNotIn("e_rank1", runtime_state.overlays)
        self.assertTrue(overlay.detached)

    def test_compile_resid_add_enforces_step_size_and_records_cost(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet_payload = _make_packet()
        packet_payload["surface_catalog"][0]["caps"]["step_size"] = 0.1
        packet_payload["budget"]["edit_cost_left_total"] = 0.5
        packet = parse_observation_packet(packet_payload)
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        command = _resid_command()
        command["edits"][0]["budget"]["step_size"] = 0.1

        permissive_policy = HarnessPolicy(global_budget=GlobalBudget(max_total_alpha=1.0, max_total_edit_cost=1.0))
        compiled = compile_command(command, packet, ctx, policy=permissive_policy)
        compiled[0].apply(ctx)

        hook_record = runtime_state.hooks["e_rescue"]
        self.assertAlmostEqual(hook_record["metadata"]["step_size"], 0.1, places=6)
        self.assertGreater(hook_record["metadata"]["edit_cost"], 0.0)

        act = torch.zeros(1, 4, 3)
        out = hook_record["hook_fn"](act, None)
        self.assertLessEqual(float(out[0, -1].norm().item()), 0.1001)

    def test_compile_readout_direction_resid_add_uses_unembed_columns(self):
        class TinyReadoutModel:
            W_U = torch.tensor(
                [
                    [1.0, 0.0, 0.0, 0.0],
                    [0.0, 1.0, 0.0, 0.0],
                    [0.0, 0.0, 1.0, 0.0],
                ]
            )

        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        runtime_state.model = TinyReadoutModel()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        command = _resid_command()
        command["edits"][0]["source"] = {
            "dtype": "vector",
            "expr": {
                "fn": "readout_direction",
                "target_token_ids": [1],
                "negative_token_ids": [2],
                "negative_scale": 1.0,
            },
        }

        compiled = compile_command(command, packet, ctx)
        compiled[0].apply(ctx)
        hook_fn = runtime_state.hooks["e_rescue"]["hook_fn"]
        out = hook_fn(torch.zeros(1, 4, 3), None)
        expected_direction = torch.nn.functional.normalize(torch.tensor([0.0, 1.0, -1.0]), dim=0)
        self.assertTrue(torch.allclose(out[0, -1], 0.2 * expected_direction, atol=1e-6))

    def test_readout_direction_gathers_before_fp32_conversion(self):
        runtime_state = FakeRuntimeState()
        ctx = StepContext(packet=parse_observation_packet(_make_packet()), runtime_state=runtime_state,
                          traces={}, stats={}, adapter=FakeAdapter())
        expr = {"fn": "readout_direction", "target_token_ids": [1, 4],
                "negative_token_ids": [3, 6], "negative_scale": 0.25, "normalize": False}
        for dtype in (torch.float16, torch.bfloat16):
            for transposed in (False, True):
                with self.subTest(dtype=dtype, transposed=transposed):
                    weights = (torch.arange(24, dtype=torch.float32, device="cpu") / 7).reshape(3, 8).to(dtype)
                    matrix = weights.T.contiguous() if transposed else weights
                    runtime_state.model = type("ReadoutModel", (), {"W_U": torch.nn.Parameter(matrix)})()
                    source = _readout_matrix(ctx)
                    self.assertEqual(source.data_ptr(), matrix.data_ptr())
                    self.assertEqual(source.dtype, dtype)
                    full_fp32 = weights.float()
                    target = full_fp32[:, [1, 4]].T.contiguous().mean(dim=0)
                    negative = full_fp32[:, [3, 6]].T.contiguous().mean(dim=0)
                    actual = compile_expr(expr)(ctx)
                    self.assertEqual(actual.dtype, torch.float32)
                    self.assertTrue(torch.equal(actual, target - 0.25 * negative))

    def test_readout_direction_rejects_unsafe_payloads(self):
        command = _resid_command()
        command["edits"][0]["source"] = {
            "dtype": "vector",
            "expr": {
                "fn": "readout_direction",
                "target_token_ids": [True],
            },
        }
        with self.assertRaises(SchemaError):
            parse_controller_command(command)

        command = _resid_command()
        command["edits"][0]["source"] = {
            "dtype": "vector",
            "expr": {
                "fn": "readout_direction",
                "target_token_ids": [-1],
            },
        }
        with self.assertRaises(SchemaError):
            parse_controller_command(command)

        command = _resid_command()
        command["edits"][0]["source"] = {
            "dtype": "vector",
            "expr": {
                "fn": "readout_direction",
                "target_token_ids": [1],
                "target_scale": 2.5,
            },
        }
        with self.assertRaises(SchemaError):
            parse_controller_command(command)

        command = _resid_command()
        command["edits"][0]["source"] = {
            "dtype": "vector",
            "expr": {
                "fn": "readout_direction",
                "negative_token_ids": list(range(33)),
            },
        }
        with self.assertRaises(SchemaError):
            parse_controller_command(command)

    def test_actual_delta_classifies_attractor_relief_without_target_lift(self):
        worker = HookedTransformerWorkerRuntime.__new__(HookedTransformerWorkerRuntime)
        cls = worker._classify_actual_delta_result(
            {
                "continuation_baseline": " the the",
                "continuation_candidate": " the",
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "attractor_family_mass_delta": -0.0001,
                "attractor_top20_hit_delta": -1,
                "repeat_flag_delta": -1,
                "repetition_score_delta": -0.2,
                "entropy_delta": 0.04,
                "top1_margin_delta": -0.01,
            }
        )
        self.assertEqual(cls, "collapse_suppressor")

    def test_actual_delta_keeps_rank_and_gap_movement_below_target_lift(self):
        worker = HookedTransformerWorkerRuntime.__new__(HookedTransformerWorkerRuntime)
        self.assertEqual(
            worker._classify_actual_delta_result(
                {
                    "focus_rank_delta": 8,
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                }
            ),
            "rank_carrier",
        )
        self.assertEqual(
            worker._classify_actual_delta_result(
                {
                    "target_top20_threshold_gap_delta": -0.12,
                    "target_piece_logit_delta": 0.01,
                    "target_mass_delta": 0.0,
                    "target_top20_hit_delta": 0,
                }
            ),
            "readout_gap_movement",
        )
        self.assertEqual(
            worker._classify_actual_delta_result(
                {
                    "target_mass_delta": 0.00003,
                    "target_top20_hit_delta": 0,
                }
            ),
            "target_lift",
        )

    def test_compile_loop_rescue_resid_add_records_loop_rescue_budget_pool(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet_payload = _make_packet()
        packet_payload["budget"]["loop_rescue_edits_left_this_run"] = 2
        packet_payload["budget"]["loop_rescue_alpha_left_total"] = 0.12
        packet_payload["budget"]["loop_rescue_edit_cost_left_total"] = 0.12
        packet_payload["surface_catalog"][0]["caps"]["step_size"] = 0.06
        packet = parse_observation_packet(packet_payload)
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)

        compiled = compile_command(_loop_rescue_command(), packet, ctx)
        compiled[0].apply(ctx)

        hook_record = runtime_state.hooks["e_loop_rescue"]
        self.assertEqual(hook_record["metadata"]["budget_pool"], "loop_rescue")


class _ToyTaskEnv:
    def reset(self, seed: int) -> str:
        self.seed = seed
        return f"seed={seed}"

    def score(self, output: str) -> float:
        return 1.0 if "patched" in output else 0.0

    def done(self, output: str) -> bool:
        return "patched" in output


class _ToyController:
    def __init__(self):
        self.calls = 0
        self._last_trace = None

    def latest_trace(self):
        return self._last_trace

    def invoke(self, packet):
        self.calls += 1
        self._last_trace = {
            "provider": "fake",
            "model": "toy-controller",
            "observation": {
                "step": packet["step"],
                "worker_status": packet["worker_view"]["status"],
                "surface_ids": [surface["surface_id"] for surface in packet["surface_catalog"]],
                "controller_memory": list(packet.get("controller_memory", [])),
            },
            "attempts": [
                {
                    "attempt": 1,
                    "provider": "fake",
                    "model": "toy-controller",
                    "latency_ms": 1.0,
                    "parse_ok": True,
                    "response_text": "{\"version\":\"0.1\",\"decision\":\"apply\"}",
                }
            ],
            "decision": {
                "decision": "apply" if self.calls == 1 else "noop",
                "edit_ids": ["e_rescue"] if self.calls == 1 else [],
                "ops": ["resid_add"] if self.calls == 1 else [],
                "step_sizes": [0.1] if self.calls == 1 else [],
                "total_edit_cost": 0.1 if self.calls == 1 else 0.0,
            },
            "success": True,
        }
        if self.calls == 1:
            return _resid_command()
        return {"version": "0.1", "decision": "noop"}


class _LoopRescueToyController(_ToyController):
    def invoke(self, packet):
        self.calls += 1
        self._last_trace = {
            "provider": "fake",
            "model": "toy-controller",
            "observation": {
                "step": packet["step"],
                "worker_status": packet["worker_view"]["status"],
            },
            "attempts": [
                {
                    "attempt": 1,
                    "provider": "fake",
                    "model": "toy-controller",
                    "latency_ms": 1.0,
                    "parse_ok": True,
                    "response_text": "{\"version\":\"0.1\",\"decision\":\"apply\"}",
                }
            ],
            "decision": {
                "decision": "apply" if self.calls == 1 else "noop",
                "edit_ids": ["e_loop_rescue"] if self.calls == 1 else [],
                "ops": ["resid_add"] if self.calls == 1 else [],
            },
            "success": True,
        }
        if self.calls == 1:
            return _loop_rescue_command()
        return {"version": "0.1", "decision": "noop"}


class _OverBudgetLoopRescueToyController(_ToyController):
    def invoke(self, packet):
        self.calls += 1
        self._last_trace = {
            "provider": "fake",
            "model": "toy-controller",
            "observation": {
                "step": packet["step"],
                "worker_status": packet["worker_view"]["status"],
            },
            "attempts": [
                {
                    "attempt": 1,
                    "provider": "fake",
                    "model": "toy-controller",
                    "latency_ms": 1.0,
                    "parse_ok": True,
                    "response_text": "{\"version\":\"0.1\",\"decision\":\"apply\"}",
                }
            ],
            "decision": {
                "decision": "apply" if self.calls == 1 else "noop",
                "edit_ids": ["e_loop_rescue_overbudget"] if self.calls == 1 else [],
                "ops": ["resid_add"] if self.calls == 1 else [],
            },
            "success": True,
        }
        if self.calls == 1:
            return _loop_rescue_command(alpha=0.08, step_size=0.08, edit_id="e_loop_rescue_overbudget")
        return {"version": "0.1", "decision": "noop"}


class _ParsedCommandController:
    def __init__(self, inner):
        self.inner = inner

    def latest_trace(self):
        return self.inner.latest_trace()

    def invoke(self, packet):
        command = self.inner.invoke(packet)
        if isinstance(command, ControllerCommand):
            return command
        return parse_controller_command(command)


class _ToyWorkerRuntime:
    def __init__(self, runtime_state):
        self.runtime_state = runtime_state
        self.output = ""
        self.steps = 0
        self._latest_effect_trace = {"completed_effects": [], "summary": {"window_size": 0, "verdict_counts": {}, "hypothesis_stats": [], "latest_effects": []}}
        self._controller_memory = []
        self._observer_checks = []
        self._pending_observer_check_events = []
        self._tool_results = []
        self._pending_tool_events = []
        self._diagnostic_results = []
        self._pending_diagnostic_events = []

    def reset(self, prompt: str) -> None:
        self.prompt = prompt
        self.output = "base"
        self.steps = 0
        self._controller_memory = []
        self._observer_checks = []
        self._pending_observer_check_events = []
        self._tool_results = []
        self._pending_tool_events = []
        self._diagnostic_results = []
        self._pending_diagnostic_events = []

    def step(self) -> None:
        self.steps += 1
        if self.steps >= 2 and self.runtime_state.has_edit("e_rescue"):
            self.output = "patched"
        elif self.steps >= 2:
            self.output = "base"

    def done(self) -> bool:
        return self.steps >= 2

    def build_controller_packet(self):
        rollbackable_ids = list(self.runtime_state.hooks) + list(self.runtime_state.overlays)
        packet = _make_packet(rollbackable_ids=rollbackable_ids)
        packet["controller_memory"] = [dict(entry) for entry in self._controller_memory]
        if self._observer_checks:
            packet["latest_observer_check"] = dict(self._observer_checks[-1])
            packet["recent_observer_checks"] = [dict(entry) for entry in self._observer_checks[-4:]]
        packet["tool_catalog"] = [
            {"tool": "tokenize_terms", "available": True, "cost_hint": "cheap", "budget_left": 4},
            {"tool": "dry_run_decode", "available": True, "cost_hint": "expensive", "budget_left": 4},
        ]
        if self._tool_results:
            packet["latest_tool_results"] = [dict(entry) for entry in self._tool_results[-2:]]
            packet["recent_tool_results"] = [dict(entry) for entry in self._tool_results[-4:]]
        if self._diagnostic_results:
            packet["latest_diagnostic_results"] = [dict(entry) for entry in self._diagnostic_results[-2:]]
            packet["recent_diagnostic_results"] = [dict(entry) for entry in self._diagnostic_results[-4:]]
        return packet

    def observe_recent_effects(self) -> None:
        if self.steps >= 2 and self.runtime_state.has_edit("e_rescue"):
            effect = {
                "edit_id": "e_rescue",
                "surface_id": "s_resid_l11_last",
                "observed_window_steps": 1,
                "before": {"entropy": 2.5, "top1_margin": 0.05, "repetition_score": 0.4},
                "after": {"entropy": 2.0, "top1_margin": 0.08, "repetition_score": 0.2},
                "delta": {"entropy": -0.5, "top1_margin": 0.03, "repetition_score": -0.2},
                "verdict": "helpful",
                "hypothesis": "rescue",
                "expected_effect": "break_loop",
            }
            self._latest_effect_trace = {
                "completed_effects": [effect],
                "summary": summarize_effects([effect]),
            }
            return None
        self._latest_effect_trace = {"completed_effects": [], "summary": summarize_effects(())}
        return None

    def tick_ttl(self) -> None:
        return None

    def cleanup_expired(self) -> None:
        return None

    def final_text(self) -> str:
        return self.output

    def latest_effect_trace(self):
        return self._latest_effect_trace

    def record_controller_memory(self, entry, *, decision=None):
        stored = dict(entry)
        if decision is not None:
            stored["decision"] = decision
        self._controller_memory.append(stored)
        self._controller_memory = self._controller_memory[-3:]
        return stored

    def request_observer_check(self, request, *, source="controller"):
        stored = {
            "check_type": "semantic_progress",
            "trigger": f"{source}_request",
            "verdict": "baseline" if not self._observer_checks else "flat",
            "score": 0.4,
            "requested_by": source,
            "request_kind": request.get("kind", "semantic_progress"),
            "request_reason": request.get("reason"),
            "recorded_step": self.steps,
        }
        self._observer_checks.append(stored)
        self._pending_observer_check_events.append(stored)
        return dict(stored)

    def pop_observer_check_events(self):
        events = [dict(entry) for entry in self._pending_observer_check_events]
        self._pending_observer_check_events = []
        return events

    def request_controller_tools(self, requests, *, source="controller"):
        results = []
        for request in requests:
            tool_name = request.get("tool")
            if tool_name == "tokenize_terms":
                result = {
                    "tool": "tokenize_terms",
                    "status": "ok",
                    "requested_by": source,
                    "recorded_step": self.steps,
                    "term_count": len(request.get("terms", [])),
                }
            elif tool_name == "dry_run_decode":
                result = {
                    "tool": "dry_run_decode",
                    "status": "ok",
                    "requested_by": source,
                    "recorded_step": self.steps,
                    "entropy_delta": -0.1,
                    "repeat_flag_delta": -1,
                    "required_term_recall_delta": 0.25,
                }
            else:
                continue
            self._tool_results.append(result)
            self._pending_tool_events.append(result)
            results.append(dict(result))
        self._tool_results = self._tool_results[-4:]
        return results

    def pop_tool_events(self):
        events = [dict(entry) for entry in self._pending_tool_events]
        self._pending_tool_events = []
        return events

    def request_controller_diagnostics(self, requests, *, source="controller", packet=None):
        results = []
        for request in requests:
            diagnostic = request.get("diagnostic", request.get("diagnostic_request", "operator_diagnostic_replay"))
            result = {
                "diagnostic": diagnostic,
                "status": "ok",
                "requested_by": source,
                "recorded_step": self.steps,
                "bundle_key": request.get("bundle_key"),
                "next_evidence_needed": request.get("next_evidence_needed"),
                "operator_certified": False,
                "production_apply_allowed": False,
                "evidence_rows": [
                    {
                        "evidence_kind": "operator_replay",
                        "status": "blocked",
                        "actuator_class": "dead_actuator",
                    }
                ],
            }
            self._diagnostic_results.append(result)
            self._pending_diagnostic_events.append(result)
            results.append(dict(result))
        self._diagnostic_results = self._diagnostic_results[-4:]
        return results

    def pop_diagnostic_events(self):
        events = [dict(entry) for entry in self._pending_diagnostic_events]
        self._pending_diagnostic_events = []
        return events


class _BudgetExhaustedToyWorkerRuntime(_ToyWorkerRuntime):
    def build_controller_packet(self):
        packet = super().build_controller_packet()
        packet["budget"]["edits_left_this_run"] = 0
        return packet


class _LoopRescueBudgetToyWorkerRuntime(_ToyWorkerRuntime):
    def build_controller_packet(self):
        packet = super().build_controller_packet()
        packet["budget"]["edits_left_this_run"] = 0
        packet["budget"]["alpha_left_total"] = 0.0
        packet["budget"]["edit_cost_left_total"] = 0.0
        packet["budget"]["loop_rescue_edits_left_this_run"] = 2
        packet["budget"]["loop_rescue_alpha_left_total"] = 0.12
        packet["budget"]["loop_rescue_edit_cost_left_total"] = 0.12
        return packet


class _LowAlphaLoopRescueBudgetToyWorkerRuntime(_ToyWorkerRuntime):
    def build_controller_packet(self):
        packet = super().build_controller_packet()
        packet["budget"]["edits_left_this_run"] = 0
        packet["budget"]["alpha_left_total"] = 0.0
        packet["budget"]["edit_cost_left_total"] = 0.0
        packet["budget"]["loop_rescue_edits_left_this_run"] = 1
        packet["budget"]["loop_rescue_alpha_left_total"] = 0.04
        packet["budget"]["loop_rescue_edit_cost_left_total"] = 0.04
        return packet


class _MemoryToyController(_ToyController):
    def invoke(self, packet):
        response = super().invoke(packet)
        if self.calls == 1:
            return _resid_command_with_memory()
        return response


class _ObserverRequestToyController(_ToyController):
    def invoke(self, packet):
        response = super().invoke(packet)
        if self.calls == 1:
            return _noop_command_with_observer_request()
        return response


class _ToolRequestToyController(_ToyController):
    def invoke(self, packet):
        response = super().invoke(packet)
        if self.calls == 1:
            return _noop_command_with_tool_requests()
        return response


class _DiagnosticRequestToyController(_ToyController):
    def invoke(self, packet):
        response = super().invoke(packet)
        if self.calls == 1:
            return _noop_command_with_diagnostic_request()
        return response


class TestLoopAndEffects(unittest.TestCase):
    def test_build_edit_effect_marks_helpful(self):
        effect = build_edit_effect(
            edit_id="e1",
            surface_id="s1",
            observed_window_steps=1,
            before={
                "entropy": 2.5,
                "top1_margin": 0.05,
                "repetition_score": 0.4,
                "required_term_recall": 0.0,
                "forbidden_term_clean": 1.0,
                "word_budget_score": 1.0,
                "budget_ok": 1.0,
            },
            after={
                "entropy": 2.1,
                "top1_margin": 0.09,
                "repetition_score": 0.2,
                "required_term_recall": 0.25,
                "forbidden_term_clean": 1.0,
                "word_budget_score": 1.0,
                "budget_ok": 1.0,
            },
            hypothesis="rescue",
            expected_effect="break_loop",
        )
        self.assertEqual(effect["verdict"], "helpful")
        self.assertEqual(effect["hypothesis"], "rescue")
        summary = summarize_effects([effect])
        self.assertEqual(summary["hypothesis_stats"][0]["hypothesis"], "rescue")
        self.assertEqual(summary["verdict_counts"]["helpful"], 1)
        self.assertIn("mean_progress_delta", summary["hypothesis_stats"][0])
        self.assertIn("progress_delta", summary["latest_effects"][0])
        self.assertIn("mean_required_term_recall_delta", summary["hypothesis_stats"][0])
        self.assertIn("required_term_recall_delta", summary["latest_effects"][0])
        self.assertIn("mean_required_term_span_progress_delta", summary["hypothesis_stats"][0])
        self.assertIn("required_term_span_progress_delta", summary["latest_effects"][0])

    def test_build_edit_effect_marks_looping_without_progress_as_harmful(self):
        effect = build_edit_effect(
            edit_id="e_loop",
            surface_id="s1",
            observed_window_steps=1,
            before={
                "entropy": 10.1,
                "top1_margin": 0.01,
                "repetition_score": 0.0,
                "partial_score": 0.45,
                "repeat_flag": 0.0,
                "no_progress_steps": 0.0,
                "progress_score": 0.25,
                "task_violation_count": 4.0,
                "done": 0.0,
            },
            after={
                "entropy": 7.8,
                "top1_margin": 0.29,
                "repetition_score": 1.0,
                "partial_score": 0.45,
                "repeat_flag": 1.0,
                "no_progress_steps": 3.0,
                "progress_score": 0.25,
                "task_violation_count": 4.0,
                "done": 0.0,
            },
            hypothesis="bad_reward",
        )

        self.assertEqual(effect["verdict"], "harmful")
        summary = summarize_effects([effect])
        self.assertEqual(summary["verdict_counts"]["harmful"], 1)
        self.assertTrue(summary["latest_effects"][0]["after_is_looping"])

    def test_build_edit_effect_marks_collapse_sharpener_and_tracks_harmful_memory(self):
        effect = build_edit_effect(
            edit_id="e_sharp",
            surface_id="s1",
            observed_window_steps=1,
            before={
                "entropy": 2.5,
                "top1_margin": 0.01,
                "repetition_score": 0.0,
                "repeat_flag": 0.0,
                "required_term_recall": 0.0,
                "required_term_span_progress": 0.0,
                "partial_score": 0.0,
                "semantic_progress_score": 0.0,
                "progress_score": 0.0,
            },
            after={
                "entropy": 2.4,
                "top1_margin": 0.02,
                "repetition_score": 0.2,
                "repeat_flag": 1.0,
                "required_term_recall": 0.0,
                "required_term_span_progress": 0.0,
                "partial_score": 0.0,
                "semantic_progress_score": 0.0,
                "progress_score": 0.0,
            },
            surface_family_key="kv_anchor:budget:exact_prompt_span",
            operator_recipe_id="recipe:budget:span_mean",
            bundle_key="kv_pair:budget:source_body:72:73",
        )
        self.assertEqual(effect["actuator_class"], "collapse_sharpener")
        summary = summarize_effects([effect])
        self.assertIn("kv_anchor:budget:exact_prompt_span", summary["recent_harmful_surface_family_keys"])
        self.assertIn("kv_anchor:budget:exact_prompt_span", summary["recent_collapse_sharpener_surface_family_keys"])
        self.assertIn("recipe:budget:span_mean", summary["recent_collapse_sharpener_operator_recipe_ids"])
        self.assertEqual(summary["latest_effects"][0]["actuator_class"], "collapse_sharpener")

    def test_production_trial_effect_summary_records_outcome_ledger_and_veto_keys(self):
        effect = build_edit_effect(
            edit_id="trial_1",
            surface_id="s_resid_pre_l6_last",
            observed_window_steps=1,
            before={
                "entropy": 2.5,
                "top1_margin": 0.01,
                "repetition_score": 0.0,
                "repeat_flag": 0.0,
                "required_term_recall": 0.0,
                "required_term_span_progress": 0.0,
                "partial_score": 0.0,
                "semantic_progress_score": 0.0,
                "progress_score": 0.0,
            },
            after={
                "entropy": 2.2,
                "top1_margin": 0.04,
                "repetition_score": 0.5,
                "repeat_flag": 1.0,
                "required_term_recall": 0.0,
                "required_term_span_progress": 0.0,
                "partial_score": 0.0,
                "semantic_progress_score": 0.0,
                "progress_score": 0.0,
            },
            surface_family_key="activation_patch_trial:s_resid_pre_l6_last",
            operator_recipe_id="activation_patch:budget:trial",
            bundle_key="kv_pair:budget:source_body:72:73",
            objective_bundle_key="kv_pair:budget:source_body:72:73",
            step_actuator_bundle_key="kv_pair:budget:source_body:72:73",
            apply_kind="production_trial",
            production_trial_allowed=True,
            production_trial_budget_class="alternate_followup",
            production_trial_followup_allowed=True,
            production_apply_allowed=False,
            certified_for_apply=False,
        )

        self.assertEqual(effect["trial_effect_class"], "collapse_sharpener")
        summary = summarize_effects([effect])
        self.assertEqual(summary["production_trial_outcome_counts"]["collapse_sharpener"], 1)
        self.assertEqual(summary["latest_effects"][0]["trial_effect_class"], "collapse_sharpener")
        self.assertEqual(summary["latest_effects"][0]["production_trial_budget_class"], "alternate_followup")
        self.assertEqual(summary["production_trial_outcome_ledger"][0]["apply_kind"], "production_trial")
        self.assertEqual(
            summary["production_trial_outcome_ledger"][0]["production_trial_budget_class"],
            "alternate_followup",
        )
        self.assertEqual(summary["production_trial_outcome_ledger"][0]["trial_effect_class"], "collapse_sharpener")
        self.assertEqual(
            summary["production_trial_outcome_ledger"][0]["promotion_ladder_stage"],
            "trial_blocked_needs_alternate_operator",
        )
        self.assertEqual(
            summary["production_trial_policy_ladder_latest"],
            "trial_blocked_needs_alternate_operator",
        )
        self.assertIn(
            "activation_patch_trial:s_resid_pre_l6_last",
            summary["recent_production_trial_veto_surface_family_keys"],
        )
        self.assertIn(
            "activation_patch:budget:trial",
            summary["recent_production_trial_veto_operator_recipe_ids"],
        )

    def test_build_edit_effect_marks_loop_relief_without_coverage_as_stabilizing_only(self):
        effect = build_edit_effect(
            edit_id="e_stabilize",
            surface_id="s1",
            observed_window_steps=1,
            before={
                "entropy": 5.0,
                "top1_margin": 0.02,
                "repetition_score": 1.0,
                "partial_score": 0.45,
                "required_term_recall": 0.0,
                "required_term_span_progress": 0.0,
                "repeat_flag": 1.0,
                "no_progress_steps": 2.0,
                "progress_score": 0.0,
            },
            after={
                "entropy": 3.2,
                "top1_margin": 0.1,
                "repetition_score": 0.2,
                "partial_score": 0.45,
                "required_term_recall": 0.0,
                "required_term_span_progress": 0.0,
                "repeat_flag": 0.0,
                "no_progress_steps": 0.0,
                "progress_score": 0.0,
            },
            hypothesis="loop_break_only",
        )

        self.assertEqual(effect["verdict"], "neutral")
        self.assertEqual(effect["signal_profile"], "stabilizing_only")
        summary = summarize_effects([effect])
        self.assertEqual(summary["verdict_counts"]["neutral"], 1)
        self.assertEqual(summary["hypothesis_stats"][0]["stabilizing_only_count"], 1)
        self.assertEqual(summary["latest_effects"][0]["signal_profile"], "stabilizing_only")

    def test_run_episode_smoke(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        result = run_episode(
            _ToyTaskEnv(),
            _ToyWorkerRuntime(runtime_state),
            _ToyController(),
            ctx,
            logger=logger,
        )

        self.assertEqual(result.score, 1.0)
        self.assertEqual(result.output, "patched")
        self.assertTrue(any(event["event"] == "controller_observation" for event in logger.events))
        self.assertTrue(any(event["event"] == "controller_provider_attempt" for event in logger.events))
        self.assertTrue(any(event["event"] == "controller_decision" for event in logger.events))
        self.assertTrue(any(event["event"] == "controller_effect" for event in logger.events))
        self.assertTrue(any(event["event"] == "controller_effect_summary" for event in logger.events))
        self.assertTrue(any(event["event"] == "compiled_edit" for event in logger.events))
        self.assertEqual(logger.events[-1]["event"], "episode_end")

    def test_run_episode_guards_apply_when_run_budget_is_exhausted(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        result = run_episode(
            _ToyTaskEnv(),
            _BudgetExhaustedToyWorkerRuntime(runtime_state),
            _ToyController(),
            ctx,
            logger=logger,
        )

        self.assertEqual(result.output, "base")
        self.assertEqual(result.score, 0.0)
        self.assertTrue(any(event["event"] == "controller_guardrail" for event in logger.events))
        self.assertFalse(any(event["event"] == "compiled_edit" for event in logger.events))
        first_command = next(event for event in logger.events if event["event"] == "controller_command")
        self.assertEqual(first_command["command"]["decision"], "noop")

    def test_run_episode_guards_apply_when_run_budget_is_exhausted_for_parsed_command(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        result = run_episode(
            _ToyTaskEnv(),
            _BudgetExhaustedToyWorkerRuntime(runtime_state),
            _ParsedCommandController(_ToyController()),
            ctx,
            logger=logger,
        )

        self.assertEqual(result.output, "base")
        self.assertEqual(result.score, 0.0)
        self.assertTrue(any(event["event"] == "controller_guardrail" for event in logger.events))
        self.assertFalse(any(event["event"] == "compiled_edit" for event in logger.events))
        first_command = next(event for event in logger.events if event["event"] == "controller_command")
        self.assertEqual(first_command["command"]["decision"], "noop")

    def test_run_episode_allows_loop_rescue_when_loop_rescue_budget_remains(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        result = run_episode(
            _ToyTaskEnv(),
            _LoopRescueBudgetToyWorkerRuntime(runtime_state),
            _LoopRescueToyController(),
            ctx,
            logger=logger,
        )

        self.assertEqual(result.output, "base")
        self.assertFalse(any(event["event"] == "controller_guardrail" for event in logger.events))
        self.assertTrue(any(event["event"] == "compiled_edit" for event in logger.events))
        first_command = next(event for event in logger.events if event["event"] == "controller_command")
        self.assertEqual(first_command["command"]["decision"], "apply")

    def test_run_episode_guards_over_budget_loop_rescue_apply(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        result = run_episode(
            _ToyTaskEnv(),
            _LowAlphaLoopRescueBudgetToyWorkerRuntime(runtime_state),
            _OverBudgetLoopRescueToyController(),
            ctx,
            logger=logger,
        )

        self.assertEqual(result.output, "base")
        self.assertEqual(result.score, 0.0)
        self.assertTrue(any(event["event"] == "controller_guardrail" for event in logger.events))
        self.assertFalse(any(event["event"] == "controller_error" for event in logger.events))
        self.assertFalse(any(event["event"] == "compiled_edit" for event in logger.events))
        first_guard = next(event for event in logger.events if event["event"] == "controller_guardrail")
        self.assertEqual(first_guard["reason"], "command exceeds packet loop_rescue alpha budget")
        first_command = next(event for event in logger.events if event["event"] == "controller_command")
        self.assertEqual(first_command["command"]["decision"], "noop")
        self.assertEqual(logger.events[-1]["event"], "episode_end")

    def test_run_episode_guards_over_budget_loop_rescue_apply_for_parsed_command(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        result = run_episode(
            _ToyTaskEnv(),
            _LowAlphaLoopRescueBudgetToyWorkerRuntime(runtime_state),
            _ParsedCommandController(_OverBudgetLoopRescueToyController()),
            ctx,
            logger=logger,
        )

        self.assertEqual(result.output, "base")
        self.assertEqual(result.score, 0.0)
        self.assertTrue(any(event["event"] == "controller_guardrail" for event in logger.events))
        self.assertFalse(any(event["event"] == "controller_error" for event in logger.events))
        self.assertFalse(any(event["event"] == "compiled_edit" for event in logger.events))
        first_guard = next(event for event in logger.events if event["event"] == "controller_guardrail")
        self.assertEqual(first_guard["reason"], "command exceeds packet loop_rescue alpha budget")
        first_command = next(event for event in logger.events if event["event"] == "controller_command")
        self.assertEqual(first_command["command"]["decision"], "noop")
        self.assertEqual(logger.events[-1]["event"], "episode_end")

    def test_run_episode_records_controller_memory(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        worker = _ToyWorkerRuntime(runtime_state)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            worker,
            _MemoryToyController(),
            ctx,
            logger=logger,
        )

        self.assertEqual(worker._controller_memory[0]["hypothesis"], "small_rescue")
        self.assertEqual(worker._controller_memory[0]["micro_rationale"], "test a small reversible rescue first")
        self.assertEqual(worker._controller_memory[0]["focus_term"], "budget")
        self.assertEqual(worker._controller_memory[0]["surface_family_key"], "resid_add_s_resid_l11_last")
        self.assertAlmostEqual(worker._controller_memory[0]["transfer_confidence"], 0.35)
        self.assertAlmostEqual(worker._controller_memory[0]["same_family_escalation_risk"], 0.4)
        self.assertEqual(worker._controller_memory[0]["finish_budget_reserved"], 1)
        self.assertEqual(worker._controller_memory[0]["evidence_bullets"][0], "helpful_on=budget@l11")
        self.assertEqual(worker._controller_memory[0]["next_trigger"], "loop_relief_without_coverage")
        self.assertEqual(worker._controller_memory[0]["next_action"], "request_observer_check")
        self.assertEqual(worker._controller_memory[0]["decision"], "apply")
        self.assertTrue(any(event["event"] == "controller_memory" for event in logger.events))
        observations = [event for event in logger.events if event["event"] == "controller_observation"]
        self.assertEqual(observations[-1]["controller_memory"][0]["hypothesis"], "small_rescue")

    def test_run_episode_logs_controller_selection_report(self):
        class _DualPlanToyController(_ToyController):
            def invoke(self, packet):
                self.calls += 1
                if self.calls == 1:
                    command = _resid_command()
                    command["meta"] = dict(command.get("meta", {})) | {
                        "objective_bundle_key": "kv_pair:budget:source_body:10:12",
                        "step_actuator_bundle_key": "kv_pair:send:source_body:8:10",
                        "shadow_proposals": [
                            {
                                "kind": "bridge_shadow",
                                "bundle_key": "kv_pair:send:source_body:8:10",
                                "reason": "keep send as a shadow bridge until certified",
                                "decision": "shadow",
                            }
                        ],
                        "why_not_apply": "bridge remains shadow_only until certified_for_apply",
                    }
                    return command
                return {"version": "0.1", "decision": "noop"}

        class _BundleAwareToyWorkerRuntime(_ToyWorkerRuntime):
            def build_controller_packet(self):
                packet = super().build_controller_packet()
                packet["strategy_hints"] = {
                    "readout_analyzer_suggested_bundle_key": "kv_pair:budget:source_body:10:12",
                    "gate_report_frontier_bundle_key": "kv_pair:budget:source_body:10:12",
                    "gate_report_selection_source": "sidecar_tiebreak",
                    "bridge_plan_objective_bundle_key": "kv_pair:budget:source_body:10:12",
                    "bridge_plan_actuator_bundle_key": "kv_pair:send:source_body:8:10",
                    "bridge_plan_reason": "no_certified_self_actuator_target_lift_owned_by_other_bundle",
                    "shot_candidate_edits": [
                        {
                            "bundle_key": "kv_pair:budget:source_body:10:12",
                            "surface_id": "s_resid_l11_last",
                            "op": {"kind": "resid_add"},
                        }
                    ],
                }
                return packet

        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            _BundleAwareToyWorkerRuntime(runtime_state),
            _DualPlanToyController(),
            ctx,
            logger=logger,
        )

        first_command = next(event for event in logger.events if event["event"] == "controller_command")
        self.assertEqual(first_command["sidecar_suggested_bundle_key"], "kv_pair:budget:source_body:10:12")
        self.assertEqual(first_command["gate_report_frontier_bundle_key"], "kv_pair:budget:source_body:10:12")
        self.assertEqual(first_command["bridge_plan_objective_bundle_key"], "kv_pair:budget:source_body:10:12")
        self.assertEqual(first_command["bridge_plan_actuator_bundle_key"], "kv_pair:send:source_body:8:10")
        self.assertEqual(
            first_command["bridge_plan_reason"],
            "no_certified_self_actuator_target_lift_owned_by_other_bundle",
        )
        self.assertFalse(first_command["bridge_plan_used"])
        self.assertEqual(first_command["controller_objective_bundle_key"], "kv_pair:budget:source_body:10:12")
        self.assertEqual(first_command["controller_step_actuator_bundle_key"], "kv_pair:send:source_body:8:10")
        self.assertEqual(first_command["controller_plan_mode"], "dual_layer")
        self.assertTrue(first_command["controller_bridge_plan_visible"])
        self.assertFalse(first_command["controller_bridge_dual_layer_missing"])
        self.assertIsNone(first_command["controller_bridge_dual_layer_reason"])
        self.assertEqual(first_command["controller_shadow_proposal_count"], 1)
        self.assertEqual(
            first_command["controller_why_not_apply"],
            "bridge remains shadow_only until certified_for_apply",
        )
        self.assertEqual(first_command["controller_selected_bundle_key"], "kv_pair:budget:source_body:10:12")
        self.assertEqual(first_command["controller_rejected_signals"], [])
        selection_event = next(event for event in logger.events if event["event"] == "controller_selection")
        self.assertEqual(selection_event["controller_selection_source"], "sidecar_tiebreak")
        self.assertEqual(selection_event["controller_plan_mode"], "dual_layer")

    def test_run_episode_logs_bridge_visible_but_single_layer(self):
        class _BridgeVisibleNoopController(_ToyController):
            def invoke(self, packet):
                self.calls += 1
                return {"version": "0.1", "decision": "noop"}

        class _BridgeVisibleToyWorkerRuntime(_ToyWorkerRuntime):
            def build_controller_packet(self):
                packet = super().build_controller_packet()
                packet["strategy_hints"] = {
                    "gate_report_frontier_bundle_key": "kv_pair:budget:source_body:10:12",
                    "bridge_plan_objective_bundle_key": "kv_pair:budget:source_body:10:12",
                    "bridge_plan_actuator_bundle_key": "kv_pair:send:source_body:8:10",
                    "bridge_plan_reason": "no_certified_self_actuator_target_lift_owned_by_other_bundle",
                }
                return packet

        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            _BridgeVisibleToyWorkerRuntime(runtime_state),
            _BridgeVisibleNoopController(),
            ctx,
            logger=logger,
        )

        selection_event = next(event for event in logger.events if event["event"] == "controller_selection")
        self.assertTrue(selection_event["controller_bridge_plan_visible"])
        self.assertTrue(selection_event["controller_bridge_dual_layer_missing"])
        self.assertEqual(selection_event["controller_bridge_dual_layer_reason"], "bridge_available_but_single_layer")
        self.assertEqual(selection_event["controller_plan_mode"], "single_layer")

    def test_run_episode_logs_bridge_unavailable_reason(self):
        class _BridgeUnavailableNoopController(_ToyController):
            def invoke(self, packet):
                self.calls += 1
                return {"version": "0.1", "decision": "noop"}

        class _BridgeUnavailableToyWorkerRuntime(_ToyWorkerRuntime):
            def build_controller_packet(self):
                packet = super().build_controller_packet()
                packet["strategy_hints"] = {
                    "gate_report_frontier_bundle_key": "kv_pair:budget:source_body:10:12",
                    "bridge_plan_unavailable_reason": "all_dead_actuator",
                    "bridge_plan_unavailable_objective_bundle_key": "kv_pair:budget:source_body:10:12",
                    "bridge_plan_unavailable_objective_reasons": {
                        "kv_pair:budget:source_body:10:12": "all_dead_actuator",
                    },
                    "bridge_eval_context_drift": False,
                }
                return packet

        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            _BridgeUnavailableToyWorkerRuntime(runtime_state),
            _BridgeUnavailableNoopController(),
            ctx,
            logger=logger,
        )

        selection_event = next(event for event in logger.events if event["event"] == "controller_selection")
        self.assertFalse(selection_event["controller_bridge_plan_visible"])
        self.assertEqual(selection_event["controller_bridge_plan_unavailable_reason"], "all_dead_actuator")
        self.assertEqual(selection_event["bridge_plan_unavailable_objective_bundle_key"], "kv_pair:budget:source_body:10:12")
        self.assertEqual(
            selection_event["bridge_plan_unavailable_objective_reasons"]["kv_pair:budget:source_body:10:12"],
            "all_dead_actuator",
        )
        self.assertFalse(selection_event["bridge_eval_context_drift"])

    def test_run_episode_prefers_meta_bridge_unavailable_reason(self):
        class _BridgeUnavailableMetaController(_ToyController):
            def invoke(self, packet):
                self.calls += 1
                return {
                    "version": "0.1",
                    "decision": "noop",
                    "meta": {
                        "bridge_plan_unavailable_reason": "meta_no_safe_actuator",
                        "bridge_plan_unavailable_objective_bundle_key": "kv_pair:budget:source_body:10:12",
                        "bridge_plan_unavailable_objective_reasons": {
                            "kv_pair:budget:source_body:10:12": "meta_no_safe_actuator",
                        },
                    },
                }

        class _BridgeUnavailableStaleHintsToyWorkerRuntime(_ToyWorkerRuntime):
            def build_controller_packet(self):
                packet = super().build_controller_packet()
                packet["strategy_hints"] = {
                    "gate_report_frontier_bundle_key": "kv_pair:budget:source_body:10:12",
                    "bridge_plan_unavailable_reason": "stale_strategy_hint_reason",
                    "bridge_plan_unavailable_objective_bundle_key": "kv_pair:budget:source_body:10:12",
                    "bridge_plan_unavailable_objective_reasons": {
                        "kv_pair:budget:source_body:10:12": "stale_strategy_hint_reason",
                    },
                }
                return packet

        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            _BridgeUnavailableStaleHintsToyWorkerRuntime(runtime_state),
            _BridgeUnavailableMetaController(),
            ctx,
            logger=logger,
        )

        selection_event = next(event for event in logger.events if event["event"] == "controller_selection")
        self.assertEqual(selection_event["bridge_plan_unavailable_reason"], "meta_no_safe_actuator")
        self.assertEqual(selection_event["controller_bridge_plan_unavailable_reason"], "meta_no_safe_actuator")
        self.assertEqual(
            selection_event["bridge_plan_unavailable_objective_reasons"]["kv_pair:budget:source_body:10:12"],
            "meta_no_safe_actuator",
        )

    def test_extract_diagnostic_requests_keeps_distinct_intents(self):
        objective = "kv_pair:budget:source_body:10:12"
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "diagnostic_request": {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "bundle_key": objective,
                    "objective_bundle_key": objective,
                    "next_evidence_needed": "rank_carrier_to_target_conversion",
                },
                "controller_memory": {
                    "diagnostic_request": {
                        "diagnostic": "compare_extra_operator_diagnostics",
                        "bundle_key": objective,
                        "objective_bundle_key": objective,
                        "next_evidence_needed": "post_bridge_exhaustion_recipe_expansion",
                        "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                    }
                },
            },
        }

        requests = _extract_diagnostic_requests(command, {"strategy_hints": {}})

        self.assertEqual(len(requests), 2)
        self.assertEqual(
            {request["next_evidence_needed"] for request in requests},
            {
                "rank_carrier_to_target_conversion",
                "post_bridge_exhaustion_recipe_expansion",
            },
        )

    def test_extract_diagnostic_requests_dedupes_post_bridge_next_action_alias(self):
        objective = "kv_pair:budget:source_body:10:12"
        command = {
            "version": "0.1",
            "decision": "noop",
            "meta": {
                "diagnostic_request": {
                    "diagnostic": "compare_extra_operator_diagnostics",
                    "bundle_key": objective,
                    "objective_bundle_key": objective,
                    "next_evidence_needed": "post_bridge_exhaustion_recipe_expansion",
                    "operator_recipe_expansion_mode": "post_bridge_exhaustion",
                    "post_bridge_exhaustion_recipe_expansion_requested": True,
                },
                "next_action": "request_compare_extra_operator_diagnostics",
                "next_evidence_needed": "post_bridge_exhaustion_recipe_expansion",
            },
        }

        requests = _extract_diagnostic_requests(command, {"strategy_hints": {}})

        self.assertEqual(len(requests), 1)
        self.assertEqual(requests[0]["diagnostic"], "compare_extra_operator_diagnostics")
        self.assertEqual(requests[0]["next_evidence_needed"], "post_bridge_exhaustion_recipe_expansion")
        self.assertEqual(requests[0]["operator_recipe_expansion_mode"], "post_bridge_exhaustion")
        self.assertTrue(requests[0]["post_bridge_exhaustion_recipe_expansion_requested"])

    def test_run_episode_marks_forced_diagnostic_apply_in_selection_report(self):
        class _DiagnosticToyController(_ToyController):
            def invoke(self, packet):
                self.calls += 1
                if self.calls == 1:
                    command = _resid_command()
                    command["meta"] = dict(command.get("meta", {})) | {
                        "apply_kind": "diagnostic_probe",
                        "production_apply_allowed": False,
                        "certified_for_apply": False,
                        "objective_bundle_key": "kv_pair:budget:source_body:10:12",
                        "step_actuator_bundle_key": "kv_pair:budget:source_body:10:12",
                    }
                    return command
                return {"version": "0.1", "decision": "noop"}

        class _BundleAwareToyWorkerRuntime(_ToyWorkerRuntime):
            def build_controller_packet(self):
                packet = super().build_controller_packet()
                packet["strategy_hints"] = {
                    "gate_report_frontier_bundle_key": "kv_pair:budget:source_body:10:12",
                    "shot_candidate_edits": [
                        {
                            "bundle_key": "kv_pair:budget:source_body:10:12",
                            "surface_id": "s_resid_l11_last",
                            "op": {"kind": "resid_add"},
                        }
                    ],
                }
                return packet

        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            _BundleAwareToyWorkerRuntime(runtime_state),
            _DiagnosticToyController(),
            ctx,
            logger=logger,
        )

        selection_event = next(event for event in logger.events if event["event"] == "controller_selection")
        self.assertEqual(selection_event["controller_selection_source"], "forced_diagnostic_apply")
        self.assertEqual(selection_event["controller_apply_kind"], "diagnostic_probe")
        self.assertFalse(selection_event["production_apply_allowed"])
        self.assertFalse(selection_event["certified_for_apply"])

    def test_run_episode_noop_reports_collapse_sharpener_veto_reason(self):
        class _NoopController(_ToyController):
            def invoke(self, packet):
                self.calls += 1
                return {
                    "version": "0.1",
                    "decision": "noop",
                    "meta": {
                        "objective_bundle_key": "kv_pair:budget:source_body:72:73",
                        "step_actuator_bundle_key": "kv_pair:budget:source_body:72:73",
                        "surface_family_key": "kv_anchor:budget:exact_prompt_span",
                    },
                }

        class _RecentHarmToyWorkerRuntime(_ToyWorkerRuntime):
            def build_controller_packet(self):
                packet = super().build_controller_packet()
                packet["strategy_hints"] = {
                    "gate_report_frontier_bundle_key": "kv_pair:budget:source_body:72:73",
                    "gate_report_rejected_signals": ["single_bundle"],
                    "diagnostic_evidence_ledger_count": 1,
                    "diagnostic_evidence_ledger": [
                        {
                            "bundle_key": "kv_pair:budget:source_body:72:73",
                            "evidence_kind": "readout_probe",
                            "diagnostic_family": "logit_adjacent",
                            "status": "supportive",
                        }
                    ],
                    "bundle_diagnostic_status": {
                        "kv_pair:budget:source_body:72:73": {
                            "bundle_key": "kv_pair:budget:source_body:72:73",
                            "readout_reachable": True,
                            "head_sensitive": False,
                            "feature_supported": False,
                            "operator_certified": False,
                            "blocked_by": ["collapse_sharpener"],
                            "next_evidence_needed": "non_dead_attention_ablation_signal",
                            "diagnostic_request": "attention_head_ablation_on_frontier",
                            "reason_text": "budget needs attention ablation after collapse sharpener",
                        }
                    },
                    "diagnostic_frontier_bundle_key": "kv_pair:budget:source_body:72:73",
                    "diagnostic_frontier_next_evidence": "non_dead_attention_ablation_signal",
                    "diagnostic_frontier_request": "attention_head_ablation_on_frontier",
                    "diagnostic_frontier_reason_text": "budget needs attention ablation after collapse sharpener",
                }
                packet["recent_effect_summary"] = {
                    "window_size": 1,
                    "verdict_counts": {"harmful": 1},
                    "hypothesis_stats": [],
                    "latest_effects": [
                        {
                            "bundle_key": "kv_pair:budget:source_body:72:73",
                            "surface_family_key": "kv_anchor:budget:exact_prompt_span",
                            "operator_recipe_id": "recipe:budget:span_mean",
                            "actuator_class": "collapse_sharpener",
                        }
                    ],
                    "recent_harmful_surface_family_keys": ["kv_anchor:budget:exact_prompt_span"],
                    "recent_collapse_sharpener_surface_family_keys": ["kv_anchor:budget:exact_prompt_span"],
                    "recent_harmful_operator_recipe_ids": ["recipe:budget:span_mean"],
                    "recent_collapse_sharpener_operator_recipe_ids": ["recipe:budget:span_mean"],
                    "recent_harmful_bundle_keys": ["kv_pair:budget:source_body:72:73"],
                    "recent_collapse_sharpener_bundle_keys": ["kv_pair:budget:source_body:72:73"],
                }
                return packet

        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            _RecentHarmToyWorkerRuntime(runtime_state),
            _NoopController(),
            ctx,
            logger=logger,
        )

        selection_event = next(event for event in logger.events if event["event"] == "controller_selection")
        self.assertIn("single_bundle", selection_event["controller_rejected_signals"])
        self.assertIn("recent_harmful_family", selection_event["controller_rejected_signals"])
        self.assertIn("collapse_sharpener_veto", selection_event["controller_rejected_signals"])
        self.assertIn("no_certified_actuator_for_frontier", selection_event["controller_rejected_signals"])
        self.assertIn("collapse_sharpener", selection_event["controller_why_not_apply"])
        self.assertEqual(selection_event["visible_frontier_status"], "visible_but_no_safe_actuator")
        self.assertEqual(selection_event["controller_loop_pressure_mode"], "investigate_visible_no_safe_actuator")
        self.assertEqual(selection_event["diagnostic_evidence_ledger_count"], 1)
        self.assertEqual(selection_event["diagnostic_frontier_next_evidence"], "non_dead_attention_ablation_signal")
        self.assertEqual(selection_event["diagnostic_frontier_request"], "attention_head_ablation_on_frontier")
        self.assertEqual(selection_event["controller_recommended_diagnostic_request"], "attention_head_ablation_on_frontier")
        self.assertIn("attention_head_ablation_on_frontier", selection_event["controller_diagnostic_request_options"])
        self.assertEqual(selection_event["controller_next_evidence_options"][0], "non_dead_attention_ablation_signal")
        self.assertIn("certified_self_or_bridge_actuator", selection_event["controller_next_evidence_options"])
        self.assertEqual(selection_event["controller_suggested_shadow_proposals"][0]["decision"], "shadow")

    def test_run_episode_records_guarded_noop_reason_in_controller_memory(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        worker = _BudgetExhaustedToyWorkerRuntime(runtime_state)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            worker,
            _ToyController(),
            ctx,
            logger=logger,
        )

        self.assertEqual(worker._controller_memory[0]["decision"], "noop")
        self.assertEqual(worker._controller_memory[0]["noop_reason"], "budget_exhausted")
        self.assertEqual(worker._controller_memory[0]["apply_block_reason"], "edits_left_this_run_exhausted")
        self.assertEqual(worker._controller_memory[0]["surface_family_key"], "resid_add_s_resid_l11_last")
        self.assertEqual(worker._controller_memory[0]["evidence_bullets"][0], "main_edit_budget exhausted")
        memory_events = [event for event in logger.events if event["event"] == "controller_memory"]
        self.assertEqual(memory_events[0]["noop_reason"], "budget_exhausted")
        self.assertEqual(memory_events[0]["apply_block_reason"], "edits_left_this_run_exhausted")

    def test_run_episode_executes_controller_requested_observer_check(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        worker = _ToyWorkerRuntime(runtime_state)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            worker,
            _ObserverRequestToyController(),
            ctx,
            logger=logger,
        )

        self.assertTrue(any(event["event"] == "controller_observer_check_request" for event in logger.events))
        self.assertTrue(any(event["event"] == "observer_check" for event in logger.events))
        self.assertEqual(worker._controller_memory[0]["micro_rationale"], "Loop eased, but coverage is still zero.")
        self.assertEqual(worker._controller_memory[0]["next_trigger"], "observer_flat_after_loop_relief")
        self.assertEqual(worker._controller_memory[0]["next_action"], "apply")
        self.assertEqual(worker._observer_checks[-1]["trigger"], "controller_request")

    def test_run_episode_executes_controller_requested_tools(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        worker = _ToyWorkerRuntime(runtime_state)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            worker,
            _ToolRequestToyController(),
            ctx,
            logger=logger,
        )

        self.assertTrue(any(event["event"] == "controller_tool_request" for event in logger.events))
        self.assertTrue(any(event["event"] == "controller_tool_result" for event in logger.events))
        self.assertEqual(worker._tool_results[0]["tool"], "tokenize_terms")
        self.assertEqual(worker._tool_results[1]["tool"], "dry_run_decode")
        packet_after = worker.build_controller_packet()
        self.assertEqual(packet_after["tool_catalog"][0]["tool"], "tokenize_terms")
        self.assertEqual(packet_after["latest_tool_results"][0]["tool"], "tokenize_terms")

    def test_run_episode_executes_controller_requested_diagnostics(self):
        adapter = FakeAdapter()
        runtime_state = FakeRuntimeState()
        packet = parse_observation_packet(_make_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        worker = _ToyWorkerRuntime(runtime_state)
        logger = InMemoryStructuredLogger()

        run_episode(
            _ToyTaskEnv(),
            worker,
            _DiagnosticRequestToyController(),
            ctx,
            logger=logger,
        )

        self.assertTrue(any(event["event"] == "controller_diagnostic_request" for event in logger.events))
        self.assertTrue(any(event["event"] == "controller_diagnostic_result" for event in logger.events))
        self.assertEqual(worker._diagnostic_results[0]["diagnostic"], "operator_diagnostic_replay")
        self.assertFalse(worker._diagnostic_results[0]["production_apply_allowed"])
        packet_after = worker.build_controller_packet()
        self.assertEqual(packet_after["latest_diagnostic_results"][0]["diagnostic"], "operator_diagnostic_replay")
        self.assertEqual(packet_after["latest_diagnostic_results"][0]["next_evidence_needed"], "certified_self_or_bridge_actuator")


class TestRank1Bridge(unittest.TestCase):
    def test_parameter_aware_lift_maps_hidden_to_mlp_row_space(self):
        bridge = HybridRank1VectorBridge()
        matrix = torch.arange(12, dtype=torch.float32).reshape(4, 3)
        geometry = Rank1Geometry(target_shape=(4, 3), rows=4, cols=3, matrix=matrix)
        raw = torch.tensor([1.0, 2.0, 3.0])

        adapted = bridge.adapt(raw, side="row", geometry=geometry)
        expected = matrix @ raw
        expected = expected / expected.norm()

        self.assertEqual(tuple(adapted.shape), (4,))
        self.assertTrue(torch.allclose(adapted, expected, atol=1e-6, rtol=1e-5))

    def test_resample_fallback_hits_target_length(self):
        bridge = HybridRank1VectorBridge()
        matrix = torch.eye(5, dtype=torch.float32)
        geometry = Rank1Geometry(target_shape=(5, 5), rows=5, cols=5, matrix=matrix)
        raw = torch.tensor([1.0, -1.0])

        adapted = bridge.adapt(raw, side="row", geometry=geometry)

        self.assertEqual(tuple(adapted.shape), (5,))


class DeterministicRuntimeState(FakeRuntimeState):
    HOOK_NAMES = {
        "resid_pre": "resid_pre:11",
        "resid_post": "resid_post:11",
        "hidden": "resid_post:11",
    }

    def __init__(self, codec):
        super().__init__()
        self.codec = codec
        self.seed = 23
        self.vocab_size = len(codec.alphabet)
        self.base_token = int(codec.encode("a")[0].item())
        self.hint_token = int(codec.encode("b")[0].item())
        self.edit_token = int(codec.encode("c")[0].item())
        self.last_tokens = None
        self.last_logits = None
        self.last_cache = None
        self.trace_caches = {}
        self.trace_sequences = {}
        self.trace_alignment_step = None
        self.running_stats = {}

    def _freeze_cache(self, cache):
        return {str(name): tensor.detach().clone() for name, tensor in cache.items()}

    def run_with_cache(self, model_input, *, return_type="logits", **_kwargs):
        tokens = model_input.detach().clone().to(dtype=torch.long)
        seq_len = tokens.shape[1]
        base = tokens[0].float().unsqueeze(-1)
        resid_pre = torch.cat([base + 0.1, base + 0.2, base + 0.3], dim=-1).unsqueeze(0)
        resid_post = resid_pre + 0.5
        mlp_out = resid_post + 0.25

        for record in self.hooks.values():
            if record["hook_name"] == "resid_pre:11":
                resid_pre = record["hook_fn"](resid_pre, None)

        cache = {
            "resid_pre:11": resid_pre,
            "resid_post:11": resid_post,
            "mlp_out:11": mlp_out,
            "blocks.11.hook_resid_pre": resid_pre,
            "blocks.11.hook_resid_post": resid_post,
            "blocks.11.hook_mlp_out": mlp_out,
            "blocks.7.hook_resid_post": resid_post,
        }
        self.last_tokens = tokens
        self.last_cache = self._freeze_cache(cache)

        next_token = self.base_token
        if any(int(token_id) == self.hint_token for token_id in tokens[0].tolist()):
            next_token = self.hint_token
        if self.hooks or self.overlays:
            next_token = self.edit_token

        logits = torch.zeros((1, seq_len, self.vocab_size), dtype=torch.float32)
        logits[0, -1, next_token] = 8.0
        logits[0, -1, (next_token + 1) % self.vocab_size] = 2.0
        self.last_logits = logits.detach().clone()
        return logits, cache

    def snapshot_last_cache(self, trace_id):
        self.trace_caches[trace_id] = self._freeze_cache(self.last_cache)

    def put_trace_cache(self, trace_id, cache):
        self.trace_caches[trace_id] = self._freeze_cache(cache)

    def put_step_trace(self, trace_id, trace):
        self.trace_sequences[trace_id] = trace

    def set_trace_alignment(self, step):
        self.trace_alignment_step = step

    def get_cache(self, scope, trace_id=None, *, step=None):
        if scope == "runtime":
            return self.last_cache
        if scope == "trace":
            if trace_id in self.trace_sequences:
                aligned_step = self.trace_alignment_step if step is None else step
                return self.trace_sequences[trace_id].aligned_cache(aligned_step)
            return self.trace_caches[trace_id]
        raise KeyError(scope)

    def read_tensor(self, ref, ctx):
        packet = getattr(ctx, "packet", {}) or {}
        step = packet.get("step") if isinstance(packet, dict) else getattr(packet, "step", None)
        cache = self.get_cache(ref["scope"], ref.get("trace_id"), step=step)
        hook_name = self.HOOK_NAMES[ref["tensor"]]
        return cache[hook_name][0, -1].detach().clone()


class _ThreeStepTaskEnv:
    def __init__(self, target_token):
        self.target_token = target_token

    def reset(self, seed: int) -> str:
        self.seed = seed
        return "p"

    def score(self, output: str) -> float:
        return 1.0 if self.target_token in output else 0.0

    def done(self, output: str) -> bool:
        return len(output) >= 3


class _PromptHintController:
    def __init__(self, hint):
        self.hint = hint
        self.calls = 0
        self._last_trace = None

    def latest_trace(self):
        return self._last_trace

    def invoke(self, packet):
        self.calls += 1
        self._last_trace = {
            "provider": "fake",
            "model": "prompt-hint",
            "observation": {
                "step": packet["step"],
                "worker_status": packet["worker_view"]["status"],
            },
            "attempts": [
                {
                    "attempt": 1,
                    "provider": "fake",
                    "model": "prompt-hint",
                    "latency_ms": 1.0,
                    "parse_ok": True,
                    "response_text": self.hint,
                }
            ],
            "decision": {"advice": self.hint if self.calls == 1 else None, "advice_length": len(self.hint) if self.calls == 1 else 0},
            "success": True,
        }
        if self.calls == 1:
            return self.hint
        return None


class _ResidEditController:
    def __init__(self):
        self.calls = 0

    def invoke(self, _packet):
        self.calls += 1
        if self.calls == 1:
            return _resid_command()
        return {"version": "0.1", "decision": "noop"}


class TestWorkerRuntimeAndBaselines(unittest.TestCase):
    def _surface_catalog(self):
        base_surface = _make_packet()["surface_catalog"][0]
        return [
            base_surface,
            {
                "surface_id": "s_resid_pre_l3_last",
                "target": {
                    "kind": "activation",
                    "worker": "os_0",
                    "site": "resid_pre",
                    "layer": 3,
                    "token": {"mode": "last"},
                },
                "allow_ops": ["resid_add", "activation_patch"],
                "caps": {
                    "max_alpha": 0.12,
                    "max_ttl_steps": 1,
                    "norm_clip": 1.5,
                    "step_size": 0.08,
                    "revertible_only": True,
                },
            },
            {
                "surface_id": "s_resid_pre_l4_last",
                "target": {
                    "kind": "activation",
                    "worker": "os_0",
                    "site": "resid_pre",
                    "layer": 4,
                    "token": {"mode": "last"},
                },
                "allow_ops": ["resid_add", "activation_patch"],
                "caps": {
                    "max_alpha": 0.12,
                    "max_ttl_steps": 1,
                    "norm_clip": 1.5,
                    "step_size": 0.08,
                    "revertible_only": True,
                },
            },
            {
                "surface_id": "s_resid_pre_l3_prev",
                "target": {
                    "kind": "activation",
                    "worker": "os_0",
                    "site": "resid_pre",
                    "layer": 3,
                    "token": {"mode": "index", "value": -2},
                },
                "allow_ops": ["resid_add"],
                "caps": {
                    "max_alpha": 0.12,
                    "max_ttl_steps": 1,
                    "norm_clip": 1.5,
                    "step_size": 0.08,
                    "revertible_only": True,
                },
            },
        ]

    def _make_worker_runtime(
        self,
        *,
        decoder_control_mode: str = "off",
        task_feedback_fn=None,
        observer_check_fn=None,
        codec=None,
        readout_sidecar_analyzer=None,
        readout_analyzer_rerank_mode: str = "apply",
    ):
        codec = codec or CharacterCodec("pabc!? ")
        runtime_state = DeterministicRuntimeState(codec)
        adapter = FakeAdapter()
        return HookedTransformerWorkerRuntime(
            runtime_state=runtime_state,
            adapter=adapter,
            surface_catalog=self._surface_catalog(),
            codec=codec,
            task_id="toy_baseline",
            goal_hint="emit the useful token",
            constraints=("keep going",),
            max_generated_tokens=3,
            max_edits_per_run=4,
            max_total_alpha=0.5,
            max_active_patch_slots=1,
            stop_checker=lambda output: len(output) >= 3,
            task_feedback_fn=task_feedback_fn,
            observer_check_fn=observer_check_fn,
            decoder_control_mode=decoder_control_mode,
            readout_sidecar_analyzer=readout_sidecar_analyzer,
            readout_analyzer_rerank_mode=readout_analyzer_rerank_mode,
        )

    def test_worker_runtime_packet_is_schema_shaped(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime.step()

        packet = worker_runtime.build_controller_packet()
        parsed = parse_observation_packet(packet)

        self.assertIsInstance(parsed, ControllerObservationPacket)
        self.assertEqual(packet["worker_view"]["generated_tail"], "a")
        self.assertEqual(packet["budget"]["edits_left_this_run"], 4)
        self.assertEqual(packet["budget"]["edit_cost_left_total"], 0.5)
        self.assertEqual(packet["surface_catalog"][0]["surface_id"], "s_resid_l11_last")
        self.assertEqual(packet["recent_effect_summary"]["window_size"], 0)

    def test_activation_patch_trial_materializes_as_activation_patch_op(self):
        worker_runtime = self._make_worker_runtime()
        candidate = {
            "objective_bundle_key": "entity_insert:a:source_body:0:1",
            "objective_term": "a",
            "actuator_bundle_key": "entity_insert:a:source_body:0:1",
            "site": "resid_pre",
            "layer": 3,
            "alpha": 0.05,
            "source_localization": "source_term_token",
            "patch_mode": "blend",
            "operator_recipe_id": "activation_patch_test_recipe",
        }
        trial_contract = {
            "max_alpha": 0.15,
            "norm_clip": None,
            "trial_budget_class": "primary",
            "production_trial_followup_allowed": False,
        }

        trial_edit = worker_runtime._activation_patch_trial_edit_from_candidate(
            candidate,
            trial_contract=trial_contract,
        )

        self.assertIsNotNone(trial_edit)
        assert trial_edit is not None
        self.assertEqual(trial_edit["op"], {"kind": "activation_patch", "alpha": 0.05, "mode": "blend"})
        self.assertEqual(trial_edit["budget"]["ttl_steps"], 1)
        self.assertIsNone(trial_edit["budget"]["norm_clip"])
        self.assertEqual(trial_edit["target"], {"surface_id": "s_resid_pre_l3_last"})
        self.assertEqual(trial_edit["source"]["expr"]["ref"]["token"], {"mode": "index", "value": 0})
        self.assertEqual(trial_edit["meta"]["activation_patch_op_kind"], "activation_patch")
        self.assertEqual(trial_edit["meta"]["activation_patch_mode"], "blend")
        self.assertFalse(trial_edit["meta"]["production_apply_allowed"])

        cap_release_candidate = dict(candidate)
        cap_release_candidate["step_size"] = 0.12
        cap_release_edit = worker_runtime._activation_patch_trial_edit_from_candidate(
            cap_release_candidate,
            trial_contract=trial_contract,
        )
        self.assertIsNotNone(cap_release_edit)
        assert cap_release_edit is not None
        self.assertEqual(cap_release_edit["budget"]["step_size"], 0.08)
        self.assertEqual(cap_release_edit["meta"]["step_size"], 0.08)

        diagnostic_cap_release_contract = dict(trial_contract)
        diagnostic_cap_release_contract["trial_budget_class"] = "diagnostic_only"
        diagnostic_cap_release_contract["allow_step_size_cap_release"] = True
        diagnostic_cap_release_contract["max_step_size"] = 0.2
        diagnostic_cap_release_edit = worker_runtime._activation_patch_trial_edit_from_candidate(
            cap_release_candidate,
            trial_contract=diagnostic_cap_release_contract,
        )
        self.assertIsNotNone(diagnostic_cap_release_edit)
        assert diagnostic_cap_release_edit is not None
        self.assertEqual(diagnostic_cap_release_edit["budget"]["step_size"], 0.12)
        self.assertEqual(diagnostic_cap_release_edit["meta"]["apply_kind"], "diagnostic_probe")
        self.assertFalse(diagnostic_cap_release_edit["meta"]["production_trial_allowed"])
        self.assertEqual(diagnostic_cap_release_edit["meta"]["surface_step_size_cap"], 0.08)
        self.assertTrue(diagnostic_cap_release_edit["meta"]["step_size_cap_release_allowed"])

    def test_activation_patch_review_materializes_entity_blueprint_without_cached_rows(self):
        worker_runtime = self._make_worker_runtime()
        blueprint = {
            "kind": "entity_insertion_candidate_blueprint",
            "objective_term": "a",
            "first_piece": "a",
            "first_token_id": 1,
            "readout_status": "near_reachable",
            "rank": 88,
            "source_provenance": "source_body",
            "source_span": {
                "start": 0,
                "end": 1,
                "provenance_class": "source_body",
                "text": "a",
            },
            "candidate_key": "entity_insert:a:source_body:near_reachable",
            "candidate_status": "shadow_blueprint_only",
            "production_apply_allowed": False,
            "certified_for_apply": False,
        }
        worker_runtime._diagnostic_results = [
            {
                "diagnostic": "entity_insertion_operator_candidate_review",
                "candidate_blueprints": [blueprint],
            }
        ]
        worker_runtime._latest_diagnostic_results = []

        def fake_trial_edit(candidate, *, trial_contract):
            self.assertEqual(candidate["site"], "resid_pre")
            self.assertEqual(candidate["layer"], 11)
            self.assertEqual(candidate["patch_mode"], "blend")
            return {
                "id": "diag_activation_patch",
                "target": {"surface_id": "s_resid_l11_last"},
                "source": {"dtype": "vector", "expr": {"ref": {"scope": "runtime"}}},
                "op": {"kind": "activation_patch", "alpha": candidate["alpha"], "mode": "blend"},
                "budget": {"ttl_steps": 1, "norm_clip": 1.0, "revertible": True},
                "meta": {"operator_recipe_id": candidate["operator_recipe_id"]},
            }

        def fake_replay(candidate_edits, **kwargs):
            self.assertEqual(candidate_edits[0]["op"]["kind"], "activation_patch")
            self.assertEqual(kwargs["intended_bundle_key"], "entity_insert:a:source_body:near_reachable")
            return {
                "status": "ok",
                "actual_delta_class": "readout_gap_movement",
                "target_mass_delta": 0.00003,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 6,
                "target_piece": "a",
                "target_piece_logit_delta": 0.002,
                "target_top20_threshold_gap_delta": -0.01,
                "term_readout_deltas": {"a": {"lift_score": 0.04}},
                "candidate_fingerprint": {"bundle_key": kwargs["intended_bundle_key"]},
                "eval_context_fingerprint": {"max_new_tokens": kwargs["max_new_tokens"]},
            }

        matrix_row = {"operator_axis": "target_piece_binding_seed_matrix", "measurement_complete": True,
                      "state_restored": True, "no_edit_max_abs_logit_delta": 0.0,
                      "repeat_max_abs_logit_delta": 0.0, "measurement_context_id": "context:fixture"}
        with patch.object(worker_runtime, "_activation_patch_trial_edit_from_candidate", side_effect=fake_trial_edit), \
             patch.object(worker_runtime, "_activation_patch_target_piece_binding_seed_matrix", return_value={
                 "rows": [matrix_row], "status": "dose_matched_response_complete", "state_restored": True}):
            with patch.object(worker_runtime, "replay_candidate_edits_actual_delta", side_effect=fake_replay):
                result = worker_runtime._execute_controller_diagnostic_request(
                    {
                        "diagnostic": "activation_patch_candidate_review",
                        "bundle_key": "entity_insert:a:source_body:near_reachable",
                        "objective_bundle_key": "entity_insert:a:source_body:near_reachable",
                        "next_evidence_needed": "activation_patch_candidate_review",
                    },
                    source="unit_test",
                    packet={"strategy_hints": {"diagnostic_frontier_bundle_key": "entity_insert:a:source_body:near_reachable"}},
                )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["activation_patch_blueprint_materialization_count"], 3)
        for key, value in matrix_row.items():
            self.assertEqual(result["target_piece_binding_seed_matrix_rows"][0][key], value)
        self.assertTrue(result["activation_patch_candidate_pool"])
        first = result["activation_patch_candidate_pool"][0]
        self.assertEqual(first["evidence_kind"], "activation_patch_certification")
        self.assertEqual(first["diagnostic_family"], "activation_patch")
        self.assertEqual(first["activation_patch_mode"], "blend")
        self.assertEqual(first["activation_patch_op_kind"], "activation_patch")
        self.assertIn(
            "source_span_mean",
            {row["activation_patch_source_localization"] for row in result["activation_patch_candidate_pool"]},
        )
        self.assertEqual(result["activation_patch_candidate_review"]["status"], "shadow_blueprint_ready")
        self.assertTrue(result["activation_patch_compile_preview_created"])
        self.assertFalse(result["activation_patch_candidate_review"]["compile_preview"]["production_apply_allowed"])

    def test_activation_patch_review_retries_after_unhooked_cached_row(self):
        objective = "entity_insert:a:source_body:near_reachable"
        request = {"diagnostic": "activation_patch_candidate_review", "bundle_key": objective,
                   "objective_bundle_key": objective}
        for hook_count, expected_calls in ((0, 1), (1, 0)):
            with self.subTest(hook_count=hook_count):
                worker_runtime = self._make_worker_runtime()
                packet = {"strategy_hints": {"diagnostic_evidence_ledger": [{
                    "bundle_key": objective, "objective_bundle_key": objective,
                    "evidence_kind": "activation_patch_certification",
                    "activation_patch_hook_call_count": hook_count,
                }]}}
                with patch.object(worker_runtime, "_activation_patch_rows_from_entity_blueprints",
                                  return_value=[]) as materialize:
                    result = worker_runtime._execute_controller_diagnostic_request(
                        request, source="unit_test", packet=packet)
                self.assertIsNotNone(result)
                self.assertEqual(materialize.call_count, expected_calls)

    def test_activation_patch_dedicated_diagnostics_reject_cross_mode_without_replay(self):
        worker_runtime = self._make_worker_runtime()
        diagnostics = (
            "activation_patch_candidate_review",
            "activation_patch_runtime_support_probe",
            "activation_patch_promotion_gate_review",
            "activation_patch_production_shadow_replay",
            "activation_patch_production_trial_gate_review",
        )
        with patch.object(worker_runtime, "_simulate_decode") as replay:
            for diagnostic, conflicting_mode in zip(diagnostics, diagnostics[1:] + diagnostics[:1]):
                with self.subTest(diagnostic=diagnostic, conflicting_mode=conflicting_mode):
                    result = worker_runtime._execute_controller_diagnostic_request(
                        {"diagnostic": diagnostic, "operator_recipe_expansion_mode": conflicting_mode},
                        source="unit_test",
                    )
                    self.assertIsNotNone(result)
                    assert result is not None
                    self.assertEqual(result["status"], "invalid_request")
                    self.assertEqual(result["blocked_reason"], "diagnostic_mode_mismatch")
                    self.assertEqual(result["expected_operator_recipe_expansion_mode"], diagnostic)
                    self.assertEqual(result["physical_replay_count"], 0)
                    self.assertEqual(result["new_measurement_count"], 0)
                    self.assertEqual(result["diagnostic_call_cost"], 0)
            replay.assert_not_called()

    def test_activation_patch_review_rejects_stale_name_then_accepts_canonical_request(self):
        worker_runtime = self._make_worker_runtime()
        blueprint = {
            "kind": "entity_insertion_candidate_blueprint",
            "objective_term": "a",
            "first_piece": "a",
            "first_token_id": 1,
            "readout_status": "near_reachable",
            "rank": 88,
            "source_provenance": "source_body",
            "source_span": {
                "start": 0,
                "end": 1,
                "provenance_class": "source_body",
                "text": "a",
            },
            "candidate_key": "entity_insert:a:source_body:near_reachable",
            "candidate_status": "shadow_blueprint_only",
            "production_apply_allowed": False,
            "certified_for_apply": False,
        }
        worker_runtime._diagnostic_results = [
            {
                "diagnostic": "entity_insertion_operator_candidate_review",
                "candidate_blueprints": [blueprint],
            }
        ]

        def fake_trial_edit(candidate, *, trial_contract):
            return {
                "id": "diag_activation_patch",
                "target": {"surface_id": "s_resid_l11_last"},
                "source": {"dtype": "vector", "expr": {"ref": {"scope": "runtime"}}},
                "op": {"kind": "activation_patch", "alpha": candidate["alpha"], "mode": "blend"},
                "budget": {"ttl_steps": 1, "norm_clip": 1.0, "revertible": True},
                "meta": {"operator_recipe_id": candidate["operator_recipe_id"]},
            }

        def fake_replay(candidate_edits, **kwargs):
            self.assertEqual(candidate_edits[0]["op"]["kind"], "activation_patch")
            return {
                "status": "ok",
                "actual_delta_class": "readout_gap_movement",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 4,
                "target_top20_threshold_gap_delta": -0.004,
                "term_readout_deltas": {"a": {"lift_score": 0.02}},
            }

        with patch.object(worker_runtime, "_activation_patch_trial_edit_from_candidate", side_effect=fake_trial_edit):
            with patch.object(worker_runtime, "replay_candidate_edits_actual_delta", side_effect=fake_replay):
                result = worker_runtime._execute_controller_diagnostic_request(
                    {
                        "diagnostic": "carrier_to_actuator_conversion_sweep",
                        "bundle_key": "entity_insert:a:source_body:near_reachable",
                        "objective_bundle_key": "entity_insert:a:source_body:near_reachable",
                        "operator_recipe_expansion_mode": "activation_patch_candidate_review",
                        "next_evidence_needed": "activation_patch_candidate_review",
                    },
                    source="unit_test",
                    packet={"strategy_hints": {"diagnostic_frontier_bundle_key": "entity_insert:a:source_body:near_reachable"}},
                )
                canonical = worker_runtime._execute_controller_diagnostic_request(
                    {
                        "diagnostic": "activation_patch_candidate_review",
                        "bundle_key": "entity_insert:a:source_body:near_reachable",
                        "objective_bundle_key": "entity_insert:a:source_body:near_reachable",
                        "operator_recipe_expansion_mode": "activation_patch_candidate_review",
                        "next_evidence_needed": "activation_patch_candidate_review",
                    },
                    source="unit_test",
                    packet={"strategy_hints": {"diagnostic_frontier_bundle_key": "entity_insert:a:source_body:near_reachable"}},
                )

        self.assertIsNotNone(result)
        assert result is not None
        self.assertEqual(result["status"], "invalid_request")
        self.assertEqual(result["blocked_reason"], "diagnostic_mode_mismatch")
        self.assertEqual(result["diagnostic_call_cost"], 0)
        self.assertIsNotNone(canonical)
        assert canonical is not None
        self.assertEqual(canonical["diagnostic_role"], "activation_patch_candidate_review")
        self.assertEqual(canonical["activation_patch_blueprint_materialization_count"], 3)
        self.assertTrue(canonical["activation_patch_candidate_pool"])
        self.assertFalse(canonical["production_apply_allowed"])

    def test_activation_patch_local_step_size_sweep_replays_saturated_carriers(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("Keep a.\nSOURCE: a b\nANSWER:")
        observed_step_sizes: list[float] = []

        def fake_replay(candidate_edits, **kwargs):
            edit = candidate_edits[0]
            observed_step_sizes.append(float(edit["budget"]["step_size"]))
            self.assertEqual(edit["op"]["kind"], "activation_patch")
            self.assertEqual(kwargs["intended_bundle_key"], "entity_insert:a:source_body:0:1")
            return {
                "status": "ok",
                "actual_delta_class": "readout_gap_movement",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 1,
                "target_top20_threshold_gap_delta": -0.002,
                "target_piece_logit_delta": 0.001,
                "term_readout_deltas": {"a": {"lift_score": 0.02}},
                "activation_patch_hook_call_count": 1,
                "activation_patch_selected_token_count": 1,
                "activation_patch_source_norm": 10.0,
                "activation_patch_target_norm_before": 9.0,
                "activation_patch_target_norm_after": 9.1,
                "activation_patch_source_target_cosine": 0.9,
                "activation_patch_source_target_delta_norm": 1.0,
                "activation_patch_raw_blend_delta_norm": 0.09,
                "activation_patch_blend_delta_norm": float(edit["budget"]["step_size"]),
                "activation_patch_step_size_clip_saturated": False,
                "candidate_fingerprint": {"step_size": edit["budget"]["step_size"]},
                "eval_context_fingerprint": {"max_new_tokens": kwargs["max_new_tokens"]},
            }

        seed_rows = [
            {
                "evidence_kind": "activation_patch_certification",
                "diagnostic_family": "activation_patch",
                "activation_patch_op_kind": "activation_patch",
                "objective_bundle_key": "entity_insert:a:source_body:0:1",
                "actuator_bundle_key": "entity_insert:a:source_body:0:1",
                "intended_term": "a",
                "activation_patch_site": "resid_pre",
                "activation_patch_layer": 3,
                "activation_patch_alpha": 0.05,
                "activation_patch_step_size": 0.04,
                "activation_patch_source_localization": "source_term_token",
                "activation_patch_patch_mode": "blend",
                "activation_patch_hook_call_count": 1,
                "activation_patch_step_size_clip_saturated": True,
                "status": "supportive",
                "actual_delta_class": "readout_gap_movement",
                "actuator_class": "self_actuator",
                "target_top20_threshold_gap_delta": -0.001,
                "self_delta": 0.01,
                "recipe_name": "activation_patch_resid_pre_l3_source_term_token_a050",
                "operator_recipe_id": "seed_recipe",
            }
        ]

        with patch.object(worker_runtime, "replay_candidate_edits_actual_delta", side_effect=fake_replay):
            rows = worker_runtime._activation_patch_local_step_size_sweep_rows(seed_rows)

        self.assertEqual(observed_step_sizes, [0.05, 0.08])
        self.assertEqual(len(rows), 2)
        self.assertTrue(all(row["activation_patch_local_step_size_sweep"] for row in rows))
        self.assertTrue(all(row["operator_axis"] == "activation_patch_local_step_size_sweep" for row in rows))
        self.assertTrue(all(row["production_apply_allowed"] is False for row in rows))
        self.assertEqual([row["activation_patch_step_size"] for row in rows], [0.05, 0.08])
        self.assertEqual(rows[0]["actual_delta_class"], "readout_gap_movement")

    def test_activation_patch_cap_release_response_curve_targets_local_carriers(self):
        worker_runtime = self._make_worker_runtime()
        observed: list[tuple[str, float]] = []

        def fake_trial_edit(candidate, *, trial_contract):
            step_size = float(candidate["step_size"])
            return {
                "id": f"diag_activation_patch_{candidate['site']}_{step_size}",
                "target": {"surface_id": f"s_{candidate['site']}_l{candidate['layer']}_last"},
                "source": {"dtype": "vector", "expr": {"ref": {"scope": "runtime"}}},
                "op": {"kind": "activation_patch", "alpha": candidate["alpha"], "mode": "blend"},
                "budget": {
                    "ttl_steps": 1,
                    "norm_clip": 1.0,
                    "revertible": True,
                    "step_size": step_size,
                },
                "meta": {"operator_recipe_id": candidate["operator_recipe_id"]},
            }

        def fake_replay(candidate_edits, **kwargs):
            edit = candidate_edits[0]
            site = str(edit["target"]["surface_id"]).split("_l", 1)[0].removeprefix("s_")
            step_size = float(edit["budget"]["step_size"])
            observed.append((site, step_size))
            return {
                "status": "ok",
                "actual_delta_class": "rank_carrier",
                "target_mass_delta": 0.000001 if step_size >= 0.16 else 0.0,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 0,
                "target_top20_threshold_gap_delta": -0.01 * step_size,
                "target_piece_logit_delta": 0.002 * step_size,
                "term_readout_deltas": {"a": {"lift_score": 0.02}},
                "repeat_delta": 0.0,
                "entropy_delta": -0.001,
                "top1_margin_delta": 0.0005,
                "activation_patch_hook_call_count": 1,
                "activation_patch_selected_token_count": 1,
                "activation_patch_source_norm": 10.0,
                "activation_patch_target_norm_before": 9.0,
                "activation_patch_target_norm_after": 9.1,
                "activation_patch_source_target_cosine": 0.95,
                "activation_patch_source_target_delta_norm": 1.0,
                "activation_patch_raw_blend_delta_norm": 0.4,
                "activation_patch_blend_delta_norm": step_size,
                "activation_patch_step_size_clip_saturated": True,
            }

        seed_rows = [
            {
                "evidence_kind": "activation_patch_certification",
                "diagnostic_family": "activation_patch",
                "activation_patch_op_kind": "activation_patch",
                "objective_bundle_key": "entity_insert:a:source_body:0:1",
                "actuator_bundle_key": "entity_insert:a:source_body:0:1",
                "intended_term": "a",
                "activation_patch_site": "mlp_out",
                "activation_patch_layer": 11,
                "activation_patch_alpha": 0.03,
                "activation_patch_step_size": 0.12,
                "activation_patch_source_localization": "source_term_token",
                "activation_patch_patch_mode": "blend",
                "activation_patch_hook_call_count": 1,
                "activation_patch_step_size_clip_saturated": True,
                "status": "supportive",
                "actual_delta_class": "rank_carrier",
                "actuator_class": "self_actuator",
                "target_top20_threshold_gap_delta": -0.0013,
                "self_delta": 0.01,
                "recipe_name": "activation_patch_mlp_out_l11_source_term_token_a030_step120",
                "operator_recipe_id": "seed_mlp",
            },
            {
                "evidence_kind": "activation_patch_certification",
                "diagnostic_family": "activation_patch",
                "activation_patch_op_kind": "activation_patch",
                "objective_bundle_key": "entity_insert:a:source_body:0:1",
                "actuator_bundle_key": "entity_insert:a:source_body:0:1",
                "intended_term": "a",
                "activation_patch_site": "resid_pre",
                "activation_patch_layer": 11,
                "activation_patch_alpha": 0.04,
                "activation_patch_step_size": 0.12,
                "activation_patch_source_localization": "source_term_token",
                "activation_patch_patch_mode": "blend",
                "activation_patch_hook_call_count": 1,
                "activation_patch_step_size_clip_saturated": True,
                "status": "supportive",
                "actual_delta_class": "rank_carrier",
                "actuator_class": "self_actuator",
                "target_top20_threshold_gap_delta": -0.0006,
                "self_delta": 0.03,
                "recipe_name": "activation_patch_resid_pre_l11_source_term_token_a040_step120",
                "operator_recipe_id": "seed_resid",
            },
        ]

        with patch.object(worker_runtime, "_activation_patch_trial_edit_from_candidate", side_effect=fake_trial_edit):
            with patch.object(worker_runtime, "replay_candidate_edits_actual_delta", side_effect=fake_replay):
                rows = worker_runtime._activation_patch_cap_release_response_curve_rows(seed_rows)

        self.assertEqual(observed, [("mlp_out", 0.16), ("mlp_out", 0.2), ("resid_pre", 0.16)])
        self.assertEqual([row["activation_patch_step_size"] for row in rows], [0.16, 0.2, 0.16])
        self.assertTrue(all(row["activation_patch_cap_release_response_curve"] for row in rows))
        self.assertTrue(
            all(row["operator_axis"] == "activation_patch_cap_release_response_curve" for row in rows)
        )
        self.assertTrue(all(row["production_apply_allowed"] is False for row in rows))
        self.assertEqual(rows[0]["entropy_delta"], -0.001)

    def test_activation_patch_cap_release_response_curve_runs_seed_discovery_when_no_observed_seed(self):
        worker_runtime = self._make_worker_runtime()
        observed: list[tuple[str, float]] = []

        def fake_trial_edit(candidate, *, trial_contract):
            step_size = float(candidate["step_size"])
            return {
                "id": f"diag_activation_patch_{candidate['site']}_{step_size}",
                "target": {"surface_id": f"s_{candidate['site']}_l{candidate['layer']}_last"},
                "source": {"dtype": "vector", "expr": {"ref": {"scope": "runtime"}}},
                "op": {"kind": "activation_patch", "alpha": candidate["alpha"], "mode": "blend"},
                "budget": {
                    "ttl_steps": 1,
                    "norm_clip": 1.0,
                    "revertible": True,
                    "step_size": step_size,
                },
                "meta": {"operator_recipe_id": candidate["operator_recipe_id"]},
            }

        def fake_replay(candidate_edits, **kwargs):
            edit = candidate_edits[0]
            site = str(edit["target"]["surface_id"]).split("_l", 1)[0].removeprefix("s_")
            step_size = float(edit["budget"]["step_size"])
            observed.append((site, step_size))
            return {
                "status": "ok",
                "actual_delta_class": "neutral",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 0,
                "target_top20_threshold_gap_delta": -0.001 * step_size,
                "term_readout_deltas": {"a": {"lift_score": 0.0}},
                "activation_patch_hook_call_count": 1,
                "activation_patch_selected_token_count": 1,
                "activation_patch_source_norm": 10.0,
                "activation_patch_target_norm_before": 9.0,
                "activation_patch_target_norm_after": 9.1,
                "activation_patch_source_target_cosine": 0.95,
                "activation_patch_source_target_delta_norm": 1.0,
                "activation_patch_raw_blend_delta_norm": 0.4,
                "activation_patch_blend_delta_norm": step_size,
                "activation_patch_step_size_clip_saturated": True,
            }

        seed_rows = [
            {
                "evidence_kind": "activation_patch_certification",
                "diagnostic_family": "activation_patch",
                "activation_patch_op_kind": "activation_patch",
                "objective_bundle_key": "entity_insert:a:source_body:0:1",
                "actuator_bundle_key": "entity_insert:a:source_body:0:1",
                "intended_term": "a",
                "activation_patch_site": "mlp_out",
                "activation_patch_layer": 11,
                "activation_patch_alpha": 0.03,
                "activation_patch_step_size": 0.03,
                "activation_patch_source_localization": "source_term_token",
                "activation_patch_patch_mode": "blend",
                "activation_patch_hook_call_count": 1,
                "activation_patch_step_size_clip_saturated": True,
                "status": "blocked",
                "actual_delta_class": "dead_actuator",
                "actuator_class": "dead_actuator",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "recipe_name": "activation_patch_mlp_out_l11_source_term_token_a030",
                "operator_recipe_id": "seed_mlp_dead",
            },
            {
                "evidence_kind": "activation_patch_certification",
                "diagnostic_family": "activation_patch",
                "activation_patch_op_kind": "activation_patch",
                "objective_bundle_key": "entity_insert:a:source_body:0:1",
                "actuator_bundle_key": "entity_insert:a:source_body:0:1",
                "intended_term": "a",
                "activation_patch_site": "resid_pre",
                "activation_patch_layer": 11,
                "activation_patch_alpha": 0.04,
                "activation_patch_step_size": 0.04,
                "activation_patch_source_localization": "source_term_token",
                "activation_patch_patch_mode": "blend",
                "activation_patch_hook_call_count": 1,
                "activation_patch_step_size_clip_saturated": True,
                "status": "blocked",
                "actual_delta_class": "dead_actuator",
                "actuator_class": "dead_actuator",
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "recipe_name": "activation_patch_resid_pre_l11_source_term_token_a040",
                "operator_recipe_id": "seed_resid_dead",
            },
        ]

        with patch.object(worker_runtime, "_activation_patch_trial_edit_from_candidate", side_effect=fake_trial_edit):
            with patch.object(worker_runtime, "replay_candidate_edits_actual_delta", side_effect=fake_replay):
                rows = worker_runtime._activation_patch_cap_release_response_curve_rows(seed_rows)

        self.assertEqual(observed, [("mlp_out", 0.05), ("mlp_out", 0.08), ("resid_pre", 0.05)])
        self.assertEqual(
            [row["activation_patch_seed_source"] for row in rows],
            ["forced_canonical_seed_discovery"] * 3,
        )
        self.assertTrue(all(row["operator_axis"] == "activation_patch_seed_discovery" for row in rows))
        self.assertTrue(all(row["activation_patch_seed_discovery"] for row in rows))
        self.assertTrue(all(not row["activation_patch_cap_release_response_curve"] for row in rows))
        self.assertTrue(all(row["activation_patch_forced_seed"] for row in rows))
        self.assertTrue(all(row["production_apply_allowed"] is False for row in rows))

    def test_worker_runtime_tokenize_terms_tool_returns_token_units(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")

        results = worker_runtime.request_controller_tools(
            [{"tool": "tokenize_terms", "terms": ["ab", "c"]}],
            source="controller",
        )

        self.assertEqual(results[0]["tool"], "tokenize_terms")
        self.assertEqual(results[0]["term_count"], 2)
        self.assertEqual(results[0]["terms"][0]["term"], "ab")
        self.assertEqual(results[0]["terms"][0]["token_ids"], [1, 2])
        self.assertEqual(results[0]["terms"][0]["piece_count"], 2)
        self.assertEqual(results[0]["terms"][0]["control_profile"], "sequence_bias_plus_patience")
        self.assertEqual(results[0]["terms"][0]["biasable_units"][0]["piece"], "a")
        self.assertEqual(results[0]["terms"][1]["control_profile"], "single_token_bias_ok")
        self.assertEqual(results[0]["soft_logit_bias_ok_terms"], ["c"])
        self.assertEqual(results[0]["needs_sequence_support_terms"], ["ab"])

    def test_worker_runtime_constraint_scorer_tool_uses_task_feedback_and_observer(self):
        def task_feedback_fn(output):
            has_c = "c" in output
            return {
                "done": has_c,
                "partial_score": 1.0 if has_c else 0.0,
                "progress_label": "progressing" if has_c else "stalled",
                "required_term_recall": 1.0 if has_c else 0.0,
                "required_term_span_progress_by_term": {"c": 1.0 if has_c else 0.0},
                "constraint_violations": [] if has_c else ["missing_required_terms"],
                "forbidden_term_clean": 1.0,
                "word_budget_score": 1.0,
                "missing_required_terms": [] if has_c else ["c"],
            }

        def observer_check_fn(output, *, task_feedback=None, trigger="runtime", worker_runtime=None):
            return {
                "check_type": "semantic_progress",
                "trigger": trigger,
                "score": 0.9 if "c" in output else 0.2,
                "raw_score": 0.9 if "c" in output else 0.2,
                "coverage_weight": 1.0,
            }

        worker_runtime = self._make_worker_runtime(
            task_feedback_fn=task_feedback_fn,
            observer_check_fn=observer_check_fn,
        )
        worker_runtime.reset("p")

        results = worker_runtime.request_controller_tools(
            [{"tool": "constraint_scorer", "candidate": "c"}],
            source="controller",
        )

        self.assertEqual(results[0]["tool"], "constraint_scorer")
        self.assertAlmostEqual(results[0]["required_term_recall"], 1.0)
        self.assertAlmostEqual(results[0]["semantic_progress_score"], 0.9)
        self.assertIn("semantic_checked", results[0]["explanation_tags"])

    def test_worker_runtime_kv_feature_scan_reports_cache_head_candidates(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("pp")

        class _FakeAttn:
            def __init__(self):
                self.W_K = torch.tensor(
                    [
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                    ],
                    dtype=torch.float32,
                )
                self.W_V = torch.tensor(
                    [
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                        [[1.0, 0.0], [0.0, 1.0], [0.0, 0.0]],
                    ],
                    dtype=torch.float32,
                )

        fake_model = type(
            "FakeModel",
            (),
            {"blocks": [type("FakeBlock", (), {"attn": _FakeAttn()})() for _ in range(12)]},
        )()
        worker_runtime.model = fake_model
        worker_runtime.runtime_state.model = fake_model
        worker_runtime.runtime_state.last_cache = {
            "blocks.3.attn.hook_k": torch.tensor(
                [[[[0.1, 0.0], [0.0, 0.1]], [[0.2, 0.0], [0.1, 0.2]]]],
                dtype=torch.float32,
            ),
            "blocks.3.attn.hook_v": torch.tensor(
                [[[[0.1, 0.0], [0.3, 0.2]], [[0.1, 0.0], [1.0, 0.0]]]],
                dtype=torch.float32,
            ),
        }
        worker_runtime._feature_prototype_cache["term_x"] = torch.tensor([1.0, 0.0, 0.0], dtype=torch.float32)

        scan = worker_runtime.kv_feature_scan(
            feature_groups={
                "required_terms": {
                    "terms": ("term_x",),
                    "polarity": "promote",
                    "feature_kind": "required_term",
                }
            }
        )

        self.assertIsNotNone(scan)
        assert scan is not None
        self.assertEqual(scan["projection_mode"], "attn_weight_head_projection")
        self.assertEqual(scan["groups"][0]["group"], "required_terms")
        self.assertIn(scan["top_feature_hits"][0]["site"], {"k_cache", "v_cache"})
        self.assertEqual(scan["top_feature_hits"][0]["layer"], 3)
        self.assertIn(scan["top_feature_hits"][0]["head"], {0, 1})
        self.assertEqual(scan["top_feature_hits"][0]["token_mode"], "last")
        self.assertIn("argmax_pos", scan["top_feature_hits"][0])
        self.assertTrue(scan["top_feature_hits"][0]["source_positions"])
        self.assertEqual(
            scan["top_feature_hits"][0]["source_positions"][0]["position"],
            scan["top_feature_hits"][0]["argmax_pos"],
        )

    def test_worker_runtime_kv_feature_scan_handles_gqa_expanded_weights(self):
        worker_runtime = self._make_worker_runtime()

        class _FakeAttn:
            def __init__(self):
                self.W_K = torch.tensor(
                    [
                        [[1.0, 0.0], [0.0, 0.0], [0.0, 0.0]],
                        [[1.0, 0.0], [0.0, 0.0], [0.0, 0.0]],
                        [[1.0, 0.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                    ],
                    dtype=torch.float32,
                )
                self.W_V = torch.tensor(
                    [
                        [[1.0, 0.0], [0.0, 0.0], [0.0, 0.0]],
                        [[1.0, 0.0], [0.0, 0.0], [0.0, 0.0]],
                        [[1.0, 0.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                    ],
                    dtype=torch.float32,
                )

        fake_model = type(
            "FakeGQAModel",
            (),
            {
                "blocks": [type("FakeBlock", (), {"attn": _FakeAttn()})() for _ in range(12)],
                "cfg": type("FakeCfg", (), {"n_heads": 6, "n_key_value_heads": 2, "d_head": 2, "d_model": 3})(),
            },
        )()
        worker_runtime.model = fake_model
        worker_runtime.runtime_state.model = fake_model
        worker_runtime.runtime_state.last_cache = {
            "blocks.3.attn.hook_k": torch.tensor(
                [[[[1.0, 0.0], [0.0, 0.1]], [[0.2, 0.0], [0.0, 0.2]]]],
                dtype=torch.float32,
            ),
            "blocks.3.attn.hook_v": torch.tensor(
                [[[[0.5, 0.0], [0.1, 0.1]], [[0.0, 0.2], [0.0, 0.6]]]],
                dtype=torch.float32,
            ),
        }
        worker_runtime._feature_prototype_cache["term_x"] = torch.tensor([1.0, 0.0, 0.0], dtype=torch.float32)

        scan = worker_runtime.kv_feature_scan(
            feature_groups={
                "required_terms": {
                    "terms": ("term_x",),
                    "polarity": "promote",
                    "feature_kind": "required_term",
                }
            }
        )

        self.assertIsNotNone(scan)
        assert scan is not None
        self.assertEqual(scan["top_feature_hits"][0]["site"], "k_cache")
        self.assertEqual(scan["top_feature_hits"][0]["layer"], 3)
        self.assertEqual(scan["top_feature_hits"][0]["head"], 0)

    def test_worker_runtime_kv_feature_scan_prioritizes_required_promote_hits(self):
        worker_runtime = self._make_worker_runtime()

        class _FakeAttn:
            def __init__(self):
                self.W_K = torch.tensor(
                    [
                        [[1.0, 1.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 0.0], [0.0, 1.0], [0.0, 0.0]],
                    ],
                    dtype=torch.float32,
                )
                self.W_V = torch.tensor(
                    [
                        [[1.0, 0.0], [0.0, 0.0], [0.0, 0.0]],
                        [[0.0, 0.0], [1.0, 1.0], [0.0, 0.0]],
                    ],
                    dtype=torch.float32,
                )

        fake_model = type(
            "FakeModel",
            (),
            {"blocks": [type("FakeBlock", (), {"attn": _FakeAttn()})() for _ in range(12)]},
        )()
        worker_runtime.model = fake_model
        worker_runtime.runtime_state.model = fake_model
        worker_runtime.runtime_state.last_cache = {
            "blocks.3.attn.hook_k": torch.tensor(
                [[[[1.0, 0.0], [0.0, 1.0]], [[0.1, 0.0], [0.0, 0.2]]]],
                dtype=torch.float32,
            ),
            "blocks.3.attn.hook_v": torch.tensor(
                [[[[1.0, 0.0], [0.0, 1.0]], [[0.1, 0.0], [0.0, 0.2]]]],
                dtype=torch.float32,
            ),
        }
        worker_runtime._feature_prototype_cache["term_req"] = torch.tensor([1.0, 0.0, 0.0], dtype=torch.float32)
        worker_runtime._feature_prototype_cache["term_forbid"] = torch.tensor([0.0, 1.0, 0.0], dtype=torch.float32)

        scan = worker_runtime.kv_feature_scan(
            feature_groups={
                "required_terms": {
                    "terms": ("term_req",),
                    "polarity": "promote",
                    "feature_kind": "required_term",
                },
                "forbidden_phrases": {
                    "terms": ("term_forbid",),
                    "polarity": "suppress",
                    "feature_kind": "forbidden_phrase",
                },
            }
        )

        self.assertIsNotNone(scan)
        assert scan is not None
        self.assertEqual(scan["top_feature_hits"][0]["group"], "required_terms")
        self.assertEqual(scan["top_feature_hits"][0]["polarity"], "promote")
        self.assertEqual(scan["top_feature_hits"][0]["site"], "v_cache")
        self.assertEqual(scan["top_feature_hits"][1]["group"], "forbidden_phrases")
        self.assertEqual(scan["top_feature_hits"][1]["site"], "k_cache")

    def test_worker_runtime_packet_promotes_kv_scan_hits_into_cache_surfaces_and_hints(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["term_x"],
            "entity_recall_terms": ["term_x"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.41,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 1,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "term_x",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "alignment": 0.31,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {
                                "position": 0,
                                "relative_index": -1,
                                "segment_kind": "prompt",
                                "piece": "p",
                                "alignment": 0.31,
                            }
                        ],
                    }
                ],
                "groups": [
                    {
                        "group": "required_terms",
                        "polarity": "promote",
                        "top_features": [
                            {
                                "feature": "term_x",
                                "site": "v_cache",
                                "layer": 3,
                                "head": 1,
                                "token_mode": "last",
                                "alignment": 0.31,
                                "argmax_pos": 0,
                                "argmax_relative_index": -1,
                                "argmax_piece": "p",
                                "argmax_segment_kind": "prompt",
                                "source_positions": [
                                    {
                                        "position": 0,
                                        "relative_index": -1,
                                        "segment_kind": "prompt",
                                        "piece": "p",
                                        "alignment": 0.31,
                                    }
                                ],
                            }
                        ],
                    }
                ],
            },
        }
        worker_runtime._recent_effects = [
            {
                "hypothesis": "small_loop_rescue",
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "observed_window_steps": 1,
                "before": {
                    "entropy": 1.2,
                    "top1_margin": 0.1,
                    "repetition_score": 0.8,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                },
                "after": {
                    "entropy": 1.1,
                    "top1_margin": 0.2,
                    "repetition_score": 0.5,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                },
                "delta": {
                    "repetition_score": -0.3,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                },
                "verdict": "neutral",
                "signal_profile": "stabilizing_only",
            }
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_annotate_kv_candidates_with_canary",
            side_effect=lambda items: [dict(item, canary_checked=True, canary_pass=True, canary_focus_logit_delta=0.01) for item in items],
        ):
            packet = worker_runtime.build_controller_packet()
        parsed = parse_observation_packet(packet)

        promoted = next(surface for surface in packet["surface_catalog"] if surface["target"]["kind"] == "cache")
        self.assertEqual(promoted["target"]["site"], "v_cache")
        self.assertEqual(promoted["target"]["layer"], 3)
        self.assertEqual(promoted["target"]["head"], 1)
        self.assertEqual(promoted["allow_ops"], ["kv_mix"])
        self.assertEqual(promoted["caps"]["max_ttl_steps"], 1)
        self.assertEqual(
            packet["latest_observer_check"]["kv_feature_scan"]["top_feature_hits"][0]["surface_id"],
            promoted["surface_id"],
        )
        self.assertEqual(parsed.surface_map()[promoted["surface_id"]].target.kind, "cache")
        self.assertEqual(packet["strategy_hints"]["preferred_kv_surface_id"], promoted["surface_id"])
        self.assertFalse(packet["strategy_hints"]["kv_probe_needed"])
        self.assertEqual(packet["strategy_hints"]["kv_candidate_edits"][0]["surface_id"], promoted["surface_id"])
        self.assertEqual(packet["strategy_hints"]["kv_candidate_edits"][0]["op"]["kind"], "kv_mix")
        self.assertEqual(packet["strategy_hints"]["kv_candidate_edits"][0]["op"]["which"], "v")
        self.assertEqual(packet["strategy_hints"]["kv_candidate_edits"][0]["source"]["v"]["ref"]["tensor"], "v_cache")
        self.assertEqual(packet["strategy_hints"]["kv_candidate_edits"][0]["source"]["v"]["ref"]["head"], 1)
        self.assertEqual(packet["strategy_hints"]["kv_candidate_edits"][0]["source"]["v"]["ref"]["token"]["value"], 0)
        self.assertTrue(packet["strategy_hints"]["kv_candidate_edits"][0]["canary_pass"])

    def test_worker_runtime_packet_keeps_actionable_k_side_kv_candidate(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["term_x", "term_y"],
            "entity_recall_terms": ["term_x", "term_y"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.33,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 3,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "term_x",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "alignment": 0.31,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.31}],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "term_y",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 4,
                        "head": 1,
                        "token_mode": "last",
                        "alignment": 0.29,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.29}],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "term_x",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "alignment": 0.34,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.34}],
                        "coverage_progress": 0.0,
                    },
                ],
            },
        }
        worker_runtime._recent_effects = [
            {
                "hypothesis": "loop_relief_only",
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "expected_effect": "break_loop",
                "signal_profile": "stabilizing_only",
                "verdict": "neutral",
            }
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_annotate_kv_candidates_with_canary",
            side_effect=lambda items: [dict(item, canary_checked=True, canary_pass=False, canary_reason="focus_token_flat") for item in items],
        ):
            packet = worker_runtime.build_controller_packet()

        kv_candidates = packet["strategy_hints"]["kv_candidate_edits"]
        self.assertGreaterEqual(len(kv_candidates), 2)
        self.assertIn("k_cache", {item["site"] for item in kv_candidates})
        self.assertIn("v_cache", {item["site"] for item in kv_candidates})
        k_candidate = next(item for item in kv_candidates if item["site"] == "k_cache")
        self.assertEqual(k_candidate["op"]["which"], "k")
        self.assertEqual(k_candidate["site_preference"], "k_cache")
        promoted_sites = {
            surface["target"]["site"]
            for surface in packet["surface_catalog"]
            if isinstance(surface, dict) and isinstance(surface.get("target"), dict) and surface["target"].get("kind") == "cache"
        }
        self.assertIn("k_cache", promoted_sites)
        self.assertIn("v_cache", promoted_sites)

    def test_worker_runtime_packet_can_expand_k_candidate_from_surface_hits(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["term_x"],
            "entity_recall_terms": ["term_x"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.3,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 2,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "term_x",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "alignment": 0.32,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.32}],
                        "coverage_progress": 0.0,
                    }
                ],
                "groups": [
                    {
                        "group": "required_terms",
                        "polarity": "promote",
                        "top_features": [
                            {
                                "feature": "term_x",
                                "site": "v_cache",
                                "layer": 3,
                                "head": 1,
                                "token_mode": "last",
                                "alignment": 0.32,
                                "argmax_pos": 0,
                                "argmax_relative_index": -1,
                                "argmax_piece": "p",
                                "argmax_segment_kind": "prompt",
                                "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.32}],
                                "surface_hits": [
                                    {
                                        "site": "v_cache",
                                        "layer": 3,
                                        "head": 1,
                                        "token_mode": "last",
                                        "alignment": 0.32,
                                        "argmax_pos": 0,
                                        "argmax_relative_index": -1,
                                        "argmax_piece": "p",
                                        "argmax_segment_kind": "prompt",
                                        "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.32}],
                                    },
                                    {
                                        "site": "k_cache",
                                        "layer": 3,
                                        "head": 0,
                                        "token_mode": "last",
                                        "alignment": 0.31,
                                        "argmax_pos": 0,
                                        "argmax_relative_index": -1,
                                        "argmax_piece": "p",
                                        "argmax_segment_kind": "prompt",
                                        "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.31}],
                                    },
                                ],
                                "coverage_progress": 0.0,
                            }
                        ],
                    }
                ],
            },
        }
        worker_runtime._recent_effects = [
            {
                "hypothesis": "loop_relief_only",
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "expected_effect": "break_loop",
                "signal_profile": "stabilizing_only",
                "verdict": "neutral",
            }
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_annotate_kv_candidates_with_canary",
            side_effect=lambda items: [dict(item, canary_checked=True, canary_pass=False, canary_reason="focus_token_flat") for item in items],
        ):
            packet = worker_runtime.build_controller_packet()

        self.assertIn("k_cache", {item["site"] for item in packet["strategy_hints"]["kv_candidate_edits"]})

    def test_worker_runtime_build_dry_run_command_accepts_kv_candidate_edit(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["term_x"],
            "entity_recall_terms": ["term_x"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.41,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 1,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "term_x",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "alignment": 0.31,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {
                                "position": 0,
                                "relative_index": -1,
                                "segment_kind": "prompt",
                                "piece": "p",
                                "alignment": 0.31,
                            }
                        ],
                    }
                ],
            },
        }
        worker_runtime._recent_effects = [
            {
                "hypothesis": "small_loop_rescue",
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "observed_window_steps": 1,
                "before": {
                    "entropy": 1.2,
                    "top1_margin": 0.1,
                    "repetition_score": 0.8,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                },
                "after": {
                    "entropy": 1.1,
                    "top1_margin": 0.2,
                    "repetition_score": 0.5,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                },
                "delta": {
                    "repetition_score": -0.3,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                },
                "verdict": "neutral",
                "signal_profile": "stabilizing_only",
            }
        ]
        packet = worker_runtime.build_controller_packet()
        candidate_edit = packet["strategy_hints"]["kv_candidate_edits"][0]

        command = worker_runtime._build_dry_run_command(candidate_edit)

        self.assertIsNotNone(command)
        assert command is not None
        parsed = parse_controller_command(command)
        self.assertEqual(parsed.edits[0].op.kind, "kv_mix")
        self.assertEqual(parsed.edits[0].target.surface_id, candidate_edit["surface_id"])
        validate_command_against_packet(command, packet)

    def test_worker_runtime_kv_canary_accepts_two_token_prefix_progress(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["budget"],
            "entity_recall_terms": ["budget"],
        }
        vocab_size = 6
        baseline_logits = torch.zeros(vocab_size, dtype=torch.float32)
        edited_logits = torch.zeros(vocab_size, dtype=torch.float32)
        edited_logits[1] = 0.0006
        candidate = {
            "surface_id": "s_k_cache_l3_h0_last_promoted",
            "kind": "kv_mix",
            "site": "k_cache",
            "source": {
                "dtype": "cache_pair",
                "k": {
                    "ref": {
                        "scope": "runtime",
                        "worker": "os_0",
                        "tensor": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token": {"mode": "index", "value": 4},
                    }
                },
            },
            "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
            "budget": {"ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.03, "revertible": True},
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_target_token_sequences",
            return_value=[_TargetTokenSequence(term="budget", token_ids=(1, 2), variant=" budget")],
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_simulate_decode",
            side_effect=[
                {
                    "continuation": "zz",
                    "continuation_token_ids": [5, 5],
                    "first_logits": baseline_logits,
                    "entropy": 1.0,
                    "repeat_flag": False,
                    "scoring": {
                        "required_term_recall": 0.0,
                        "required_term_span_progress": 0.0,
                        "semantic_progress_score": 0.0,
                    },
                },
                {
                    "continuation": " ab",
                    "continuation_token_ids": [1, 2],
                    "first_logits": edited_logits,
                    "entropy": 0.98,
                    "repeat_flag": False,
                    "scoring": {
                        "required_term_recall": 0.0,
                        "required_term_span_progress": 0.4,
                        "semantic_progress_score": 0.02,
                    },
                },
            ],
        ):
            annotated = worker_runtime._annotate_kv_candidates_with_canary([candidate])

        self.assertTrue(annotated[0]["canary_checked"])
        self.assertTrue(annotated[0]["canary_pass"])
        self.assertEqual(annotated[0]["canary_reason"], "target_prefix_improved")
        self.assertEqual(annotated[0]["canary_prefix_depth_delta"], 2)
        self.assertGreater(annotated[0]["canary_space_focus_logit_delta"], 0.0)

    def test_worker_runtime_kv_canary_accepts_target_rank_improvement(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["budget"],
            "entity_recall_terms": ["budget"],
        }
        vocab_size = 8
        baseline_logits = torch.tensor([0.7, 0.12, 0.55, 0.4, 0.35, 0.3, 0.2, 0.1], dtype=torch.float32)
        edited_logits = torch.tensor([0.7, 0.48, 0.55, 0.4, 0.35, 0.3, 0.2, 0.1], dtype=torch.float32)
        candidate = {
            "surface_id": "s_k_cache_l3_h0_last_promoted",
            "kind": "kv_mix",
            "site": "k_cache",
            "source": {
                "dtype": "cache_pair",
                "k": {
                    "ref": {
                        "scope": "runtime",
                        "worker": "os_0",
                        "tensor": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token": {"mode": "index", "value": 4},
                    }
                },
            },
            "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
            "budget": {"ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.03, "revertible": True},
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_target_token_sequences",
            return_value=[_TargetTokenSequence(term="budget", token_ids=(1, 2), variant=" budget")],
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_simulate_decode",
            side_effect=[
                {
                    "continuation": "zz",
                    "continuation_token_ids": [5, 5],
                    "first_logits": baseline_logits,
                    "entropy": 1.0,
                    "repeat_flag": False,
                    "scoring": {
                        "required_term_recall": 0.0,
                        "required_term_span_progress": 0.0,
                        "semantic_progress_score": 0.0,
                    },
                },
                {
                    "continuation": "zz",
                    "continuation_token_ids": [5, 5],
                    "first_logits": edited_logits,
                    "entropy": 0.99,
                    "repeat_flag": False,
                    "scoring": {
                        "required_term_recall": 0.0,
                        "required_term_span_progress": 0.0,
                        "semantic_progress_score": 0.0,
                    },
                },
            ],
        ):
            annotated = worker_runtime._annotate_kv_candidates_with_canary([candidate])

        self.assertTrue(annotated[0]["canary_checked"])
        self.assertTrue(annotated[0]["canary_pass"])
        self.assertEqual(annotated[0]["canary_reason"], "target_rank_improved")
        self.assertGreaterEqual(annotated[0]["canary_focus_rank_delta"], 4)
        self.assertGreater(annotated[0]["canary_target_mass_delta"], 0.0)

    def test_worker_runtime_actionable_kv_hits_demotes_recent_flat_probe(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["term_x", "term_y"],
            "entity_recall_terms": ["term_x", "term_y"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.3,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 2,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "term_x",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "surface_id": "s_v_cache_l3_h1_last_promoted",
                        "alignment": 0.36,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.36}],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "term_y",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "alignment": 0.32,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [{"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.32}],
                        "coverage_progress": 0.0,
                    },
                ],
            },
        }
        worker_runtime._tool_results = [
            {
                "tool": "dry_run_decode",
                "status": "ok",
                "candidate_edit": {"surface_id": "s_v_cache_l3_h1_last_promoted", "kind": "kv_mix"},
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "repeat_flag_delta": 0,
                "topk_token_diff": [{"piece": "EW", "prob_delta": 0.0, "logit_delta": 0.0}],
            },
            {
                "tool": "dry_run_decode",
                "status": "ok",
                "candidate_edit": {"surface_id": "s_k_cache_l3_h0_last_promoted", "kind": "kv_mix"},
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.2,
                "semantic_progress_delta": 0.01,
                "repeat_flag_delta": 0,
                "topk_token_diff": [{"piece": " budget", "prob_delta": 0.0001, "logit_delta": 0.0008}],
            },
        ]

        hits = worker_runtime._actionable_kv_hits(limit=2)

        self.assertEqual(hits[0]["surface_id"], "s_k_cache_l3_h0_last_promoted")
        self.assertEqual(hits[0]["recent_probe"]["label"], "positive")
        self.assertEqual(hits[1]["surface_id"], "s_v_cache_l3_h1_last_promoted")
        self.assertEqual(hits[1]["recent_probe"]["label"], "dead_actuator")

    def test_worker_runtime_recent_probe_history_classifies_shot_bridge_in_shared_score_space(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._tool_results = [
            {
                "tool": "dry_run_decode",
                "status": "ok",
                "candidate_edit": {
                    "surface_id": "s_resid_pre_l3_prev",
                    "kind": "resid_add",
                    "role": "shot_source_bridge_prev",
                    "focus_feature": "budget",
                    "phase_objective": "readout_escape",
                    "span_kind": "exact_prompt_piece",
                    "provenance_class": "source_body",
                    "source_position": 4,
                },
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "repeat_flag_delta": 0,
                "target_mass_delta": 0.00004,
                "target_mass_edited": 0.00035,
                "target_top20_hit_delta": 0,
                "target_top20_hits_edited": 0,
                "focus_rank_delta": 8,
                "rank_focus_delta": 10,
                "focus_logit_delta": 0.0009,
                "focus_prob_delta": 0.00002,
                "topk_token_diff": [{"piece": " budget", "prob_delta": 0.00002, "logit_delta": 0.0009}],
            }
        ]

        history = worker_runtime._recent_probe_history()

        self.assertEqual(history[0]["probe_family"], "shot_bridge")
        self.assertEqual(history[0]["probe_phase_profile"], "readout_escape")
        self.assertIn("readout", history[0]["positive_axes"])
        self.assertGreater(history[0]["readout_score"], history[0]["constraint_score"])

    def test_worker_runtime_recent_probe_history_uses_composition_criteria_for_resid_family(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._tool_results = [
            {
                "tool": "dry_run_decode",
                "status": "ok",
                "candidate_edit": {
                    "surface_id": "s_resid_l11_last",
                    "kind": "resid_add",
                    "role": "shot_last_anchor",
                    "focus_feature": "Omar",
                    "phase_objective": "entity_insertion",
                    "span_kind": "exact_prompt_span_mean",
                    "provenance_class": "source_body",
                    "source_position": 8,
                    "source_span": {"start": 8, "end": 10},
                },
                "required_term_recall_delta": 0.25,
                "required_term_span_progress_delta": 0.5,
                "semantic_progress_delta": 0.03,
                "repeat_flag_delta": 0,
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 0,
                "rank_focus_delta": 0,
                "focus_logit_delta": 0.0,
                "focus_prob_delta": 0.0,
                "topk_token_diff": [{"piece": " Omar", "prob_delta": 0.0, "logit_delta": 0.0}],
            }
        ]

        history = worker_runtime._recent_probe_history(phase_profiles={"composition"})

        self.assertEqual(history[0]["probe_family"], "resid_add")
        self.assertEqual(history[0]["probe_phase_profile"], "composition")
        self.assertIn("constraint", history[0]["positive_axes"])
        self.assertGreater(history[0]["constraint_score"], history[0]["readout_score"])
        self.assertEqual(history[0]["label"], "actionable_positive")

    def test_worker_runtime_k_source_positions_prefer_term_like_prompt_piece(self):
        worker_runtime = self._make_worker_runtime()
        prototype = torch.tensor([1.0, 0.0], dtype=torch.float32)
        cache_tensor = torch.tensor([[[[1.0, 0.0]], [[1.0, 0.0]]]], dtype=torch.float32)
        position_records = [
            {"position": 0, "relative_index": -2, "segment_kind": "prompt", "piece": ".\n"},
            {"position": 1, "relative_index": -1, "segment_kind": "prompt", "piece": " budget"},
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_project_feature_into_kv_head",
            return_value=torch.tensor([1.0, 0.0], dtype=torch.float32, device="cpu"),
        ):
            rows = worker_runtime._kv_source_positions_for_feature(
                prototype,
                feature="budget",
                cache_tensor=cache_tensor,
                layer=3,
                site="k_cache",
                head=0,
                width=2,
                head_count=1,
                position_records=position_records,
                max_positions=2,
            )

        self.assertEqual(rows[0]["piece"], " budget")
        self.assertGreater(rows[0]["anchor_quality"], rows[1]["anchor_quality"])

    def test_worker_runtime_v_source_positions_reuse_position_invariant_projection(self):
        worker_runtime = self._make_worker_runtime()
        prototype = torch.tensor([1.0, 0.0], dtype=torch.float32)
        cache_tensor = torch.tensor([[[[1.0, 0.0]], [[1.0, 0.0]], [[1.0, 0.0]]]], dtype=torch.float32)
        position_records = [
            {"position": 0, "relative_index": -3, "segment_kind": "prompt", "piece": " Mira"},
            {"position": 1, "relative_index": -2, "segment_kind": "prompt", "piece": " send"},
            {"position": 2, "relative_index": -1, "segment_kind": "prompt", "piece": " budget"},
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_project_feature_into_kv_head",
            return_value=torch.tensor([1.0, 0.0], dtype=torch.float32, device="cpu"),
        ) as projected:
            rows = worker_runtime._kv_source_positions_for_feature(
                prototype,
                feature="budget",
                cache_tensor=cache_tensor,
                layer=3,
                site="v_cache",
                head=0,
                width=2,
                head_count=1,
                position_records=position_records,
                max_positions=3,
            )

        self.assertEqual(projected.call_count, 1)
        self.assertGreaterEqual(len(rows), 1)

    def test_worker_runtime_shot_mode_only_prefers_canary_passing_kv_candidates(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["term_x"],
            "entity_recall_terms": ["term_x"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.41,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 1,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "term_x",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "alignment": 0.31,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {
                                "position": 0,
                                "relative_index": -1,
                                "segment_kind": "prompt",
                                "piece": "p",
                                "alignment": 0.31,
                            }
                        ],
                    }
                ],
            },
        }
        worker_runtime._recent_effects = [
            {
                "hypothesis": "small_loop_rescue",
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "expected_effect": "break_loop",
                "signal_profile": "stabilizing_only",
                "verdict": "neutral",
            }
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_annotate_kv_candidates_with_canary",
            side_effect=lambda items: [dict(item, canary_checked=True, canary_pass=False, canary_focus_logit_delta=0.0) for item in items],
        ):
            packet = worker_runtime.build_controller_packet()

        self.assertFalse(packet["strategy_hints"]["kv_probe_needed"])
        self.assertNotIn("preferred_kv_surface_id", packet["strategy_hints"])
        self.assertFalse(packet["strategy_hints"]["kv_candidate_edits"][0]["canary_pass"])

    def test_worker_runtime_logit_bias_prefers_space_prefixed_variant(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="logit_bias_entity_soft")
        worker_runtime.reset("p")
        worker_runtime._append_output_token(worker_runtime.runtime_state.base_token)
        worker_runtime._no_progress_steps = 1
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["ab"],
            "entity_recall_terms": ["ab"],
            "required_term_span_progress_by_term": {"ab": 0.0},
        }

        space_token = int(worker_runtime.codec.encode(" ")[0].item())
        a_token = int(worker_runtime.codec.encode("a")[0].item())
        logits = torch.full((worker_runtime.runtime_state.vocab_size,), -5.0, dtype=torch.float32)
        logits[space_token] = 1.0
        logits[a_token] = 1.0

        adjusted, state = worker_runtime._apply_soft_entity_logit_bias(logits)

        self.assertGreater(float(adjusted[space_token].item()), float(adjusted[a_token].item()))
        self.assertIn("ab", state["logit_bias_prefer_space_terms"])

    def test_worker_runtime_packet_exposes_entity_phase_and_l4_term_cooldown(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="logit_bias_entity_soft")
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "progressing",
            "required_term_recall": 0.0,
            "missing_required_terms": ["ab", "c"],
            "entity_recall_terms": ["ab", "c"],
        }
        worker_runtime._tool_results = [
            {
                "tool": "tokenize_terms",
                "soft_logit_bias_ok_terms": ["c"],
                "needs_sequence_support_terms": ["ab"],
                "span_progress_watch_terms": ["ab"],
            }
        ]
        worker_runtime._recent_effects = [
            {
                "edit_id": "e_required_term_nudge_l4",
                "surface_id": "s_resid_pre_l4_last",
                "op": "resid_add",
                "hypothesis": "required_term_nudge_l4",
                "verdict": "harmful",
                "delta": {
                    "required_term_recall": 0.0,
                    "required_term_span_progress": 0.0,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                },
            }
        ]

        packet = worker_runtime.build_controller_packet()

        self.assertEqual(packet["control_phase_hint"], "shot_mode")
        self.assertEqual(packet["strategy_hints"]["loop_severity"], "none")
        self.assertEqual(packet["strategy_hints"]["easy_entity_terms"], ["c"])
        self.assertEqual(packet["strategy_hints"]["hard_entity_terms"], ["ab"])
        self.assertTrue(packet["strategy_hints"]["prefer_space_prefixed_logit_bias"])
        self.assertTrue(packet["strategy_hints"]["prefer_auxiliary_entity_bias"])
        self.assertTrue(packet["strategy_hints"]["shot_mode_ready"])
        self.assertEqual(packet["strategy_hints"]["direct_entity_edit_gate"], "shot_mode_first")
        self.assertEqual(packet["strategy_hints"]["prefer_shot_tools"], ["constraint_scorer", "dry_run_decode"])
        self.assertTrue(packet["strategy_hints"]["shot_probe_needed"])
        self.assertEqual(packet["strategy_hints"]["preferred_shot_surface_id"], "s_resid_pre_l3_prev")
        self.assertEqual(packet["strategy_hints"]["shot_candidate_edits"][0]["surface_id"], "s_resid_pre_l3_prev")
        self.assertNotIn(
            "s_resid_pre_l4_last",
            [candidate["surface_id"] for candidate in packet["strategy_hints"]["shot_candidate_edits"]],
        )
        self.assertTrue(packet["strategy_hints"]["l4_term_nudge_cooldown"])
        self.assertEqual(packet["strategy_hints"]["avoid_recall_surfaces"], ["s_resid_pre_l4_last"])

    def test_worker_runtime_packet_switches_to_shot_mode_after_stabilizing_only_loop_relief(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="logit_bias_entity_soft")
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["budget", "send", "Mira"],
            "entity_recall_terms": ["budget", "send", "Mira"],
        }
        worker_runtime._tool_results = [
            {
                "tool": "tokenize_terms",
                "soft_logit_bias_ok_terms": ["budget", "send"],
                "needs_sequence_support_terms": ["Mira"],
                "span_progress_watch_terms": ["Mira"],
            }
        ]
        worker_runtime._recent_effects = [
            {
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "hypothesis": "loop_break_small_rescue",
                "verdict": "neutral",
                "signal_profile": "stabilizing_only",
                "delta": {
                    "required_term_recall": 0.0,
                    "required_term_span_progress": 0.0,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                    "repeat_flag": -1.0,
                    "no_progress_steps": -1.0,
                },
            }
        ]

        packet = worker_runtime.build_controller_packet()

        self.assertEqual(packet["control_phase_hint"], "shot_mode")
        self.assertTrue(packet["strategy_hints"]["shot_mode_ready"])
        self.assertEqual(packet["strategy_hints"]["direct_entity_edit_gate"], "shot_mode_first")
        self.assertEqual(packet["strategy_hints"]["loop_break_attempt_count"], 1)
        self.assertEqual(packet["strategy_hints"]["stabilizing_only_count"], 1)
        self.assertEqual(packet["strategy_hints"]["prefer_shot_tools"], ["constraint_scorer", "dry_run_decode"])
        self.assertTrue(packet["strategy_hints"]["shot_probe_needed"])
        self.assertEqual(packet["strategy_hints"]["preferred_shot_surface_id"], "s_resid_pre_l3_prev")
        self.assertEqual(packet["strategy_hints"]["shot_candidate_edits"][0]["surface_id"], "s_resid_pre_l3_prev")
        self.assertIn(
            "s_resid_pre_l4_last",
            [candidate["surface_id"] for candidate in packet["strategy_hints"]["shot_candidate_edits"]],
        )

    def test_worker_runtime_packet_exposes_answer_readout_canary_for_missing_terms(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["ab"],
            "entity_recall_terms": ["ab"],
        }

        packet = worker_runtime.build_controller_packet()

        canary = packet["worker_view"]["answer_readout_canary"]
        self.assertIn("top_tokens", canary)
        self.assertTrue(canary["top_tokens"])
        self.assertIn("target_mass", canary)
        self.assertIn("focus_rank", canary)
        self.assertEqual(
            packet["strategy_hints"]["answer_readout_summary"]["semantic_focus_term"],
            canary["semantic_focus_term"],
        )
        self.assertEqual(
            packet["strategy_hints"]["answer_readout_summary"]["reachable_focus_term"],
            canary["reachable_focus_term"],
        )
        self.assertEqual(
            packet["strategy_hints"]["answer_readout_summary"]["reachable_focus_rank"],
            canary["reachable_focus_rank"],
        )
        self.assertEqual(
            packet["strategy_hints"]["answer_readout_summary"]["attractor_family_overlap_tokens"],
            canary["attractor_family_overlap_tokens"],
        )

    def test_worker_runtime_strategy_hints_arm_preprobe_readout_escape_from_canary(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["budget", "Mira"],
            "entity_recall_terms": ["budget", "Mira"],
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value={
                "semantic_focus_term": "Mira",
                "semantic_focus_source": "kv_feature_scan",
                "reachable_focus_term": "budget",
                "reachable_focus_piece": " budget",
                "reachable_focus_rank": 901,
                "target_mass": 0.000142,
                "target_top20_hits": 0,
                "attractor_family_mass": 0.300192,
                "attractor_family_top_overlap": 4,
                "attractor_family_overlap_tokens": ["EW", " EW", "inou", " shards"],
                "top_tokens": ["EW", " EW", "inou", " shards", "Lawson"],
            },
        ):
            packet = worker_runtime.build_controller_packet()

        hints = packet["strategy_hints"]
        self.assertEqual(packet["control_phase_hint"], "readout_escape")
        self.assertTrue(hints["shot_mode_ready"])
        self.assertTrue(hints["readout_escape_needed"])
        self.assertEqual(hints["readout_escape_reason"], "preprobe_first_token_collapse")
        self.assertEqual(hints["controller_focus_term"], "budget")
        self.assertEqual(hints["controller_focus_source"], "reachable_focus")
        self.assertEqual(hints["attractor_family_overlap_tokens"], ["EW", " EW", "inou", " shards"])
        self.assertTrue(hints["readout_escape_block_reason"]["preprobe_collapse"])
        self.assertTrue(hints["readout_escape_block_reason"]["mass_below_threshold"])
        self.assertTrue(hints["readout_escape_block_reason"]["rank_bad"])
        self.assertTrue(hints["readout_escape_block_reason"]["top20_hits_zero"])
        self.assertTrue(hints["readout_escape_block_reason"]["attractor_mass_high"])
        self.assertFalse(hints["readout_escape_block_reason"]["shot_mode_not_ready"])
        self.assertTrue(hints["readout_escape_block_reason"]["no_candidates"])
        self.assertTrue(hints["kv_candidate_builder_called"])
        self.assertEqual(hints["kv_candidate_builder_source"], "runtime")
        self.assertEqual(hints["kv_candidate_builder_stage"], "kv_candidate_builder")
        self.assertEqual(hints["kv_candidate_builder_output_count"], 0)
        self.assertIn("no_feature_hits", hints["kv_candidate_builder_prune_reasons"])

    def test_worker_runtime_readout_escape_builder_prefers_reachable_term_and_exact_prompt_span(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p ab c")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["ab", "c"],
            "entity_recall_terms": ["ab", "c"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.2,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 2,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "ab",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "alignment": 0.34,
                        "argmax_pos": 2,
                        "argmax_relative_index": -4,
                        "argmax_piece": "a",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 2, "relative_index": -4, "segment_kind": "prompt", "piece": "a", "alignment": 0.34}
                        ],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "c",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "surface_id": "s_v_cache_l3_h1_last_promoted",
                        "alignment": 0.36,
                        "argmax_pos": 5,
                        "argmax_relative_index": -1,
                        "argmax_piece": "c",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 5, "relative_index": -1, "segment_kind": "prompt", "piece": "c", "alignment": 0.36}
                        ],
                        "coverage_progress": 0.0,
                    },
                ],
            },
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value={
                "semantic_focus_term": "c",
                "semantic_focus_source": "kv_feature_scan",
                "reachable_focus_term": "ab",
                "reachable_focus_piece": "ab",
                "reachable_focus_rank": 901,
                "target_mass": 0.00012,
                "target_top20_hits": 0,
                "attractor_family_mass": 0.22,
                "attractor_family_top_overlap": 2,
                "attractor_family_overlap_tokens": ["EW", " EW"],
                "top_tokens": ["EW", " EW", "inou"],
            },
        ):
            packet = worker_runtime.build_controller_packet()

        hints = packet["strategy_hints"]
        candidate = hints["kv_candidate_edits"][0]
        self.assertEqual(packet["control_phase_hint"], "readout_escape")
        self.assertEqual(hints["escape_builder_target_terms"][0], "ab")
        self.assertGreaterEqual(hints["escape_builder_candidates_before_prune"], 2)
        self.assertEqual(candidate["focus_feature"], "ab")
        self.assertEqual(candidate["span_kind"], "exact_prompt_span_mean")
        self.assertEqual(candidate["phase_objective"], "readout_escape")
        self.assertTrue(candidate["read_source_resolved"])
        self.assertTrue(candidate["write_target_resolved"])
        self.assertEqual(candidate["source_span"], {"start": 1, "end": 4})
        self.assertEqual(candidate["candidate_family"], "kv_anchor:ab:exact_prompt_span")
        self.assertEqual(candidate["provenance_class"], "misc_prompt")

    def test_worker_runtime_readout_escape_source_bridge_uses_exact_prompt_span_mean(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p ab c")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["ab", "c"],
            "entity_recall_terms": ["ab", "c"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.2,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 1,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "ab",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "alignment": 0.34,
                        "argmax_pos": 2,
                        "argmax_relative_index": -4,
                        "argmax_piece": "a",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 2, "relative_index": -4, "segment_kind": "prompt", "piece": "a", "alignment": 0.34}
                        ],
                        "coverage_progress": 0.0,
                    }
                ],
            },
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value={
                "semantic_focus_term": "c",
                "semantic_focus_source": "kv_feature_scan",
                "reachable_focus_term": "ab",
                "reachable_focus_piece": "ab",
                "reachable_focus_rank": 901,
                "target_mass": 0.00012,
                "target_top20_hits": 0,
                "attractor_family_mass": 0.22,
                "attractor_family_top_overlap": 2,
                "attractor_family_overlap_tokens": ["EW", " EW"],
                "top_tokens": ["EW", " EW", "inou"],
            },
        ):
            packet = worker_runtime.build_controller_packet()

        matching = [
            candidate
            for candidate in packet["strategy_hints"]["shot_candidate_edits"]
            if candidate.get("role") == "shot_source_bridge_span_mean"
        ]
        self.assertTrue(matching)
        self.assertEqual(matching[0]["focus_feature"], "ab")
        self.assertEqual(matching[0]["span_kind"], "exact_prompt_span_mean")
        self.assertEqual(matching[0]["phase_objective"], "readout_escape")
        self.assertEqual(matching[0]["source_span"], {"start": 1, "end": 4})
        self.assertEqual(matching[0]["provenance_class"], "misc_prompt")

    def test_worker_runtime_readout_escape_builder_prefers_source_body_and_emits_clean_bundle_inputs(self):
        prompt = (
            "Keep these terms: budget\n"
            "SOURCE: budget update\n"
            "ANSWER:"
        )
        codec = CharacterCodec("Keep these terms: budget\nSOURCE: update\nANSWER:")
        worker_runtime = self._make_worker_runtime(codec=codec)
        worker_runtime.reset(prompt)
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["budget"],
            "entity_recall_terms": ["budget"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.2,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 2,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "budget",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "alignment": 0.34,
                        "argmax_pos": 18,
                        "argmax_relative_index": -18,
                        "argmax_piece": "b",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 18, "relative_index": -18, "segment_kind": "prompt", "piece": "b", "alignment": 0.34}
                        ],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "budget",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "surface_id": "s_v_cache_l3_h1_last_promoted",
                        "alignment": 0.36,
                        "argmax_pos": 18,
                        "argmax_relative_index": -18,
                        "argmax_piece": "b",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 18, "relative_index": -18, "segment_kind": "prompt", "piece": "b", "alignment": 0.36}
                        ],
                        "coverage_progress": 0.0,
                    },
                ],
            },
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value={
                "semantic_focus_term": "budget",
                "semantic_focus_source": "kv_feature_scan",
                "reachable_focus_term": "budget",
                "reachable_focus_piece": "budget",
                "reachable_focus_rank": 901,
                "target_mass": 0.00012,
                "target_top20_hits": 0,
                "attractor_family_mass": 0.22,
                "attractor_family_top_overlap": 2,
                "attractor_family_overlap_tokens": ["EW", " EW"],
                "top_tokens": ["EW", " EW", "inou"],
            },
        ):
            packet = worker_runtime.build_controller_packet()

        hints = packet["strategy_hints"]
        self.assertEqual(packet["control_phase_hint"], "readout_escape")
        self.assertEqual(hints["candidate_provenance_counts_before_prune"]["constraint_header"], 2)
        self.assertEqual(hints["candidate_provenance_counts_before_prune"]["source_body"], 2)
        self.assertEqual(hints["candidate_provenance_counts_before_prune"]["misc_prompt"], 2)
        self.assertEqual(hints["candidate_provenance_counts_after_prune"], {"source_body": 2})
        self.assertEqual(hints["dominance_prune_drops"], 4)
        self.assertEqual(hints["same_term_family_drops"], 0)
        bundle_inputs = hints["bundle_inputs"]
        self.assertEqual(len(bundle_inputs), 1)
        self.assertEqual(bundle_inputs[0]["term"], "budget")
        self.assertEqual(bundle_inputs[0]["provenance_class"], "source_body")
        kv_candidates = hints["kv_candidate_edits"]
        self.assertEqual(len(kv_candidates), 2)
        self.assertTrue(all(candidate["provenance_class"] == "source_body" for candidate in kv_candidates))
        self.assertTrue(all(candidate.get("bundle_ready", False) for candidate in kv_candidates))
        self.assertEqual({candidate["site"] for candidate in kv_candidates}, {"k_cache", "v_cache"})

    def test_worker_runtime_prune_escape_candidates_preserves_term_specific_bundle_keys_when_surfaces_overlap(self):
        worker_runtime = self._make_worker_runtime()
        candidates = [
            {
                "focus_feature": "send",
                "kind": "kv_mix",
                "site": "k_cache",
                "surface_id": "s_shared_k",
                "provenance_class": "source_body",
                "span_kind": "exact_prompt_span_mean",
                "source_span": {"start": 38, "end": 43},
                "candidate_family": "kv_anchor:send:exact_prompt_span",
                "alignment": 0.31,
            },
            {
                "focus_feature": "send",
                "kind": "kv_mix",
                "site": "v_cache",
                "surface_id": "s_shared_v",
                "provenance_class": "source_body",
                "span_kind": "exact_prompt_span_mean",
                "source_span": {"start": 38, "end": 43},
                "candidate_family": "kv_anchor:send:exact_prompt_span",
                "alignment": 0.32,
            },
            {
                "focus_feature": "budget",
                "kind": "kv_mix",
                "site": "k_cache",
                "surface_id": "s_shared_k",
                "provenance_class": "source_body",
                "span_kind": "exact_prompt_span_mean",
                "source_span": {"start": 43, "end": 50},
                "candidate_family": "kv_anchor:budget:exact_prompt_span",
                "alignment": 0.37,
            },
            {
                "focus_feature": "budget",
                "kind": "kv_mix",
                "site": "v_cache",
                "surface_id": "s_shared_v",
                "provenance_class": "source_body",
                "span_kind": "exact_prompt_span_mean",
                "source_span": {"start": 43, "end": 50},
                "candidate_family": "kv_anchor:budget:exact_prompt_span",
                "alignment": 0.39,
            },
        ]
        debug: dict[str, Any] = {}

        selected = worker_runtime._prune_escape_candidates(candidates, debug=debug)

        self.assertEqual(len(debug["bundle_inputs"]), 2)
        self.assertEqual({bundle["term"] for bundle in debug["bundle_inputs"]}, {"send", "budget"})
        self.assertEqual(
            {candidate["bundle_key"] for candidate in selected},
            {"kv_pair:send:source_body:38:43", "kv_pair:budget:source_body:43:50"},
        )
        self.assertTrue(all(candidate.get("bundle_ready", False) for candidate in selected))

    def test_worker_runtime_readout_escape_builder_expands_hit_budget_for_two_term_frontier(self):
        prompt = (
            "Keep these terms: send, budget\n"
            "SOURCE: send budget now\n"
            "ANSWER:"
        )
        codec = CharacterCodec("Keep these terms: send, budget\nSOURCE: now\nANSWER:")
        worker_runtime = self._make_worker_runtime(codec=codec)
        worker_runtime.reset(prompt)
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["send", "budget"],
            "entity_recall_terms": ["send", "budget"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.2,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 4,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "send",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 2,
                        "head": 0,
                        "token_mode": "last",
                        "surface_id": "s_k_cache_l2_h0_last_promoted",
                        "alignment": 0.31,
                        "argmax_pos": 38,
                        "argmax_relative_index": -38,
                        "argmax_piece": " send",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 38, "relative_index": -38, "segment_kind": "prompt", "piece": " send", "alignment": 0.31}
                        ],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "send",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 2,
                        "head": 1,
                        "token_mode": "last",
                        "surface_id": "s_v_cache_l2_h1_last_promoted",
                        "alignment": 0.32,
                        "argmax_pos": 38,
                        "argmax_relative_index": -38,
                        "argmax_piece": " send",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 38, "relative_index": -38, "segment_kind": "prompt", "piece": " send", "alignment": 0.32}
                        ],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "budget",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 2,
                        "token_mode": "last",
                        "surface_id": "s_k_cache_l3_h2_last_promoted",
                        "alignment": 0.37,
                        "argmax_pos": 43,
                        "argmax_relative_index": -43,
                        "argmax_piece": " budget",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 43, "relative_index": -43, "segment_kind": "prompt", "piece": " budget", "alignment": 0.37}
                        ],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "budget",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 3,
                        "token_mode": "last",
                        "surface_id": "s_v_cache_l3_h3_last_promoted",
                        "alignment": 0.39,
                        "argmax_pos": 43,
                        "argmax_relative_index": -43,
                        "argmax_piece": " budget",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 43, "relative_index": -43, "segment_kind": "prompt", "piece": " budget", "alignment": 0.39}
                        ],
                        "coverage_progress": 0.0,
                    },
                ],
            },
        }

        fake_surface_lookup = {
            ("k_cache", 2, 0, "last"): {"surface_id": "s_k_cache_l2_h0_last_promoted", "max_alpha": 0.06, "step_size": 0.03, "norm_clip": 1.0},
            ("v_cache", 2, 1, "last"): {"surface_id": "s_v_cache_l2_h1_last_promoted", "max_alpha": 0.06, "step_size": 0.04, "norm_clip": 1.0},
            ("k_cache", 3, 2, "last"): {"surface_id": "s_k_cache_l3_h2_last_promoted", "max_alpha": 0.06, "step_size": 0.03, "norm_clip": 1.0},
            ("v_cache", 3, 3, "last"): {"surface_id": "s_v_cache_l3_h3_last_promoted", "max_alpha": 0.06, "step_size": 0.04, "norm_clip": 1.0},
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value={
                "semantic_focus_term": "Mira",
                "semantic_focus_source": "kv_feature_scan",
                "reachable_focus_term": "budget",
                "reachable_focus_piece": " budget",
                "reachable_focus_rank": 768,
                "target_mass": 0.000142,
                "target_top20_hits": 0,
                "attractor_family_mass": 0.300192,
                "attractor_family_top_overlap": 4,
                "attractor_family_overlap_tokens": ["EW", " EW", "inou", " shards"],
                "top_tokens": ["EW", " EW", "inou", " shards", "Lawson"],
            },
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_cache_surface_lookup",
            return_value=fake_surface_lookup,
        ):
            packet = worker_runtime.build_controller_packet()

        hints = packet["strategy_hints"]
        self.assertEqual(packet["control_phase_hint"], "readout_escape")
        self.assertEqual(hints["escape_builder_hit_limit"], 4)
        self.assertEqual(len(hints["bundle_inputs"]), 2)
        self.assertEqual({bundle["term"] for bundle in hints["bundle_inputs"]}, {"send", "budget"})
        kv_candidates = hints["kv_candidate_edits"]
        self.assertEqual(len(kv_candidates), 4)
        self.assertEqual(
            {candidate["bundle_key"] for candidate in kv_candidates},
            {"kv_pair:send:source_body:38:43", "kv_pair:budget:source_body:43:50"},
        )

    def test_heuristic_readout_sidecar_analyzer_prefers_more_reachable_term(self):
        analyzer = build_heuristic_readout_sidecar_analyzer()
        capture = ReadoutSidecarCapture(
            run_id="run",
            episode_id="ep",
            worker_id="os_0",
            step=1,
            control_phase_hint="readout_escape",
            answer_readout_canary={
                "reachable_focus_term": "budget",
                "reachable_focus_rank": 901,
                "target_mass": 0.00012,
                "attractor_family_mass": 0.24,
                "attractor_family_overlap_tokens": ["EW", " EW"],
            },
            answer_sites=(
                ReadoutSidecarSiteCapture(
                    role="answer_boundary_prev",
                    layer=3,
                    token_selector={"mode": "index", "value": -2},
                    vector=torch.tensor([1.0, 0.0, 0.0]),
                ),
                ReadoutSidecarSiteCapture(
                    role="answer_boundary_last",
                    layer=3,
                    token_selector={"mode": "last"},
                    vector=torch.tensor([0.9, 0.1, 0.0]),
                ),
            ),
            source_sites=(
                ReadoutSidecarSiteCapture(
                    role="source_body_exact_span_mean",
                    layer=3,
                    token_selector={"mode": "span", "start": 10, "end": 12, "pool": "mean"},
                    vector=torch.tensor([0.98, 0.02, 0.0]),
                    term="Mira",
                    provenance_class="source_body",
                    span=(10, 12),
                    piece=" Mira",
                ),
                ReadoutSidecarSiteCapture(
                    role="source_body_exact_span_mean",
                    layer=3,
                    token_selector={"mode": "span", "start": 18, "end": 19, "pool": "mean"},
                    vector=torch.tensor([0.25, 0.75, 0.0]),
                    term="budget",
                    provenance_class="source_body",
                    span=(18, 19),
                    piece=" budget",
                ),
            ),
        )

        hints = analyzer(capture)

        self.assertEqual(hints["focus_term_override"], "Mira")
        self.assertEqual(hints["suggested_focus_term"], "Mira")
        self.assertEqual(hints["suggested_bundle_key"], "kv_pair:Mira:source_body:10:12")
        self.assertGreater(hints["candidate_support_terms"]["Mira"], hints["candidate_support_terms"]["budget"])
        self.assertIn("kv_pair:Mira:source_body:10:12", hints["candidate_support_scores"])
        self.assertTrue(hints["attractor_family_present"])

    def test_worker_runtime_readout_sidecar_hints_shift_escape_target_terms(self):
        prompt = (
            "Keep these terms: budget Mira\n"
            "SOURCE: Mira budget\n"
            "ANSWER:"
        )
        codec = CharacterCodec("Keep these terms: budget Mira\nSOURCE: Mira budget\nANSWER:")
        captured: dict[str, Any] = {}

        def fake_sidecar(capture):
            captured["capture"] = capture
            return {
                "analyzer_name": "fake_sidecar",
                "focus_term_override": "Mira",
                "candidate_support_terms": {"Mira": 1.4},
                "term_anchor_strength_by_term": {"Mira": 0.9},
            }

        worker_runtime = self._make_worker_runtime(codec=codec, readout_sidecar_analyzer=fake_sidecar)
        worker_runtime.reset(prompt)
        worker_runtime.step()
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["budget", "Mira"],
            "entity_recall_terms": ["budget", "Mira"],
        }

        actionable_hits = [
            {
                "group": "required_terms",
                "feature": "budget",
                "polarity": "promote",
                "site": "v_cache",
                "layer": 3,
                "head": 1,
                "token_mode": "last",
                "surface_id": "s_v_cache_l3_h1_last_promoted",
                "alignment": 0.33,
                "argmax_pos": 17,
                "argmax_relative_index": -17,
                "argmax_piece": " budget",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 17, "relative_index": -17, "segment_kind": "prompt", "piece": " budget", "alignment": 0.33}
                ],
                "coverage_progress": 0.0,
            },
            {
                "group": "required_terms",
                "feature": "Mira",
                "polarity": "promote",
                "site": "k_cache",
                "layer": 3,
                "head": 0,
                "token_mode": "last",
                "surface_id": "s_k_cache_l3_h0_last_promoted",
                "alignment": 0.31,
                "argmax_pos": 12,
                "argmax_relative_index": -22,
                "argmax_piece": " Mira",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 12, "relative_index": -22, "segment_kind": "prompt", "piece": " Mira", "alignment": 0.31}
                ],
                "coverage_progress": 0.0,
            },
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_actionable_kv_hits",
            return_value=actionable_hits,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value={
                "semantic_focus_term": "budget",
                "semantic_focus_source": "kv_feature_scan",
                "reachable_focus_term": "budget",
                "reachable_focus_piece": " budget",
                "reachable_focus_rank": 901,
                "target_mass": 0.00012,
                "target_top20_hits": 0,
                "attractor_family_mass": 0.22,
                "attractor_family_top_overlap": 2,
                "attractor_family_overlap_tokens": ["EW", " EW"],
                "top_tokens": ["EW", " EW", "inou"],
            },
        ):
            packet = worker_runtime.build_controller_packet()

        self.assertIn("capture", captured)
        capture_summary = packet["worker_view"]["readout_sidecar_capture_summary"]
        self.assertEqual(capture_summary["control_phase_hint"], "readout_escape")
        self.assertGreaterEqual(capture_summary["source_provenance_counts"]["source_body"], 1)
        self.assertEqual(packet["worker_view"]["readout_analyzer_capture_summary"]["control_phase_hint"], "readout_escape")
        hints = packet["strategy_hints"]
        self.assertEqual(hints["readout_sidecar_hints"]["focus_term_override"], "Mira")
        self.assertEqual(hints["readout_sidecar_report"]["suggested_focus_term"], "Mira")
        self.assertEqual(hints["readout_analyzer_report"]["suggested_focus_term"], "Mira")
        self.assertEqual(hints["readout_sidecar_suggested_focus_term"], "Mira")
        self.assertEqual(hints["readout_sidecar_focus_term_override"], "Mira")
        self.assertEqual(hints["readout_analyzer_hints"]["focus_term_override"], "Mira")
        self.assertEqual(hints["readout_analyzer_focus_term_override"], "Mira")
        self.assertEqual(hints["readout_analyzer_suggested_focus_term"], "Mira")
        self.assertEqual(hints["controller_focus_term"], "budget")
        self.assertEqual(hints["controller_focus_source"], "reachable_focus")
        self.assertEqual(hints["escape_builder_target_terms"][0], "budget")
        self.assertEqual(hints["kv_candidate_edits"][0]["focus_feature"], "budget")

    def test_worker_runtime_non_escape_term_order_deprioritizes_sidecar_focus(self):
        prompt = (
            "Keep these terms: budget send Mira\n"
            "SOURCE: budget send Mira\n"
            "ANSWER:"
        )
        codec = CharacterCodec(prompt)
        worker_runtime = self._make_worker_runtime(codec=codec)
        worker_runtime.reset(prompt)
        worker_runtime.step()
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["budget", "send", "Mira"],
            "entity_recall_terms": ["budget", "send", "Mira"],
        }

        ordered_terms = worker_runtime._ordered_missing_terms_for_phase(
            control_phase_hint="entity_insertion",
            answer_readout_canary={
                "semantic_focus_term": "budget",
                "reachable_focus_term": "send",
            },
            readout_sidecar_hints={
                "focus_term_override": "Mira",
                "candidate_support_terms": {"Mira": 1.9, "budget": 0.4, "send": 0.3},
                "term_anchor_strength_by_term": {"Mira": 0.95},
            },
            max_terms=3,
        )

        self.assertEqual(ordered_terms[0], "budget")
        self.assertEqual(ordered_terms[1], "send")
        self.assertEqual(ordered_terms[2], "Mira")

    def test_worker_runtime_post_bundle_rerank_uses_sidecar_support_for_final_selection(self):
        prompt = (
            "Keep these terms: budget send\n"
            "SOURCE: send budget should stay explicit.\n"
            "ANSWER:"
        )
        codec = CharacterCodec(prompt)

        def fake_sidecar(capture):
            support_scores: dict[str, float] = {}
            for site in capture.source_sites:
                if site.term not in {"budget", "send"} or site.provenance_class != "source_body":
                    continue
                if site.span is not None:
                    span_id = f"{int(site.span[0])}:{int(site.span[1])}"
                    span_kind = "exact_prompt_span_mean" if (int(site.span[1]) - int(site.span[0])) > 1 else "exact_prompt_piece"
                else:
                    position = 0 if site.position is None else int(site.position)
                    span_id = f"{position}:{position + 1}"
                    span_kind = "exact_prompt_piece"
                base_score = 1.8 if site.term == "budget" else 0.35
                support_scores[f"kv_pair:{site.term}:source_body:{span_id}"] = base_score
                support_scores[f"{site.term}|source_body|{span_id}|kv_v|{span_kind}"] = base_score - 0.1
                support_scores[f"{site.term}|source_body|{span_id}|kv_k|{span_kind}"] = base_score - 0.2
            return {
                "analyzer_name": "fake_sidecar",
                "focus_term_override": "budget",
                "candidate_support_terms": {"budget": 1.8, "send": 0.35},
                "term_anchor_strength_by_term": {"budget": 0.9, "send": 0.15},
                "bundle_support_scores": {key: value for key, value in support_scores.items() if key.startswith("kv_pair:")},
                "candidate_support_scores": support_scores,
            }

        def _prepare_runtime(readout_sidecar_analyzer):
            worker_runtime = self._make_worker_runtime(codec=codec, readout_sidecar_analyzer=readout_sidecar_analyzer)
            worker_runtime.reset(prompt)
            worker_runtime.step()
            worker_runtime._last_task_feedback = {
                "done": False,
                "progress_label": "stalled",
                "required_term_recall": 0.0,
                "required_term_span_progress": 0.0,
                "missing_required_terms": ["budget", "send"],
                "entity_recall_terms": ["budget", "send"],
            }
            return worker_runtime

        actionable_hits = [
            {
                "group": "required_terms",
                "feature": "budget",
                "polarity": "promote",
                "site": "v_cache",
                "layer": 3,
                "head": 1,
                "token_mode": "last",
                "surface_id": "s_v_cache_l3_h1_last_promoted",
                "alignment": 0.05,
                "argmax_pos": 24,
                "argmax_relative_index": -24,
                "argmax_piece": " budget",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 24, "relative_index": -24, "segment_kind": "prompt", "piece": " budget", "alignment": 0.31}
                ],
                "coverage_progress": 0.0,
            },
            {
                "group": "required_terms",
                "feature": "budget",
                "polarity": "promote",
                "site": "k_cache",
                "layer": 3,
                "head": 0,
                "token_mode": "last",
                "surface_id": "s_k_cache_l3_h0_last_promoted",
                "alignment": 0.04,
                "argmax_pos": 24,
                "argmax_relative_index": -24,
                "argmax_piece": " budget",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 24, "relative_index": -24, "segment_kind": "prompt", "piece": " budget", "alignment": 0.28}
                ],
                "coverage_progress": 0.0,
            },
            {
                "group": "required_terms",
                "feature": "send",
                "polarity": "promote",
                "site": "v_cache",
                "layer": 3,
                "head": 3,
                "token_mode": "last",
                "surface_id": "s_v_cache_l3_h3_last_promoted",
                "alignment": 1.05,
                "argmax_pos": 19,
                "argmax_relative_index": -29,
                "argmax_piece": " send",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 19, "relative_index": -29, "segment_kind": "prompt", "piece": " send", "alignment": 0.44}
                ],
                "coverage_progress": 0.0,
            },
            {
                "group": "required_terms",
                "feature": "send",
                "polarity": "promote",
                "site": "k_cache",
                "layer": 3,
                "head": 2,
                "token_mode": "last",
                "surface_id": "s_k_cache_l3_h2_last_promoted",
                "alignment": 0.95,
                "argmax_pos": 19,
                "argmax_relative_index": -29,
                "argmax_piece": " send",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 19, "relative_index": -29, "segment_kind": "prompt", "piece": " send", "alignment": 0.41}
                ],
                "coverage_progress": 0.0,
            },
        ]
        answer_readout_canary = {
            "semantic_focus_term": "budget",
            "semantic_focus_source": "kv_feature_scan",
            "reachable_focus_term": "budget",
            "reachable_focus_piece": " budget",
            "reachable_focus_rank": 901,
            "target_mass": 0.00012,
            "target_top20_hits": 0,
            "attractor_family_mass": 0.22,
            "attractor_family_top_overlap": 2,
            "attractor_family_overlap_tokens": ["EW", " EW"],
            "top_tokens": ["EW", " EW", "inou"],
        }
        promoted_cache_surfaces = [
            {
                "surface_id": "s_v_cache_l3_h1_last_promoted",
                "target": {"kind": "cache", "worker": "os_0", "site": "v_cache", "layer": 3, "head": 1, "token": {"mode": "last"}},
                "caps": {"max_alpha": 0.08, "max_ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.04},
            },
            {
                "surface_id": "s_k_cache_l3_h0_last_promoted",
                "target": {"kind": "cache", "worker": "os_0", "site": "k_cache", "layer": 3, "head": 0, "token": {"mode": "last"}},
                "caps": {"max_alpha": 0.06, "max_ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.03},
            },
            {
                "surface_id": "s_v_cache_l3_h3_last_promoted",
                "target": {"kind": "cache", "worker": "os_0", "site": "v_cache", "layer": 3, "head": 3, "token": {"mode": "last"}},
                "caps": {"max_alpha": 0.08, "max_ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.04},
            },
            {
                "surface_id": "s_k_cache_l3_h2_last_promoted",
                "target": {"kind": "cache", "worker": "os_0", "site": "k_cache", "layer": 3, "head": 2, "token": {"mode": "last"}},
                "caps": {"max_alpha": 0.06, "max_ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.03},
            },
        ]

        worker_runtime_off = _prepare_runtime(None)
        worker_runtime_on = _prepare_runtime(fake_sidecar)
        worker_runtime_on._operator_bridge_plan_table = {
            "kv_pair:budget:source_body:24:25": {
                "objective_bundle_key": "kv_pair:budget:source_body:24:25",
                "objective_term": "budget",
                "actuator_bundle_key": "kv_pair:send:source_body:19:20",
                "actuator_term": "send",
                "operator_recipe_id": "readout_escape|kv_pair_source_anchor|source_body|exact_term_token|none",
                "actuator_class": "cross_bound",
                "bridge_required": True,
                "bridge_plan_reason": "no_certified_self_actuator_target_lift_owned_by_other_bundle",
            }
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_actionable_kv_hits",
            return_value=actionable_hits,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_promoted_cache_surfaces",
            return_value=promoted_cache_surfaces,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value=answer_readout_canary,
        ):
            packet_off = worker_runtime_off.build_controller_packet()
            packet_on = worker_runtime_on.build_controller_packet()

        hints_off = packet_off["strategy_hints"]
        hints_on = packet_on["strategy_hints"]
        self.assertEqual(hints_off["controller_focus_term"], "budget")
        self.assertEqual(hints_off["kv_candidate_edits"][0]["focus_feature"], "send")
        self.assertFalse(hints_off["bundle_reorder_applied"])
        self.assertEqual(hints_on["controller_focus_term"], "budget")
        self.assertEqual(hints_on["controller_focus_source"], "reachable_focus")
        self.assertEqual(hints_on["readout_analyzer_suggested_focus_term"], "budget")
        self.assertEqual(hints_on["selected_bundle_key"].split(":")[1], "budget")
        self.assertEqual(hints_on["kv_candidate_edits"][0]["focus_feature"], "budget")
        self.assertEqual(hints_on["bundle_selector_phase"], "readout_escape")
        self.assertTrue(hints_on["bundle_rerank_gate_open"])
        self.assertEqual(hints_on["bundle_rerank_gate_reasons"], [])
        self.assertTrue(hints_on["gate_report_open"])
        self.assertEqual(hints_on["gate_report_reasons"], [])
        self.assertEqual(hints_on["gate_report_frontier_bundle_key"].split(":")[1], "budget")
        self.assertEqual(hints_on["gate_report_selection_source"], "sidecar_tiebreak")
        self.assertTrue(hints_on["bridge_plan_available"])
        self.assertTrue(hints_on["bridge_plan_required"])
        self.assertEqual(hints_on["bridge_plan_objective_term"], "budget")
        self.assertEqual(hints_on["bridge_plan_actuator_term"], "send")
        self.assertEqual(hints_on["bridge_plan_actuator_class"], "cross_bound")
        self.assertGreater(hints_on["bundle_base_gap"], 0.0)
        self.assertGreater(hints_on["bundle_rerank_gap"], 0.0)
        self.assertEqual(hints_on["bundle_score_debug"][0]["focus_term"], "budget")
        self.assertTrue(hints_on["bundle_score_debug"][0]["bundle_support_confident"])
        self.assertTrue(hints_on["bundle_score_debug"][0]["bundle_evidence_agreement"])
        self.assertTrue(hints_on["bundle_score_debug"][0]["bundle_is_actionable_candidate"])
        self.assertGreater(hints_on["hard_margin"], 0.0)
        self.assertGreater(hints_on["pairwise_delta"], 0.0)
        self.assertEqual(
            hints_on["bundle_score_debug"][0]["pairwise_margin_breakdown_vs_base"]["actionable_adv"],
            1.0,
        )

    def test_worker_runtime_post_bundle_rerank_blocks_sidecar_when_bundle_is_not_actionable(self):
        prompt = (
            "Keep these terms: budget send\n"
            "SOURCE: send budget should stay explicit.\n"
            "ANSWER:"
        )
        codec = CharacterCodec(prompt)

        def fake_sidecar(capture):
            support_scores: dict[str, float] = {}
            for site in capture.source_sites:
                if site.term not in {"budget", "send"} or site.provenance_class != "source_body":
                    continue
                if site.span is not None:
                    span_id = f"{int(site.span[0])}:{int(site.span[1])}"
                    span_kind = "exact_prompt_span_mean" if (int(site.span[1]) - int(site.span[0])) > 1 else "exact_prompt_piece"
                else:
                    position = 0 if site.position is None else int(site.position)
                    span_id = f"{position}:{position + 1}"
                    span_kind = "exact_prompt_piece"
                base_score = 1.6 if site.term == "budget" else 0.35
                support_scores[f"kv_pair:{site.term}:source_body:{span_id}"] = base_score
                support_scores[f"{site.term}|source_body|{span_id}|kv_v|{span_kind}"] = base_score - 0.1
                support_scores[f"{site.term}|source_body|{span_id}|kv_k|{span_kind}"] = base_score - 0.2
            return {
                "analyzer_name": "fake_sidecar",
                "candidate_support_terms": {"budget": 1.6, "send": 0.35},
                "bundle_support_scores": {key: value for key, value in support_scores.items() if key.startswith("kv_pair:")},
                "candidate_support_scores": support_scores,
            }

        worker_runtime = self._make_worker_runtime(codec=codec, readout_sidecar_analyzer=fake_sidecar)
        worker_runtime.reset(prompt)
        worker_runtime.step()
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["budget", "send"],
            "entity_recall_terms": ["budget", "send"],
        }

        actionable_hits = [
            {
                "group": "required_terms",
                "feature": "budget",
                "polarity": "promote",
                "site": "v_cache",
                "layer": 3,
                "head": 1,
                "token_mode": "last",
                "surface_id": "s_v_cache_l3_h1_last_promoted",
                "alignment": 0.31,
                "argmax_pos": 24,
                "argmax_relative_index": -24,
                "argmax_piece": " budget",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 24, "relative_index": -24, "segment_kind": "prompt", "piece": " budget", "alignment": 0.31}
                ],
                "coverage_progress": 0.0,
                "recent_probe": {"label": "harmful"},
            },
            {
                "group": "required_terms",
                "feature": "budget",
                "polarity": "promote",
                "site": "k_cache",
                "layer": 3,
                "head": 0,
                "token_mode": "last",
                "surface_id": "s_k_cache_l3_h0_last_promoted",
                "alignment": 0.28,
                "argmax_pos": 24,
                "argmax_relative_index": -24,
                "argmax_piece": " budget",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 24, "relative_index": -24, "segment_kind": "prompt", "piece": " budget", "alignment": 0.28}
                ],
                "coverage_progress": 0.0,
                "recent_probe": {"label": "harmful"},
            },
            {
                "group": "required_terms",
                "feature": "send",
                "polarity": "promote",
                "site": "v_cache",
                "layer": 3,
                "head": 3,
                "token_mode": "last",
                "surface_id": "s_v_cache_l3_h3_last_promoted",
                "alignment": 0.44,
                "argmax_pos": 19,
                "argmax_relative_index": -29,
                "argmax_piece": " send",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 19, "relative_index": -29, "segment_kind": "prompt", "piece": " send", "alignment": 0.44}
                ],
                "coverage_progress": 0.0,
            },
            {
                "group": "required_terms",
                "feature": "send",
                "polarity": "promote",
                "site": "k_cache",
                "layer": 3,
                "head": 2,
                "token_mode": "last",
                "surface_id": "s_k_cache_l3_h2_last_promoted",
                "alignment": 0.41,
                "argmax_pos": 19,
                "argmax_relative_index": -29,
                "argmax_piece": " send",
                "argmax_segment_kind": "prompt",
                "source_positions": [
                    {"position": 19, "relative_index": -29, "segment_kind": "prompt", "piece": " send", "alignment": 0.41}
                ],
                "coverage_progress": 0.0,
            },
        ]
        answer_readout_canary = {
            "semantic_focus_term": "budget",
            "semantic_focus_source": "kv_feature_scan",
            "reachable_focus_term": "send",
            "reachable_focus_piece": " send",
            "reachable_focus_rank": 901,
            "target_mass": 0.00012,
            "target_top20_hits": 0,
            "attractor_family_mass": 0.22,
            "attractor_family_top_overlap": 2,
            "attractor_family_overlap_tokens": ["EW", " EW"],
            "top_tokens": ["EW", " EW", "inou"],
        }
        promoted_cache_surfaces = [
            {
                "surface_id": "s_v_cache_l3_h1_last_promoted",
                "target": {"kind": "cache", "worker": "os_0", "site": "v_cache", "layer": 3, "head": 1, "token": {"mode": "last"}},
                "caps": {"max_alpha": 0.08, "max_ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.04},
            },
            {
                "surface_id": "s_k_cache_l3_h0_last_promoted",
                "target": {"kind": "cache", "worker": "os_0", "site": "k_cache", "layer": 3, "head": 0, "token": {"mode": "last"}},
                "caps": {"max_alpha": 0.06, "max_ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.03},
            },
            {
                "surface_id": "s_v_cache_l3_h3_last_promoted",
                "target": {"kind": "cache", "worker": "os_0", "site": "v_cache", "layer": 3, "head": 3, "token": {"mode": "last"}},
                "caps": {"max_alpha": 0.08, "max_ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.04},
            },
            {
                "surface_id": "s_k_cache_l3_h2_last_promoted",
                "target": {"kind": "cache", "worker": "os_0", "site": "k_cache", "layer": 3, "head": 2, "token": {"mode": "last"}},
                "caps": {"max_alpha": 0.06, "max_ttl_steps": 1, "norm_clip": 1.0, "step_size": 0.03},
            },
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_actionable_kv_hits",
            return_value=actionable_hits,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_promoted_cache_surfaces",
            return_value=promoted_cache_surfaces,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value=answer_readout_canary,
        ):
            packet = worker_runtime.build_controller_packet()

        hints = packet["strategy_hints"]
        self.assertFalse(hints["bundle_rerank_gate_open"])
        self.assertIn("no_eligible_challenger", hints["bundle_rerank_gate_reasons"])
        self.assertEqual(hints["selected_bundle_key"].split(":")[1], "send")
        self.assertFalse(hints["gate_report_open"])
        self.assertIn("no_eligible_challenger", hints["gate_report_reasons"])
        self.assertEqual(hints["gate_report_frontier_bundle_key"].split(":")[1], "send")
        self.assertEqual(hints["kv_candidate_edits"][0]["focus_feature"], "send")
        budget_debug = next(item for item in hints["bundle_score_debug"] if item["focus_term"] == "budget")
        self.assertFalse(budget_debug["bundle_is_actionable_candidate"])
        self.assertIn("recent_harmful_family", budget_debug["rerank_vetoes"])

    def test_worker_runtime_shot_candidate_edits_readout_escape_prefers_anchored_candidates(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")

        anchored_candidate = {
            "surface_id": "s_resid_pre_l3_last",
            "kind": "resid_add",
            "role": "shot_source_bridge_last",
            "focus_feature": "budget",
            "candidate_family": "resid_bridge:budget:exact_prompt_span",
            "phase_objective": "readout_escape",
            "span_kind": "exact_prompt_span_mean",
            "provenance_class": "source_body",
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_source_bridge_shot_candidate_edits",
            return_value=[anchored_candidate],
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_recent_probe_outcomes_by_candidate_key",
            return_value={},
        ):
            selected = worker_runtime._shot_candidate_edits(control_phase_hint="readout_escape")

        self.assertEqual(len(selected), 1)
        self.assertEqual(selected[0]["role"], "shot_source_bridge_last")

    def test_worker_runtime_shot_mode_prefers_source_bridge_candidate(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="logit_bias_entity_soft")
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["ab"],
            "entity_recall_terms": ["ab"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.3,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 1,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "ab",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "alignment": 0.34,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.34}
                        ],
                        "coverage_progress": 0.0,
                    }
                ],
            },
        }
        worker_runtime._recent_effects = [
            {
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "hypothesis": "loop_break_small_rescue",
                "verdict": "neutral",
                "signal_profile": "stabilizing_only",
                "delta": {
                    "required_term_recall": 0.0,
                    "required_term_span_progress": 0.0,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                    "repeat_flag": -1.0,
                    "no_progress_steps": -1.0,
                },
            }
        ]

        packet = worker_runtime.build_controller_packet()

        candidate = packet["strategy_hints"]["shot_candidate_edits"][0]
        self.assertEqual(candidate["surface_id"], "s_resid_pre_l3_prev")
        self.assertEqual(candidate["role"], "shot_source_bridge_prev")
        self.assertEqual(candidate["source_position"], 0)
        self.assertEqual(candidate["source"]["expr"]["arg"]["arg"]["arg"]["ref"]["token"]["value"], 0)

    def test_worker_runtime_packet_exposes_retryable_weak_positive_kv_candidate(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="logit_bias_entity_soft")
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["ab"],
            "entity_recall_terms": ["ab"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.3,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 1,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "ab",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "alignment": 0.34,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "a",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "a", "alignment": 0.34}
                        ],
                        "coverage_progress": 0.0,
                    }
                ],
            },
        }
        worker_runtime._recent_effects = [
            {
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "hypothesis": "loop_break_small_rescue",
                "verdict": "neutral",
                "signal_profile": "stabilizing_only",
                "delta": {
                    "required_term_recall": 0.0,
                    "required_term_span_progress": 0.0,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                    "repeat_flag": -1.0,
                    "no_progress_steps": -1.0,
                },
            }
        ]
        worker_runtime._tool_results = [
            {
                "tool": "dry_run_decode",
                "status": "ok",
                "candidate_edit": {
                    "surface_id": "s_k_cache_l3_h0_last_promoted",
                    "kind": "kv_mix",
                    "site": "k_cache",
                },
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "repeat_flag_delta": 0,
                "target_mass_delta": 0.00002,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 5,
                "rank_focus_delta": 5,
                "topk_token_diff": [{"piece": "a", "prob_delta": 0.00002, "logit_delta": 0.0003}],
            }
        ]

        def _annotate(items):
            annotated = []
            for item in items:
                candidate = dict(item)
                if str(candidate.get("retry_stage", "") or "") == "weak_positive_retry":
                    candidate["canary_checked"] = True
                    candidate["canary_pass"] = True
                    candidate["canary_reason"] = "target_rank_improved"
                else:
                    candidate["canary_checked"] = True
                    candidate["canary_pass"] = False
                    candidate["canary_reason"] = "focus_token_flat"
                annotated.append(candidate)
            return annotated

        with patch.object(HookedTransformerWorkerRuntime, "_annotate_kv_candidates_with_canary", side_effect=_annotate):
            packet = worker_runtime.build_controller_packet()

        self.assertEqual(packet["control_phase_hint"], "shot_mode")
        self.assertTrue(packet["strategy_hints"]["kv_retry_needed"])
        self.assertEqual(packet["strategy_hints"]["preferred_kv_retry_surface_id"], "s_k_cache_l3_h0_last_promoted")
        self.assertEqual(packet["strategy_hints"]["preferred_kv_surface_id"], "s_k_cache_l3_h0_last_promoted")
        self.assertEqual(packet["strategy_hints"]["kv_retry_candidate_edits"][0]["retry_stage"], "weak_positive_retry")
        self.assertGreater(packet["strategy_hints"]["kv_retry_candidate_edits"][0]["op"]["alpha"], 0.03)
        self.assertEqual(packet["strategy_hints"]["kv_retry_candidate_edits"][0]["canary_reason"], "target_rank_improved")

    def test_worker_runtime_kv_candidates_pick_up_recent_probe_from_raw_scan(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["ab"],
            "entity_recall_terms": ["ab"],
        }
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.3,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 1,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "ab",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "alignment": 0.34,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.34}
                        ],
                        "coverage_progress": 0.0,
                    }
                ],
            },
        }
        worker_runtime._tool_results = [
            {
                "tool": "dry_run_decode",
                "status": "ok",
                "candidate_edit": {
                    "surface_id": "s_k_cache_l3_h0_last_promoted",
                    "kind": "kv_mix",
                    "site": "k_cache",
                },
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "repeat_flag_delta": 0,
                "target_mass_delta": 0.00002,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 5,
                "rank_focus_delta": 5,
                "focus_logit_delta": 0.0008,
                "focus_prob_delta": 0.00002,
                "topk_token_diff": [{"piece": "a", "prob_delta": 0.00002, "logit_delta": 0.0003}],
            }
        ]

        packet = worker_runtime.build_controller_packet()

        matching = [
            candidate
            for candidate in packet["strategy_hints"]["kv_candidate_edits"]
            if candidate["surface_id"] == "s_k_cache_l3_h0_last_promoted"
        ]
        self.assertEqual(matching[0]["recent_probe"]["label"], "weak_positive_subthreshold")

    def test_worker_runtime_strategy_hints_flag_readout_escape_for_collapsed_probe_family(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["ab"],
            "entity_recall_terms": ["ab"],
        }
        worker_runtime._recent_effects = [
            {
                "edit_id": "e_loop_rescue",
                "surface_id": "s_resid_pre_l3_last",
                "op": "resid_add",
                "hypothesis": "loop_break_small_rescue",
                "verdict": "neutral",
                "signal_profile": "stabilizing_only",
                "delta": {
                    "required_term_recall": 0.0,
                    "required_term_span_progress": 0.0,
                    "partial_score": 0.0,
                    "semantic_progress_score": 0.0,
                    "repeat_flag": -1.0,
                    "no_progress_steps": -1.0,
                },
            }
        ]
        worker_runtime._latest_observer_check = {
            "check_type": "semantic_progress",
            "trigger": "coverage_progress",
            "score": 0.2,
            "verdict": "flat",
            "kv_feature_scan": {
                "projection_mode": "attn_weight_head_projection",
                "surface_count": 2,
                "group_count": 1,
                "top_feature_hits": [
                    {
                        "group": "required_terms",
                        "feature": "ab",
                        "polarity": "promote",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "token_mode": "last",
                        "surface_id": "s_v_cache_l3_h1_last_promoted",
                        "alignment": 0.34,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.34}
                        ],
                        "coverage_progress": 0.0,
                    },
                    {
                        "group": "required_terms",
                        "feature": "ab",
                        "polarity": "promote",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "token_mode": "last",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "alignment": 0.33,
                        "argmax_pos": 0,
                        "argmax_relative_index": -1,
                        "argmax_piece": "p",
                        "argmax_segment_kind": "prompt",
                        "source_positions": [
                            {"position": 0, "relative_index": -1, "segment_kind": "prompt", "piece": "p", "alignment": 0.33}
                        ],
                        "coverage_progress": 0.0,
                    },
                ],
            },
        }
        worker_runtime._tool_results = [
            {
                "tool": "dry_run_decode",
                "status": "ok",
                "candidate_edit": {
                    "surface_id": "s_v_cache_l3_h1_last_promoted",
                    "kind": "kv_mix",
                    "site": "v_cache",
                    "focus_feature": "ab",
                },
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "repeat_flag_delta": 0,
                "target_mass_delta": 0.00002,
                "target_mass_edited": 0.00021,
                "target_top20_hit_delta": 0,
                "target_top20_hits_edited": 0,
                "focus_rank_delta": 8,
                "focus_rank_edited": 620,
                "rank_focus_delta": 10,
                "rank_focus_rank_edited": 512,
                "focus_logit_delta": 0.0007,
                "focus_prob_delta": 0.00002,
                "sampled_continuations": [{"variant": "candidate", "text": " shards shard"}],
                "topk_token_diff": [{"piece": "shards", "prob_delta": 0.00002, "logit_delta": 0.0003}],
            },
            {
                "tool": "dry_run_decode",
                "status": "ok",
                "candidate_edit": {
                    "surface_id": "s_k_cache_l3_h0_last_promoted",
                    "kind": "kv_mix",
                    "site": "k_cache",
                    "focus_feature": "ab",
                },
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "repeat_flag_delta": 0,
                "target_mass_delta": 0.00003,
                "target_mass_edited": 0.00024,
                "target_top20_hit_delta": 0,
                "target_top20_hits_edited": 0,
                "focus_rank_delta": 9,
                "focus_rank_edited": 604,
                "rank_focus_delta": 11,
                "rank_focus_rank_edited": 501,
                "focus_logit_delta": 0.0008,
                "focus_prob_delta": 0.00003,
                "sampled_continuations": [{"variant": "candidate", "text": " shards shard"}],
                "topk_token_diff": [{"piece": "shards", "prob_delta": 0.00003, "logit_delta": 0.00035}],
            },
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_current_answer_readout_canary",
            return_value={
                "semantic_focus_term": "ab",
                "semantic_focus_source": "kv_feature_scan",
                "reachable_focus_term": "ab",
                "reachable_focus_piece": " ab",
                "reachable_focus_rank": 804,
                "target_mass": 0.0003,
                "target_top20_hits": 0,
                "attractor_family_mass": 0.0042,
                "attractor_family_top_overlap": 3,
                "top_tokens": ["EW", "inou", "shards"],
            },
        ):
            packet = worker_runtime.build_controller_packet()

        hints = packet["strategy_hints"]
        self.assertEqual(packet["control_phase_hint"], "shot_mode")
        self.assertTrue(hints["readout_escape_needed"])
        self.assertEqual(hints["readout_escape_reason"], "collapsed_decode_basin")
        self.assertTrue(hints["kv_effect_family_collapsed"])
        self.assertEqual(hints["kv_effect_family_count"], 1)
        self.assertEqual(hints["semantic_focus_term"], "ab")
        self.assertEqual(hints["reachable_focus_term"], "ab")
        self.assertEqual(hints["reachable_focus_rank"], 804)
        self.assertEqual(hints["controller_focus_term"], "ab")
        self.assertEqual(hints["controller_focus_source"], "reachable_focus")
        self.assertIn("candidate_family_count", hints["readout_escape_block_reason"])

    def test_worker_runtime_dry_run_decode_tool_compares_small_candidate_edit(self):
        def task_feedback_fn(output):
            has_c = "c" in output
            span = 1.0 if has_c else 0.0
            return {
                "done": has_c,
                "partial_score": 1.0 if has_c else 0.0,
                "progress_label": "progressing" if has_c else "stalled",
                "required_term_recall": 1.0 if has_c else 0.0,
                "required_term_span_progress_by_term": {"c": span},
                "required_term_span_progress": span,
                "constraint_violations": [] if has_c else ["missing_required_terms"],
                "forbidden_term_clean": 1.0,
                "word_budget_score": 1.0,
                "missing_required_terms": [] if has_c else ["c"],
            }

        def observer_check_fn(output, *, task_feedback=None, trigger="runtime", worker_runtime=None):
            return {
                "check_type": "semantic_progress",
                "trigger": trigger,
                "score": 0.8 if "c" in output else 0.1,
                "raw_score": 0.8 if "c" in output else 0.1,
                "coverage_weight": 1.0,
            }

        worker_runtime = self._make_worker_runtime(
            task_feedback_fn=task_feedback_fn,
            observer_check_fn=observer_check_fn,
        )
        worker_runtime.reset("p")

        before = worker_runtime.final_text()
        results = worker_runtime.request_controller_tools(
            [
                {
                    "tool": "dry_run_decode",
                    "candidate_edit": {
                        "surface_id": "s_resid_l11_last",
                        "kind": "resid_add",
                        "alpha": 0.04,
                        "ttl_steps": 1,
                        "step_size": 0.04,
                    },
                    "max_new_tokens": 2,
                }
            ],
            source="controller",
        )

        self.assertEqual(results[0]["tool"], "dry_run_decode")
        self.assertEqual(results[0]["status"], "ok")
        self.assertGreater(results[0]["required_term_recall_delta"], 0.0)
        self.assertGreater(results[0]["semantic_progress_delta"], 0.0)
        self.assertEqual(results[0]["probe_family"], "resid_add")
        self.assertEqual(results[0]["probe_phase_profile"], "composition")
        self.assertIn("constraint", results[0]["positive_axes"])
        self.assertIsInstance(results[0]["probe_summary"], dict)
        self.assertEqual(worker_runtime.final_text(), before)

    def test_worker_runtime_replay_candidate_edits_actual_delta_uses_pair_override(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime._last_task_feedback = {
            "done": False,
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.0,
            "missing_required_terms": ["c"],
            "entity_recall_terms": ["c"],
        }
        baseline = {
            "continuation": "bb",
            "first_logits": torch.tensor([0.0, 8.0, 0.0], dtype=torch.float32),
            "entropy": 0.1,
            "repeat_flag": False,
            "scoring": {
                "required_term_recall": 0.0,
                "required_term_span_progress": 0.0,
                "semantic_progress_score": 0.0,
            },
        }
        edited = {
            "continuation": "cc",
            "first_logits": torch.tensor([0.0, 0.0, 8.0], dtype=torch.float32),
            "entropy": 0.2,
            "repeat_flag": False,
            "scoring": {
                "required_term_recall": 1.0,
                "required_term_span_progress": 1.0,
                "semantic_progress_score": 0.5,
            },
        }
        candidate_a = {
            "surface_id": "s_resid_l11_last",
            "kind": "resid_add",
            "phase_objective": "composition",
            "provenance_class": "source_body",
            "span_kind": "exact_prompt_span_mean",
            "focus_feature": "c",
        }
        candidate_b = {
            "surface_id": "s_resid_pre_l3_prev",
            "kind": "resid_add",
            "phase_objective": "composition",
            "provenance_class": "source_body",
            "span_kind": "exact_prompt_span_mean",
            "focus_feature": "c",
        }
        with patch.object(
            HookedTransformerWorkerRuntime,
            "_simulate_decode",
            side_effect=[baseline, edited],
        ) as simulate_mock, patch.object(
            HookedTransformerWorkerRuntime,
            "_classify_probe_result",
            return_value=None,
        ):
            result = worker_runtime.replay_candidate_edits_actual_delta(
                [candidate_a, candidate_b],
                max_new_tokens=2,
                top_k=3,
                max_edits_per_step_override=2,
                label="pair:test",
            )

        self.assertEqual(result["status"], "ok")
        self.assertEqual(result["actual_delta_class"], "required_term_progress")
        policy_override = simulate_mock.call_args_list[1].kwargs["policy_override"]
        self.assertEqual(policy_override.global_budget.max_edits_per_step, 2)
        self.assertFalse(simulate_mock.call_args_list[0].kwargs["score_observer_check"])
        self.assertFalse(simulate_mock.call_args_list[1].kwargs["score_observer_check"])
        self.assertTrue(result["observer_check_skipped"])
        self.assertEqual(result["operator_family_key"], "composition|resid_add|source_body|exact_prompt_span_mean")
        self.assertEqual(result["candidate_fingerprint"]["recipe_name"], "pair")
        self.assertEqual(result["eval_context_fingerprint"]["decode_step"], 0)
        self.assertEqual(result["eval_context_fingerprint"]["max_edits_per_step"], 2)

    def test_target_piece_binding_is_frozen_before_edited_rank_movement(self):
        codec = CharacterCodec("pab ")
        worker_runtime = self._make_worker_runtime(codec=codec)
        worker_runtime.reset("p")
        baseline_logits = torch.tensor([0.0, -2.0, -3.0, 2.0], dtype=torch.float32)
        edited_logits = torch.tensor([0.0, 6.0, 5.0, 2.0], dtype=torch.float32)
        sequences = [
            _TargetTokenSequence(term="a", token_ids=(1,), variant="a"),
            _TargetTokenSequence(term="a", token_ids=(3, 1), variant=" a"),
            _TargetTokenSequence(term="b", token_ids=(2,), variant="b"),
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_target_token_sequences",
            return_value=sequences,
        ):
            metrics = worker_runtime._first_token_target_readout_metrics(
                baseline_logits,
                edited_logits,
                focus_terms=("a", "b"),
                preferred_term="A",
            )

        self.assertEqual(metrics["target_piece_token_id"], 3)
        self.assertEqual(metrics["target_piece"], " ")
        self.assertEqual(metrics["post_edit_best_token_id"], 1)
        self.assertFalse(metrics["post_edit_matches_binding"])
        self.assertFalse(metrics["target_piece_binding_report"]["post_edit_matches_binding"])
        self.assertEqual(
            metrics["target_piece_binding_report"]["binding_selection_time"],
            "pre_edit",
        )
        self.assertEqual(metrics["target_piece_binding_report"]["objective_term"], "a")
        baseline_probs = torch.softmax(baseline_logits, dim=-1)
        edited_probs = torch.softmax(edited_logits, dim=-1)
        expected_mass_delta = float(
            edited_probs[[1, 3]].sum().item() - baseline_probs[[1, 3]].sum().item()
        )
        self.assertAlmostEqual(metrics["target_mass_delta"], round(expected_mass_delta, 6))

    def test_target_piece_binding_rejects_fully_masked_objective_pieces(self):
        codec = CharacterCodec("pab ")
        worker_runtime = self._make_worker_runtime(codec=codec)
        worker_runtime.reset("p")
        baseline_logits = torch.tensor(
            [0.0, float("-inf"), float("-inf"), 2.0],
            dtype=torch.float32,
        )

        with patch.object(
            HookedTransformerWorkerRuntime,
            "_target_token_sequences",
            return_value=[
                _TargetTokenSequence(term="a", token_ids=(1,), variant="a"),
                _TargetTokenSequence(term="a", token_ids=(2,), variant=" a"),
            ],
        ):
            binding = worker_runtime._resolve_target_piece_binding(
                baseline_logits,
                focus_terms=("a",),
                preferred_term="a",
            )

        self.assertIsNone(binding)

    def test_diagnostic_evidence_identity_preserves_binding_seed_axes(self):
        base_row = {
            "bundle_key": "entity_insert:mira:source_body:weak_reachable",
            "operator_recipe_id": "activation_patch_seed",
            "recipe_name": "activation_patch_seed",
            "diagnostic_family": "activation_patch",
            "evidence_kind": "activation_patch_certification",
            "operator_axis": "activation_patch_candidate_review",
        }
        matrix_row = {
            **base_row,
            "evidence_kind": "target_piece_binding_replay",
            "operator_axis": "target_piece_binding_seed_matrix",
            "target_piece_binding_seed_matrix_id": "tpbsm:test",
            "target_piece_binding_id": "tpb:canonical",
            "target_piece_binding_variant": "canonical",
            "activation_patch_seed_source": "direct_candidate",
        }
        alternate_row = {
            **matrix_row,
            "target_piece_binding_id": "tpb:alternate",
            "target_piece_binding_variant": "alternate",
        }

        base_identity = (
            HookedTransformerWorkerRuntime._diagnostic_evidence_row_identity(base_row)
        )
        matrix_identity = (
            HookedTransformerWorkerRuntime._diagnostic_evidence_row_identity(matrix_row)
        )
        alternate_identity = (
            HookedTransformerWorkerRuntime._diagnostic_evidence_row_identity(alternate_row)
        )

        self.assertNotEqual(base_identity, matrix_identity)
        self.assertNotEqual(matrix_identity, alternate_identity)

    def test_activation_patch_target_piece_binding_seed_matrix_factorizes_axes(self):
        codec = CharacterCodec("pab ")
        worker_runtime = self._make_worker_runtime(codec=codec)
        worker_runtime.reset("p")
        objective_key = "entity_insert:a:source_body:near_reachable"
        baseline_logits = torch.tensor([0.0, -2.0, -3.0, 2.0], dtype=torch.float32)
        seed_rows = [
            {
                "objective_bundle_key": objective_key,
                "intended_term": "a",
                "diagnostic_family": "activation_patch",
                "operator_axis": "activation_patch_blueprint_materialization",
                "recipe_family": "activation_patch|resid_pre|source_term_token",
                "recipe_name": "direct_seed",
                "operator_recipe_id": "direct_seed_id",
                "activation_patch_site": "resid_pre",
                "activation_patch_layer": 3,
                "activation_patch_alpha": 0.05,
                "activation_patch_step_size": 0.05,
                "activation_patch_source_localization": "source_term_token",
                "activation_patch_seed_source": "direct_candidate",
                "status": "supportive",
                "actual_delta_class": "rank_carrier",
                "focus_rank_delta": 2,
            },
            {
                "objective_bundle_key": objective_key,
                "intended_term": "a",
                "diagnostic_family": "activation_patch",
                "operator_axis": "activation_patch_local_step_size_sweep",
                "recipe_family": "activation_patch|resid_pre|source_term_token",
                "recipe_name": "observed_seed",
                "operator_recipe_id": "observed_seed_id",
                "activation_patch_site": "resid_pre",
                "activation_patch_layer": 3,
                "activation_patch_alpha": 0.05,
                "activation_patch_step_size": 0.08,
                "activation_patch_source_localization": "source_term_token",
                "activation_patch_seed_source": "observed_gap_carrier",
                "status": "supportive",
                "actual_delta_class": "rank_carrier",
                "target_top20_threshold_gap_delta": -0.002,
                "focus_rank_delta": 4,
            },
        ]

        def fake_materialize(candidate, *, trial_contract):
            return {
                "target": {"surface_id": "s_resid_pre_l3_last"},
                "source": {"dtype": "vector", "expr": {"fn": "cache"}},
                "op": {"kind": "activation_patch", "alpha": candidate["alpha"], "mode": "blend"},
                "budget": {"ttl_steps": 1, "step_size": candidate["step_size"], "revertible": True},
                "operator_recipe_id": candidate["operator_recipe_id"],
            }

        def fake_replay(_candidate_edits, **kwargs):
            binding = dict(kwargs["target_piece_binding"])
            label = str(kwargs.get("label") or "")
            observed = "observed_gap_carrier" in label
            canonical = label.endswith(":canonical")
            logit_delta = (
                0.4 if observed and canonical else 0.8 if observed else 0.1 if canonical else 0.2
            )
            target_token_id = int(binding["chosen_target_token_id"])
            return {
                "status": "ok",
                "actual_delta_class": "rank_carrier",
                "target_piece_binding_id": binding["binding_id"],
                "target_piece_binding_manifest": binding,
                "target_piece_binding_report": {
                    **binding,
                    "post_edit_matches_binding": canonical,
                },
                "target_piece": codec.decode([target_token_id]),
                "target_piece_token_id": target_token_id,
                "target_piece_logit_delta": logit_delta,
                "target_piece_prob_delta": logit_delta / 100.0,
                "target_rank_delta": int(logit_delta * 10),
                "target_rank_after": 100 - int(logit_delta * 10),
                "target_mass_delta": 0.000002 if observed else 0.000001,
                "target_top20_hit_delta": 0,
                "target_top20_threshold_gap_delta": -logit_delta,
                "post_edit_best_piece": "a" if canonical else codec.decode([target_token_id]),
                "post_edit_best_token_id": 1 if canonical else target_token_id,
                "focus_rank_delta": int(logit_delta * 10),
                "repeat_flag_delta": 0,
                "repetition_score_delta": 0.0,
            }

        with patch.object(
            worker_runtime,
            "_simulate_decode",
            return_value={"first_logits": baseline_logits},
        ), patch.object(
            worker_runtime,
            "_target_token_sequences",
            return_value=[
                _TargetTokenSequence(term="a", token_ids=(1,), variant="a"),
                _TargetTokenSequence(term="a", token_ids=(3, 1), variant=" a"),
            ],
        ), patch.object(
            worker_runtime,
            "_activation_patch_trial_edit_from_candidate",
            side_effect=fake_materialize,
        ), patch.object(
            worker_runtime,
            "replay_candidate_edits_actual_delta",
            side_effect=fake_replay,
        ):
            report = worker_runtime._activation_patch_target_piece_binding_seed_matrix(
                seed_rows,
                objective_bundle_key=objective_key,
                objective_term="a",
            )

        self.assertEqual(report["status"], "factorized_2x2_complete")
        self.assertEqual(report["row_count"], 4)
        self.assertEqual(report["seed_sources"], ["direct_candidate", "observed_gap_carrier"])
        self.assertEqual(
            {row["target_piece_binding_variant"] for row in report["rows"]},
            {"canonical", "alternate"},
        )
        self.assertEqual(len({row["target_piece_binding_id"] for row in report["rows"]}), 2)
        self.assertTrue(str(report["target_piece_binding_seed_matrix_id"]).startswith("tpbsm:"))
        self.assertEqual(
            {row["target_piece_binding_seed_matrix_id"] for row in report["rows"]},
            {report["target_piece_binding_seed_matrix_id"]},
        )
        self.assertTrue(all(row["diagnostic_only"] for row in report["rows"]))
        self.assertTrue(all(not row["production_apply_allowed"] for row in report["rows"]))
        logit_effect = report["effect_metrics"]["target_piece_logit_delta"]
        self.assertAlmostEqual(logit_effect["alternate_minus_canonical"], 0.25)
        self.assertAlmostEqual(logit_effect["binding_x_seed_interaction"], 0.3)
        self.assertTrue(report["term_mass_is_binding_invariant_by_definition"])

    def test_worker_runtime_classify_actual_delta_result_marks_collapse_isomorphic(self):
        worker_runtime = self._make_worker_runtime()

        outcome = worker_runtime._classify_actual_delta_result(
            {
                "continuation_baseline": "bb",
                "continuation_candidate": "cc",
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "repeat_flag_delta": 0,
                "target_mass_delta": -0.972144,
                "target_top20_hit_delta": -1,
                "focus_rank_delta": 0,
                "rank_focus_delta": 0,
            }
        )

        self.assertEqual(outcome, "collapse_isomorphic")

    def test_worker_runtime_classify_actual_delta_result_marks_collapse_sharpener(self):
        worker_runtime = self._make_worker_runtime()

        outcome = worker_runtime._classify_actual_delta_result(
            {
                "continuation_baseline": "bb",
                "continuation_candidate": "the the",
                "required_term_recall_delta": 0.0,
                "required_term_span_progress_delta": 0.0,
                "semantic_progress_delta": 0.0,
                "repeat_flag_delta": 1,
                "entropy_delta": -0.07489,
                "top1_margin_delta": 0.0089,
                "repetition_score_delta": 1.0,
                "target_mass_delta": 0.0,
                "target_top20_hit_delta": 0,
                "focus_rank_delta": 0,
                "rank_focus_delta": 0,
            }
        )

        self.assertEqual(outcome, "collapse_sharpener")

    def test_worker_runtime_replay_operator_certification_populates_packet_hints(self):
        worker_runtime = self._make_worker_runtime()
        packet = {
            "strategy_hints": {
                "kv_candidate_edits": [
                    {
                        "bundle_key": "kv_pair:send:source_body:10:12",
                        "surface_id": "s_v_cache_l3_h1_last_promoted",
                        "site": "v_cache",
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                    },
                    {
                        "bundle_key": "kv_pair:send:source_body:10:12",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "site": "k_cache",
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                    },
                    {
                        "bundle_key": "kv_pair:budget:source_body:12:14",
                        "surface_id": "s_v_cache_l3_h3_last_promoted",
                        "site": "v_cache",
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                    },
                    {
                        "bundle_key": "kv_pair:budget:source_body:12:14",
                        "surface_id": "s_k_cache_l3_h2_last_promoted",
                        "site": "k_cache",
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                    },
                ],
                "base_winner_bundle_key": "kv_pair:send:source_body:10:12",
                "challenger_bundle_key": "kv_pair:budget:source_body:12:14",
                "selected_bundle_key": "kv_pair:send:source_body:10:12",
                "selection_source": "base_shadow",
            }
        }
        family_key = "readout_escape|kv_pair_source_anchor|source_body|exact_prompt_span_mean"
        replay_results = [
            {"status": "ok", "label": "single:send:v", "operator_family_key": family_key, "actual_delta_class": "dead_actuator"},
            {"status": "ok", "label": "single:send:k", "operator_family_key": family_key, "actual_delta_class": "collapse_isomorphic"},
            {"status": "ok", "label": "pair:send", "operator_family_key": family_key, "actual_delta_class": "collapse_isomorphic"},
            {"status": "ok", "label": "single:budget:v", "operator_family_key": family_key, "actual_delta_class": "target_lift"},
            {"status": "ok", "label": "single:budget:k", "operator_family_key": family_key, "actual_delta_class": "target_lift"},
            {"status": "ok", "label": "pair:budget", "operator_family_key": family_key, "actual_delta_class": "neutral"},
        ]

        with patch.object(
            HookedTransformerWorkerRuntime,
            "build_controller_packet",
            return_value=packet,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "replay_candidate_edits_actual_delta",
            side_effect=replay_results,
        ):
            summary = worker_runtime.replay_operator_certification()

        self.assertEqual(summary["operator_certifications"][0]["certification_status"], "apply_eligible")
        self.assertTrue(summary["operator_certifications"][0]["certified_for_apply"])

        worker_runtime.reset("p")
        worker_runtime.step()
        live_packet = worker_runtime.build_controller_packet()
        hints = live_packet["strategy_hints"]
        self.assertEqual(hints["operator_certification_count"], 1)
        self.assertEqual(hints["operator_certification_families"][0]["operator_family_key"], family_key)

    def test_worker_runtime_materialize_recipe_candidate_builds_contrastive_window_recipe(self):
        worker_runtime = self._make_worker_runtime()
        token_records = [
            {"position": 0, "segment_kind": "prompt", "piece": " send", "provenance_class": "source_body"},
            {"position": 1, "segment_kind": "prompt", "piece": " budget", "provenance_class": "source_body"},
            {"position": 2, "segment_kind": "prompt", "piece": " Omar", "provenance_class": "source_body"},
        ]
        candidate = {
            "surface_id": "s_v_cache_l3_h1_last_promoted",
            "kind": "kv_mix",
            "site": "v_cache",
            "layer": 3,
            "head": 1,
            "phase_objective": "readout_escape",
            "bundle_family": "kv_pair_source_anchor",
            "provenance_class": "source_body",
            "span_kind": "exact_prompt_span_mean",
            "source_span": {"start": 1, "end": 2},
            "source_position": 1,
            "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
            "source": {"dtype": "cache_pair", "v": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "v_cache", "layer": 3, "head": 1, "token": {"mode": "span", "start": 1, "end": 2, "pool": "mean"}}}},
        }
        competitor = {
            **candidate,
            "source_span": {"start": 0, "end": 1},
            "source_position": 0,
        }

        with patch.object(HookedTransformerWorkerRuntime, "_token_position_records", return_value=token_records):
            recipe = worker_runtime._materialize_recipe_candidate(
                candidate,
                localization="exact_term_window_pm1_weighted",
                pooling="weighted_mean",
                contrast_mode="minus_base",
                competitor_candidate=competitor,
            )

        self.assertIsNotNone(recipe)
        assert recipe is not None
        self.assertEqual(recipe["recipe_localization"], "exact_term_window_pm1_weighted")
        self.assertEqual(recipe["recipe_pooling"], "weighted_mean")
        self.assertEqual(recipe["contrast_mode"], "minus_base")
        self.assertIn("exact_term_window_pm1_weighted|weighted_mean|minus_base", recipe["operator_recipe_id"])
        self.assertEqual(recipe["source"]["v"]["fn"], "sub")

        def _max_arg_count(expr):
            if not isinstance(expr, Mapping):
                return 0
            count = len(expr.get("args", [])) if isinstance(expr.get("args"), list) else 0
            nested = [_max_arg_count(item) for item in expr.get("args", []) if isinstance(expr.get("args"), list)]
            for key in ("arg", "left", "right", "basis"):
                if isinstance(expr.get(key), Mapping):
                    nested.append(_max_arg_count(expr[key]))
            return max([count, *nested], default=count)

        self.assertLessEqual(_max_arg_count(recipe["source"]["v"]), HarnessPolicy.default_v0().max_expr_args)

    def test_worker_runtime_materialize_recipe_candidate_builds_minus_stealer_window_recipe(self):
        worker_runtime = self._make_worker_runtime()
        token_records = [
            {"position": 0, "segment_kind": "prompt", "piece": " send", "provenance_class": "source_body"},
            {"position": 1, "segment_kind": "prompt", "piece": " now", "provenance_class": "source_body"},
            {"position": 2, "segment_kind": "prompt", "piece": " budget", "provenance_class": "source_body"},
            {"position": 3, "segment_kind": "prompt", "piece": " draft", "provenance_class": "source_body"},
        ]
        candidate = {
            "surface_id": "s_v_cache_l3_h1_last_promoted",
            "bundle_key": "kv_pair:budget:source_body:2:4",
            "focus_feature": "budget",
            "site": "v_cache",
            "layer": 3,
            "head": 1,
            "phase_objective": "readout_escape",
            "bundle_family": "kv_pair_source_anchor",
            "provenance_class": "source_body",
            "span_kind": "exact_prompt_span_mean",
            "source_span": {"start": 2, "end": 4},
            "source_position": 2,
            "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
            "source": {"dtype": "cache_pair", "v": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "v_cache", "layer": 3, "head": 1, "token": {"mode": "span", "start": 2, "end": 4, "pool": "mean"}}}},
        }
        competitor = {
            **candidate,
            "bundle_key": "kv_pair:send:source_body:0:2",
            "focus_feature": "send",
            "source_span": {"start": 0, "end": 2},
            "source_position": 0,
        }

        with patch.object(HookedTransformerWorkerRuntime, "_token_position_records", return_value=token_records):
            recipe = worker_runtime._materialize_recipe_candidate(
                candidate,
                localization="exact_term_window_pm1_weighted",
                pooling="weighted_mean",
                contrast_mode="minus_stealer",
                competitor_candidate=competitor,
                contrast_scale=0.5,
            )

        self.assertIsNotNone(recipe)
        assert recipe is not None
        self.assertEqual(recipe["contrast_mode"], "minus_stealer")
        self.assertAlmostEqual(recipe["recipe_contrast_scale"], 0.5)
        self.assertIn("minus_stealer@", recipe["operator_recipe_id"])
        self.assertEqual(recipe["source"]["v"]["fn"], "sub")
        self.assertEqual(recipe["source"]["v"]["args"][1]["fn"], "scale")
        self.assertAlmostEqual(float(recipe["source"]["v"]["args"][1]["by"]), 0.5)

    def test_worker_runtime_summarize_operator_recipe_bundle_ownership_classifies_cross_bound(self):
        worker_runtime = self._make_worker_runtime()

        ownership = worker_runtime._summarize_operator_recipe_bundle_ownership(
            [
                {
                    "operator_recipe_id": "readout_escape|kv_pair_source_anchor|source_body|loc|pool|none|k0.0300|v0.0400",
                    "operator_recipe_seed_key": "kv_pair|loc|pool",
                    "intended_bundle_key": "kv_pair:budget:source_body:12:14",
                    "term_readout_deltas": {
                        "budget": {"lift_score": 0.01},
                        "send": {"lift_score": 0.08},
                    },
                    "label": "budget_primary",
                    "status": "ok",
                    "actual_delta_class": "target_lift",
                }
            ],
            bundle_term_by_key={
                "kv_pair:budget:source_body:12:14": "budget",
                "kv_pair:send:source_body:10:12": "send",
            },
        )

        self.assertEqual(len(ownership), 1)
        self.assertEqual(ownership[0]["realized_lift_bundle_key"], "kv_pair:send:source_body:10:12")
        self.assertEqual(ownership[0]["actuator_class"], "cross_bound")
        self.assertEqual(ownership[0]["bridge_plan_bundle_key"], "kv_pair:send:source_body:10:12")
        self.assertEqual(ownership[0]["operator_recipe_seed_key"], "kv_pair|loc|pool")

    def test_worker_runtime_summarize_bridge_plan_recommendations_prefers_cross_bound_without_self(self):
        worker_runtime = self._make_worker_runtime()

        recommendations = worker_runtime._summarize_bridge_plan_recommendations(
            [
                {
                    "intended_bundle_key": "kv_pair:send:source_body:10:12",
                    "intended_term": "send",
                    "realized_lift_bundle_key": "kv_pair:budget:source_body:12:14",
                    "realized_lift_term": "budget",
                    "bridge_plan_bundle_key": "kv_pair:budget:source_body:12:14",
                    "operator_recipe_id": "recipe_a",
                    "operator_recipe_seed_key": "seed_a",
                    "actuator_class": "cross_bound",
                    "self_delta": 0.01,
                    "cross_delta": 0.022,
                    "alignment_margin": -0.012,
                    "bundle_lift_scores": {
                        "kv_pair:send:source_body:10:12": 0.01,
                        "kv_pair:budget:source_body:12:14": 0.022,
                    },
                },
                {
                    "intended_bundle_key": "kv_pair:send:source_body:10:12",
                    "intended_term": "send",
                    "realized_lift_bundle_key": "kv_pair:budget:source_body:12:14",
                    "realized_lift_term": "budget",
                    "bridge_plan_bundle_key": "kv_pair:budget:source_body:12:14",
                    "operator_recipe_id": "recipe_b",
                    "operator_recipe_seed_key": "seed_b",
                    "actuator_class": "bridge_actuator",
                    "self_delta": 0.0,
                    "cross_delta": 0.03,
                    "alignment_margin": -0.03,
                    "bundle_lift_scores": {
                        "kv_pair:send:source_body:10:12": 0.0,
                        "kv_pair:budget:source_body:12:14": 0.03,
                    },
                },
                {
                    "intended_bundle_key": "kv_pair:send:source_body:10:12",
                    "intended_term": "send",
                    "realized_lift_bundle_key": "kv_pair:send:source_body:10:12",
                    "realized_lift_term": "send",
                    "operator_recipe_id": "recipe_send",
                    "operator_recipe_seed_key": "seed_send",
                    "actuator_class": "self_actuator",
                    "self_delta": 0.08,
                    "cross_delta": 0.0,
                    "alignment_margin": 0.08,
                    "bundle_lift_scores": {
                        "kv_pair:budget:source_body:12:14": 0.0,
                        "kv_pair:send:source_body:10:12": 0.08,
                    },
                },
            ]
        )

        self.assertEqual(len(recommendations), 1)
        self.assertEqual(recommendations[0]["objective_bundle_key"], "kv_pair:budget:source_body:12:14")
        self.assertEqual(recommendations[0]["actuator_bundle_key"], "kv_pair:send:source_body:10:12")
        self.assertEqual(recommendations[0]["actuator_class"], "cross_bound")
        self.assertTrue(recommendations[0]["bridge_required"])
        self.assertEqual(recommendations[0]["objective_lift_delta"], 0.022)
        self.assertEqual(
            recommendations[0]["bridge_plan_reason"],
            "no_certified_self_actuator_target_lift_owned_by_other_bundle",
        )

    def test_worker_runtime_replay_operator_recipe_matrix_summarizes_recipe_certifications(self):
        worker_runtime = self._make_worker_runtime()
        token_records = [
            {"position": 10, "segment_kind": "prompt", "piece": " send", "provenance_class": "source_body"},
            {"position": 11, "segment_kind": "prompt", "piece": " now", "provenance_class": "source_body"},
            {"position": 12, "segment_kind": "prompt", "piece": " budget", "provenance_class": "source_body"},
            {"position": 13, "segment_kind": "prompt", "piece": " draft", "provenance_class": "source_body"},
            {"position": 14, "segment_kind": "prompt", "piece": " Omar", "provenance_class": "source_body"},
        ]
        packet = {
            "strategy_hints": {
                "kv_candidate_edits": [
                    {
                        "bundle_key": "kv_pair:send:source_body:10:12",
                        "surface_id": "s_v_cache_l3_h1_last_promoted",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 10, "end": 12},
                        "source_position": 10,
                        "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
                        "source": {"dtype": "cache_pair", "v": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "v_cache", "layer": 3, "head": 1, "token": {"mode": "span", "start": 10, "end": 12, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:send:source_body:10:12",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 10, "end": 12},
                        "source_position": 10,
                        "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
                        "source": {"dtype": "cache_pair", "k": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "k_cache", "layer": 3, "head": 0, "token": {"mode": "span", "start": 10, "end": 12, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:budget:source_body:12:14",
                        "surface_id": "s_v_cache_l3_h3_last_promoted",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 3,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 12, "end": 14},
                        "source_position": 12,
                        "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
                        "source": {"dtype": "cache_pair", "v": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "v_cache", "layer": 3, "head": 3, "token": {"mode": "span", "start": 12, "end": 14, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:budget:source_body:12:14",
                        "surface_id": "s_k_cache_l3_h2_last_promoted",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 2,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 12, "end": 14},
                        "source_position": 12,
                        "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
                        "source": {"dtype": "cache_pair", "k": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "k_cache", "layer": 3, "head": 2, "token": {"mode": "span", "start": 12, "end": 14, "pool": "mean"}}}},
                    },
                ],
                "base_winner_bundle_key": "kv_pair:send:source_body:10:12",
                "challenger_bundle_key": "kv_pair:budget:source_body:12:14",
                "selected_bundle_key": "kv_pair:send:source_body:10:12",
                "selection_source": "base_shadow",
            }
        }

        def _fake_actual_delta(candidate_edits, *, label=None, **_kwargs):
            assert label is not None
            if "term_window_pm1_weighted_minus_base:pair:kv_pair:budget:source_body:12:14" in label:
                return {"status": "ok", "label": label, "actual_delta_class": "target_lift"}
            return {"status": "ok", "label": label, "actual_delta_class": "collapse_isomorphic"}

        with patch.object(
            HookedTransformerWorkerRuntime,
            "build_controller_packet",
            return_value=packet,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_token_position_records",
            return_value=token_records,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "replay_candidate_edits_actual_delta",
            side_effect=_fake_actual_delta,
        ):
            summary = worker_runtime.replay_operator_recipe_matrix()

        matching = [
            item for item in summary["operator_recipe_certifications"]
            if "exact_term_window_pm1_weighted|weighted_mean|minus_base" in str(item.get("operator_recipe_id", ""))
            and "kv_pair_source_anchor" in str(item.get("operator_recipe_id", ""))
        ]
        self.assertTrue(matching)
        self.assertEqual(matching[0]["certification_status"], "apply_eligible")

    def test_worker_runtime_replay_operator_recipe_matrix_marks_replay_error_certification(self):
        worker_runtime = self._make_worker_runtime()
        token_records = [
            {"position": 10, "segment_kind": "prompt", "piece": " send", "provenance_class": "source_body"},
            {"position": 11, "segment_kind": "prompt", "piece": " now", "provenance_class": "source_body"},
            {"position": 12, "segment_kind": "prompt", "piece": " budget", "provenance_class": "source_body"},
        ]
        packet = {
            "strategy_hints": {
                "kv_candidate_edits": [
                    {
                        "bundle_key": "kv_pair:send:source_body:10:12",
                        "surface_id": "s_v_cache_l3_h1_last_promoted",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 10, "end": 12},
                        "source_position": 10,
                        "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
                        "source": {"dtype": "cache_pair", "v": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "v_cache", "layer": 3, "head": 1, "token": {"mode": "span", "start": 10, "end": 12, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:send:source_body:10:12",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 10, "end": 12},
                        "source_position": 10,
                        "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
                        "source": {"dtype": "cache_pair", "k": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "k_cache", "layer": 3, "head": 0, "token": {"mode": "span", "start": 10, "end": 12, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:budget:source_body:12:13",
                        "surface_id": "s_v_cache_l3_h3_last_promoted",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 3,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 12, "end": 13},
                        "source_position": 12,
                        "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
                        "source": {"dtype": "cache_pair", "v": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "v_cache", "layer": 3, "head": 3, "token": {"mode": "span", "start": 12, "end": 13, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:budget:source_body:12:13",
                        "surface_id": "s_k_cache_l3_h2_last_promoted",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 2,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 12, "end": 13},
                        "source_position": 12,
                        "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
                        "source": {"dtype": "cache_pair", "k": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "k_cache", "layer": 3, "head": 2, "token": {"mode": "span", "start": 12, "end": 13, "pool": "mean"}}}},
                    },
                ],
                "base_winner_bundle_key": "kv_pair:send:source_body:10:12",
                "challenger_bundle_key": "kv_pair:budget:source_body:12:13",
                "selected_bundle_key": "kv_pair:send:source_body:10:12",
                "selection_source": "base_shadow",
            }
        }

        with patch.object(
            HookedTransformerWorkerRuntime,
            "build_controller_packet",
            return_value=packet,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_token_position_records",
            return_value=token_records,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "replay_candidate_edits_actual_delta",
            side_effect=lambda *_args, label=None, **_kwargs: {
                "status": "error",
                "label": label,
                "error": "simulate_decode_failed",
            },
        ):
            summary = worker_runtime.replay_operator_recipe_matrix(
                recipe_specs=[
                    {
                        "recipe_name": "term_window_pm1_weighted_minus_base",
                        "localization": "exact_term_window_pm1_weighted",
                        "pooling": "weighted_mean",
                        "contrast_mode": "minus_base",
                        "modes": ("kv_pair",),
                    }
                ]
            )

        self.assertEqual(len(summary["operator_recipe_certifications"]), 1)
        certification = summary["operator_recipe_certifications"][0]
        self.assertEqual(certification["certification_status"], "shadow_only")
        self.assertEqual(certification["certification_reason"], "replay_error")
        self.assertEqual(certification["actual_delta_class_counts"]["error"], 1)

    def test_worker_runtime_replay_operator_recipe_matrix_uses_inferred_stealer_bundle(self):
        worker_runtime = self._make_worker_runtime()
        token_records = [
            {"position": 10, "segment_kind": "prompt", "piece": " send", "provenance_class": "source_body"},
            {"position": 11, "segment_kind": "prompt", "piece": " now", "provenance_class": "source_body"},
            {"position": 12, "segment_kind": "prompt", "piece": " budget", "provenance_class": "source_body"},
            {"position": 13, "segment_kind": "prompt", "piece": " draft", "provenance_class": "source_body"},
        ]
        packet = {
            "strategy_hints": {
                "kv_candidate_edits": [
                    {
                        "bundle_key": "kv_pair:send:source_body:10:12",
                        "surface_id": "s_v_cache_l3_h1_last_promoted",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 1,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 10, "end": 12},
                        "source_position": 10,
                        "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
                        "source": {"dtype": "cache_pair", "v": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "v_cache", "layer": 3, "head": 1, "token": {"mode": "span", "start": 10, "end": 12, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:send:source_body:10:12",
                        "surface_id": "s_k_cache_l3_h0_last_promoted",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 0,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 10, "end": 12},
                        "source_position": 10,
                        "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
                        "source": {"dtype": "cache_pair", "k": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "k_cache", "layer": 3, "head": 0, "token": {"mode": "span", "start": 10, "end": 12, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:budget:source_body:12:14",
                        "surface_id": "s_v_cache_l3_h3_last_promoted",
                        "site": "v_cache",
                        "layer": 3,
                        "head": 3,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 12, "end": 14},
                        "source_position": 12,
                        "op": {"kind": "kv_mix", "alpha": 0.04, "which": "v"},
                        "source": {"dtype": "cache_pair", "v": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "v_cache", "layer": 3, "head": 3, "token": {"mode": "span", "start": 12, "end": 14, "pool": "mean"}}}},
                    },
                    {
                        "bundle_key": "kv_pair:budget:source_body:12:14",
                        "surface_id": "s_k_cache_l3_h2_last_promoted",
                        "site": "k_cache",
                        "layer": 3,
                        "head": 2,
                        "phase_objective": "readout_escape",
                        "bundle_family": "kv_pair_source_anchor",
                        "provenance_class": "source_body",
                        "span_kind": "exact_prompt_span_mean",
                        "source_span": {"start": 12, "end": 14},
                        "source_position": 12,
                        "op": {"kind": "kv_mix", "alpha": 0.03, "which": "k"},
                        "source": {"dtype": "cache_pair", "k": {"ref": {"scope": "runtime", "worker": "os_0", "tensor": "k_cache", "layer": 3, "head": 2, "token": {"mode": "span", "start": 12, "end": 14, "pool": "mean"}}}},
                    },
                ],
                "base_winner_bundle_key": "kv_pair:send:source_body:10:12",
                "challenger_bundle_key": "kv_pair:budget:source_body:12:14",
                "selected_bundle_key": "kv_pair:budget:source_body:12:14",
                "selection_source": "controller_apply",
            }
        }
        seen_stealer_partner = {"value": None}

        def _fake_actual_delta(candidate_edits, *, label=None, **kwargs):
            assert label is not None
            base_result = {
                "status": "ok",
                "label": label,
                "intended_bundle_key": kwargs.get("intended_bundle_key"),
                "intended_term": kwargs.get("intended_term"),
                "contrast_partner_bundle_key": kwargs.get("contrast_partner_bundle_key"),
                "contrast_partner_term": kwargs.get("contrast_partner_term"),
            }
            if "baseline_span_mean:pair:kv_pair:budget:source_body:12:14" in label:
                return {
                    **base_result,
                    "actual_delta_class": "target_lift",
                    "term_readout_deltas": {
                        "budget": {"lift_score": 0.01},
                        "send": {"lift_score": 0.08},
                    },
                }
            if "baseline_span_mean:pair:kv_pair:send:source_body:10:12" in label:
                return {
                    **base_result,
                    "actual_delta_class": "target_lift",
                    "term_readout_deltas": {
                        "budget": {"lift_score": 0.08},
                        "send": {"lift_score": 0.01},
                    },
                }
            if "term_window_pm1_weighted:pair:kv_pair:budget:source_body:12:14" in label:
                return {
                    **base_result,
                    "actual_delta_class": "target_lift",
                    "term_readout_deltas": {
                        "budget": {"lift_score": 0.01},
                        "send": {"lift_score": 0.08},
                    },
                }
            if "term_window_pm1_weighted:pair:kv_pair:send:source_body:10:12" in label:
                return {
                    **base_result,
                    "actual_delta_class": "target_lift",
                    "term_readout_deltas": {
                        "budget": {"lift_score": 0.08},
                        "send": {"lift_score": 0.01},
                    },
                }
            if "term_window_pm1_weighted_minus_stealer_l050:pair:kv_pair:budget:source_body:12:14" in label:
                seen_stealer_partner["value"] = kwargs.get("contrast_partner_bundle_key")
                return {**base_result, "actual_delta_class": "neutral"}
            return {**base_result, "actual_delta_class": "neutral"}

        with patch.object(
            HookedTransformerWorkerRuntime,
            "build_controller_packet",
            return_value=packet,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "_token_position_records",
            return_value=token_records,
        ), patch.object(
            HookedTransformerWorkerRuntime,
            "replay_candidate_edits_actual_delta",
            side_effect=_fake_actual_delta,
        ):
            summary = worker_runtime.replay_operator_recipe_matrix(
                recipe_specs=[
                    {
                        "recipe_name": "baseline_span_mean",
                        "localization": "exact_prompt_span_mean",
                        "pooling": "mean",
                        "contrast_mode": "none",
                        "modes": ("kv_pair",),
                    },
                    {
                        "recipe_name": "term_window_pm1_weighted",
                        "localization": "exact_term_window_pm1_weighted",
                        "pooling": "weighted_mean",
                        "contrast_mode": "none",
                        "modes": ("kv_pair",),
                    },
                    {
                        "recipe_name": "term_window_pm1_weighted_minus_stealer_l050",
                        "localization": "exact_term_window_pm1_weighted",
                        "pooling": "weighted_mean",
                        "contrast_mode": "minus_stealer",
                        "contrast_scale": 0.5,
                        "competitor_strategy": "stealer",
                        "modes": ("kv_pair",),
                    },
                ]
            )

        self.assertEqual(seen_stealer_partner["value"], "kv_pair:send:source_body:10:12")
        self.assertIn(
            "*::kv_pair:budget:source_body:12:14",
            summary["recipe_stealer_bundle_keys"],
        )
        budget_recommendations = [
            item
            for item in summary["bridge_plan_recommendations"]
            if str(item.get("objective_bundle_key", "") or "") == "kv_pair:budget:source_body:12:14"
        ]
        self.assertTrue(budget_recommendations)
        self.assertEqual(budget_recommendations[0]["actuator_bundle_key"], "kv_pair:send:source_body:10:12")
        self.assertEqual(budget_recommendations[0]["actuator_class"], "cross_bound")

    def test_worker_runtime_current_tokens_use_model_device_when_available(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.model = type("FakeModel", (), {"cfg": type("Cfg", (), {"device": "cpu"})()})()
        worker_runtime.reset("p")

        with patch("SpiralInterventionLab.runtime.worker.torch.tensor", return_value=torch.zeros((1, 1), dtype=torch.long)) as tensor_mock:
            worker_runtime._current_token_tensor()

        self.assertEqual(tensor_mock.call_args.kwargs["dtype"], torch.long)
        self.assertEqual(tensor_mock.call_args.kwargs["device"], torch.device("cpu"))

    def test_worker_runtime_snapshot_trace_records_step_aligned_frames(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        for _ in range(3):
            worker_runtime.step()

        trace = worker_runtime.snapshot_trace("paired_baseline")

        self.assertIsInstance(trace, StepAlignedTrace)
        self.assertEqual(trace.step_count, 3)
        self.assertIn("paired_baseline", worker_runtime.runtime_state.trace_sequences)
        self.assertEqual(trace.aligned_frame(1).output_text, "a")
        self.assertEqual(trace.aligned_frame(3).output_text, "aaa")
        self.assertEqual(trace.aligned_cache(1)["resid_pre:11"].shape[1], 1)
        self.assertEqual(trace.aligned_cache(3)["resid_pre:11"].shape[1], 3)

    def test_worker_runtime_recent_effect_summary_tracks_hypothesis(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime.step()

        packet = worker_runtime.build_controller_packet()
        ctx = StepContext(
            packet=parse_observation_packet(packet),
            runtime_state=worker_runtime.runtime_state,
            traces={},
            stats={},
            adapter=worker_runtime.adapter,
        )
        compiled = compile_command(_resid_command(), packet, ctx)
        compiled[0].apply(ctx)

        worker_runtime.observe_recent_effects()
        worker_runtime.step()
        worker_runtime.observe_recent_effects()

        effect_trace = worker_runtime.latest_effect_trace()
        self.assertEqual(effect_trace["completed_effects"][0]["hypothesis"], "rescue")
        self.assertEqual(effect_trace["completed_effects"][0]["expected_effect"], "break_loop")

        packet_after = worker_runtime.build_controller_packet()
        summary = packet_after["recent_effect_summary"]
        self.assertEqual(summary["window_size"], 1)
        self.assertEqual(summary["hypothesis_stats"][0]["hypothesis"], "rescue")
        self.assertEqual(summary["hypothesis_stats"][0]["last_expected_effect"], "break_loop")

    def test_worker_runtime_loop_cycle_detection_marks_alternating_suffix(self):
        worker_runtime = self._make_worker_runtime()
        worker_runtime.reset("p")
        worker_runtime._append_output_token(worker_runtime.runtime_state.base_token)
        worker_runtime._append_output_token(worker_runtime.runtime_state.hint_token)
        worker_runtime._append_output_token(worker_runtime.runtime_state.base_token)
        worker_runtime._append_output_token(worker_runtime.runtime_state.hint_token)

        self.assertEqual(worker_runtime._loop_cycle_length(), 2)
        self.assertTrue(worker_runtime._repeat_flag())

    def test_worker_runtime_loop_aware_decoder_control_breaks_repeated_argmax_loop(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="loop_aware")
        worker_runtime.reset("p")

        for _ in range(3):
            worker_runtime.step()

        self.assertEqual(worker_runtime.final_text(), "aab")
        packet = worker_runtime.build_controller_packet()
        self.assertEqual(packet["telemetry"]["decoder_control_mode"], "loop_aware")
        self.assertTrue(packet["telemetry"]["decoder_rescue_active"])

    def test_worker_runtime_forbidden_phrase_guardrail_blocks_prefix_continuation_when_decoder_off(self):
        class _Episode:
            forbidden_terms = ("ab",)
            max_words = 9

        class _Env:
            current_episode = _Episode()

            def task_feedback(self, _output):
                return {"done": False, "progress_label": "progressing"}

        env = _Env()
        worker_runtime = self._make_worker_runtime(
            task_feedback_fn=env.task_feedback,
            codec=CharacterCodec("pabc!?, "),
        )
        worker_runtime.reset("p")
        worker_runtime._append_output_token(int(worker_runtime.codec.encode("a")[0].item()))

        b_token = int(worker_runtime.codec.encode("b")[0].item())
        c_token = int(worker_runtime.codec.encode("c")[0].item())
        logits = torch.full((worker_runtime.runtime_state.vocab_size,), -5.0, dtype=torch.float32)
        logits[b_token] = 2.0
        logits[c_token] = 1.0

        adjusted, state = worker_runtime._apply_decoder_control(logits)

        self.assertEqual(int(torch.argmax(adjusted).item()), c_token)
        self.assertTrue(state["guardrail_active"])
        self.assertTrue(state["forbidden_phrase_guardrail_active"])
        self.assertEqual(state["forbidden_phrase_blocked_terms"], ["ab"])
        self.assertEqual(state["mode"], "off")

    def test_worker_runtime_word_budget_guardrail_pushes_to_punctuation_when_decoder_off(self):
        class _Episode:
            forbidden_terms = ()
            max_words = 2

        class _Env:
            current_episode = _Episode()

            def task_feedback(self, _output):
                return {"done": False, "progress_label": "progressing"}

        env = _Env()
        worker_runtime = self._make_worker_runtime(task_feedback_fn=env.task_feedback)
        worker_runtime.reset("p")
        for text in ("a", " ", "b"):
            worker_runtime._append_output_token(int(worker_runtime.codec.encode(text)[0].item()))

        c_token = int(worker_runtime.codec.encode("c")[0].item())
        bang_token = int(worker_runtime.codec.encode("!")[0].item())
        comma_token = int(worker_runtime.codec.encode(",")[0].item())
        logits = torch.full((worker_runtime.runtime_state.vocab_size,), -5.0, dtype=torch.float32)
        logits[c_token] = 2.0
        logits[comma_token] = 1.5
        logits[bang_token] = 1.0

        adjusted, state = worker_runtime._apply_decoder_control(logits)

        self.assertEqual(int(torch.argmax(adjusted).item()), bang_token)
        self.assertTrue(state["guardrail_active"])
        self.assertTrue(state["word_budget_guardrail_active"])
        self.assertEqual(state["word_budget_current_words"], 2)
        self.assertEqual(state["word_budget_max_words"], 2)

    def test_worker_runtime_loop_aware_prune_demotes_stalled_top_token(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="loop_aware_prune")
        worker_runtime.reset("p")
        worker_runtime._append_output_token(worker_runtime.runtime_state.base_token)
        worker_runtime._no_progress_steps = 2

        logits = torch.full((worker_runtime.runtime_state.vocab_size,), -5.0, dtype=torch.float32)
        logits[worker_runtime.runtime_state.base_token] = 1.0
        logits[worker_runtime.runtime_state.hint_token] = 2.0
        logits[worker_runtime.runtime_state.edit_token] = 1.8

        adjusted, state = worker_runtime._apply_decoder_control(logits)

        self.assertEqual(int(torch.argmax(adjusted).item()), worker_runtime.runtime_state.edit_token)
        self.assertTrue(state["candidate_prune_active"])
        self.assertEqual(state["track"], "auxiliary")

    def test_worker_runtime_loop_aware_constraint_biases_missing_term_token(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="loop_aware_constraint")
        worker_runtime.reset("p")
        worker_runtime._append_output_token(worker_runtime.runtime_state.base_token)
        worker_runtime._no_progress_steps = 1
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "missing_required_terms": ["b"],
        }

        logits = torch.full((worker_runtime.runtime_state.vocab_size,), -5.0, dtype=torch.float32)
        logits[worker_runtime.runtime_state.base_token] = 1.0
        logits[worker_runtime.runtime_state.hint_token] = 0.2
        logits[worker_runtime.runtime_state.edit_token] = 0.7

        adjusted, state = worker_runtime._apply_decoder_control(logits)

        self.assertEqual(int(torch.argmax(adjusted).item()), worker_runtime.runtime_state.hint_token)
        self.assertEqual(state["constraint_target_terms"], ["b"])
        self.assertGreaterEqual(state["constraint_target_count"], 1)
        self.assertEqual(state["track"], "auxiliary")

    def test_worker_runtime_loop_aware_entity_recall_continues_missing_term_sequence(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="loop_aware_entity_recall")
        worker_runtime.reset("p")
        worker_runtime._append_output_token(worker_runtime.runtime_state.hint_token)
        worker_runtime._no_progress_steps = 2
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "entity_recall_terms": ["bc"],
            "missing_required_terms": ["bc"],
        }

        logits = torch.full((worker_runtime.runtime_state.vocab_size,), -5.0, dtype=torch.float32)
        logits[worker_runtime.runtime_state.base_token] = 0.8
        logits[worker_runtime.runtime_state.hint_token] = 1.7
        logits[worker_runtime.runtime_state.edit_token] = 1.2

        adjusted, state = worker_runtime._apply_decoder_control(logits)

        self.assertEqual(int(torch.argmax(adjusted).item()), worker_runtime.runtime_state.edit_token)
        self.assertTrue(state["entity_prior_active"])
        self.assertEqual(state["entity_prefix_depth"], 1)
        self.assertIn("bc", state["entity_continued_terms"])
        self.assertEqual(state["track"], "auxiliary")

    def test_worker_runtime_logit_bias_entity_soft_biases_missing_entity_tokens(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="logit_bias_entity_soft")
        worker_runtime.reset("p")
        worker_runtime._append_output_token(worker_runtime.runtime_state.base_token)
        worker_runtime._no_progress_steps = 2
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "required_term_span_progress": 0.2,
            "entity_recall_terms": ["b", "c"],
            "missing_required_terms": ["b", "c"],
            "entity_recall_progress_by_term": {"b": 0.7, "c": 0.0},
            "required_term_span_progress_by_term": {"b": 0.7, "c": 0.0},
        }

        logits = torch.full((worker_runtime.runtime_state.vocab_size,), -5.0, dtype=torch.float32)
        logits[worker_runtime.runtime_state.base_token] = 1.0
        logits[worker_runtime.runtime_state.hint_token] = 0.45
        logits[worker_runtime.runtime_state.edit_token] = 0.45

        adjusted, state = worker_runtime._apply_decoder_control(logits)

        self.assertTrue(state["logit_bias_active"])
        self.assertEqual(state["logit_bias_term_count"], 2)
        self.assertEqual(state["logit_bias_focus_term_count"], 2)
        self.assertGreaterEqual(state["logit_bias_token_count"], 2)
        self.assertGreater(float(adjusted[worker_runtime.runtime_state.hint_token].item()), 0.45)
        self.assertGreater(float(adjusted[worker_runtime.runtime_state.edit_token].item()), 0.45)
        self.assertGreater(
            float(adjusted[worker_runtime.runtime_state.edit_token].item()),
            float(adjusted[worker_runtime.runtime_state.hint_token].item()),
        )
        self.assertEqual(state["track"], "auxiliary")

    def test_worker_runtime_logit_bias_entity_soft_prefers_easy_terms_first(self):
        worker_runtime = self._make_worker_runtime(decoder_control_mode="logit_bias_entity_soft")
        worker_runtime.reset("p")
        worker_runtime._last_task_feedback = {
            "done": False,
            "progress_label": "stalled",
            "required_term_recall": 0.0,
            "entity_recall_terms": ["ab", "c"],
            "missing_required_terms": ["ab", "c"],
            "entity_recall_progress_by_term": {"ab": 0.0, "c": 0.0},
            "required_term_span_progress_by_term": {"ab": 0.0, "c": 0.0},
        }
        worker_runtime._tool_results = [
            {
                "tool": "tokenize_terms",
                "soft_logit_bias_ok_terms": ["c"],
                "needs_sequence_support_terms": ["ab"],
            }
        ]

        logits = torch.full((worker_runtime.runtime_state.vocab_size,), -5.0, dtype=torch.float32)
        adjusted, state = worker_runtime._apply_soft_entity_logit_bias(logits)

        self.assertTrue(state["logit_bias_active"])
        self.assertEqual(state["logit_bias_focus_mode"], "easy_terms_first")
        self.assertEqual(state["logit_bias_focus_terms"][0], "c")
        self.assertEqual(state["logit_bias_easy_terms"], ["c"])
        self.assertEqual(state["logit_bias_hard_terms"], ["ab"])
        self.assertGreaterEqual(float(adjusted.max().item()), -5.0)

    def test_worker_runtime_runs_bounded_observer_check_on_coverage_progress(self):
        seen = []

        def task_feedback_fn(output):
            partial = 1.0 if output.endswith("a") else 0.0
            return {
                "done": False,
                "partial_score": partial,
                "progress_label": "progressing" if partial > 0.0 else "stalled",
                "required_term_recall": partial,
                "required_term_span_progress": partial,
            }

        def observer_check_fn(output, *, task_feedback=None, trigger="runtime"):
            seen.append((output, dict(task_feedback or {}), trigger))
            return {
                "check_type": "semantic_progress",
                "trigger": trigger,
                "raw_score": 0.8,
                "coverage_weight": 1.0,
                "score": 0.8,
            }

        worker_runtime = self._make_worker_runtime(
            task_feedback_fn=task_feedback_fn,
            observer_check_fn=observer_check_fn,
        )
        worker_runtime.reset("p")
        worker_runtime.step()

        packet = worker_runtime.build_controller_packet()

        self.assertEqual(len(seen), 1)
        self.assertIn("latest_observer_check", packet)
        self.assertEqual(packet["latest_observer_check"]["trigger"], "coverage_progress")
        self.assertEqual(packet["telemetry"]["observer_check_count"], 1)
        self.assertEqual(packet["telemetry"]["observer_check_budget_left"], 3)
        self.assertEqual(packet["latest_observer_check"]["verdict"], "baseline")
        self.assertEqual(worker_runtime._effect_metrics()["semantic_progress_score"], 0.8)

    def test_worker_runtime_reports_flat_observer_check_delta_on_repeat_trigger(self):
        def observer_check_fn(output, *, task_feedback=None, trigger="runtime"):
            score = 0.62 if output.endswith("b") else 0.60
            return {
                "check_type": "semantic_progress",
                "trigger": trigger,
                "raw_score": score,
                "coverage_weight": 1.0,
                "score": score,
            }

        def task_feedback_fn(output):
            partial = 0.22 if output.endswith("b") else 0.20 if output.endswith("a") else 0.0
            return {
                "done": False,
                "partial_score": partial,
                "progress_label": "progressing" if partial > 0.0 else "stalled",
                "required_term_recall": partial,
            }

        worker_runtime = self._make_worker_runtime(
            task_feedback_fn=task_feedback_fn,
            observer_check_fn=observer_check_fn,
        )
        worker_runtime.reset("p")
        worker_runtime.step()
        worker_runtime._append_output_token(worker_runtime.runtime_state.hint_token)
        worker_runtime.step()

        packet = worker_runtime.build_controller_packet()

        self.assertEqual(packet["recent_observer_checks"][-1]["verdict"], "flat")
        self.assertAlmostEqual(packet["recent_observer_checks"][-1]["delta_vs_last_check"], 0.02)

    def test_probe_frames_use_step_aligned_baseline_trace(self):
        baseline_worker = self._make_worker_runtime()
        baseline_worker.reset("p")
        for _ in range(3):
            baseline_worker.step()
        baseline_trace = baseline_worker.snapshot_trace("paired_baseline")

        worker_runtime = self._make_worker_runtime()
        worker_runtime.runtime_state.put_step_trace("paired_baseline", baseline_trace)
        worker_runtime.reset("p")

        worker_runtime.step()
        packet_step1 = worker_runtime.build_controller_packet()
        probe_step1 = packet_step1["probe_frames"][0]["stats"]["cosine_to_paired_baseline"]

        worker_runtime.step()
        packet_step2 = worker_runtime.build_controller_packet()
        probe_step2 = packet_step2["probe_frames"][0]["stats"]["cosine_to_paired_baseline"]

        self.assertAlmostEqual(probe_step1, 1.0, places=6)
        self.assertAlmostEqual(probe_step2, 1.0, places=6)

    def test_b1_prompt_hints_affect_context_without_polluting_output(self):
        worker_runtime = self._make_worker_runtime()
        controller = _PromptHintController("b")
        logger = InMemoryStructuredLogger()

        result = run_b1(
            _ThreeStepTaskEnv("b"),
            worker_runtime,
            controller,
            logger=logger,
            max_hints_per_run=1,
        )

        self.assertEqual(result.output, "abb")
        self.assertEqual(result.score, 1.0)
        self.assertTrue(any(event["event"] == "prompt_advice" for event in logger.events))
        self.assertTrue(any(event["event"] == "controller_provider_attempt" for event in logger.events))
        self.assertTrue(any(event["event"] == "controller_decision" for event in logger.events))

    def test_c1_runner_uses_activation_only_edit_path(self):
        worker_runtime = self._make_worker_runtime()
        controller = _ResidEditController()

        result = run_c1(_ThreeStepTaskEnv("c"), worker_runtime, controller)

        # TTL=2 covers two generated tokens, not registration plus one token.
        self.assertEqual(result.output, "acc")
        self.assertEqual(result.score, 1.0)

    def test_activation_only_policy_keeps_cache_edits_but_denies_weight_patches(self):
        policy = activation_only_policy()

        self.assertEqual(policy.allow_ops, ("resid_add", "kv_mix"))
        self.assertIn("kv_mix", policy.allow_ops)
        self.assertNotIn("rank1_patch", policy.allow_ops)

    def test_minimal_baseline_suite_runs_b0_b1_c1_and_seeds_paired_trace(self):
        controller = _ResidEditController()
        hint_controller = _PromptHintController("b")
        created_workers = []

        def make_worker():
            worker = self._make_worker_runtime()
            created_workers.append(worker)
            return worker

        suite = run_minimal_baseline_suite(
            _ThreeStepTaskEnv("c"),
            make_worker_runtime=make_worker,
            c1_controller=controller,
            b1_controller=hint_controller,
        )

        self.assertEqual(suite.b0.output, "aaa")
        self.assertEqual(suite.b1.output, "abb")
        self.assertEqual(suite.c1.output, "acc")
        self.assertEqual(suite.b0.score, 0.0)
        self.assertEqual(suite.c1.score, 1.0)
        self.assertEqual(suite.paired_trace_id, "paired_baseline")
        self.assertIn("paired_baseline", created_workers[1].runtime_state.trace_sequences)
        self.assertIn("paired_baseline", created_workers[2].runtime_state.trace_sequences)
        self.assertEqual(created_workers[1].runtime_state.trace_sequences["paired_baseline"].step_count, 3)

    def test_minimal_baseline_suite_releases_completed_workers_but_keeps_trace(self):
        for with_b1 in (False, True):
            with self.subTest(with_b1=with_b1):
                worker_refs = []
                seeded_traces = []

                def make_worker():
                    gc.collect()
                    self.assertTrue(all(ref() is None for ref in worker_refs))
                    worker = self._make_worker_runtime()
                    seeded_traces.append(worker.runtime_state.trace_sequences)
                    worker_refs.append(weakref.ref(worker))
                    return worker

                suite = run_minimal_baseline_suite(
                    _ThreeStepTaskEnv("c"),
                    make_worker_runtime=make_worker,
                    c1_controller=_ResidEditController(),
                    b1_controller=_PromptHintController("b") if with_b1 else None,
                )

                self.assertEqual(suite.b0.output, "aaa")
                self.assertEqual(suite.c1.output, "acc")
                self.assertEqual(suite.c1.score, 1.0)
                self.assertEqual(len(worker_refs), 3 if with_b1 else 2)
                for traces in seeded_traces[1:]:
                    self.assertEqual(traces["paired_baseline"].step_count, 3)


@unittest.skipUnless(HAS_TRANSFORMER_LENS, "transformer_lens is not installed")
class TestHookedTransformerIntegration(unittest.TestCase):
    def _make_model(self):
        cfg = HookedTransformerConfig(
            n_layers=2,
            d_model=32,
            n_heads=4,
            d_head=8,
            d_mlp=64,
            n_ctx=16,
            d_vocab=97,
            act_fn="relu",
            device="cpu",
            seed=0,
        )
        model = HookedTransformer(cfg)
        model.eval()
        return model

    def _runtime_packet(self):
        return {
            "version": "0.1",
            "run_id": "run_tlens",
            "episode_id": "ep_tlens",
            "worker_id": "os_0",
            "step": 1,
            "horizon": {"generated_tokens": 4, "max_generated_tokens": 8, "done": False},
            "task_view": {
                "mode": "redacted",
                "task_id": "toy_tlens",
                "prompt_hash": "sha256:tlens",
                "goal_hint": "toy tlens",
                "constraints": [],
            },
            "worker_view": {"generated_tail": "x", "status": "thinking"},
            "telemetry": {
                "entropy": 1.5,
                "top1_margin": 0.15,
                "repetition_score": 0.0,
                "repeat_flag": False,
                "no_progress_steps": 0,
            },
            "surface_catalog": [
                {
                    "surface_id": "s_resid_l0_last",
                    "target": {
                        "kind": "activation",
                        "worker": "os_0",
                        "site": "resid_pre",
                        "layer": 0,
                        "token": {"mode": "last"},
                    },
                    "allow_ops": ["resid_add"],
                    "caps": {
                        "max_alpha": 0.5,
                        "max_ttl_steps": 3,
                        "norm_clip": 5.0,
                        "revertible_only": True,
                    },
                },
                {
                    "surface_id": "s_weight_l0_attn",
                    "target": {
                        "kind": "weight",
                        "worker": "os_0",
                        "module": "attn_out",
                        "layer": 0,
                    },
                    "allow_ops": ["rank1_patch"],
                    "caps": {
                        "max_alpha": 0.2,
                        "max_ttl_steps": 3,
                        "rank_cap": 1,
                        "revertible_only": True,
                    },
                },
                {
                    "surface_id": "s_weight_l0_mlp",
                    "target": {
                        "kind": "weight",
                        "worker": "os_0",
                        "module": "mlp_out",
                        "layer": 0,
                    },
                    "allow_ops": ["rank1_patch"],
                    "caps": {
                        "max_alpha": 0.2,
                        "max_ttl_steps": 3,
                        "rank_cap": 1,
                        "revertible_only": True,
                    },
                },
            ],
            "probe_frames": [],
            "trace_bank": [
                {
                    "trace_id": "paired_baseline",
                    "origin": "paired_baseline",
                    "compatible": True,
                    "similarity_hint": 1.0,
                    "tags": ["same_seed"],
                }
            ],
            "active_edits": [],
            "recent_effects": [],
            "budget": {
                "edits_left_this_step": 1,
                "edits_left_this_run": 3,
                "alpha_left_total": 0.5,
                "active_patch_slots_left": 1,
                "rollbackable_ids": [],
            },
            "task_feedback": {"done": False, "progress_label": "progressing"},
        }

    def test_hooked_transformer_runtime_resid_add_changes_cached_activation(self):
        model = self._make_model()
        runtime_state = HookedTransformerRuntimeState(model, seed=11)
        adapter = HookedTransformerAdapter(model)
        tokens = torch.tensor([[1, 2, 3, 4]], dtype=torch.long)

        _logits, cache = runtime_state.run_with_cache(tokens, return_type="logits")
        baseline_last = cache["blocks.0.hook_resid_pre"][0, -1].detach().clone()
        runtime_state.snapshot_last_cache("paired_baseline")

        packet = parse_observation_packet(self._runtime_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)

        command = {
            "version": "0.1",
            "decision": "apply",
            "edits": [
                {
                    "id": "e_resid_tlens",
                    "target": {"surface_id": "s_resid_l0_last"},
                    "source": {
                        "dtype": "vector",
                        "expr": {
                            "ref": {
                                "scope": "runtime",
                                "worker": "os_0",
                                "tensor": "resid_pre",
                                "layer": 0,
                                "token": {"mode": "last"},
                            }
                        },
                    },
                    "op": {"kind": "resid_add", "alpha": 0.25},
                    "budget": {"ttl_steps": 2, "norm_clip": 5.0, "revertible": True},
                }
            ],
        }

        permissive_policy = HarnessPolicy(global_budget=GlobalBudget(max_total_alpha=1.0, max_total_edit_cost=1.0))
        compiled = compile_command(command, packet, ctx, policy=permissive_policy)
        compiled[0].apply(ctx)
        self.assertIn("e_resid_tlens", runtime_state.hooks)

        _logits2, edited_cache = runtime_state.run_with_cache(tokens, return_type="logits")
        edited_last = edited_cache["blocks.0.hook_resid_pre"][0, -1].detach()
        expected = baseline_last + (0.25 * baseline_last)
        self.assertTrue(torch.allclose(edited_last, expected, atol=1e-5, rtol=1e-4))

        runtime_state.tick_ttl()
        runtime_state.tick_ttl()
        self.assertNotIn("e_resid_tlens", runtime_state.hooks)

    def test_hooked_transformer_adapter_reads_cache_refs_from_position_axis(self):
        model = self._make_model()
        runtime_state = HookedTransformerRuntimeState(model, seed=19)
        adapter = HookedTransformerAdapter(model)
        tokens = torch.tensor([[1, 2, 3, 4]], dtype=torch.long)

        _logits, cache = runtime_state.run_with_cache(tokens, return_type="logits")
        packet = parse_observation_packet(self._runtime_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)

        ref = {
            "scope": "runtime",
            "worker": "os_0",
            "tensor": "v_cache",
            "layer": 0,
            "head": 0,
            "token": {"mode": "index", "value": 1},
        }
        selected = adapter.read_ref(ref, ctx)
        expected = cache["blocks.0.attn.hook_v"][0, 1, 0].detach()
        self.assertTrue(torch.allclose(selected, expected, atol=1e-6, rtol=1e-5))

    def test_hooked_transformer_runtime_kv_mix_uses_cache_token_positions_not_head_axis(self):
        model = self._make_model()
        runtime_state = HookedTransformerRuntimeState(model, seed=23)
        adapter = HookedTransformerAdapter(model)
        tokens = torch.tensor([[1, 2, 3, 4]], dtype=torch.long)

        _logits, cache = runtime_state.run_with_cache(tokens, return_type="logits")
        baseline_last = cache["blocks.0.attn.hook_v"][0, -1, 0].detach().clone()
        source_token = cache["blocks.0.attn.hook_v"][0, 1, 0].detach().clone()
        runtime_state.snapshot_last_cache("paired_baseline")

        packet_dict = self._runtime_packet()
        packet_dict["surface_catalog"].append(
            {
                "surface_id": "s_v_l0_h0_last",
                "target": {
                    "kind": "cache",
                    "worker": "os_0",
                    "site": "v_cache",
                    "layer": 0,
                    "head": 0,
                    "token": {"mode": "last"},
                },
                "allow_ops": ["kv_mix"],
                "caps": {
                    "max_alpha": 0.5,
                    "max_ttl_steps": 2,
                    "norm_clip": 5.0,
                    "step_size": 0.5,
                    "revertible_only": True,
                },
            }
        )
        packet = parse_observation_packet(packet_dict)
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)

        command = {
            "version": "0.1",
            "decision": "apply",
            "edits": [
                {
                    "id": "e_kv_mix_tlens",
                    "target": {"surface_id": "s_v_l0_h0_last"},
                    "source": {
                        "dtype": "cache_pair",
                        "v": {
                            "ref": {
                                "scope": "runtime",
                                "worker": "os_0",
                                "tensor": "v_cache",
                                "layer": 0,
                                "head": 0,
                                "token": {"mode": "index", "value": 1},
                            }
                        },
                    },
                    "op": {"kind": "kv_mix", "which": "v", "alpha": 0.5},
                    "budget": {"ttl_steps": 1, "norm_clip": 5.0, "step_size": 0.5, "revertible": True},
                }
            ],
        }

        permissive_policy = HarnessPolicy(global_budget=GlobalBudget(max_total_alpha=1.0, max_total_edit_cost=1.0))
        compiled = compile_command(command, packet, ctx, policy=permissive_policy)
        compiled[0].apply(ctx)
        self.assertIn("e_kv_mix_tlens", runtime_state.hooks)

        _logits2, edited_cache = runtime_state.run_with_cache(tokens, return_type="logits")
        edited_last = edited_cache["blocks.0.attn.hook_v"][0, -1, 0].detach()
        prepared_source = prepare_direction(source_token, alpha=0.5, norm_clip=5.0, step_size=0.5)
        expected = ((1.0 - 0.5) * baseline_last) + (0.5 * prepared_source)
        self.assertTrue(torch.allclose(edited_last, expected, atol=1e-5, rtol=1e-4))

        compiled[0].rollback(ctx)
        self.assertNotIn("e_kv_mix_tlens", runtime_state.hooks)

    def test_hooked_transformer_runtime_attn_rank1_overlay_applies_and_rolls_back(self):
        model = self._make_model()
        runtime_state = HookedTransformerRuntimeState(model, seed=13)
        adapter = HookedTransformerAdapter(model)
        tokens = torch.tensor([[5, 6, 7, 8]], dtype=torch.long)

        _logits, _cache = runtime_state.run_with_cache(tokens, return_type="logits")
        runtime_state.snapshot_last_cache("paired_baseline")
        packet = parse_observation_packet(self._runtime_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        permissive_policy = HarnessPolicy(deny_targets=())

        param = model.blocks[0].attn.W_O
        before = param.detach().clone()
        u = adapter.read_ref(
            {
                "scope": "runtime",
                "worker": "os_0",
                "tensor": "resid_post",
                "layer": 0,
                "token": {"mode": "last"},
            },
            ctx,
        )
        v = adapter.read_ref(
            {
                "scope": "trace",
                "trace_id": "paired_baseline",
                "worker": "os_0",
                "tensor": "resid_post",
                "layer": 0,
                "token": {"mode": "last"},
            },
            ctx,
        )

        compiled = compile_command(_attn_rank1_command(), packet, ctx, policy=permissive_policy)
        compiled[0].apply(ctx)
        self.assertIn("e_attn_rank1", runtime_state.overlays)

        expected_delta = (0.05 * torch.outer(u, v)).reshape_as(param)
        self.assertTrue(torch.allclose(param.detach(), before + expected_delta, atol=1e-5, rtol=1e-4))

        compiled[0].rollback(ctx)
        self.assertTrue(torch.allclose(param.detach(), before, atol=1e-6, rtol=1e-5))

    def test_hooked_transformer_runtime_mlp_rank1_overlay_bridges_hidden_dim_mismatch(self):
        model = self._make_model()
        runtime_state = HookedTransformerRuntimeState(model, seed=17)
        adapter = HookedTransformerAdapter(model)
        tokens = torch.tensor([[9, 10, 11, 12]], dtype=torch.long)

        _logits, _cache = runtime_state.run_with_cache(tokens, return_type="logits")
        runtime_state.snapshot_last_cache("paired_baseline")
        packet = parse_observation_packet(self._runtime_packet())
        ctx = StepContext(packet=packet, runtime_state=runtime_state, traces={}, stats={}, adapter=adapter)
        permissive_policy = HarnessPolicy(deny_targets=())

        param = model.blocks[0].mlp.W_out
        before = param.detach().clone()
        geometry = adapter._parameter_geometry(adapter.resolve_surface(packet, parse_controller_command(_mlp_rank1_command()).edits[0].target))
        raw_u = adapter.read_ref(
            {
                "scope": "runtime",
                "worker": "os_0",
                "tensor": "resid_post",
                "layer": 0,
                "token": {"mode": "last"},
            },
            ctx,
        )
        raw_v = adapter.read_ref(
            {
                "scope": "trace",
                "trace_id": "paired_baseline",
                "worker": "os_0",
                "tensor": "resid_post",
                "layer": 0,
                "token": {"mode": "last"},
            },
            ctx,
        )
        adapted_u = adapter.rank1_bridge.adapt(raw_u, side="row", geometry=geometry)
        adapted_v = adapter.rank1_bridge.adapt(raw_v, side="col", geometry=geometry)

        compiled = compile_command(_mlp_rank1_command(), packet, ctx, policy=permissive_policy)
        compiled[0].apply(ctx)
        self.assertIn("e_mlp_rank1", runtime_state.overlays)

        expected_delta = (0.05 * torch.outer(adapted_u, adapted_v)).reshape_as(param)
        self.assertTrue(torch.allclose(param.detach(), before + expected_delta, atol=1e-5, rtol=1e-4))

        compiled[0].rollback(ctx)
        self.assertTrue(torch.allclose(param.detach(), before, atol=1e-6, rtol=1e-5))


if __name__ == "__main__":
    unittest.main()
